"""Diagnostic-only arithmetic reassociation at the archived control."""
from pathlib import Path
import sys
import json
import hashlib
import argparse
import importlib.util

ROOT = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(ROOT))
OUT = Path(__file__).resolve().parent


def child():
    import torch
    from examples.weather_scenarios import fv_point_3h_current_gradient_resume as original
    from examples.weather_scenarios import fv_point_3h_seed_linear_probe as seed
    from examples.weather_scenarios import fv_point_3h_nonsmooth_coupled_probe as shared
    from advar import transport
    helper_path = OUT / "netflux_update.py"
    spec = importlib.util.spec_from_file_location("netflux_update", helper_path)
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    plan_sha = "a5f83fde4576e65c948f8e896544015f64f9c279b6640417f6523b33670214d2"
    plan = original.load_plan(original.PLAN, plan_sha)
    base = original.endpoint.load_endpoint()
    control = base["control"]
    problem, background, _, parameters, truth, _ = seed._prepare_fixed_seed()
    initial_identity = shared._input_identity(problem, background, control, parameters, truth)
    assert initial_identity == base["input_after"]
    assert shared._runtime() == base["runtime_after"]
    original_fn = transport._euler_minmod
    weights = original.geometry._face_weights(problem, axis="y", row=4, column=3)
    normal = original.geometry._face_normal(control, weights)
    records = {}
    counts = {"gradient_and_value": 0, "residual_forward": 0}
    with helper.netflux_update() as kernel_change:
        for side in (-1, 1):
            with transport.selected_face_extension("y", 4, 3, side):
                grad, value = torch.func.grad_and_value(problem.objective)(control, parameters)
                counts["gradient_and_value"] += 1
                with torch.no_grad():
                    residual = problem.observation_residual(control, parameters)
                counts["residual_forward"] += 1
            assert bool(torch.isfinite(grad).all() and torch.isfinite(value) and torch.isfinite(residual).all())
            old_grad = torch.tensor(base["repeat"]["side_gradients"][str(side)], dtype=control.dtype)
            records[str(side)] = {"gradient": grad.tolist(), "objective": float(value),
                "residual": residual.tolist(), "gradient_delta_l2": float((grad-old_grad).norm()),
                "objective_delta": float(value)-float(base["repeat"]["objective"])}
    assert transport._euler_minmod is original_fn
    minus = torch.tensor(records["-1"]["gradient"], dtype=control.dtype)
    plus = torch.tensor(records["1"]["gradient"], dtype=control.dtype)
    jump = plus-minus
    unit = normal/normal.norm()
    tangent = jump-unit*torch.dot(unit,jump)
    budget = 128*torch.finfo(control.dtype).eps*max(float(minus.norm()),float(plus.norm()),float(jump.norm()))
    minus_r = torch.tensor(records["-1"]["residual"], dtype=control.dtype)
    plus_r = torch.tensor(records["1"]["residual"], dtype=control.dtype)
    assert counts == {"gradient_and_value": 2, "residual_forward": 2}
    assert shared._input_identity(problem, background, control, parameters, truth)==initial_identity
    original.load_plan(original.PLAN, plan_sha)
    result = {"scope":"mathematically equivalent Euler reassociation; changed numerical evaluator; no candidate/P2/HVP/optimizer/futureE",
        "base_control_sha256": original.BASE_SHA, "plan_sha256":plan_sha,
        "helper_sha256":hashlib.sha256(helper_path.read_bytes()).hexdigest(),
        "kernel_change":kernel_change,
        "input_unchanged":True,"frozen_source_pins_unchanged":True,"function_restored":True,
        "calls":counts,"sides":records,"production_q":float(shared._production_face_value(problem,control,"y",4,3)),
        "tangent_jump_l2":float(tangent.norm()),"support_budget":budget,
        "support_ratio":float(tangent.norm())/budget,"side_residual_delta_l2":float((plus_r-minus_r).norm())}
    (OUT/"netflux_point_result.json").write_text(json.dumps(result,indent=2,allow_nan=False)+"\n")


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--child",action="store_true")
    args=parser.parse_args()
    if args.child:
        child()
        return
    from examples.weather_scenarios.fv_diagnostic_guard import run_guarded_diagnostic
    result=run_guarded_diagnostic([str(ROOT/".venv/bin/python"),str(Path(__file__).resolve()),"--child"],
        wall_seconds=120,rss_bytes=1024**3,report_path=OUT/"netflux_guard.json",log_path=OUT/"netflux_guard.log")
    print(json.dumps(result))
    raise SystemExit(int(result["exit_code"]!=0 or result.get("resource_termination") is not None))


if __name__=="__main__":
    main()
