"""Small two-step test of selected-face extensions at and near zero flux.

This diagnostic uses only the public finite-volume step on a 3x3 fully-known
field. The streamfunction produces a divergence-free horizontal row flow. The
center row has an exact linear-ramp minmod tie. It does not construct or run the
production objective, trajectory, HVP, optimizer, or forecast score.
"""
from __future__ import annotations

import json
from pathlib import Path
import subprocess
import sys

import torch

ROOT = Path(__file__).resolve().parents[4]
if str(ROOT / "src") not in sys.path:
    sys.path.insert(0, str(ROOT / "src"))

from advar.transport import (
    finite_volume_step, face_volume_fluxes, observe_minmod_stages,
    selected_face_extension,
)

DTYPE = torch.float64
TARGET_FACE = ("x", 1, 1)
PRODUCTION_Q = 6.938893903907228e-18
FLUXES = (0.0, PRODUCTION_Q, 1.0e-15, 1.0e-13, 1.0e-12)
INITIAL = torch.tensor(
    [[1.0, 2.0, 3.0], [1.0, 2.0, 3.0], [1.0, 2.0, 3.0]], dtype=DTYPE
)
WEIGHTS = torch.tensor(
    [[0.2, -0.7, 0.3], [-0.4, 1.1, 0.2], [0.5, -0.3, 0.8]], dtype=DTYPE
)


def _boundaries(dtype: torch.dtype) -> tuple[tuple[tuple[torch.Tensor, ...], ...], tuple[tuple[torch.Tensor, ...], ...]]:
    # The known support includes every exterior trace, including incoming flow.
    echo = tuple(torch.zeros(3, dtype=dtype) for _ in range(4))
    support = tuple(torch.ones(3, dtype=dtype) for _ in range(4))
    return (echo, echo), (support, support)


def _evaluate(q_value: float, side: int) -> dict[str, object]:
    # Controls are [nine cell echoes, selected face flow, log growth]. The
    # streamfunction row basis gives Qx[1,:] = q_value and Qy = 0, so the
    # discrete divergence vanishes exactly and the selected face Qx[1,1]
    # equals the scalar flow control.
    controls = torch.cat(
        (INITIAL.reshape(-1), torch.tensor([q_value, 0.02], dtype=DTYPE))
    ).requires_grad_()
    echo = controls[:9].reshape(3, 3)
    flow, log_growth = controls[9], controls[10]
    psi_basis = torch.zeros((4, 4), dtype=DTYPE)
    psi_basis[2, :] = 1.0
    qx, qy = face_volume_fluxes(flow * psi_basis)
    boundary_echo, boundary_support = _boundaries(DTYPE)
    state = echo
    stage_states: list[torch.Tensor] = []
    with selected_face_extension(*TARGET_FACE, side), observe_minmod_stages(
        lambda q, _qx, _qy: stage_states.append(q)
    ):
        for _ in range(2):
            state = finite_volume_step(
                state,
                torch.ones_like(state),
                qx,
                qy,
                dt_seconds=0.1,
                spacing_yx=(1.0, 1.0),
                log_growth=log_growth,
                boundary_echo=boundary_echo,
                boundary_support=boundary_support,
                reconstruction="minmod",
            ).echo
        objective = (state * WEIGHTS).sum()
        gradient = torch.autograd.grad(objective, controls)[0]
    center_slopes = []
    for stage_state in stage_states:
        left = stage_state[1, 1] - stage_state[1, 0]
        right = stage_state[1, 2] - stage_state[1, 1]
        branch = "tie" if bool(left == right) else ("left" if bool(left < right) else "right")
        center_slopes.append({"left": _scalar(left), "right": _scalar(right), "minmod_branch": branch})
    return {
        "state": state.detach(),
        "objective": objective.detach(),
        "gradient": gradient.detach(),
        "face_flux": qx.detach()[1, 1],
        "stage_states": stage_states,
        "center_slopes": center_slopes,
    }


def _scalar(value: torch.Tensor) -> float:
    return float(value.detach())


def main() -> None:
    results = []
    for q_value in FLUXES:
        minus = _evaluate(q_value, -1)
        plus = _evaluate(q_value, +1)
        jump = plus["gradient"] - minus["gradient"]
        tangent_jump = jump.clone()
        # Here dQ/dcontrols is exactly the unit vector in control slot 9.
        tangent_jump[9] = 0
        state_delta = plus["state"] - minus["state"]
        stage_state_deltas = [
            (plus_q - minus_q).tolist()
            for plus_q, minus_q in zip(plus["stage_states"], minus["stage_states"], strict=True)
        ]
        results.append(
            {
                "q_control": q_value,
                "computed_Qx_1_1": _scalar(minus["face_flux"]),
                "minus_objective": _scalar(minus["objective"]),
                "plus_objective": _scalar(plus["objective"]),
                "max_abs_state_difference": _scalar(state_delta.abs().amax()),
                "state_difference": state_delta.tolist(),
                "minmod_euler_stage_state_differences": stage_state_deltas,
                "minus_center_slopes": minus["center_slopes"],
                "plus_center_slopes": plus["center_slopes"],
                "side_gradient_difference": jump.tolist(),
                "flow_normal_component": _scalar(jump[9]),
                "tangential_jump_norm_over_echo_and_growth": _scalar(
                    torch.linalg.vector_norm(tangent_jump)
                ),
                "max_abs_tangential_component": _scalar(tangent_jump.abs().amax()),
                "growth_gradient_difference": _scalar(jump[10]),
            }
        )

    exact, production, moderate, small = results[0], results[1], results[3], results[4]
    if exact["tangential_jump_norm_over_echo_and_growth"] != 0.0:
        raise AssertionError("exact-zero common-face tangency was not recovered")
    if production["max_abs_state_difference"] != 0.0:
        raise AssertionError("production-sized flux changed a two-step primal state")
    if production["tangential_jump_norm_over_echo_and_growth"] != 0.0:
        raise AssertionError("production-sized flux created a resolved two-step tangent jump")
    if small["max_abs_state_difference"] <= 0.0:
        raise AssertionError("larger near-zero flux did not change the selected-branch state")
    if small["tangential_jump_norm_over_echo_and_growth"] <= 0.0:
        raise AssertionError("larger near-zero flux did not create a tangential extension gap")

    root = Path(__file__).resolve().parents[4]
    output = {
        "scope": "two finite_volume_step calls on a synthetic 3x3 field; no production objective, HVP, optimizer, or forecast score",
        "repository_head": subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=root, text=True
        ).strip(),
        "dtype": "float64",
        "target_face": {"axis": "x", "row": 1, "column": 1},
        "flow_construction": "psi[2,:]=p; all other vertices zero; Qx[1,:]=p, Qy=0; div(Q)=0",
        "input_echo": INITIAL.tolist(),
        "initial_center_minmod_slopes": {"left": 1.0, "right": 1.0},
        "objective_weights": WEIGHTS.tolist(),
        "steps": 2,
        "dt_seconds": 0.1,
        "log_growth_per_step_control": 0.02,
        "gradient_control_order": "echo[0,0]..echo[2,2], p, log_growth",
        "tangent_projection": "zero control slot 9 because d(Qx[1,1])/dcontrols=e_9",
        "production_reference_flux": PRODUCTION_Q,
        "comparison_to_archived_failure": {
            "archived_tangent_jump": 3.837774472618545e-13,
            "archived_support_budget": 7.975354596702747e-15,
            "archived_production_flux": PRODUCTION_Q,
            "moderate_flux_tangential_jump": moderate["tangential_jump_norm_over_echo_and_growth"],
            "larger_flux_tangential_jump": small["tangential_jump_norm_over_echo_and_growth"],
        },
        "results": results,
        "interpretation": [
            "At exact Q=0, both extensions share the same restricted objective and the measured gradient jump is exactly normal in this reproduction.",
            "At Q=6.938893903907228e-18, both selected extensions produce bit-identical two-step states and zero measured tangential jump here; this local probe does not attribute the archived 3.84e-13 residual to that flux alone.",
            "At Q=1e-12, the branch-state difference is about 1e-13 and the growth/echo tangential gradient residual is resolved, showing how an off-face extension gap can arise near the minmod tie once transport changes the represented state.",
            "The larger-Q example is a mechanism demonstration, not a quantitative explanation of the production residual; its flux exceeds the production residual flux by over five orders of magnitude, and only two steps are used.",
        ],
    }
    out = Path(__file__).resolve().parent / "selected_face_minmod_repro.json"
    out.write_text(json.dumps(output, indent=2, allow_nan=False) + "\n")
    print(out)
    print(json.dumps(
        [
            {
                "Q": row["computed_Qx_1_1"],
                "state_gap": row["max_abs_state_difference"],
                "tangent_jump": row["tangential_jump_norm_over_echo_and_growth"],
                "growth_jump": row["growth_gradient_difference"],
            }
            for row in results
        ], indent=2,
    ))


if __name__ == "__main__":
    main()
