# Team 6 GREEN: minmod net-flux arithmetic probe

## Diagnostic helper and scope

[netflux_update.py](./netflux_update.py) inspects the live `advar.transport._euler_minmod` source, requires exactly one match for its final return, then compiles a private-globals replacement that changes only

`q - dt * (outgoing / area) + dt * (incoming / area)`

to

`q + dt * ((incoming - outgoing) / area)`.

It temporarily binds only `transport._euler_minmod` in the current process and restores the original callable in `finally`. The helper reports SHA-256 identities for both inspected and compiled source. No source file is edited; the context is serial-use diagnostic machinery, not a thread-safe runtime option. It does not zero or clamp a face flux.

## Small synthetic check

The two-step probe used float64 fully-known minmod fields, a stationary divergence-free streamfunction flow, and `dt=0.1`. The nominal 4×4 field was positive with strict interior limiter choices. Its maximum actual Courant number was `0.2`, within the minmod limit `0.5`. Both evaluators returned finite, nonnegative echo; support remained exactly one. Their stage minmod branch signatures matched. Gradient L2 difference was `5.55e-17`; a deterministic directional derivative agreed exactly at the recorded precision.

The nominal mass-budget residual was `1.78e-15` for each evaluator against a mass change of `-1.826105`; the scale-aware roundoff allowance was `2.16e-12`. The observed maximum one-stage outflow fraction was `0.2426`, below the `0.75` bound.

A second case started from identically zero echo and used the smallest normal float64 boundary echo (`2.2250738585072014e-308`) on a known incoming left trace. Both evaluators kept all outputs finite and nonnegative and retained positive subnormal echo (`sum = 8.9002909838811e-310`) with maximum Courant `0.02`. The physical inflow budget matched at the recorded precision.

The helper was also exited through an intentional exception in the diagnostic process; the original callable was restored. The recorded live minmod source hash is `803e8879d11c2c2755ae7b7cb2aceca7af21af41804d718784b7afb83187a775`; the compiled regrouped kernel hash is `097b65886b60c20e52d6ba0c929e3206ea547f6ca728995c7d1d379f2a568715`.

## Positivity bound for the checked domain

For a nonnegative cell value `q` and nonnegative neighboring values, each minmod x slope satisfies `|sx| <= q`: a positive slope is bounded by the backward difference `q-q_left <= q`, and a negative slope is bounded by the forward difference `q_right-q <= q`. The same argument applies to `sy`. Thus all reconstructed face values `q ± sx/2` and `q ± sy/2` lie between `q/2` and `3q/2`.

Let `O` be the sum of outgoing positive volume rates for a cell. Each outgoing reconstructed trace is at most `3q/2`, so the Euler outflow decrement is at most `(3q/2) * dt*O/area`. The native minmod CFL gate enforces `dt*O/area <= 1/2`, giving an outflow decrement no larger than `3q/4`. Incoming traces are nonnegative, so this establishes the one-stage positivity lower bound `q_new >= q/4` in exact arithmetic for this domain. The probe checks this componentwise using the actual recorded Euler-stage states; its maximum measured ratio was `0.2426`.

## Limits

This confirms a useful local finite-precision alternative for one minmod Euler evaluator. It is mathematically the same flux update, but floating-point values and derivatives can change with regrouping. The check does not prove the alternative is uniformly safer for extreme area/flux scales: forming `incoming-outgoing` can cancel a tiny net flux, while the original divides each term separately. The subnormal inflow case verifies one retained trace; other overflow/underflow combinations remain untested.

This synthetic evidence is separate from the fixed 556a production-side-gradient diagnostic. It is not a full objective, production trajectory, HVP, optimizer, or forecast evaluation, and does not certify a root cause or authorize a source patch. Full measured outputs and equation identities are in [netflux_update_results.json](./netflux_update_results.json).
