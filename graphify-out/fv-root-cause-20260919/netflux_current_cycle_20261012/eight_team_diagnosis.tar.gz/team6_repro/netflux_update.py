"""Temporary, source-pinned minmod net-flux arithmetic diagnostic."""
from __future__ import annotations

from contextlib import contextmanager
import hashlib
import inspect
from typing import Iterator

from advar import transport

_ORIGINAL_RETURN = "return q - dt * (outgoing / area) + dt * (incoming / area)"
_NET_RETURN = "return q + dt * ((incoming - outgoing) / area)"


def _sha(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def equation_identity() -> dict[str, object]:
    """Report live kernel and the exact arithmetic rewrite without patching."""
    function = transport._euler_minmod
    source = inspect.getsource(function)
    return {
        "function": f"{function.__module__}.{function.__qualname__}",
        "original_source_sha256": _sha(source),
        "original_equation": _ORIGINAL_RETURN,
        "net_flux_equation": _NET_RETURN,
        "original_return_occurrences": source.count(_ORIGINAL_RETURN),
    }


@contextmanager
def netflux_update() -> Iterator[dict[str, object]]:
    """Temporarily regroup the last minmod Euler flux expression in-process.

    The replacement is compiled from the live inspected function into a private
    copy of its globals. Only ``transport._euler_minmod`` is rebound, and the
    original callable is restored on every exit path. Use serially in this
    diagnostic process; this context is not a thread-safe runtime option.
    """
    original = transport._euler_minmod
    source = inspect.getsource(original)
    if source.count(_ORIGINAL_RETURN) != 1:
        raise RuntimeError("live minmod return does not match the pinned equation")
    alternate = source.replace(
        "def _euler_minmod(", "def _euler_minmod_netflux(", 1
    ).replace(_ORIGINAL_RETURN, _NET_RETURN, 1)
    namespace = dict(original.__globals__)
    exec(compile(alternate, "<diagnostic-netflux-euler>", "exec"), namespace)
    replacement = namespace.get("_euler_minmod_netflux")
    if replacement is None or replacement.__globals__ is original.__globals__:
        raise RuntimeError("net-flux diagnostic did not compile in isolated globals")

    record: dict[str, object] = {
        "function": f"{original.__module__}.{original.__qualname__}",
        "original_source_sha256": _sha(source),
        "alternate_source_sha256": _sha(alternate),
        "original_equation": _ORIGINAL_RETURN,
        "alternate_equation": _NET_RETURN,
        "replacement_count": source.count(_ORIGINAL_RETURN),
        "only_final_return_regrouped": source.replace(
            _ORIGINAL_RETURN, _NET_RETURN, 1
        ) == alternate.replace("_euler_minmod_netflux(", "_euler_minmod(", 1),
        "source_file_edited": False,
    }
    transport._euler_minmod = replacement
    try:
        yield record
    finally:
        transport._euler_minmod = original
        record["restored_original_callable"] = transport._euler_minmod is original
