# Team 6 GREEN: minimal selected-face/minmod reproduction

## Setup

Ran `selected_face_minmod_repro.py` at PR297 head `c0b94f9` with `.venv/bin/python`. It uses the existing public `finite_volume_step`, `face_volume_fluxes`, `selected_face_extension`, and read-only `observe_minmod_stages` APIs. The experiment uses two SSPRK2 FV steps on a 3×3 fully-known echo field. A streamfunction `psi[2,:]=p` creates `Qx[1,:]=p`, `Qy=0`, hence exact discrete divergence zero; the selected internal face is `Qx[1,1]=p`. Every boundary support trace is one and every boundary echo trace is the known value zero. No missing/unknown data is introduced. The central row starts as `[1,2,3]`, so its left and right x differences tie exactly. Growth is a differentiable control (`log_growth=0.02` per step); no AD quantity is detached in the objective path.

The scalar diagnostic objective is a fixed weighted sum of the final 3×3 echo. We differentiate over the nine initial echoes, `p`, and log growth. Since `dQx[1,1]/dcontrols=e_p`, the common-face tangential projection sets only the flow-control component to zero.

## Results

| Face Q | Max state difference between extensions | Tangential gradient jump (echo + growth) | Growth-gradient difference |
|---:|---:|---:|---:|
| exact `0` | `0` | `0` | `0` |
| production `6.9389e-18` | `0` | `0` | `0` |
| `1e-15` | `8.88e-16` | `5.59e-16` | `0` |
| `1e-13` | `1.07e-14` | `4.94e-14` | `-2.84e-14` |
| `1e-12` | `1.04e-13` | `4.12e-13` | `-3.16e-13` |

The recorded stage trace shows the active minmod side can separate once the selected-face update changes represented state: at `Q=1e-15`, the two second Euler-stage center traces choose opposite x slopes (`left` versus `right`). At exact `Q=0` and the production-sized `6.94e-18`, all compared stage states and minmod choices are identical. At `Q=1e-12`, the selected branches separate the state by about `1e-13`, and the tangential gradient residual is the same order as the archived `3.84e-13` residual.

## Interpretation and supported remedy

This establishes a concrete mechanism: off the common face, the two signed extensions are different smooth charts. If the flux perturbation moves a state across a minmod tie, the later derivative traces can differ in echo and growth directions, even though the selected face is the only forced signed branch. At exact `Q=0`, this reproduction restores the restriction identity: both objective values agree and the gradient jump is normal.

It does **not** explain the archived production residual by itself. The production flux `6.94e-18` is over five orders smaller than the `1e-12` case that produces a comparable tangent residual here, and it causes no representable state/trace change in this two-step case. Long-horizon accumulation or other numerical/trace effects remain open; this run cannot rule them out. Therefore it does not support increasing the common-face tolerance, clipping the flux, or changing the FV source.

The discriminating regression should include: (1) an exact-zero selected face with a fixed minmod tie and assert extension values/states agree and the side-gradient jump has zero tangential component; (2) the production-sized residual flux and assert branch trace/state identity for this fixture; and (3) a representable near-zero crossing that records differing minmod choices and a nonzero off-face tangent residual, to prevent treating the selected extension as a physical rule away from the face. A production repair should first reproduce the failed pinned side gradients with actual minmod traces; if the expected common-face identity is required, the derivative evaluation must be made at the same exact face point and with identical nonselected limiter branches. No arbitrary flux threshold or derivative coercion follows from this evidence.

## Verification boundary

The single probe completed successfully and emitted `selected_face_minmod_repro.json`. This is a local float64 numerical reproduction only. No production objective, trajectory, HVP, optimizer step, full tests, or forecast score was run. Frozen source and receipt files were not edited.
