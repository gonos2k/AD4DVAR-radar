# PR297 common-face flux cancellation: GREEN evidence

This probe targets the selected face from the current PR297 source: `qy[4,3]` (`axis="y", row=4, column=3`). I first ran and discarded a sweep on the historical `qy[3,2]` face, then prepared the fixed seed once for the corrected sweep. That preliminary wrong-face run means the overall task used two seed preparations; only the corrected run below is evidence for PR297. The only post-preparation calculations in the corrected run were this face's production/direct fluxes, their scalar AD normals, and one-ULP neighbors. No objective, HVP, candidate search, forecast step, or FV integration ran. No archived control was changed or promoted.

The face formula is

`Q = dot(w, tanh(c[20:25]))`, with `w = [0, -0.08, -0.28, -0.14, -0.84]`.

The frozen production path first computes bounded coefficients, forms the vertex field with `einsum("k,kij->ij", coeff, psi_basis)`, then differences adjacent vertices. Over the reals, that is the same linear face functional. FP64 rounds the two operation orders differently. The raw formula is exactly zero at all four archived points, while production Q is at most one FP64 rounding residue:

| Archived control | SHA prefix | Formula Q | Production Q | AD normals exactly equal |
|---|---|---:|---:|---|
| 98ee base | `98ee63ab` | 0 | `-0.0` | yes |
| 96602 step 1 | `96602a6e` | 0 | `-0.0` | yes |
| 1b742 step 2 | `1b742dc3` | 0 | `-6.938893903907228e-18` | yes |
| 556a step 3 | `556a25d9` | 0 | `+6.938893903907228e-18` | yes |

At 556a, both nearest representable values on pivot `c24` make production Q exactly zero while keeping formula Q exactly zero. Each is one ULP from the archived coordinate, `±2.168404344971009e-19`; the candidate control SHA is `44968bc98e51b39090b746cfc7875d7af1f7ce3366b656828f982016c7a22560` for `nextafter(c24, -inf)` and `b3d3b838b2cde393e9cb200c904015a40dce32ae275d094c0be7f4de32d24a49` for `nextafter(c24, +inf)`. Both have formula Q `0` and production Q `-0.0`. These are arithmetic witnesses only; neither candidate replaces or edits 556a.

The sweep checked both adjacent values for each flow control, indices 20 through 24. The smallest exact-zero control change over representable FP64 controls is one ULP in `c24`, with Euclidean norm `2.168404344971009e-19`: the face depends only on flow controls 20–24, the nearest representable spacing among them is at `c24`, and both adjacent `c24` values produce exact zero. Changing the unrelated growth control cannot alter this face. `c20` moving downward also yields exact zero, with a larger change of `6.938893903907228e-18`.

The direct face expression and the production `psi`-first expression have exactly equal AD normals at all four archived points (zero infinity-norm discrepancy). Thus the measured face cancellation explains the scalar primal residue, but it does not explain the archived tangential side-gradient jump: the normal direction itself agrees exactly. A direct face-basis evaluation is the same discrete face functional in real arithmetic and preserves AD when expressed in tensors. Replacing only one entry of production `qx/qy` would break the shared streamfunction construction. Evaluating every face from basis differences remains conservative in real arithmetic by the mixed-difference identity, but its finite-precision divergence was not measured here; it would need to pass the existing scale-aware divergence contract before any production use. The least disruptive mathematical treatment is to retain the conservative production flux path and use a scale-aware roundoff bound for face-zero qualification, as the archived face audit already does. Do not infer a physical zero from raw `Q==0` alone or alter the accepted control to remove a one-ULP residual.

Source and archive closure is inherited from the after-failure verification: plan `a5f83fde…70214d2`, 196 source pins and 271 archive pins all verified; source, fixed input, and runtime were rechecked after the failed continuation. The canonical input baseline SHA is `7c38906045ba2effa8cc94562a9e2729f9823e918ec08521dd4e066910389da6`, whose parent raw SHA is `c64cde977e9a28dc28addd81d6d116aa7de6b1e005a6e1643622c9a7b28e5e37`.

The reproducible corrected sweep is `flux_probe.py`; `finalize_evidence.py` attaches neighbor vectors and the archived pin-closure receipt without rerunning seed preparation or flux evaluation. `flux_probe.json` contains full endpoint and neighbor values. `exactsource/` snapshots the operator, seed, and selected-face source files used to interpret the results; `exactsource_manifest.json` records their SHA-256 values.
