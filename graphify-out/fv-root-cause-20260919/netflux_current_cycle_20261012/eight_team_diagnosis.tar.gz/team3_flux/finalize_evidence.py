"""Complete the face probe record from its pinned baseline and ULP sweep."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

import torch

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
BASELINE = ROOT / "graphify-out/fv-root-cause-20260919/common_face_diagnosis_20261012/BASELINE.json"
VERIFICATION = ROOT / "graphify-out/fv-root-cause-20260919/GRADIENT_RESUME_VERIFICATION_20261011.json"


def tensor_sha(value: torch.Tensor) -> str:
    return hashlib.sha256(value.contiguous().numpy().tobytes()).hexdigest()


def main() -> None:
    record = json.loads((HERE / "flux_probe.json").read_text())
    baseline = json.loads(BASELINE.read_text())
    verification = json.loads(VERIFICATION.read_text())
    if record["target_face"] != {"array": "qy", "row": 4, "column": 3}:
        raise ValueError("wrong selected face in probe record")
    weights = record["face_weights"]
    limits = record["coefficient_limits"]
    record["face_basis_differences"] = [w / limit for w, limit in zip(weights, limits, strict=True)]
    record["operator_arithmetic"] = {
        "production": "bounded coeffs -> psi = einsum(coeff, psi_basis) -> qy[4,3] = -(psi[4,4] - psi[4,3])",
        "direct_face": "dot(-(psi_basis[:,4,4]-psi_basis[:,4,3])*limits, tanh(control[20:25]))",
        "ad_method": "torch.func.grad on each scalar face evaluator; controls remain differentiable",
    }
    base = torch.tensor(baseline["points"][2]["control"], dtype=torch.float64)
    exact = []
    for direction in (-torch.inf, torch.inf):
        candidate = base.clone()
        candidate[24] = torch.nextafter(candidate[24], candidate.new_tensor(direction))
        q = record["endpoint_fluxes"]["556a_step3"]
        neighbor = next(row for row in record["one_ulp_neighbors"]["neighbors"]
                        if row["control_index"] == 24
                        and row["direction"] == ("down" if direction < 0 else "up"))
        production_q = neighbor["production_q"]
        exact.append({
            "control_index": 24,
            "direction": "down" if direction < 0 else "up",
            "control_delta": (candidate[24] - base[24]).item(),
            "candidate_control": candidate.tolist(),
            "candidate_control_sha256": tensor_sha(candidate),
            "formula_q": neighbor["formula_q"],
            "production_q": production_q,
            "exact_zero": production_q == 0.0,
        })
    record["minimum_exact_zero_neighbors"] = exact
    record["source_archive_closure"] = {
        "plan_sha256": verification["plan_sha256"],
        "source_pin_count": verification["source_pins"],
        "archive_pin_count": verification["archive_pins"],
        "all_pins_verified": verification["all_pins_verified"],
        "after_failure_source_pins_verified": verification["after_failure_source_pins_verified"],
        "after_failure_input_verified": verification["after_failure_input_verified"],
        "after_failure_runtime_verified": verification["after_failure_runtime_verified"],
        "baseline_sha256": hashlib.sha256(BASELINE.read_bytes()).hexdigest(),
        "parent_raw_sha256": baseline["parent_raw_sha256"],
    }
    record["run_accounting"] = {
        "correct_face_seed_preparations": 1,
        "discarded_wrong_face_seed_preparations": 1,
        "total_seed_preparations_in_task": 2,
        "discarded_face": "qy[3,2] historical Qy32 probe; excluded from PR297 conclusions",
    }
    record.pop("seed_preparations", None)
    record.pop("prepared_original_sha256", None)
    source_rows = []
    for path in sorted((HERE / "exactsource").rglob("*")):
        if path.is_file():
            data = path.read_bytes()
            source_rows.append({
                "path": path.relative_to(HERE / "exactsource").as_posix(),
                "sha256": hashlib.sha256(data).hexdigest(),
                "bytes": len(data),
            })
    manifest = {
        "repository_head": record["repository_head"],
        "files": source_rows,
        "probe_script_sha256": hashlib.sha256((HERE / "flux_probe.py").read_bytes()).hexdigest(),
        "finalizer_script_sha256": hashlib.sha256((HERE / "finalize_evidence.py").read_bytes()).hexdigest(),
        "baseline_sha256": record["source_archive_closure"]["baseline_sha256"],
    }
    (HERE / "exactsource_manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    (HERE / "flux_probe.json").write_text(json.dumps(record, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
