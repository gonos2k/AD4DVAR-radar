"""Reproduce the 556a common-face flux cancellation with bounded operations.

The only FV preparation is the fixed seed constructor. After that this script
loads four archived controls and evaluates the named face flux, direct face
formula, AD normal, and nearby representable control values. It never evaluates
the objective, an HVP, a forecast step, or a finite-volume integration.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import sys

import torch

ROOT = Path(__file__).resolve().parents[4]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from advar import transport, variational
from examples.weather_scenarios import fv_point_3h_seed_linear_probe as seed

OUT = Path(__file__).resolve().parent
EVIDENCE = ROOT / "graphify-out/fv-root-cause-20260919"
BASELINE = EVIDENCE / "common_face_diagnosis_20261012/BASELINE.json"
PRIOR_RAW = EVIDENCE / "current_tangent_search_20261011_attempt1/step.json"
FACE = ("qy", 4, 3)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def face_weights(problem: object) -> torch.Tensor:
    spec = problem.frozen.fv_transport
    # PR297's selected face is y,row=4,column=3; qy[r,c] is the
    # negative difference between adjacent vertex streamfunction values.
    return -(spec.psi_basis[:, 4, 4] - spec.psi_basis[:, 4, 3]) * spec.coefficient_limits


def coeff(problem: object, control: torch.Tensor) -> torch.Tensor:
    spec = problem.frozen.fv_transport
    nowcast = problem.frozen.nowcast_config
    return variational.bounded_fv_coefficients(
        control[20:25], psi_basis=spec.psi_basis,
        coefficient_limits=spec.coefficient_limits,
        dt_seconds=nowcast.interval_minutes * 60.0 / spec.substeps_per_interval,
        spacing_yx=spec.spacing_yx, reconstruction=spec.reconstruction,
        max_courant=spec.max_courant,
    )


def production(problem: object, control: torch.Tensor) -> torch.Tensor:
    spec = problem.frozen.fv_transport
    psi = torch.einsum("k,kij->ij", coeff(problem, control), spec.psi_basis)
    qx, qy = transport.face_volume_fluxes(psi)
    return qy[4, 3]


def direct(control: torch.Tensor, weights: torch.Tensor) -> torch.Tensor:
    return torch.dot(weights, torch.tanh(control[20:25]))


def main() -> None:
    baseline_bytes = BASELINE.read_bytes()
    baseline = json.loads(baseline_bytes)
    prior_bytes = PRIOR_RAW.read_bytes()
    prior = json.loads(prior_bytes)
    # Single fixed-seed/problem preparation; no objective or forecast evaluation.
    problem, original, seed_control, parameters, truth, identity = seed._prepare_fixed_seed()
    weights = face_weights(problem)
    spec = problem.frozen.fv_transport
    result = {
        "scope": "face flux/normal/one-ulp only; no objective, HVP, forecast, or FV integration",
        "repository_head": __import__("subprocess").check_output(
            ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
        "seed_preparations": 1,
        "baseline_sha256": sha(baseline_bytes),
        "prior_endpoint_raw_sha256": sha(prior_bytes),
        "seed_identity": identity,
        "prepared_seed_control_sha256": identity.get("control_sha256"),
        "prepared_parameters_sha256": identity.get("parameters_sha256"),
        "target_face": {"array": FACE[0], "row": FACE[1], "column": FACE[2]},
        "face_weights": weights.tolist(),
        "face_basis_differences": (-(spec.psi_basis[:, 4, 4] - spec.psi_basis[:, 4, 3])).tolist(),
        "coefficient_limits": spec.coefficient_limits.tolist(),
        "endpoint_fluxes": {},
    }
    controls = {"98ee_base": torch.tensor(prior["current_control"], dtype=torch.float64)}
    controls.update({name: torch.tensor(point["control"], dtype=torch.float64)
                     for name, point in zip(("96602_step1", "1b742_step2", "556a_step3"),
                                            baseline["points"], strict=True)})
    expected_sha = {
        "98ee_base": "98ee63abf614756ddbdbba5cc480d66a3235a17b4def8c50b084c4f20dcdd957",
        "96602_step1": "96602a6e0fc68ad708d31601ee91229e66aaffe8d0210da7861da39c536eb73c",
        "1b742_step2": "1b742dc3c2ea69e735215fa462a22554ac41f5b33f1b96fa76dd5384fbb39168",
        "556a_step3": "556a25d910cad707b108cc8c6770af9ebf6b34f5a84196736e9fee82ed298a8b",
    }
    for name, control in controls.items():
        got = hashlib.sha256(control.contiguous().numpy().tobytes()).hexdigest()
        if got != expected_sha[name]:
            raise ValueError(f"control receipt mismatch for {name}: {got}")
    result["endpoint_control_sha256_expected"] = expected_sha
    result["receipt_closure"] = {
        "baseline_source": baseline["source"],
        "baseline_parent_raw_sha256": baseline["parent_raw_sha256"],
        "98ee_endpoint_identity_matches": prior.get("current_control_sha256") == expected_sha["98ee_base"],
    }
    oneulp: dict[str, object] = {}
    for name, control in controls.items():
        q_formula = direct(control, weights)
        q_prod = production(problem, control)
        formula_normal = torch.func.grad(lambda c: direct(c, weights))(control)
        production_normal = torch.func.grad(lambda c: production(problem, c))(control)
        result["endpoint_fluxes"][name] = {
            "control_sha256": hashlib.sha256(control.contiguous().numpy().tobytes()).hexdigest(),
            "formula_q": q_formula.item(),
            "production_q": q_prod.item(),
            "production_minus_formula": (q_prod - q_formula).item(),
            "formula_normal": formula_normal.tolist(),
            "production_normal": production_normal.tolist(),
            "normal_exactly_equal": bool(torch.equal(formula_normal, production_normal)),
            "normal_linf_difference": torch.max(torch.abs(formula_normal - production_normal)).item(),
        }
        if name != "556a_step3":
            continue
        neighbors = []
        for index in range(20, 25):
            for direction_name, direction in (("down", -torch.inf), ("up", torch.inf)):
                candidate = control.clone()
                candidate[index] = torch.nextafter(candidate[index], candidate.new_tensor(direction))
                qf = direct(candidate, weights)
                qp = production(problem, candidate)
                neighbors.append({
                    "control_index": index,
                    "direction": direction_name,
                    "control_delta": (candidate[index] - control[index]).item(),
                    "candidate_control": candidate.tolist(),
                    "candidate_control_sha256": hashlib.sha256(
                        candidate.contiguous().numpy().tobytes()).hexdigest(),
                    "formula_q": qf.item(),
                    "production_q": qp.item(),
                    "production_minus_formula": (qp - qf).item(),
                    "exact_production_zero": bool(qp == 0),
                    "formula_still_exact_zero": bool(qf == 0),
                })
        oneulp = {
            "base_control_sha256": result["endpoint_fluxes"][name]["control_sha256"],
            "neighbors": neighbors,
            "exact_zero_neighbors": [x for x in neighbors if x["exact_production_zero"]],
            "minimum_control_ulp_change": min(abs(x["control_delta"]) for x in neighbors),
        }
    result["one_ulp_neighbors"] = oneulp
    result["operator_arithmetic"] = {
        "production": "bounded coeffs -> psi = einsum(coeff, psi_basis) -> qy[4,3] = -(psi[4,4] - psi[4,3])",
        "direct_face": "dot(-(psi_basis[:,4,4]-psi_basis[:,4,3])*limits, tanh(control[20:25]))",
        "ad_method": "torch.func.grad on each scalar face evaluator; controls remain differentiable",
    }
    (OUT / "flux_probe.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
