# Team 4 GREEN: fresh-base AD and e20 sensitivity check

## Result

The original 556a control was recomputed under the receipt-matched fixed input,
runtime, and pinned source. The fresh minus and plus gradients match the
archived vectors with L-infinity error `0`; side objective values from all
four JVPs match the archived native J. Forward objective JVPs along e13/e18
agree with the corresponding reverse-gradient components for both sides:
absolute errors range from `3.57e-16` to `7.36e-16`, below the existing
scale-based budgets. The e20 HVP JVP primals match the standalone gradients
exactly, and all products are finite.

The local e20 HVP does not explain the measured one-ULP gradient changes on
the minus side. The HVP predicts an L2 gradient change of about `1.88e-15` for
either adjacent c20 control. The fresh neighbor-minus-base changes are
`3.84696e-13` down and `3.84829e-13` up, with linearization residuals near
`3.85e-13` (residual/observed ratios `1.002` and `0.998`). Their largest
observed components are tangent coordinates 18 and 13, while the HVP predicts
its largest component at coordinate 25. The plus-side observed changes are
much smaller (`1.57e-15` down, `6.90e-16` up) and are of the same order as its
`1.88e-15` local HVP predictions, though their residual ratios are `1.21` and
`1.08`.

Guard2 had already shown that both neighboring trace pairs pass, exactly
match the archived 556a signatures, and have zero selector/sign field
differences. Guard3 verifies that the fixed input and runtime match the
closed endpoint, and that the five relevant production sources match both the
resume pins and guard2 source receipts. This makes the minus-side one-ULP
gradient difference reproducible under the same recorded branch signatures.
The result establishes a mismatch between the local first-order HVP prediction
and the finite gradient change over one ULP. It does not identify the
responsible operation or prove that the mathematical objective is nonsmooth
there.

## Method and scope

The guarded diagnostic made exactly two fresh side-gradient calls at c, two
side HVP calls along e20 using `torch.func.jvp(grad)`, and four side objective
JVP calls along e13/e18. Each call has a started/completed checkpoint. The
control remains `556a25d9…ed298a8b`; formula Q is zero and production Q is
`6.938893903907228e-18`. The endpoint receipt loader, archived J/gradient
contract, fixed input identity, runtime identity, and source pins were checked
before the derivative calls, then input/runtime/source identity was checked
again afterward.

For each neighbor, the script compares its fresh guard2 side gradient with
the newly recomputed base gradient. It compares that observed difference with
`delta_c20 * H_side e20`. No trace, search, candidate, optimizer, future-E,
or forecast score ran. The one guard completed in `47.12 s`, with sampled peak
RSS `531,759,104` bytes under the `120 s` / `1 GiB` limits. Guard and child
progress receipts are `guard3.json`, `guard3.log`, and
`diagnostic3.progress.json`. The frozen source SHA-256 is
`b7d2507e82a91c07695d3bb456ce0d8b50e841fce12a3f44aa90b67bf0bdf611`.

## Disposition

The results rule out a simple explanation in which the archived minus-side
gradient differs from the live producer, and they show that the first-order
e20 HVP is far too small to account for the minus-side neighbor change. The
JVP checks support forward/reverse consistency for e13/e18 at the base point;
they do not establish parity across every direction. The source of the
one-ULP response remains unlocalized. Keep the original common-face direction
unsupported and preserve all existing tolerances pending a path-level
roundoff/branch investigation.
