"""Decompose the 556a side-gradient jump through the observation residual VJP."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parent
EVIDENCE = ROOT / "graphify-out/fv-root-cause-20260919"
BASELINE_PATH = OUT.parent / "BASELINE.json"
REPLAY_PATH = OUT / "diagnostic4.json"
FRESH_GRADIENT_PATH = OUT / "diagnostic3.json"
RESUME_PLAN_PATH = EVIDENCE / "GRADIENT_RESUME_PLAN_20261011.json"
RESUME_ARCHIVE_PATH = EVIDENCE / "GRADIENT_CONTINUATION_ARCHIVE_20261011.json"
FACE_AXIS, FACE_ROW, FACE_COLUMN = "y", 4, 3


def _tensor_sha(value) -> str:
    return hashlib.sha256(value.contiguous().cpu().numpy().tobytes()).hexdigest()


def _summary(value, normal):
    import torch
    unit = normal / torch.linalg.vector_norm(normal)
    tangent = value - unit * torch.dot(unit, value)
    norm = torch.linalg.vector_norm(value)
    tangent_norm = torch.linalg.vector_norm(tangent)
    return {
        "l2": float(norm),
        "linf": float(value.abs().max()),
        "tangential_l2": float(tangent_norm),
        "tangential_linf": float(tangent.abs().max()),
        "tangent_components_13_18_25": {str(i): float(tangent[i]) for i in (13, 18, 25)},
        "largest_tangent_components": [
            {"index": int(i), "value": float(tangent[i])}
            for i in torch.topk(tangent.abs(), k=5).indices],
        "angle_cosine_with_full_jump": None,
    }


def child() -> None:
    import torch
    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))
    from advar import transport, variational
    from examples.weather_scenarios import fv_point_3h_current_gradient_endpoint as endpoint_loader
    from examples.weather_scenarios import fv_point_3h_nonsmooth_coupled_probe as shared
    from examples.weather_scenarios import fv_point_3h_seed_linear_probe as seed

    baseline_bytes = BASELINE_PATH.read_bytes()
    baseline = json.loads(baseline_bytes)
    replay_result = json.loads(REPLAY_PATH.read_text())
    fresh = json.loads(FRESH_GRADIENT_PATH.read_text())
    plan = json.loads(RESUME_PLAN_PATH.read_text())
    archive = json.loads(RESUME_ARCHIVE_PATH.read_text())
    endpoint = endpoint_loader.load_endpoint()
    control = torch.tensor(baseline["points"][-1]["control"], dtype=torch.float64)
    if (replay_result["base_control_sha256"] != baseline["base_control_sha256"]
            or fresh["base_control_sha256"] != baseline["base_control_sha256"]
            or endpoint["raw"].get("current_control_sha256") != baseline["base_control_sha256"]
            or archive.get("raw_sha256") != baseline.get("parent_raw_sha256")
            or _tensor_sha(control) != baseline["base_control_sha256"]):
        raise ValueError("pinned 556a baseline, replay report, and endpoint do not close")

    problem, original, _seed_control, parameters, truth, seed_identity = seed._prepare_fixed_seed()
    if problem.frozen.fv_transport is None or problem.frozen.fv_transport.replay is not True:
        raise ValueError("guard5 requires the original replay-on fixed-seed problem")
    input_identity = shared._input_identity(problem, original, control, parameters, truth)
    runtime_before = shared._runtime()
    if (input_identity != endpoint["input_after"] or runtime_before != endpoint["runtime_after"]
            or replay_result.get("input_identity_matches_endpoint") is not True
            or replay_result.get("runtime_matches_endpoint") is not True):
        raise ValueError("guard5 input/runtime differs from the replay-on endpoint receipt")

    source_keys = (
        "src/advar/transport.py", "src/advar/variational.py",
        "src/advar/fv_point_research_problem.py",
        "examples/weather_scenarios/fv_point_3h_seed_linear_probe.py",
        "examples/weather_scenarios/fv_point_3h_nonsmooth_coupled_probe.py",
    )
    source_before = {}
    for key in source_keys:
        digest = hashlib.sha256((ROOT / key).read_bytes()).hexdigest()
        if (plan.get("source_files", {}).get(key) != digest
                or fresh.get("source_identity", {}).get(key, digest) != digest
                or replay_result.get("source_identity", {}).get(key, digest) != digest):
            raise ValueError(f"guard5 producer source differs from pinned input: {key}")
        source_before[key] = digest

    if not bool(problem._detected_mask.all()):
        raise ValueError("residual VJP contract requires all fixed observations detected")
    contract = problem.contract(parameters)
    delta = contract.analysis_config.pseudo_huber_delta
    phi = lambda residual: variational._pseudo_huber_cost(residual, delta).sum()
    phi_gradient = torch.func.grad(phi)
    residual_function = lambda current: problem.observation_residual(current, parameters)

    counts = {"vjp_tapes_started": 0, "vjp_tapes_completed": 0,
              "pullbacks_started": 0, "pullbacks_completed": 0,
              "residual_cotangent_grads_started": 0,
              "residual_cotangent_grads_completed": 0}
    progress_path = OUT / "diagnostic5.progress.json"

    def progress(stage: str) -> None:
        progress_path.write_text(json.dumps({"stage": stage, **counts}, indent=2) + "\n")

    target_on = replay_result["current556_replay_residual_forwards"]["on"]
    cotangent_plus = None
    residual_plus = None
    a_plus = None
    plus_trace = {}
    with transport.selected_face_extension(FACE_AXIS, FACE_ROW, FACE_COLUMN, 1):
        counts["vjp_tapes_started"] += 1
        progress("plus_vjp_tape_started")
        residual_plus, pullback_plus = torch.func.vjp(residual_function, control)
        counts["vjp_tapes_completed"] += 1
        if _tensor_sha(residual_plus) != target_on["1"]["residual_sha256"]:
            raise ValueError("plus VJP tape residual differs bytewise from guard4c forward")
        counts["residual_cotangent_grads_started"] += 1
        progress("plus_residual_cotangent_gradient_started")
        cotangent_plus = phi_gradient(residual_plus)
        if not bool(torch.isfinite(cotangent_plus).all()):
            raise ValueError("plus pseudo-Huber residual cotangent is nonfinite")
        counts["residual_cotangent_grads_completed"] += 1
        counts["pullbacks_started"] += 1
        progress("plus_pullback_started")
        a_plus = pullback_plus(cotangent_plus)[0]
        if not bool(torch.isfinite(a_plus).all()):
            raise ValueError("plus observation-residual pullback is nonfinite")
        counts["pullbacks_completed"] += 1
        plus_trace = {"residual_sha256": _tensor_sha(residual_plus),
                      "shape": list(residual_plus.shape),
                      "cotangent": cotangent_plus.tolist(),
                      "cotangent_sha256": _tensor_sha(cotangent_plus)}
        del pullback_plus
        progress("plus_pullback_completed")

    residual_minus = None
    cotangent_minus = None
    a_minus = None
    a_minus_common = None
    with transport.selected_face_extension(FACE_AXIS, FACE_ROW, FACE_COLUMN, -1):
        counts["vjp_tapes_started"] += 1
        progress("minus_vjp_tape_started")
        residual_minus, pullback_minus = torch.func.vjp(residual_function, control)
        counts["vjp_tapes_completed"] += 1
        if _tensor_sha(residual_minus) != target_on["-1"]["residual_sha256"]:
            raise ValueError("minus VJP tape residual differs bytewise from guard4c forward")
        counts["residual_cotangent_grads_started"] += 1
        progress("minus_residual_cotangent_gradient_started")
        cotangent_minus = phi_gradient(residual_minus)
        if not bool(torch.isfinite(cotangent_minus).all()):
            raise ValueError("minus pseudo-Huber residual cotangent is nonfinite")
        counts["residual_cotangent_grads_completed"] += 1

        counts["pullbacks_started"] += 1
        progress("minus_pullback_current_cotangent_started")
        a_minus = pullback_minus(cotangent_minus)[0]
        if not bool(torch.isfinite(a_minus).all()):
            raise ValueError("minus current-cotangent pullback is nonfinite")
        counts["pullbacks_completed"] += 1

        counts["pullbacks_started"] += 1
        progress("minus_pullback_plus_cotangent_started")
        a_minus_common = pullback_minus(cotangent_plus)[0]
        if not bool(torch.isfinite(a_minus_common).all()):
            raise ValueError("minus common-cotangent pullback is nonfinite")
        counts["pullbacks_completed"] += 1
        minus_trace = {"residual_sha256": _tensor_sha(residual_minus),
                       "shape": list(residual_minus.shape),
                       "cotangent": cotangent_minus.tolist(),
                       "cotangent_sha256": _tensor_sha(cotangent_minus)}
        del pullback_minus
        progress("minus_pullbacks_completed")

    cotangent_term = a_minus_common - a_minus
    jacobian_term = a_plus - a_minus_common
    decomposed_jump = cotangent_term + jacobian_term
    direct_data_jump = a_plus - a_minus
    archived_gradients = {
        side: torch.tensor(fresh["fresh_original_gradients"][str(side)], dtype=control.dtype)
        for side in (-1, 1)}
    archived_full_jump = archived_gradients[1] - archived_gradients[-1]
    normal = shared._face_normal(control, shared._face_weights(
        problem, axis=FACE_AXIS, row=FACE_ROW, column=FACE_COLUMN))
    unit_normal = normal / torch.linalg.vector_norm(normal)

    def project(value):
        return value - unit_normal * torch.dot(unit_normal, value)

    total_tangent = project(archived_full_jump)
    cotangent_tangent = project(cotangent_term)
    jacobian_tangent = project(jacobian_term)

    def alignment(left, right):
        denom = torch.linalg.vector_norm(left) * torch.linalg.vector_norm(right)
        if float(denom) == 0.0:
            return None
        return float(torch.dot(left, right) / denom)

    residual_delta = residual_plus - residual_minus
    per_group = []
    if residual_delta.ndim >= 2:
        for group in range(residual_delta.shape[0]):
            row = residual_delta[group]
            per_group.append({"group_index": group, "l2": float(row.norm()),
                              "linf": float(row.abs().max()),
                              "delta": row.tolist()})
    nonzero = residual_delta != 0
    changed_residual_indices = [
        {"index": list(index), "delta": float(residual_delta[tuple(index)])}
        for index in nonzero.nonzero().tolist()]

    source_after = {key: hashlib.sha256((ROOT / key).read_bytes()).hexdigest()
                    for key in source_keys}
    input_after = shared._input_identity(problem, original, control, parameters, truth)
    runtime_after = shared._runtime()
    if source_after != source_before or input_after != input_identity or runtime_after != runtime_before:
        raise ValueError("source, input, or runtime changed during VJP decomposition")

    result = {
        "repository_head": replay_result["repository_head"],
        "base_control_sha256": baseline["base_control_sha256"],
        "baseline_sha256": hashlib.sha256(baseline_bytes).hexdigest(),
        "input_identity_matches_endpoint": input_identity == endpoint["input_after"],
        "runtime_matches_endpoint": runtime_before == endpoint["runtime_after"],
        "source_identity": source_before,
        "source_unchanged": source_before == source_after,
        "seed_identity": seed_identity,
        "face": {"axis": FACE_AXIS, "row": FACE_ROW, "column": FACE_COLUMN,
                 "formula_q": float(shared._face_value(control, shared._face_weights(
                     problem, axis=FACE_AXIS, row=FACE_ROW, column=FACE_COLUMN))),
                 "production_q": float(shared._production_face_value(
                     problem, control, FACE_AXIS, FACE_ROW, FACE_COLUMN)),
                 "normal": normal.tolist()},
        "replay_forward_residual_match": {
            "plus": residual_plus is not None
                    and _tensor_sha(residual_plus) == target_on["1"]["residual_sha256"],
            "minus": residual_minus is not None
                    and _tensor_sha(residual_minus) == target_on["-1"]["residual_sha256"],
            "residual_plus": residual_plus.tolist(),
            "residual_minus": residual_minus.tolist(),
            "residual_delta": residual_delta.tolist(),
            "residual_delta_l2": float(residual_delta.norm()),
            "residual_delta_linf": float(residual_delta.abs().max()),
            "changed_residual_components": changed_residual_indices,
            "residual_difference_by_group": per_group,
        },
        "cotangents_and_tapes": {"plus": plus_trace, "minus": minus_trace,
            "plus_phi_l2": float(cotangent_plus.norm()),
            "minus_phi_l2": float(cotangent_minus.norm())},
        "pullback_vectors": {"A_plus": a_plus.tolist(), "A_minus": a_minus.tolist(),
            "A_minus_common": a_minus_common.tolist(),
            "cotangent_term": cotangent_term.tolist(),
            "jacobian_term": jacobian_term.tolist(),
            "decomposed_jump": decomposed_jump.tolist(),
            "direct_data_jump": direct_data_jump.tolist(),
            "archived_full_jump": archived_full_jump.tolist()},
        "decomposition_metrics": {
            "cotangent_term": _summary(cotangent_term, normal),
            "jacobian_term": _summary(jacobian_term, normal),
            "sum": _summary(decomposed_jump, normal),
            "direct_data_jump": _summary(direct_data_jump, normal),
            "archived_full_jump": _summary(archived_full_jump, normal),
            "cotangent_tangent_alignment_with_total": alignment(cotangent_tangent, total_tangent),
            "jacobian_tangent_alignment_with_total": alignment(jacobian_tangent, total_tangent),
            "reconstruction_l2": float((decomposed_jump - direct_data_jump).norm()),
            "data_vs_full_jump_l2": float((direct_data_jump - archived_full_jump).norm()),
            "data_vs_full_tangent_l2": float((project(direct_data_jump)
                                               - total_tangent).norm()),
        },
        "call_counts": {**counts, "limits": {"vjp_tapes": 2, "pullbacks": 3,
            "FV_side_gradient_calls": 0, "HVP_JVP_search_score_calls": 0}},
        "scope": "original replay-on 556a only: 2 residual VJP tapes, 3 pullbacks; no full FV gradients, HVP/JVP, candidates, optimizer, future-E, or forecast score",
    }
    (OUT / "diagnostic5.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    progress("completed")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--child", action="store_true")
    args = parser.parse_args()
    if args.child:
        child()
        return 0
    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))
    from examples.weather_scenarios.fv_diagnostic_guard import run_guarded_diagnostic
    result = run_guarded_diagnostic(
        [str(ROOT / ".venv/bin/python"), str(Path(__file__).resolve()), "--child"],
        wall_seconds=120, rss_bytes=1024**3,
        report_path=OUT / "guard5.json", log_path=OUT / "guard5.log")
    print(json.dumps(result, indent=2))
    return int(result.get("exit_code", 1) != 0
               or result.get("resource_termination") is not None
               or result.get("monitor_error") is not None)


if __name__ == "__main__":
    raise SystemExit(main())
