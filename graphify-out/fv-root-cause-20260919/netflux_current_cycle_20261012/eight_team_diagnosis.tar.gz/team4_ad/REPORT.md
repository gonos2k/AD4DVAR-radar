# Team 4 GREEN AD diagnosis: 556a common-face support

## Result

The matched one-ULP controls both pass the existing common-face support gate.
At `c20` moved down, production Q becomes exactly zero and the tangential
gradient jump is `6.10e-17`; at `c20` moved up, production Q returns to
`6.94e-18` and the tangential jump is `5.61e-17`. Both are below the unchanged
`7.98e-15` budget by factors of about 131 and 142. The archived 556a control
has the same positive production-Q residual as the up-neighbor, but its saved
tangential jump is `3.84e-13` (48.12 times the budget).

This result does not isolate production-Q cancellation as the cause. The two
fresh neighbor minus gradients differ by `1.80e-15` in L2, and the plus
gradients differ by `1.79e-15`, despite the production-Q change. Both neighbor
traces exactly match the archived 556a side signatures. Each neighbor's minus
gradient differs from the archived base by about `3.85e-13`, concentrated in
tangent state coordinates 18 and 13. The earlier current-gradient resume had
passed its recorded side-gradient match budget for the fresh base check under
the same pinned producer (`GRADIENT_RESUME_GREEN_FINAL_20261011.md`); the
failed raw did not persist those fresh vectors. Team4's later same-input/runtime
guard recomputed both base gradients and matched the archived vectors with
L-infinity error `0`, confirming the neighbor-versus-base change under the
same source and identities. Together these results show a strong one-ULP
response along the full FV AD path while the recorded branch choices and face
signs remain unchanged. They do not identify which operation causes that
response. The nonzero-Q up-neighbor shows that the saved Q residual alone is
insufficient to explain the failure. See [REPORT3.md](REPORT3.md) for the
e20-HVP comparison and forward/reverse JVP checks.

## Experiment and verification

The experiment used the receipt-pinned 556a control and fixed seed at PR297
HEAD `c0b94f9`. It compared archived side gradients at the original control
with four fresh `torch.func.grad(problem.objective)` calls at two reconstructed
controls: `c20` down (exact production Q=0) and `c20` up (production
Q=`6.938893903907228e-18`). The formula face value remained exactly zero at
both controls. The c20-down candidate hash is
`e4c085b12617a742de795ab5ed2aa6bd5cebfabc73211128c4726f9c32a9bdbe`.
Production and formula face normals agreed bitwise at the exact-Q neighbor.
The production source checks matched their frozen pins, and the receipt loader
validated the archived endpoint and traces.

Four trace-only ordinary forward calls recorded the two side traces at each
neighbor. Both controls had 360 stages per side, passed the current branch-pair
gate, matched the archived 556a signatures, and had zero differing choice or
face-sign fields. Their normalized minimum margins equal the archived values:
active limiter gap/Q-scale `4.53076e-7`, x slope/Q-scale `5.98648e-4`, y
slope/Q-scale `1.63831e-5`, and nonselected y-face flux/scale `3.25959e-3`.
This excludes a recorded selector change in these one-ULP comparisons; it does
not bound derivative conditioning or prove that every latent event is absent.

The sole replacement guard completed in `12.17 s` with sampled peak RSS
`513,458,176` bytes, below the `120 s` / `1 GiB` limits. It used four trace
forwards and four side-gradient calls. No HVP, candidate evaluation,
optimizer, objective-value recording, or score ran. The preceding guard child
failed on the `qy` versus `y` axis label before any side-gradient call; its
failure log and report are retained as `guard.log` and `guard.json`. The
replacement source is pinned by SHA-256
`529ee69013688697db7423ac2a74f19a1d6519caec15a7fe372aa8954cb298e4`.

## Limits

The first neighbor diagnostic reused archived base gradients; the follow-up
guard independently requalified both base vectors against those receipts
under matching input/runtime/source identities. Neither new control received
native-J/P2 or endpoint qualification, so these remain diagnostics and cannot
be promoted as continuation points. The equal trace signatures show no
recorded branch switch, but do not provide an error bound for 360-stage AD
accumulation. Keep the original 556a direction unsupported under the existing
gate. The e20-HVP discrepancy narrows the numerical question but does not
identify a correction.

No production source, tolerance, or frozen receipt was changed.
