"""Bounded AD check for the archived 556a common-face gradient jump.

This script launches one guarded child. The child performs two or four
production side-gradient evaluations at the exact-production-Q neighbor and
its same-coordinate one-ulp nonzero-flux counterpart. It uses the
archived 556a gradients as the original-control reference and never evaluates
an HVP, candidate, optimizer step, or score.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parent
EVIDENCE = ROOT / "graphify-out/fv-root-cause-20260919"
BASELINE = OUT.parent / "BASELINE.json"
FLUX = OUT.parent / "team3_flux/flux_probe.json"
SOURCE_MANIFEST = OUT.parent / "team3_flux/exactsource_manifest.json"
RESUME_PLAN = EVIDENCE / "GRADIENT_RESUME_PLAN_20261011.json"
RESUME_ARCHIVE = EVIDENCE / "GRADIENT_CONTINUATION_ARCHIVE_20261011.json"
ENDPOINT_LOADER = ROOT / "examples/weather_scenarios/fv_point_3h_current_gradient_endpoint.py"
FACE_AXIS = "y"
FACE_ARRAY = "qy"
FACE_ROW = 4
FACE_COLUMN = 3
FACE = (FACE_ARRAY, FACE_ROW, FACE_COLUMN)
MAX_CALLS = 4


def _sha_control(control) -> str:
    return hashlib.sha256(control.contiguous().numpy().tobytes()).hexdigest()


def _support(gradient_minus, gradient_plus, normal):
    import torch

    jump = gradient_plus - gradient_minus
    unit_normal = normal / torch.linalg.vector_norm(normal)
    tangent = jump - unit_normal * torch.dot(unit_normal, jump)
    eps = torch.finfo(jump.dtype).eps
    budget = 128 * eps * max(float(gradient_minus.norm()),
                             float(gradient_plus.norm()), float(jump.norm()))
    return {
        "jump_l2": float(jump.norm()),
        "tangential_jump_l2": float(tangent.norm()),
        "support_budget": budget,
        "tangential_to_budget": float(tangent.norm()) / budget,
        "tangential_jump": tangent.tolist(),
    }


def _field_difference_count(left, right) -> int:
    if isinstance(left, dict) and isinstance(right, dict):
        return sum(_field_difference_count(left.get(key), right.get(key))
                   for key in set(left) | set(right))
    if isinstance(left, list) and isinstance(right, list):
        common = min(len(left), len(right))
        return (sum(_field_difference_count(left[i], right[i]) for i in range(common))
                + abs(len(left) - len(right)))
    return int(left != right)


def child() -> None:
    import torch

    ROOT_STR = str(ROOT)
    if ROOT_STR not in sys.path:
        sys.path.insert(0, ROOT_STR)
    from advar import transport, variational
    from examples.weather_scenarios import fv_point_3h_candidate_requalification as requal
    from examples.weather_scenarios import fv_point_3h_face_transition_diagnostic as geometry
    from examples.weather_scenarios import fv_point_3h_nonsmooth_coupled_probe as shared
    from examples.weather_scenarios import fv_point_3h_seed_linear_probe as seed
    import importlib.util

    # Reject a bad selected-face context before the fixed-seed preparation.
    with transport.selected_face_extension(FACE_AXIS, FACE_ROW, FACE_COLUMN, -1):
        pass

    baseline_bytes = BASELINE.read_bytes()
    flux_bytes = FLUX.read_bytes()
    baseline = json.loads(baseline_bytes)
    flux = json.loads(flux_bytes)
    source_manifest = json.loads(SOURCE_MANIFEST.read_text())
    resume_plan = json.loads(RESUME_PLAN.read_text())
    resume_archive = json.loads(RESUME_ARCHIVE.read_text())
    if (hashlib.sha256(baseline_bytes).hexdigest() != flux.get("baseline_sha256")
            or flux.get("repository_head") != "c0b94f9bd922f94e1cd2a6ce6d22c706aa547223"
            or flux.get("target_face") != {"array": FACE_ARRAY, "row": FACE_ROW,
                                            "column": FACE_COLUMN}
            or flux.get("receipt_closure", {}).get("98ee_endpoint_identity_matches") is not True
            or flux.get("receipt_closure", {}).get("baseline_parent_raw_sha256")
                != baseline.get("parent_raw_sha256")
            or resume_archive.get("raw_sha256") != baseline.get("parent_raw_sha256")
            or source_manifest.get("repository_head") != flux.get("repository_head")):
        raise ValueError("team3 flux evidence does not close to the pinned 556a baseline")
    team3_dir = FLUX.parent
    if (source_manifest.get("probe_script_sha256")
            != hashlib.sha256((team3_dir / "flux_probe.py").read_bytes()).hexdigest()
            or source_manifest.get("finalizer_script_sha256")
            != hashlib.sha256((team3_dir / "finalize_evidence.py").read_bytes()).hexdigest()):
        raise ValueError("team3 flux source manifest does not match its probe/finalizer")
    if (len(resume_plan.get("source_files", {})) != 196
            or len(resume_plan.get("archive_files", {})) != 271):
        raise ValueError("resume plan source/archive pin inventory is incomplete")
    source_keys = (
        "src/advar/transport.py", "src/advar/variational.py",
        "examples/weather_scenarios/fv_point_3h_seed_linear_probe.py",
        "examples/weather_scenarios/fv_point_3h_nonsmooth_coupled_probe.py",
        "examples/weather_scenarios/fv_point_3h_face_transition_diagnostic.py",
        "examples/weather_scenarios/fv_point_3h_candidate_requalification.py",
        "examples/weather_scenarios/fv_point_3h_current_gradient_endpoint.py",
    )
    source_checks = {}
    for key in source_keys:
        path = ROOT / key
        expected = resume_plan["source_files"].get(key)
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if expected != actual:
            raise ValueError(f"production source differs from frozen resume pin: {key}")
        source_checks[key] = actual
    manifest_source_checks = {}
    for entry in source_manifest.get("files", []):
        key = entry["path"]
        actual = hashlib.sha256((ROOT / key).read_bytes()).hexdigest()
        if actual != entry["sha256"]:
            raise ValueError(f"team3 exact-source manifest differs from current source: {key}")
        manifest_source_checks[key] = actual
    expected_base_sha = baseline["base_control_sha256"]
    if (flux.get("endpoint_control_sha256_expected", {}).get("556a_step3") != expected_base_sha
            or resume_archive.get("raw_sha256") != baseline.get("parent_raw_sha256")):
        raise ValueError("current 556a control or parent raw is not pinned consistently")
    base = baseline["points"][-1]
    base_control = torch.tensor(base["control"], dtype=torch.float64)
    if _sha_control(base_control) != baseline["base_control_sha256"]:
        raise ValueError("archived 556a control hash does not match baseline receipt")

    exact = flux["one_ulp_neighbors"]["exact_zero_neighbors"]
    if not exact:
        raise ValueError("team3 flux probe supplied no exact-production-zero neighbor")
    neighbors = flux["one_ulp_neighbors"]["neighbors"]

    # Use a matched same-coordinate pair: c20-down is exact Q=0 and c20-up
    # has the adjacent production residual while formula Q remains zero.
    exact = next((row for row in exact if int(row["control_index"]) == 20
                  and row["direction"] == "down"), None)
    if exact is None:
        raise ValueError("team3 receipt lacks the selected c20-down exact-Q neighbor")
    neighbor = base_control.clone()
    index = int(exact["control_index"])
    direction = -torch.inf if exact["direction"] == "down" else torch.inf
    neighbor[index] = torch.nextafter(neighbor[index], neighbor.new_tensor(direction))
    expected_exact_hashes = {
        (20, "down"): "e4c085b12617a742de795ab5ed2aa6bd5cebfabc73211128c4726f9c32a9bdbe",
    }
    expected_neighbor_hash = expected_exact_hashes.get((index, exact["direction"]))
    if expected_neighbor_hash is None or _sha_control(neighbor) != expected_neighbor_hash:
        raise ValueError("reconstructed exact-Q nextafter control hash differs from team3 receipt")

    nonzero_row = next((row for row in neighbors
                        if int(row["control_index"]) == index
                        and row["direction"] == "up"
                        and not row["exact_production_zero"]), None)
    if nonzero_row is None:
        raise ValueError("team3 receipt lacks the matched c20-up nonzero-Q neighbor")
    controls = [("exact_production_zero", neighbor)]
    nonzero = base_control.clone()
    nonzero_index = int(nonzero_row["control_index"])
    nonzero_direction = -torch.inf if nonzero_row["direction"] == "down" else torch.inf
    nonzero[nonzero_index] = torch.nextafter(
        nonzero[nonzero_index], nonzero.new_tensor(nonzero_direction))
    controls.append(("matched_one_ulp_nonzero_neighbor", nonzero))

    endpoint_spec = importlib.util.spec_from_file_location("team4_endpoint_loader", ENDPOINT_LOADER)
    if endpoint_spec is None or endpoint_spec.loader is None:
        raise ValueError("could not load the pinned endpoint receipt reader")
    endpoint_module = importlib.util.module_from_spec(endpoint_spec)
    endpoint_spec.loader.exec_module(endpoint_module)
    archived_endpoint = endpoint_module.load_endpoint()
    archived_steps = archived_endpoint["raw"]["closed_steps"]
    archived_trace = archived_steps[-1]["final_repeat"]["branch_trace"]
    if archived_endpoint["raw"].get("current_control_sha256") != expected_base_sha:
        raise ValueError("archived branch traces do not terminate at the pinned 556a control")

    problem, _original, _seed_control, parameters, _truth, seed_identity = seed._prepare_fixed_seed()
    spec = problem.frozen.fv_transport
    face_row, face_column = FACE[1], FACE[2]
    weights = geometry._face_weights(problem, axis="y", row=face_row, column=face_column)
    if not torch.equal(weights, torch.tensor(flux["face_weights"], dtype=weights.dtype)):
        raise ValueError("team3 face weights do not match the selected production face")

    def production_q(control):
        nowcast = problem.frozen.nowcast_config
        coeff = variational.bounded_fv_coefficients(
            control[20:25], psi_basis=spec.psi_basis,
            coefficient_limits=spec.coefficient_limits,
            dt_seconds=nowcast.interval_minutes * 60.0 / spec.substeps_per_interval,
            spacing_yx=spec.spacing_yx, reconstruction=spec.reconstruction,
            max_courant=spec.max_courant)
        psi = torch.einsum("k,kij->ij", coeff, spec.psi_basis)
        _qx, qy = transport.face_volume_fluxes(psi)
        return qy[face_row, face_column]

    def formula_q(control):
        return torch.dot(weights, torch.tanh(control[20:25]))

    def production_normal(control):
        return torch.func.grad(production_q)(control)

    # Re-establish flux / normal parity at the control actually used for AD.
    qbase, qbase_formula = production_q(base_control), formula_q(base_control)
    qneighbor, qneighbor_formula = production_q(neighbor), formula_q(neighbor)
    normal = production_normal(neighbor)
    formula_normal = torch.func.grad(formula_q)(neighbor)
    normal_linf = float((normal - formula_normal).abs().max())
    saved_face = baseline["production_face"]
    base_normal = production_normal(base_control)
    if (float(qbase) != saved_face["production_q"]
            or float(qbase_formula) != saved_face["formula_q"]
            or _sha_control(base_control) != saved_face["control_sha256"]
            or not torch.equal(base_normal, torch.tensor(
                saved_face["production_normal"], dtype=base_control.dtype))):
        raise ValueError("original production Q/normal does not exactly match archived baseline")
    if (float(qneighbor) != 0.0 or float(qneighbor_formula) != 0.0
            or float(qneighbor) != exact["production_q"]
            or float(qneighbor_formula) != exact["formula_q"]
            or float(neighbor[index] - base_control[index]) != exact["control_delta"]):
        raise ValueError("selected one-ulp neighbor is not exact production/formula Q=0")
    if normal_linf != 0.0:
        raise ValueError("selected production and formula normals are not bitwise equal")
    nonzero_control = controls[1][1]
    nonzero_q = production_q(nonzero_control)
    nonzero_formula_q = formula_q(nonzero_control)
    if (float(nonzero_q) == 0.0 or float(nonzero_q) != nonzero_row["production_q"]
            or float(nonzero_formula_q) != nonzero_row["formula_q"]
            or float(nonzero_control[index] - base_control[index]) != nonzero_row["control_delta"]):
        raise ValueError("nearest nonzero neighbor unexpectedly has exact production Q=0")
    archived_minus = torch.tensor(base["side_gradients"]["-1"], dtype=base_control.dtype)
    archived_plus = torch.tensor(base["side_gradients"]["1"], dtype=base_control.dtype)
    archived_support = _support(archived_minus, archived_plus,
                                torch.tensor(baseline["production_face"]["production_normal"],
                                             dtype=base_control.dtype))
    saved_support = baseline["common_face"]
    if (not math.isclose(archived_support["tangential_jump_l2"],
                         saved_support["tangent_jump_norm"], rel_tol=1e-12, abs_tol=0.0)
            or not math.isclose(archived_support["support_budget"],
                                saved_support["support_budget"], rel_tol=1e-12, abs_tol=0.0)):
        raise ValueError("recomputed archived 556a support norm/budget differs from its receipt")

    # The archived gradients are the original-c reference; only neighboring
    # controls consume fresh side-gradient evaluations.
    evaluations = 0
    outputs = {}
    for label, control in controls:
        traces = {side: shared._analysis_trace(
                    problem, control, parameters, side,
                    target={"axis": FACE_AXIS, "row": FACE_ROW, "column": FACE_COLUMN})
                  for side in (-1, 1)}
        trace_pair = requal.current_branch_pair_gate(
            traces[-1], traces[1], dtype=control.dtype, stages=360)
        trace_comparison = {
            str(side): {
                "signature_sha256": traces[side]["signature_sha256"],
                "matches_archived_556a_signature": traces[side]["signature_sha256"]
                    == archived_trace[str(side)]["signature_sha256"],
                "stage_count": traces[side]["stage_count"],
                "observed_stage_count": traces[side]["observed_stage_count"],
                "nonfinite_or_tie": traces[side]["nonfinite_or_tie"],
                "minimum_margins": traces[side]["minimum_margins"],
                "choice_field_differences_vs_archived_556a": _field_difference_count(
                    traces[side]["choices"], archived_trace[str(side)]["choices"]),
                "face_sign_field_differences_vs_archived_556a": _field_difference_count(
                    traces[side]["face_signs"], archived_trace[str(side)]["face_signs"]),
            } for side in (-1, 1)}
        trace_comparison["branch_pair_gate"] = trace_pair

        side_gradients = {}
        for side in (-1, 1):
            if evaluations >= MAX_CALLS:
                raise RuntimeError("side-gradient evaluation cap exceeded")
            gradient_fn = torch.func.grad(problem.objective, argnums=0)
            with transport.selected_face_extension(FACE_AXIS, FACE_ROW, FACE_COLUMN, side):
                gradient = gradient_fn(control, parameters)
            if not bool(torch.isfinite(gradient).all()):
                raise ValueError(f"non-finite side-{side} gradient at {label}")
            side_gradients[str(side)] = gradient
            evaluations += 1
        q = production_q(control)
        n = production_normal(control)
        outputs[label] = {
            "control_sha256": _sha_control(control),
            "control_delta_l2_from_556a": float((control - base_control).norm()),
            "formula_q": float(formula_q(control)),
            "production_q": float(q),
            "production_normal": n.tolist(),
            "normal_parity_linf": float((n - torch.func.grad(formula_q)(control)).abs().max()),
            "branch_trace_comparison": trace_comparison,
            "side_gradients": {key: value.tolist() for key, value in side_gradients.items()},
            "support": _support(side_gradients["-1"], side_gradients["1"], n),
            "side_gradient_delta_from_archived_556a": {
                sign: float((side_gradients[sign] - torch.tensor(
                    base["side_gradients"][sign], dtype=control.dtype)).norm())
                for sign in ("-1", "1")},
        }

    result = {
        "repository_head": flux.get("repository_head"),
        "base_control_sha256": baseline["base_control_sha256"],
        "team3_flux_probe_sha256": hashlib.sha256(FLUX.read_bytes()).hexdigest(),
        "team3_source_manifest_sha256": hashlib.sha256(SOURCE_MANIFEST.read_bytes()).hexdigest(),
        "baseline_sha256": hashlib.sha256(baseline_bytes).hexdigest(),
        "pinned_parent_raw_sha256": resume_archive["raw_sha256"],
        "source_pin_checks": source_checks,
        "team3_exact_source_checks": manifest_source_checks,
        "source_archive_pin_counts": {"source": len(resume_plan["source_files"]),
                                       "archive": len(resume_plan["archive_files"])},
        "scope": "fixed seed; receipt-validated original gradients/traces plus two neighboring controls; four trace-only ordinary FV forward calls and at most four side-gradient calls; no objective values, HVP/search/optimizer/score",
        "seed_identity": seed_identity,
        "archived_endpoint_receipts": archived_endpoint["receipt_files"],
        "target_face": {"array": FACE_ARRAY, "axis": FACE_AXIS,
                        "row": FACE_ROW, "column": FACE_COLUMN},
        "selected_exact_neighbor": exact,
        "selected_exact_neighbor_control_sha256": _sha_control(neighbor),
        "matched_nonzero_neighbor": nonzero_row,
        "matched_nonzero_neighbor_control_sha256": _sha_control(nonzero_control),
        "base_flux": {"formula_q": float(qbase_formula), "production_q": float(qbase)},
        "selected_neighbor_flux": {"formula_q": float(qneighbor_formula),
                                    "production_q": float(qneighbor)},
        "matched_nonzero_neighbor_production_q": float(nonzero_q),
        "neighbor_normal_parity_linf": normal_linf,
        "archived_556a_support": archived_support,
        "evaluations": {"trace_only_ordinary_forward_calls": sum(
                            sum(1 for _side in (-1, 1)) for _label, _control in controls),
                        "side_gradient_calls": evaluations,
                        "per_control": 2, "maximum": MAX_CALLS},
        "controls": outputs,
    }
    destination = OUT / "diagnostic2.json"
    destination.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--child", action="store_true")
    args = parser.parse_args()
    if args.child:
        child()
        return 0

    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))
    from examples.weather_scenarios.fv_diagnostic_guard import run_guarded_diagnostic

    python = ROOT / ".venv/bin/python"
    result = run_guarded_diagnostic(
        [str(python), str(Path(__file__).resolve()), "--child"],
        wall_seconds=120, rss_bytes=1024**3,
        report_path=OUT / "guard2.json", log_path=OUT / "guard2.log")
    print(json.dumps(result, indent=2))
    return int(result.get("exit_code", 1) != 0 or result.get("rss_limit_exceeded", False)
               or result.get("wall_timeout", False))


if __name__ == "__main__":
    raise SystemExit(main())
