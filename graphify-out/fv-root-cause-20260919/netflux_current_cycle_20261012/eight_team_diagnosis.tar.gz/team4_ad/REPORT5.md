# Team 4 GREEN: observation-residual VJP decomposition at 556a

## Result

At the replay-on 556a point, the minus/plus observation residuals differ in
only two entries of group 1, the 600-second observations: `+2.470246e-15` and
`−1.618150e-14`. Their difference has L2 norm `1.636897e-14`. The face value
is formula Q=`0` and production Q=`6.938893903907228e-18`.

The exact chain-rule split is

```text
Δg = J₊ᵀ φ'(r₊) − J₋ᵀ φ'(r₋)
   = [J₋ᵀφ'(r₊) − J₋ᵀφ'(r₋)]   +   [J₊ᵀφ'(r₊) − J₋ᵀφ'(r₊)]
       cotangent term                    residual-Jacobian term
```

Here `φ` is the same pseudo-Huber residual cost used by the objective. The
cotangent term has L2 norm `3.850948e-13` and tangential norm `3.842704e-13`;
its tangential component aligns with the archived total jump at cosine
`0.9999989`. The residual-Jacobian term has L2 norm `0.280608`, but tangential
norm only `7.547229e-16`. The sum reconstructs the direct data-gradient jump
exactly at stored precision; that data jump differs from the fresh archived
full objective jump by L2 `2.469537e-18` and L-infinity `1.734724e-18`.

In tangent coordinates, the cotangent term is `1.001285×` the archived jump,
the Jacobian term is about `0.001967×`, and their signed dot product is
`−1.897599e-28`. Their projected sum differs from the archived tangent jump
by L2 `4.339338e-18` and L-infinity `2.700674e-18`, on a `3.837774e-13`
jump. The pseudo-Huber cotangent difference has L2 `1.635794e-14`, so the
measured projected amplification `||b||/||Δφ||` is `23.4914` at this point.

This VJP split shows that the measured side residual difference contributes
essentially all of the tangential jump through the common minus-side residual
Jacobian. The side residual delta lies in the exact loss coordinates consumed
by the objective, including its quality/standard-deviation scaling and
whitening. This quantifies that contribution at this point; it does not
establish why those residual entries differ or localize that difference to a
particular floating-point operation. The attribution depends on the chosen
telescoping order: a reverse split through the plus-side Jacobian would
require a fourth pullback and could assign different sizes to the cotangent
and Jacobian terms. This run uses the requested minus-side common-Jacobian
split and does not claim that the dominant term is order-invariant.

## Checks and scope

The two residual VJP tapes reproduce the replay-on guard4c residuals byte for
byte. The fixed input, runtime, and pinned source hashes match the 556a
endpoint. The decomposition used exactly two VJP tapes and three pullbacks,
with two additional small residual-space pseudo-Huber cotangent gradients. It
ran in `7.65 s` at sampled peak RSS `522,256,384` bytes. No full FV objective
gradient, HVP/JVP, candidate, optimizer, future-E, or score call ran. The
frozen source SHA-256 is
`96fee03342ff59c1f73da144097abb72d17e4a5391f17fde9d48b1338f5a5367`.

The prior guard4c replay comparison found that plus/minus state-q hashes first
diverge at stage 142, while qx/qy flow-flux hashes, minmod choices, and face
sign records stay identical across all 360 stages. This is consistent with
the selected-face state update carrying the small side difference into the
later observation residual. The VJP split starts from the two measured
residuals; it localizes the jump to the observation-residual gradient pathway,
not to the earliest transport operation that generated those residuals.

Guard4 and guard4b were setup failures only: the first child lacked the repo
root on `sys.path`; the second rejected four identical NaN metadata scalars
because Python equality treats NaN as unequal. The corrected wrapper used
bytewise float checks and completed the diagnostic. These wrapper issues are
separate from the production gradient defect. No source, tolerance, endpoint,
or P2 receipt was changed.
