"""Fresh-base AD sensitivity check for the receipt-pinned 556a control.

Runs one guarded child with two fresh side gradients, two side HVPs along e20,
and four objective JVPs along e13/e18. It makes no trace, search, optimizer,
future-E, or score call.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parent
EVIDENCE = ROOT / "graphify-out/fv-root-cause-20260919"
BASELINE_PATH = OUT.parent / "BASELINE.json"
PRIOR_DIAGNOSTIC_PATH = OUT / "diagnostic2.json"
FLUX_PATH = OUT.parent / "team3_flux/flux_probe.json"
PRIOR_RAW_PATH = EVIDENCE / "current_gradient_resume_20261011_attempt1/step.json"
RESUME_PLAN_PATH = EVIDENCE / "GRADIENT_RESUME_PLAN_20261011.json"
RESUME_ARCHIVE_PATH = EVIDENCE / "GRADIENT_CONTINUATION_ARCHIVE_20261011.json"
MAX_GRADIENTS = 2
MAX_HVPS = 2
MAX_JVPS = 4


def _sha_control(control) -> str:
    return hashlib.sha256(control.contiguous().numpy().tobytes()).hexdigest()


def child() -> None:
    import torch

    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))
    from advar import transport
    from examples.weather_scenarios import fv_point_3h_current_gradient_endpoint as endpoint_loader
    from examples.weather_scenarios import fv_point_3h_nonsmooth_coupled_probe as shared
    from examples.weather_scenarios import fv_point_3h_seed_linear_probe as seed

    baseline_bytes = BASELINE_PATH.read_bytes()
    baseline = json.loads(baseline_bytes)
    prior = json.loads(PRIOR_DIAGNOSTIC_PATH.read_text())
    flux = json.loads(FLUX_PATH.read_text())
    resume_plan = json.loads(RESUME_PLAN_PATH.read_text())
    resume_archive = json.loads(RESUME_ARCHIVE_PATH.read_text())
    prior_raw = json.loads(PRIOR_RAW_PATH.read_text())
    endpoint = endpoint_loader.load_endpoint()
    control = torch.tensor(baseline["points"][-1]["control"], dtype=torch.float64)
    if (_sha_control(control) != baseline["base_control_sha256"]
            or prior.get("base_control_sha256") != baseline["base_control_sha256"]
            or resume_archive.get("raw_sha256") != baseline["parent_raw_sha256"]
            or prior_raw.get("current_control_sha256") != baseline["base_control_sha256"]):
        raise ValueError("current 556a control / archived P2 raw closure is inconsistent")

    source_keys = (
        "src/advar/transport.py", "src/advar/variational.py",
        "examples/weather_scenarios/fv_point_3h_seed_linear_probe.py",
        "examples/weather_scenarios/fv_point_3h_nonsmooth_coupled_probe.py",
        "examples/weather_scenarios/fv_point_3h_face_transition_diagnostic.py",
    )
    source_before = {}
    for key in source_keys:
        actual = hashlib.sha256((ROOT / key).read_bytes()).hexdigest()
        if resume_plan["source_files"].get(key) != actual:
            raise ValueError(f"production source changed from its frozen pin: {key}")
        if prior.get("source_pin_checks", {}).get(key) != actual:
            raise ValueError(f"source identity differs from the completed neighbor diagnosis: {key}")
        source_before[key] = actual

    problem, original, _seed_control, parameters, truth, seed_identity = seed._prepare_fixed_seed()
    input_before = shared._input_identity(problem, original, control, parameters, truth)
    runtime_before = shared._runtime()
    input_matches_endpoint = input_before == endpoint["input_after"]
    runtime_matches_endpoint = runtime_before == endpoint["runtime_after"]
    if not input_matches_endpoint or not runtime_matches_endpoint:
        preflight = {
            "repository_head": prior["repository_head"],
            "base_control_sha256": _sha_control(control),
            "status": "preflight_identity_mismatch",
            "fixed_input_matches_endpoint": input_matches_endpoint,
            "runtime_matches_endpoint": runtime_matches_endpoint,
            "fixed_input_current": input_before,
            "fixed_input_endpoint": endpoint["input_after"],
            "runtime_current": runtime_before,
            "runtime_endpoint": endpoint["runtime_after"],
            "seed_identity": seed_identity,
            "call_counts": {"side_gradients": 0, "hvps": 0, "objective_jvps": 0},
            "scope": "preflight only; no derivative evaluations performed",
        }
        (OUT / "diagnostic3.json").write_text(json.dumps(preflight, indent=2) + "\n")
        (OUT / "diagnostic3.progress.json").write_text(
            json.dumps({"stage": "preflight_identity_mismatch", **preflight["call_counts"]},
                       indent=2) + "\n")
        return
    if input_before != prior_raw.get("input_before") or runtime_before != prior_raw.get("runtime_before"):
        raise ValueError("fixed seed/runtime differ from the earlier 556a gradient requalification")

    weights = shared._face_weights(problem, axis="y", row=4, column=3)
    formula_q = shared._face_value(control, weights)
    production_q = shared._production_face_value(problem, control, "y", 4, 3)
    normal = shared._face_normal(control, weights)
    expected_face = baseline["production_face"]
    if (float(formula_q) != expected_face["formula_q"]
            or float(production_q) != expected_face["production_q"]
            or not torch.equal(normal, torch.tensor(expected_face["production_normal"],
                                                   dtype=control.dtype))):
        raise ValueError("fresh original face value/normal differs from the pinned diagnostic")

    neighbor_specs = {
        "down": ("exact_production_zero", "down"),
        "up": ("matched_one_ulp_nonzero_neighbor", "up"),
    }
    validated_neighbors = {}
    for label, (prior_key, direction_name) in neighbor_specs.items():
        info = prior["controls"][prior_key]
        control_neighbor = control.clone()
        direction = -torch.inf if direction_name == "down" else torch.inf
        control_neighbor[20] = torch.nextafter(
            control_neighbor[20], control_neighbor.new_tensor(direction))
        flux_row = next(row for row in flux["one_ulp_neighbors"]["neighbors"]
                        if int(row["control_index"]) == 20
                        and row["direction"] == direction_name)
        trace = info["branch_trace_comparison"]
        if (_sha_control(control_neighbor) != info["control_sha256"]
                or float(control_neighbor[20] - control[20]) != flux_row["control_delta"]
                or info["formula_q"] != flux_row["formula_q"]
                or info["production_q"] != flux_row["production_q"]
                or trace["branch_pair_gate"].get("passed") is not True
                or not trace["-1"].get("matches_archived_556a_signature")
                or not trace["1"].get("matches_archived_556a_signature")):
            raise ValueError(f"prior {label} neighbor lacks matching c20/Q/trace evidence")
        validated_neighbors[label] = {"control": control_neighbor, "diagnostic": info,
                                      "delta_c20": float(control_neighbor[20] - control[20])}

    counts = {"side_gradients_started": 0, "side_gradients_completed": 0,
              "hvps_started": 0, "hvps_completed": 0,
              "objective_jvps_started": 0, "objective_jvps_completed": 0}
    progress_path = OUT / "diagnostic3.progress.json"

    def progress(stage: str) -> None:
        progress_path.write_text(json.dumps({"stage": stage, **counts}, indent=2) + "\n")

    gradients: dict[int, torch.Tensor] = {}
    gradient_fn = torch.func.grad(problem.objective, argnums=0)
    for side in (-1, 1):
        if counts["side_gradients_started"] >= MAX_GRADIENTS:
            raise RuntimeError("side-gradient call cap exceeded")
        counts["side_gradients_started"] += 1
        progress(f"side_gradient_{side}_started")
        with transport.selected_face_extension("y", 4, 3, side):
            gradient = gradient_fn(control, parameters)
        if not bool(torch.isfinite(gradient).all()):
            raise ValueError(f"fresh side-{side} gradient is nonfinite")
        gradients[side] = gradient
        counts["side_gradients_completed"] += 1
        progress(f"side_gradient_{side}_completed")

    expected_gradients = {
        side: torch.tensor(baseline["points"][-1]["side_gradients"][str(side)],
                           dtype=control.dtype)
        for side in (-1, 1)}
    gradient_match = shared._gradient_pair_match(gradients, expected_gradients)

    direction_e20 = torch.zeros_like(control)
    direction_e20[20] = 1.0
    hvps: dict[int, torch.Tensor] = {}
    hvp_primal_errors = {}
    for side in (-1, 1):
        if counts["hvps_started"] >= MAX_HVPS:
            raise RuntimeError("HVP call cap exceeded")
        counts["hvps_started"] += 1
        progress(f"hvp_e20_side_{side}_started")
        with transport.selected_face_extension("y", 4, 3, side):
            primal, product = torch.func.jvp(
                lambda value: gradient_fn(value, parameters),
                (control,), (direction_e20,))
        if not bool(torch.isfinite(primal).all() & torch.isfinite(product).all()):
            raise ValueError(f"side-{side} e20 HVP is nonfinite")
        scale = max(float(primal.abs().max()), float(gradients[side].abs().max()),
                    torch.finfo(control.dtype).tiny)
        primal_error = float((primal - gradients[side]).abs().max())
        hvp_primal_errors[str(side)] = {
            "linf": primal_error,
            "budget": 128 * torch.finfo(control.dtype).eps * scale,
            "passed": primal_error <= 128 * torch.finfo(control.dtype).eps * scale,
        }
        hvps[side] = product
        counts["hvps_completed"] += 1
        progress(f"hvp_e20_side_{side}_completed")

    objective_jvps = {}
    jvp_indices = (13, 18)
    for side in (-1, 1):
        for index in jvp_indices:
            if counts["objective_jvps_started"] >= MAX_JVPS:
                raise RuntimeError("objective-JVP call cap exceeded")
            direction = torch.zeros_like(control)
            direction[index] = 1.0
            counts["objective_jvps_started"] += 1
            progress(f"objective_jvp_side_{side}_e{index}_started")
            with transport.selected_face_extension("y", 4, 3, side):
                value, derivative = torch.func.jvp(
                    lambda current: problem.objective(current, parameters),
                    (control,), (direction,))
            if not bool(torch.isfinite(value) & torch.isfinite(derivative)):
                raise ValueError(f"side-{side} e{index} objective JVP is nonfinite")
            reverse = gradients[side][index]
            scale = max(abs(float(derivative)), abs(float(reverse)),
                        float(gradients[side].norm()), torch.finfo(control.dtype).tiny)
            error = abs(float(derivative - reverse))
            budget = 128 * torch.finfo(control.dtype).eps * scale
            objective_jvps[f"{side}:{index}"] = {
                "objective_value": float(value),
                "archived_objective": baseline["points"][-1]["objective"],
                "objective_matches_archive": abs(float(value)
                    - baseline["points"][-1]["objective"])
                    <= 128 * torch.finfo(control.dtype).eps
                    * max(abs(float(value)), abs(baseline["points"][-1]["objective"])),
                "directional_derivative": float(derivative),
                "reverse_gradient_component": float(reverse),
                "absolute_error": error,
                "roundoff_scale_budget": budget,
                "parity_passed": error <= budget,
            }
            counts["objective_jvps_completed"] += 1
            progress(f"objective_jvp_side_{side}_e{index}_completed")

    local_predictions = {}
    for name, validated in validated_neighbors.items():
        delta = validated["delta_c20"]
        local_predictions[name] = {}
        for side in (-1, 1):
            base_gradient = gradients[side]
            neighbor_gradient = torch.tensor(validated["diagnostic"]["side_gradients"][str(side)],
                                             dtype=control.dtype)
            observed = neighbor_gradient - base_gradient
            predicted = delta * hvps[side]
            residual = observed - predicted
            scale = max(float(observed.norm()), float(predicted.norm()),
                        torch.finfo(control.dtype).tiny)
            local_predictions[name][str(side)] = {
                "control_delta_c20": delta,
                "observed_gradient_delta_l2": float(observed.norm()),
                "predicted_hvp_delta_l2": float(predicted.norm()),
                "linearization_residual_l2": float(residual.norm()),
                "residual_over_observed_scale": float(residual.norm()) / scale,
                "largest_observed_component_index": int(torch.argmax(observed.abs())),
                "largest_observed_component": float(observed[torch.argmax(observed.abs())]),
                "largest_predicted_component_index": int(torch.argmax(predicted.abs())),
            }

    input_after = shared._input_identity(problem, original, control, parameters, truth)
    runtime_after = shared._runtime()
    source_after = {key: hashlib.sha256((ROOT / key).read_bytes()).hexdigest()
                    for key in source_keys}
    if input_after != input_before or runtime_after != runtime_before or source_after != source_before:
        raise ValueError("fixed input, runtime, or pinned source changed during the AD diagnostic")

    result = {
        "repository_head": prior["repository_head"],
        "base_control_sha256": _sha_control(control),
        "fixed_input_identity": input_before,
        "runtime_identity": runtime_before,
        "source_identity": source_before,
        "source_unchanged": source_before == source_after,
        "input_unchanged": input_before == input_after,
        "runtime_unchanged": runtime_before == runtime_after,
        "seed_identity": seed_identity,
        "face": {"axis": "y", "row": 4, "column": 3,
                 "formula_q": float(formula_q), "production_q": float(production_q),
                 "normal": normal.tolist()},
        "archived_j_gradient_contract": {
            "native_j_reference": baseline["points"][-1]["objective"],
            "side_gradient_match": gradient_match,
            "fresh_side_gradient_linf_error": {
                str(side): float((gradients[side] - expected_gradients[side]).abs().max())
                for side in (-1, 1)},
            "objective_jvps": objective_jvps,
            "all_objective_jvps_match_archived_j": all(
                item["objective_matches_archive"] for item in objective_jvps.values()),
            "all_forward_reverse_jvp_checks_passed": all(
                item["parity_passed"] for item in objective_jvps.values()),
        },
        "archived_endpoint_receipts": endpoint["receipt_files"],
        "input_matches_endpoint": input_before == endpoint["input_after"],
        "runtime_matches_endpoint": runtime_before == endpoint["runtime_after"],
        "validated_neighbor_deltas": {name: value["delta_c20"]
                                       for name, value in validated_neighbors.items()},
        "hvp_e20": {str(side): hvps[side].tolist() for side in (-1, 1)},
        "hvp_primal_gradient_parity": hvp_primal_errors,
        "neighbor_linearization": local_predictions,
        "fresh_original_gradients": {str(side): gradients[side].tolist() for side in (-1, 1)},
        "call_counts": {**counts, "limits": {"side_gradients": MAX_GRADIENTS,
            "hvps": MAX_HVPS, "objective_jvps": MAX_JVPS}},
        "scope": "original 556a only: 2 side gradients, 2 side HVPs along e20, 4 side objective JVPs along e13/e18; no trace, candidate, optimizer, future-E, forecast score",
    }
    (OUT / "diagnostic3.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    progress("completed")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--child", action="store_true")
    args = parser.parse_args()
    if args.child:
        child()
        return 0
    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))
    from examples.weather_scenarios.fv_diagnostic_guard import run_guarded_diagnostic

    result = run_guarded_diagnostic(
        [str(ROOT / ".venv/bin/python"), str(Path(__file__).resolve()), "--child"],
        wall_seconds=120, rss_bytes=1024**3,
        report_path=OUT / "guard3.json", log_path=OUT / "guard3.log")
    print(json.dumps(result, indent=2))
    return int(result.get("exit_code", 1) != 0 or result.get("resource_termination") is not None
               or result.get("monitor_error") is not None)


if __name__ == "__main__":
    raise SystemExit(main())
