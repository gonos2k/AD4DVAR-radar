"""Compare FV checkpoint replay on/off at the three archived controls."""
from __future__ import annotations

import argparse
from dataclasses import fields, is_dataclass, replace
import hashlib
import json
from pathlib import Path
import sys
from typing import Any

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parent
EVIDENCE = ROOT / "graphify-out/fv-root-cause-20260919"
BASELINE_PATH = OUT.parent / "BASELINE.json"
RESUME_PLAN_PATH = EVIDENCE / "GRADIENT_RESUME_PLAN_20261011.json"
RESUME_ARCHIVE_PATH = EVIDENCE / "GRADIENT_CONTINUATION_ARCHIVE_20261011.json"
TRACE_ARCHIVE_PATH = OUT.parent / "team5_trace/trace_diagnosis.json"
MAX_GRADIENT_CALLS = 8
MAX_RESIDUAL_FORWARDS = 4
FACE_AXIS, FACE_ROW, FACE_COLUMN = "y", 4, 3


def _tensor_sha(value) -> str:
    return hashlib.sha256(value.contiguous().cpu().numpy().tobytes()).hexdigest()


def _same_bytes(left: Any, right: Any) -> bool:
    import torch
    if left is None or right is None:
        return left is right
    if isinstance(left, torch.Tensor) or isinstance(right, torch.Tensor):
        return (isinstance(left, torch.Tensor) and isinstance(right, torch.Tensor)
                and left.dtype == right.dtype and left.shape == right.shape
                and _tensor_sha(left) == _tensor_sha(right))
    if is_dataclass(left) or is_dataclass(right):
        if not (is_dataclass(left) and is_dataclass(right)
                and type(left) is type(right)):
            return False
        return all(_same_bytes(getattr(left, field.name), getattr(right, field.name))
                   for field in fields(left))
    if isinstance(left, (tuple, list)) or isinstance(right, (tuple, list)):
        return (type(left) is type(right) and len(left) == len(right)
                and all(_same_bytes(a, b) for a, b in zip(left, right)))
    if isinstance(left, dict) or isinstance(right, dict):
        return (isinstance(left, dict) and isinstance(right, dict)
                and left.keys() == right.keys()
                and all(_same_bytes(left[key], right[key]) for key in left))
    return left == right


def _same_except(left: Any, right: Any, excluded: set[str]) -> bool:
    return (is_dataclass(left) and is_dataclass(right) and type(left) is type(right)
            and all(field.name in excluded or _same_bytes(
                getattr(left, field.name), getattr(right, field.name))
                for field in fields(left)))


def _stage_choice_record(q, qx, qy, *, target: dict[str, Any]) -> dict[str, Any]:
    import torch
    q_scale = q.abs().max()
    tolerance = 128 * torch.finfo(q.dtype).eps * q_scale
    pairs = ((q[1:-1, 1:-1] - q[1:-1, :-2], q[1:-1, 2:] - q[1:-1, 1:-1]),
             (q[1:-1, 1:-1] - q[:-2, 1:-1], q[2:, 1:-1] - q[1:-1, 1:-1]))
    choices = []
    for left, right in pairs:
        active = (((left > tolerance) & (right > tolerance))
                  | ((left < -tolerance) & (right < -tolerance)))
        positive = (left > tolerance) & (right > tolerance)
        negative = (left < -tolerance) & (right < -tolerance)
        choices.append({
            "choose_left": (active & torch.where(positive, left < right, left > right)).tolist(),
            "slope_sign": torch.where(positive, 1, torch.where(negative, -1, 0)).tolist(),
            "left_sign": torch.sign(left).to(torch.int8).tolist(),
            "right_sign": torch.sign(right).to(torch.int8).tolist(),
        })
    from examples.weather_scenarios import fv_point_3h_nonsmooth_coupled_probe as shared
    return {
        "choices": choices,
        "face_signs": {
            "x": shared._face_sign_copy(qx, "x", target),
            "y": shared._face_sign_copy(qy, "y", target),
        },
        "target_flux": float((qx if target["axis"] == "x" else qy)[target["row"], target["column"]]),
    }


def _residual_forward(problem: Any, control, parameters, side: int,
                      transport: Any) -> dict[str, Any]:
    import torch
    from examples.weather_scenarios import fv_point_3h_nonsmooth_coupled_probe as shared

    target = {"axis": FACE_AXIS, "row": FACE_ROW, "column": FACE_COLUMN}
    stages = []

    def observe(q, qx, qy):
        branch = _stage_choice_record(q, qx, qy, target=target)
        stages.append({
            "q_sha256": _tensor_sha(q), "qx_sha256": _tensor_sha(qx),
            "qy_sha256": _tensor_sha(qy), **branch,
            "q_shape": list(q.shape), "qx_shape": list(qx.shape), "qy_shape": list(qy.shape),
            "q_min": float(q.min()), "q_max": float(q.max()),
            "qx_min": float(qx.min()), "qx_max": float(qx.max()),
            "qy_min": float(qy.min()), "qy_max": float(qy.max()),
        })

    with transport.selected_face_extension(FACE_AXIS, FACE_ROW, FACE_COLUMN, side):
        with torch.no_grad(), transport.observe_minmod_stages(observe):
            residual = problem.observation_residual(control, parameters)
    choices = [stage["choices"] for stage in stages]
    face_signs = [stage["face_signs"] for stage in stages]
    return {
        "stage_count": len(stages),
        "residual": residual.tolist(),
        "residual_sha256": _tensor_sha(residual),
        "residual_finite": bool(torch.isfinite(residual).all()),
        "stage_q_qx_qy_and_branch_evidence": stages,
        "choice_signature_sha256": shared._canonical_sha({
            "choices": choices, "face_signs": face_signs}),
        "target_flux_max_abs": max((abs(stage["target_flux"]) for stage in stages), default=0.0),
    }


def child() -> None:
    import torch
    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))
    from advar import transport
    from examples.weather_scenarios import fv_point_3h_current_gradient_endpoint as endpoint_loader
    from examples.weather_scenarios import fv_point_3h_nonsmooth_coupled_probe as shared
    from examples.weather_scenarios import fv_point_3h_seed_linear_probe as seed

    baseline_bytes = BASELINE_PATH.read_bytes()
    baseline = json.loads(baseline_bytes)
    prior = json.loads((OUT / "diagnostic3.json").read_text())
    resume_plan = json.loads(RESUME_PLAN_PATH.read_text())
    resume_archive = json.loads(RESUME_ARCHIVE_PATH.read_text())
    endpoint = endpoint_loader.load_endpoint()
    archived_trace_summary = json.loads(TRACE_ARCHIVE_PATH.read_text())
    if (prior.get("status", "completed") != "completed"
            or prior.get("base_control_sha256") != baseline["base_control_sha256"]
            or resume_archive.get("raw_sha256") != baseline.get("parent_raw_sha256")
            or endpoint["raw"].get("current_control_sha256") != baseline["base_control_sha256"]):
        raise ValueError("guard3, endpoint, and archived baseline do not close at 556a")
    if (archived_trace_summary.get("current_control_sha256") != baseline["base_control_sha256"]
            or archived_trace_summary.get("raw_child_sha256") != baseline.get("parent_raw_sha256")
            or archived_trace_summary.get("endpoint_receipts") != endpoint["receipt_files"]):
        raise ValueError("trace summary does not match the receipt-loaded endpoint")

    source_keys = (
        "src/advar/transport.py", "src/advar/variational.py",
        "src/advar/fv_point_research_problem.py",
        "examples/weather_scenarios/fv_point_3h_seed_linear_probe.py",
        "examples/weather_scenarios/fv_point_3h_nonsmooth_coupled_probe.py",
    )
    source_before = {}
    for key in source_keys:
        digest = hashlib.sha256((ROOT / key).read_bytes()).hexdigest()
        expected = resume_plan["source_files"].get(key)
        if expected != digest or prior.get("source_identity", {}).get(key, digest) != digest:
            raise ValueError(f"replay comparison source does not match frozen evidence: {key}")
        source_before[key] = digest

    problem_on, original, _seed_control, parameters, truth, seed_identity = seed._prepare_fixed_seed()
    controls = [torch.tensor(point["control"], dtype=torch.float64)
                for point in baseline["points"]]
    if len(controls) != 3 or _tensor_sha(controls[-1]) != baseline["base_control_sha256"]:
        raise ValueError("expected three pinned 966/1b/556 controls")
    closed_steps = endpoint["raw"]["closed_steps"]
    for index, control in enumerate(controls):
        step = closed_steps[index]
        trace_endpoint = archived_trace_summary["endpoints"][index]
        if (_tensor_sha(control) != step["proposal"]["control_sha256"]
                or _tensor_sha(control) != trace_endpoint["control_sha256"]):
            raise ValueError(f"baseline control {index} differs from the closed endpoint")
        for side in (-1, 1):
            archived_gradient = torch.tensor(
                step["final_repeat"]["side_gradients"][str(side)], dtype=control.dtype)
            baseline_gradient = torch.tensor(
                baseline["points"][index]["side_gradients"][str(side)], dtype=control.dtype)
            saved_signature = step["final_repeat"]["branch_trace"][str(side)]["signature_sha256"]
            summary_signature = trace_endpoint["per_side"][str(side)]["signature_sha256"]
            if (not torch.equal(archived_gradient, baseline_gradient)
                    or saved_signature != summary_signature):
                raise ValueError(f"baseline point {index} gradient/trace differs from endpoint receipt")
    input_identity = shared._input_identity(problem_on, original, controls[-1], parameters, truth)
    runtime_before = shared._runtime()
    if (input_identity != endpoint["input_after"]
            or runtime_before != endpoint["runtime_after"]
            or input_identity != prior["fixed_input_identity"]
            or runtime_before != prior["runtime_identity"]):
        raise ValueError("fixed input or runtime differs from the exact 556a endpoint receipt")

    fv_on = problem_on.frozen.fv_transport
    if fv_on is None or fv_on.replay is not True:
        raise ValueError("current problem did not construct the expected replay-on FV transport")
    fv_off = replace(fv_on, replay=False)
    frozen_off = replace(problem_on.frozen, fv_transport=fv_off)
    problem_off = replace(problem_on, frozen=frozen_off)
    contract_on = problem_on.contract(parameters)
    contract_off = problem_off.contract(parameters)
    if (contract_on.fv_transport is None or contract_off.fv_transport is None
            or contract_on.fv_transport.replay is not True
            or contract_off.fv_transport.replay is not False
            or not _same_except(fv_on, fv_off, {"replay"})
            or not _same_except(contract_on, contract_off, {"fv_transport"})
            or not _same_except(problem_on.frozen, frozen_off, {"fv_transport"})
            or not _same_except(problem_on, problem_off, {"frozen"})):
        raise ValueError("replay toggle changed fields besides the replay flag")
    if not bool(problem_on._detected_mask.all()):
        raise ValueError("observation_residual is unavailable for masked observations")

    on_whitener = problem_on.frozen.observation_whitener
    off_whitener = problem_off.frozen.observation_whitener
    whitener_fields_equal = {
        field.name: _same_bytes(getattr(on_whitener, field.name),
                                getattr(off_whitener, field.name))
        for field in fields(on_whitener)}
    point_whitener_equal = {
        "correlation_whitener": _same_bytes(problem_on._correlation_whitener,
                                            problem_off._correlation_whitener),
        "masked_whiteners": _same_bytes(problem_on._masked_whiteners,
                                         problem_off._masked_whiteners),
    }
    if not all(whitener_fields_equal.values()) or not all(point_whitener_equal.values()):
        raise ValueError("observation whitener changed when FV replay was disabled")

    source_before_replay = dict(source_before)
    counts = {"replay_off_gradients_started": 0, "replay_off_gradients_completed": 0,
              "replay_on_current_gradients_started": 0,
              "replay_on_current_gradients_completed": 0,
              "residual_forwards_started": 0, "residual_forwards_completed": 0}
    progress_path = OUT / "diagnostic4.progress.json"

    def progress(stage: str) -> None:
        progress_path.write_text(json.dumps({"stage": stage, **counts}, indent=2) + "\n")

    gradients: dict[str, dict[str, Any]] = {"off": {}, "on_current": {}}
    values: dict[str, dict[str, Any]] = {"off": {}, "on_current": {}}

    for point_index, control in enumerate(controls):
        point_name = ("96602", "1b742", "556a")[point_index]
        gradient_and_value = torch.func.grad_and_value(problem_off.objective, argnums=0)
        for side in (-1, 1):
            if (counts["replay_off_gradients_started"] >= 6
                    or counts["replay_off_gradients_started"]
                    + counts["replay_on_current_gradients_started"] >= MAX_GRADIENT_CALLS):
                raise RuntimeError("replay-off gradient call cap exceeded")
            counts["replay_off_gradients_started"] += 1
            progress(f"replay_off_{point_name}_side_{side}_started")
            with transport.selected_face_extension(FACE_AXIS, FACE_ROW, FACE_COLUMN, side):
                gradient, value = gradient_and_value(control, parameters)
            if not bool(torch.isfinite(gradient).all() & torch.isfinite(value)):
                raise ValueError(f"replay-off {point_name} side-{side} returned nonfinite data")
            key = f"{point_name}:{side}"
            gradients["off"][key] = gradient
            values["off"][key] = value
            counts["replay_off_gradients_completed"] += 1
            progress(f"replay_off_{point_name}_side_{side}_completed")

    current = controls[-1]
    gradient_and_value_on = torch.func.grad_and_value(problem_on.objective, argnums=0)
    for side in (-1, 1):
        if (counts["replay_on_current_gradients_started"] >= 2
                or counts["replay_off_gradients_started"]
                + counts["replay_on_current_gradients_started"] >= MAX_GRADIENT_CALLS):
            raise RuntimeError("replay-on gradient call cap exceeded")
        counts["replay_on_current_gradients_started"] += 1
        progress(f"replay_on_556a_side_{side}_started")
        with transport.selected_face_extension(FACE_AXIS, FACE_ROW, FACE_COLUMN, side):
            gradient, value = gradient_and_value_on(current, parameters)
        if not bool(torch.isfinite(gradient).all() & torch.isfinite(value)):
            raise ValueError(f"replay-on 556a side-{side} returned nonfinite data")
        gradients["on_current"][f"556a:{side}"] = gradient
        values["on_current"][f"556a:{side}"] = value
        counts["replay_on_current_gradients_completed"] += 1
        progress(f"replay_on_556a_side_{side}_completed")

    residual_records = {"on": {}, "off": {}}
    for mode, model in (("on", problem_on), ("off", problem_off)):
        for side in (-1, 1):
            if counts["residual_forwards_started"] >= MAX_RESIDUAL_FORWARDS:
                raise RuntimeError("observation-residual forward call cap exceeded")
            counts["residual_forwards_started"] += 1
            progress(f"residual_{mode}_side_{side}_started")
            residual_records[mode][str(side)] = _residual_forward(
                model, current, parameters, side, transport)
            counts["residual_forwards_completed"] += 1
            progress(f"residual_{mode}_side_{side}_completed")

    weights = shared._face_weights(problem_on, axis=FACE_AXIS,
                                   row=FACE_ROW, column=FACE_COLUMN)
    gradient_summaries = {}
    archived_match = {}
    for mode, point_side_gradients in gradients.items():
        points = [("96602", controls[0]), ("1b742", controls[1]), ("556a", current)]
        if mode == "on_current":
            points = [("556a", current)]
        for point_name, control in points:
            gm = point_side_gradients[f"{point_name}:-1"]
            gp = point_side_gradients[f"{point_name}:1"]
            jump = gp - gm
            normal = shared._face_normal(control, weights)
            unit_normal = normal / torch.linalg.vector_norm(normal)
            tangent_jump = jump - unit_normal * torch.dot(unit_normal, jump)
            scale = max(float(gm.norm()), float(gp.norm()), float(jump.norm()),
                        torch.finfo(control.dtype).tiny)
            support_budget = 128 * torch.finfo(control.dtype).eps * scale
            label = f"{mode}:{point_name}"
            gradient_summaries[label] = {
                "minus_l2": float(gm.norm()), "plus_l2": float(gp.norm()),
                "jump_l2": float(jump.norm()),
                "tangential_jump_l2": float(tangent_jump.norm()),
                "support_budget": support_budget,
                "tangential_to_budget": float(tangent_jump.norm()) / support_budget,
                "tangent_jump_indices_13_18_25": {
                    str(index): float(tangent_jump[index]) for index in (13, 18, 25)},
            }
            archived = {side: torch.tensor(
                baseline["points"][{"96602": 0, "1b742": 1, "556a": 2}[point_name]]
                ["side_gradients"][str(side)], dtype=control.dtype) for side in (-1, 1)}
            archived_match[label] = {
                "pass": shared._gradient_pair_match({-1: gm, 1: gp}, archived),
                "minus_linf": float((gm - archived[-1]).abs().max()),
                "plus_linf": float((gp - archived[1]).abs().max()),
            }

    residual_comparison = {}
    for side in (-1, 1):
        on_record, off_record = residual_records["on"][str(side)], residual_records["off"][str(side)]
        on_stages = on_record["stage_q_qx_qy_and_branch_evidence"]
        off_stages = off_record["stage_q_qx_qy_and_branch_evidence"]
        q_equal = [a["q_sha256"] == b["q_sha256"] for a, b in zip(on_stages, off_stages)]
        qx_equal = [a["qx_sha256"] == b["qx_sha256"] for a, b in zip(on_stages, off_stages)]
        qy_equal = [a["qy_sha256"] == b["qy_sha256"] for a, b in zip(on_stages, off_stages)]
        choices_equal = [a["choices"] == b["choices"] for a, b in zip(on_stages, off_stages)]
        signs_equal = [a["face_signs"] == b["face_signs"] for a, b in zip(on_stages, off_stages)]
        residual_comparison[str(side)] = {
            "residual_byte_equal": on_record["residual_sha256"] == off_record["residual_sha256"],
            "stage_count_on": on_record["stage_count"],
            "stage_count_off": off_record["stage_count"],
            "q_arrays_byte_equal_by_stage": q_equal,
            "qx_arrays_byte_equal_by_stage": qx_equal,
            "qy_arrays_byte_equal_by_stage": qy_equal,
            "choice_records_equal_by_stage": choices_equal,
            "face_sign_records_equal_by_stage": signs_equal,
            "choice_signature_equal": on_record["choice_signature_sha256"]
                                      == off_record["choice_signature_sha256"],
            "choice_signature_matches_archived_556a": on_record["choice_signature_sha256"]
                == archived_trace_summary["endpoints"][-1]["per_side"][str(side)]["signature_sha256"],
            "target_flux_max_abs_on": on_record["target_flux_max_abs"],
            "target_flux_max_abs_off": off_record["target_flux_max_abs"],
            "q_array_changed_stage_count": sum(not equal for equal in q_equal),
            "qx_array_changed_stage_count": sum(not equal for equal in qx_equal),
            "qy_array_changed_stage_count": sum(not equal for equal in qy_equal),
            "branch_choice_changed_stage_count": sum(not equal for equal in choices_equal),
            "face_sign_changed_stage_count": sum(not equal for equal in signs_equal),
        }

    objective_value_deltas = {
        mode: {key: float(value) - float(baseline["points"][
                    {"96602": 0, "1b742": 1, "556a": 2}[key.split(":")[0]]]["objective"])
               for key, value in row.items()}
        for mode, row in values.items()}
    current_objective_value_delta_on_minus_off = {
        str(side): float(values["on_current"][f"556a:{side}"]
                          - values["off"][f"556a:{side}"])
        for side in (-1, 1)}

    source_after = {key: hashlib.sha256((ROOT / key).read_bytes()).hexdigest()
                    for key in source_keys}
    input_after = shared._input_identity(problem_on, original, current, parameters, truth)
    runtime_after = shared._runtime()
    if source_after != source_before_replay or input_after != input_identity or runtime_after != runtime_before:
        raise ValueError("source, fixed input, or runtime changed during replay comparison")

    result = {
        "repository_head": prior["repository_head"],
        "base_control_sha256": baseline["base_control_sha256"],
        "baseline_sha256": hashlib.sha256(baseline_bytes).hexdigest(),
        "endpoint_receipts": endpoint["receipt_files"],
        "source_identity": source_before,
        "source_unchanged": source_after == source_before_replay,
        "input_identity_matches_endpoint": input_identity == endpoint["input_after"],
        "runtime_matches_endpoint": runtime_before == endpoint["runtime_after"],
        "input_unchanged": input_after == input_identity,
        "runtime_unchanged": runtime_after == runtime_before,
        "seed_identity": seed_identity,
        "replay_toggle": {"on": fv_on.replay, "off": fv_off.replay,
            "only_replay_field_changed_in_fv_spec": _same_except(fv_on, fv_off, {"replay"}),
            "frozen_fields_equal_except_fv_transport": _same_except(
                problem_on.frozen, frozen_off, {"fv_transport"}),
            "problem_fields_equal_except_frozen": _same_except(problem_on, problem_off, {"frozen"}),
            "observation_whitener_fields_byte_equal": whitener_fields_equal,
            "point_whitener_fields_byte_equal": point_whitener_equal},
        "call_counts": {**counts, "limits": {"gradient_and_value": MAX_GRADIENT_CALLS,
            "ordinary_residual_forwards": MAX_RESIDUAL_FORWARDS}},
        "gradient_summaries": gradient_summaries,
        "archived_gradient_matches": archived_match,
        "side_objective_values": {
            mode: {key: float(value) for key, value in row.items()}
            for mode, row in values.items()},
        "side_objective_value_deltas_vs_archived": objective_value_deltas,
        "current556_replay_on_minus_off_objective_delta": current_objective_value_delta_on_minus_off,
        "current556_replay_on_vs_off_gradient_linf": {
            str(side): float((gradients["on_current"][f"556a:{side}"]
                              - gradients["off"][f"556a:{side}"]).abs().max())
            for side in (-1, 1)},
        "current556_replay_residual_forwards": residual_records,
        "current556_replay_residual_comparison": residual_comparison,
        "scope": "replay on/off comparison only: 8 grad_and_value calls + 4 no-grad observation_residual forwards; no HVP/JVP/search/score",
    }
    (OUT / "diagnostic4.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    progress("completed")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--child", action="store_true")
    args = parser.parse_args()
    if args.child:
        child()
        return 0
    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))
    from examples.weather_scenarios.fv_diagnostic_guard import run_guarded_diagnostic

    resource = run_guarded_diagnostic(
        [str(ROOT / ".venv/bin/python"), str(Path(__file__).resolve()), "--child"],
        wall_seconds=120, rss_bytes=1024**3,
        report_path=OUT / "guard4b.json", log_path=OUT / "guard4b.log")
    print(json.dumps(resource, indent=2))
    return int(resource.get("exit_code", 1) != 0
               or resource.get("resource_termination") is not None
               or resource.get("monitor_error") is not None)


if __name__ == "__main__":
    raise SystemExit(main())
