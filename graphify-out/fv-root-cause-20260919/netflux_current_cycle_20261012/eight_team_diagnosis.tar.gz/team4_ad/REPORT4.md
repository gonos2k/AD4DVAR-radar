# Team 4 RED/GREEN audit: FV checkpoint replay comparison

## Guard and identity

The corrected replay diagnostic completed with child exit code 0 in `13.85 s`
and sampled peak RSS `595,558,400` bytes, below the `120 s` / `1 GiB` caps.
All calls completed: six replay-off `grad_and_value` calls (both sides at
96602, 1b742, and 556a), two replay-on calls (both sides at 556a), and four
no-grad `observation_residual` forwards (on/off × both sides). No HVP, JVP,
search, optimizer, score, or future-E call ran. Guard receipts are
`guard4c.json` and `guard4c.log`; the diagnostic is `diagnostic4.json`.

The replay-on run's fixed input, runtime, source hashes, control sequence, and
endpoint receipts match the archived baseline. The replay-off clone uses the
same physical inputs with only the replay flag changed in its contract. The
frozen-field clone differs only in
`FVAnalysisTransport.replay`. The on/off contracts and problems match outside
that field, and the frozen observation whitener plus point-observation
whitener caches are byte-identical. The corrected wrapper source SHA-256 is
`cd7ac17fc2256ca039cd62d6eabc1c65cfc38036173c0a805ee9089d76daf1bb`.

## Replay result

At the current 556a control, replay on and off produce byte-identical
observation residuals for each side. Across all 360 analysis stages per side,
the q, qx, and qy array hashes match at every stage; minmod choice records and
face-sign records also match at every stage. Both branch signatures match the
archived 556a trace. The selected-flow maximum is `6.938893903907228e-18` in
both modes.

The current side objective values are identical by mode:

| Side | Replay on/off objective | Archived J | Difference |
|---|---:|---:|---:|
| minus | 0.06101963540296702 | 0.06101963540296555 | `1.46e-15` |
| plus | 0.06101963540296555 | 0.06101963540296555 | 0 |

The 556a replay-off gradients differ from replay-on by L-infinity `4.58e-15`
on the minus side and `1.12e-15` on the plus side. The tangential jump remains
`3.83770e-13` replay off and `3.83777e-13` replay on; both are about `48.12`
times their support budgets. Replay mode does not explain the 556a support
failure.

At 96602 and 1b742, replay-off tangential jumps are `3.04e-17` and
`2.26e-16`, respectively, still far below their support budgets. Their
replay-off side-gradient vectors miss the archived replay-on vectors by
L-infinity up to `5.55e-15` and `4.62e-15`; those small differences exceed the
existing strict archived-gradient match budget, so these are replay-mode
diagnostics rather than new P2 requalification receipts. Their objective
values match the archived values exactly.

## Interpretation and limits

The forward residual arrays, stage fluxes, and branch choices stay identical
when replay is disabled, while the 556a tangential gradient jump remains. This
separates the defect from a forward-state or traced-branch change caused by the
replay toggle. It does not locate which reverse-mode accumulation, checkpoint
recomputation, or other derivative operation contributes the residual. The
At the two earlier points, replay-off gradients differ slightly from their
archived replay-on vectors; this guard did not freshly evaluate replay-on
gradients there. The direct on/off gradient comparison is only at 556a.
Preserve the current support threshold and keep the 556a direction
unsupported pending a path-level derivative error analysis.

Replay off is a diagnostic contract with a different `FVAnalysisTransport`
identity by design; it is not a production replay or an endpoint/P2 admission.

The two failed setup guards are separate wrapper defects: guard4 lacked the
repository root on the child import path; guard4b's nested equality check
treated four unchanged NaN `baseline_metadata` scalars as unequal. The
corrected helper compares floating-point bytes while preserving the exact
replay-only field check. Neither failed guard performed AD or residual calls.
No production source, tolerance, or endpoint receipt was changed.
