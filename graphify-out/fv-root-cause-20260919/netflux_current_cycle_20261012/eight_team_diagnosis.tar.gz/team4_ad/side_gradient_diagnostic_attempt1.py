"""Bounded AD check for the archived 556a common-face gradient jump.

This script launches one guarded child. The child performs two or four
production side-gradient evaluations at the exact-production-Q neighbor and,
when available, the opposite one-ulp nonzero-flux control. It uses the
archived 556a gradients as the original-control reference and never evaluates
an HVP, candidate, optimizer step, or score.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parent
EVIDENCE = ROOT / "graphify-out/fv-root-cause-20260919"
BASELINE = OUT.parent / "BASELINE.json"
FLUX = OUT.parent / "team3_flux/flux_probe.json"
FACE = ("qy", 4, 3)
SCALE = 0.84
MAX_CALLS = 4


def _sha_control(control) -> str:
    return hashlib.sha256(control.contiguous().numpy().tobytes()).hexdigest()


def _support(gradient_minus, gradient_plus, normal):
    import torch

    jump = gradient_plus - gradient_minus
    tangent = jump - torch.dot(jump, normal) / torch.dot(normal, normal) * normal
    eps = torch.finfo(jump.dtype).eps
    budget = 128 * eps * max(float(gradient_minus.norm()),
                             float(gradient_plus.norm()), float(jump.norm()))
    return {
        "jump_l2": float(jump.norm()),
        "tangential_jump_l2": float(tangent.norm()),
        "support_budget": budget,
        "tangential_to_budget": float(tangent.norm()) / budget,
        "tangential_jump": tangent.tolist(),
    }


def child() -> None:
    import torch

    ROOT_STR = str(ROOT)
    if ROOT_STR not in sys.path:
        sys.path.insert(0, ROOT_STR)
    from advar import transport, variational
    from examples.weather_scenarios import fv_point_3h_seed_linear_probe as seed

    baseline = json.loads(BASELINE.read_text())
    flux = json.loads(FLUX.read_text())
    base = baseline["points"][-1]
    base_control = torch.tensor(base["control"], dtype=torch.float64)
    if _sha_control(base_control) != baseline["base_control_sha256"]:
        raise ValueError("archived 556a control hash does not match baseline receipt")

    exact = flux["one_ulp_neighbors"]["exact_zero_neighbors"]
    if not exact:
        raise ValueError("team3 flux probe supplied no exact-production-zero neighbor")
    neighbors = flux["one_ulp_neighbors"]["neighbors"]

    def opposite_is_nonzero(row):
        opposite = "up" if row["direction"] == "down" else "down"
        return any(int(other["control_index"]) == int(row["control_index"])
                   and other["direction"] == opposite
                   and not other["exact_production_zero"] for other in neighbors)

    # Prefer a zero neighbor with a measured opposite nonzero neighbor so the
    # four-call budget distinguishes behavior at zero from its adjacent side.
    exact = min(exact, key=lambda row: (not opposite_is_nonzero(row),
                                       abs(row["control_delta"])))
    neighbor = base_control.clone()
    index = int(exact["control_index"])
    direction = -torch.inf if exact["direction"] == "down" else torch.inf
    neighbor[index] = torch.nextafter(neighbor[index], neighbor.new_tensor(direction))

    # Use the opposite representable value as a nearby nonzero-Q control when
    # the flux probe establishes that it is not exact zero.
    opposite_direction = "up" if exact["direction"] == "down" else "down"
    paired = next((row for row in neighbors
                   if int(row["control_index"]) == index
                   and row["direction"] == opposite_direction
                   and not row["exact_production_zero"]), None)
    controls = [("exact_production_zero", neighbor)]
    if paired is not None:
        nonzero = base_control.clone()
        nonzero[index] = torch.nextafter(
            nonzero[index], nonzero.new_tensor(
                -torch.inf if opposite_direction == "down" else torch.inf))
        controls.append(("opposite_one_ulp_nonzero", nonzero))

    problem, _original, _seed_control, parameters, _truth, seed_identity = seed._prepare_fixed_seed()
    spec = problem.frozen.fv_transport
    face_row, face_column = FACE[1], FACE[2]
    weights = -(spec.psi_basis[:, face_row, face_column + 1]
                - spec.psi_basis[:, face_row, face_column]) * spec.coefficient_limits

    def production_q(control):
        nowcast = problem.frozen.nowcast_config
        coeff = variational.bounded_fv_coefficients(
            control[20:25], psi_basis=spec.psi_basis,
            coefficient_limits=spec.coefficient_limits,
            dt_seconds=nowcast.interval_minutes * 60.0 / spec.substeps_per_interval,
            spacing_yx=spec.spacing_yx, reconstruction=spec.reconstruction,
            max_courant=spec.max_courant)
        psi = torch.einsum("k,kij->ij", coeff, spec.psi_basis)
        _qx, qy = transport.face_volume_fluxes(psi)
        return qy[face_row, face_column]

    def formula_q(control):
        return torch.dot(weights, torch.tanh(control[20:25]))

    def production_normal(control):
        return torch.func.grad(production_q)(control)

    # Re-establish flux / normal parity at the control actually used for AD.
    qbase, qbase_formula = production_q(base_control), formula_q(base_control)
    qneighbor, qneighbor_formula = production_q(neighbor), formula_q(neighbor)
    normal = production_normal(neighbor)
    formula_normal = torch.func.grad(formula_q)(neighbor)
    normal_linf = float((normal - formula_normal).abs().max())

    # The archived gradients are the original-c reference; only neighboring
    # controls consume fresh side-gradient evaluations.
    evaluations = 0
    outputs = {}
    for label, control in controls:
        side_gradients = {}
        for side in (-1, 1):
            if evaluations >= MAX_CALLS:
                raise RuntimeError("side-gradient evaluation cap exceeded")
            gradient_fn = torch.func.grad(problem.objective, argnums=0)
            with transport.selected_face_extension(FACE[0], FACE[1], FACE[2], side):
                gradient = gradient_fn(control, parameters)
            if not bool(torch.isfinite(gradient).all()):
                raise ValueError(f"non-finite side-{side} gradient at {label}")
            side_gradients[str(side)] = gradient
            evaluations += 1
        q = production_q(control)
        n = production_normal(control)
        outputs[label] = {
            "control_sha256": _sha_control(control),
            "control_delta_l2_from_556a": float((control - base_control).norm()),
            "formula_q": float(formula_q(control)),
            "production_q": float(q),
            "production_normal": n.tolist(),
            "normal_parity_linf": float((n - torch.func.grad(formula_q)(control)).abs().max()),
            "side_gradients": {key: value.tolist() for key, value in side_gradients.items()},
            "support": _support(side_gradients["-1"], side_gradients["1"], n),
            "side_gradient_delta_from_archived_556a": {
                sign: float((side_gradients[sign] - torch.tensor(
                    base["side_gradients"][sign], dtype=control.dtype)).norm())
                for sign in ("-1", "1")},
        }

    archived_minus = torch.tensor(base["side_gradients"]["-1"], dtype=base_control.dtype)
    archived_plus = torch.tensor(base["side_gradients"]["1"], dtype=base_control.dtype)
    archived_support = _support(archived_minus, archived_plus,
                                torch.tensor(baseline["production_face"]["production_normal"],
                                             dtype=base_control.dtype))
    result = {
        "repository_head": flux.get("repository_head"),
        "base_control_sha256": baseline["base_control_sha256"],
        "team3_flux_probe_sha256": hashlib.sha256(FLUX.read_bytes()).hexdigest(),
        "scope": "fixed seed; archived original gradients plus bounded production side-gradient AD at one exact-Q neighbor and optionally its one-ulp nonzero counterpart; no HVP/search/optimizer/score",
        "seed_identity": seed_identity,
        "target_face": {"array": FACE[0], "row": FACE[1], "column": FACE[2]},
        "selected_exact_neighbor": exact,
        "opposite_one_ulp_control": paired,
        "base_flux": {"formula_q": float(qbase_formula), "production_q": float(qbase)},
        "selected_neighbor_flux": {"formula_q": float(qneighbor_formula),
                                    "production_q": float(qneighbor)},
        "neighbor_normal_parity_linf": normal_linf,
        "archived_556a_support": archived_support,
        "evaluations": {"side_gradient_calls": evaluations,
                        "per_control": 2, "maximum": MAX_CALLS},
        "controls": outputs,
    }
    destination = OUT / "diagnostic.json"
    destination.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--child", action="store_true")
    args = parser.parse_args()
    if args.child:
        child()
        return 0

    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))
    from examples.weather_scenarios.fv_diagnostic_guard import run_guarded_diagnostic

    python = ROOT / ".venv/bin/python"
    result = run_guarded_diagnostic(
        [str(python), str(Path(__file__).resolve()), "--child"],
        wall_seconds=120, rss_bytes=1024**3,
        report_path=OUT / "guard.json", log_path=OUT / "guard.log")
    print(json.dumps(result, indent=2))
    return int(result.get("returncode", 1) != 0 or result.get("rss_limit_exceeded", False)
               or result.get("wall_timeout", False))


if __name__ == "__main__":
    raise SystemExit(main())
