"""Read-only extraction of the pinned three-step current-gradient endpoint traces."""
from __future__ import annotations

import hashlib
import importlib.util
import json
import math
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
ENDPOINT = ROOT / "examples/weather_scenarios/fv_point_3h_current_gradient_endpoint.py"
BASELINE = ROOT / "graphify-out/fv-root-cause-20260919/common_face_diagnosis_20261012/BASELINE.json"
OUT = Path(__file__).with_name("trace_diagnosis.json")


def load_endpoint():
    sys.path.insert(0, str(ROOT))
    spec = importlib.util.spec_from_file_location("fv_endpoint_receipt", ENDPOINT)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module.load_endpoint()


def diff_stages(a, b):
    return [i for i, (left, right) in enumerate(zip(a, b)) if left != right]


def changed_leaf_paths(a, b, prefix=""):
    if isinstance(a, dict) and isinstance(b, dict):
        out = []
        for key in sorted(set(a) | set(b)):
            out.extend(changed_leaf_paths(a.get(key), b.get(key), f"{prefix}.{key}" if prefix else key))
        return out
    if isinstance(a, list) and isinstance(b, list):
        out = []
        for index, (left, right) in enumerate(zip(a, b)):
            out.extend(changed_leaf_paths(left, right, f"{prefix}[{index}]"))
        if len(a) != len(b):
            out.append(f"{prefix}.length")
        return out
    return [] if a == b else [prefix]


def stage179(trace):
    record = trace[179][0]
    return {
        "choose_left": record["choose_left"][1][2],
        "left_sign": record["left_sign"][1][2],
        "right_sign": record["right_sign"][1][2],
        "slope_sign": record["slope_sign"][1][2],
    }


def gate(minus, plus):
    # Reproduce only the archived branch-pair predicate; no FV calls are made.
    eps = 2.220446049250313e-16
    bound = 128 * eps * max(minus["maximum_face_flux"], plus["maximum_face_flux"], 1e-300)
    target_max = max(max((abs(x) for x in minus["target_fluxes"]), default=0.0),
                     max((abs(x) for x in plus["target_fluxes"]), default=0.0))
    complete = all(row.get(k) == 360 for row in (minus, plus)
                   for k in ("stage_count", "observed_stage_count", "expected_stage_count"))
    same_choices = minus["choices"] == plus["choices"]
    same_signs = minus["face_signs"] == plus["face_signs"]
    no_tie = not minus["nonfinite_or_tie"] and not plus["nonfinite_or_tie"]
    return {"complete_360_each": complete, "same_choices": same_choices,
            "same_face_signs": same_signs, "no_tie": no_tie,
            "target_flux_max_abs": target_max, "target_flux_bound": bound,
            "target_flux_within_bound": target_max <= bound,
            "passed": complete and same_choices and same_signs and no_tie and target_max <= bound}


def main():
    endpoint = load_endpoint()
    raw = endpoint["raw"]
    baseline = json.loads(BASELINE.read_text())
    steps = raw["closed_steps"]
    endpoints = []
    for i, step in enumerate(steps):
        trace = step["final_repeat"]["branch_trace"]
        endpoints.append({
            "ordinal": i,
            "control_sha256": step["proposal"]["control_sha256"],
            "recorded_point_index": step["point_index"],
            "left_endpoint_base_sha256": step["base_control_sha256"],
            "branch_pair_passed_recorded": step["final_repeat"]["branch_pair_passed"],
            "trace_matches_proposal_recorded": step["final_repeat"]["trace_matches_proposal"],
            "per_side": {
                side: {
                    "stage_count": trace[side]["stage_count"],
                    "observed_stage_count": trace[side]["observed_stage_count"],
                    "expected_stage_count": trace[side]["expected_stage_count"],
                    "signature_sha256": trace[side]["signature_sha256"],
                    "minimum_margins": trace[side]["minimum_margins"],
                    "nonfinite_or_tie": trace[side]["nonfinite_or_tie"],
                    "excluded_face_from_sign_gate": trace[side]["excluded_face_from_sign_gate"],
                    "stage179_x_cell_1_2": stage179(trace[side]["choices"]),
                } for side in ("-1", "1")
            },
            "pair_gate_reproduced": gate(trace["-1"], trace["1"]),
            "per_side_choice_stage_count": len(trace["-1"]["choices"]),
            "minus_plus_choice_different_stages": diff_stages(
                trace["-1"]["choices"], trace["1"]["choices"]),
            "minus_plus_face_sign_different_stages": diff_stages(
                trace["-1"]["face_signs"], trace["1"]["face_signs"]),
        })
    transitions = []
    for old, new in zip(endpoints, endpoints[1:]):
        a = steps[old["ordinal"]]["final_repeat"]["branch_trace"]
        b = steps[new["ordinal"]]["final_repeat"]["branch_trace"]
        transitions.append({
            "from_control": old["control_sha256"], "to_control": new["control_sha256"],
            "per_side": {side: {
                "choice_changed_stages": diff_stages(a[side]["choices"], b[side]["choices"]),
                "choice_changed_leaf_paths_by_stage": {str(index): changed_leaf_paths(a[side]["choices"][index], b[side]["choices"][index]) for index in diff_stages(a[side]["choices"], b[side]["choices"])},
                "face_sign_changed_stages": diff_stages(a[side]["face_signs"], b[side]["face_signs"]),
                "stage179_from": stage179(a[side]["choices"]),
                "stage179_to": stage179(b[side]["choices"]),
                "minimum_margin_from": a[side]["minimum_margins"],
                "minimum_margin_to": b[side]["minimum_margins"],
            } for side in ("-1", "1")}
        })
    points = baseline["points"]
    base_gradient_summary = {
        "common_face_jump_norm": baseline["common_face"]["jump_norm"],
        "common_face_tangent_jump_norm": baseline["common_face"]["tangent_jump_norm"],
        "common_face_support_budget": baseline["common_face"]["support_budget"],
        "largest_absolute_tangent_jump_indices_zero_based": sorted(
            range(len(baseline["common_face"]["tangent_jump"])),
            key=lambda j: abs(baseline["common_face"]["tangent_jump"][j]), reverse=True)[:5],
        "selected_flow_normal_indices_zero_based": [21, 22, 23, 24],
        "side_gradient_index_25_by_point": [
            {side: point["side_gradients"][side][25] for side in ("-1", "1")}
            for point in points],
    }
    report = {
        "method": "receipt-only; current_gradient_endpoint.load_endpoint validates saved closure; trace comparisons use serialized branch_trace; no FV/objective/gradient/HVP/trace evaluation",
        "endpoint_receipts": endpoint["receipt_files"],
        "current_control_sha256": raw["current_control_sha256"],
        "raw_child_sha256": "c64cde977e9a28dc28addd81d6d116aa7de6b1e005a6e1643622c9a7b28e5e37",
        "optimizer_steps_applied": raw["optimizer_steps_applied"],
        "candidate_committed": raw["candidate_committed"],
        "closed_endpoint_count": len(steps),
        "endpoints": endpoints,
        "transitions": transitions,
        "pairgate_contract": {
            "source": "examples/weather_scenarios/fv_point_3h_candidate_requalification.py current_branch_pair_gate",
            "stage_count": 360,
            "requires_exact_choice_equality": True,
            "requires_exact_face_sign_equality": True,
            "requires_no_nonfinite_or_tie": True,
            "target_flux_bound_formula": "128 * eps(dtype) * max(maximum_face_flux_minus, maximum_face_flux_plus, 1e-300)",
            "selected_target_flow_handling": "target_fluxes are checked only against scaled target-flux tolerance; selected structural face is recorded as excluded_face_from_sign_gate and omitted from face-sign comparison",
        },
        "baseline_common_face_gradient_context": base_gradient_summary,
        "stage179_margin_scope": "Archived branch_trace stores only trajectory-wide minimum_margins, not the stage-indexed active-limiter gap. choices[179] is available, but gap proximity at stage 179 cannot be quantified from these receipts.",
        "limitations": [
            "The archived 360-entry traces establish pointwise selector/sign states at saved controls; they do not certify the entire path between controls.",
            "The gate is a same-endpoint minus/plus parity test; it does not compare either side against a previous endpoint's signature.",
            "No saved per-stage scalar margin is present in the raw endpoint trace, so stage-179 event proximity is unidentifiable from this archive alone.",
            "Any explanation connecting selector changes to gradient component growth is a hypothesis pending team3 production-Q residual and team4 AD evidence."
        ]
    }
    OUT.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"output": str(OUT), "endpoint_count": len(steps),
                      "transitions": transitions,
                      "pairgates": [e["pair_gate_reproduced"] for e in endpoints],
                      "stage179": [e["per_side"]["-1"]["stage179_x_cell_1_2"] for e in endpoints]}, indent=2))


if __name__ == "__main__":
    main()
