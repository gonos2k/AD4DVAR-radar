# 8팀 공통면 불일치 진단과 해소 후보 (2026-10-12)

8개 Luna/high 팀을 가동해 PR297 확정점 `556a25d9…ed298a8b`의 지원 불일치를 조사했다. PR297은 main `37bc51b9`로 병합됐다. 이 세션은 기존 소스·계획·원시 확정 기록·사용자 AGENTS/GN 작업을 보존했다. 현재점의 최적화 확정은 0개이며 역사적 가중 FV 마일스톤 약70%를 유지한다.

**찾은 결과:** 접선 gradient 불일치가 관측잔차→pseudo-Huber cotangent→잔차 Jacobian VJP 경로에서 증폭되는 것을 정량적으로 확인했고, minmod Euler의 수학적으로 같은 합산 순서를 사용하는 1줄 해소 후보를 실제 현재점에서 검증했다. 최초의 반올림 연산까지 특정하거나 새로운 evaluator가 항상 더 정확함을 증명한 것은 아니다. 생산 소스는 수정하지 않았다.

| 팀 | 독립 조사 | 근거 파일 |
|---|---|---|
|1 GREEN 수학|공통면 항등식·off-face 관계·현재 full-mixture θ′ 일반식|team1_math/REPORT.md, FOLLOWUP_DIRECTION_GATE.md|
|2 RED 수학|반례·80자리 투영·zero-normal 에너지|team2_red_math/REPORT.md, HIGH_PRECISION_CHECK.md|
|3 GREEN 유량|생산/차트 Q·법선·표현 가능한 ULP 이웃|team3_flux/REPORT.md, flux_probe.json|
|4 GREEN AD|원점·이웃·HVP/JVP·replay·잔차 VJP 분해|team4_ad/REPORT.md, REPORT3.md, REPORT4.md, REPORT5.md|
|5 RED 분기|360단계 sign/selector·직전점 비교·replay context|team5_trace/REPORT.md, ADDENDUM.md|
|6 GREEN 재현|작은 FV·동등한 Euler 합산·보존성/양성/AD·실제점 prototype|team6_repro/REPORT.md, NETFLUX_REPRO_REPORT.md|
|7 GREEN 통합|입력/소스/수치 근거와 일반화 범위 감사|team7_green/REPORT.md|
|8 RED 통합|원인 반례·해소 정책의 한계·재자격 요구|team8_red/REPORT.md|

## 확인한 경로와 제외한 설명

- 원점의 새 양측 gradient는 보관 벡터와 비트 단위로 일치한다. e13/e18 전방 JVP와 역방향 gradient도 일치한다. 재현 실패나 단순 reverse-only 결함으로 설명되지 않는다.
- 저장 FP64 벡터의 80자리 투영은3.8377756618e-13이며, zero-normal 좌표가 불일치 에너지의99.8594%다. 마지막 projector 계산만 고정밀로 바꿔 해결할 문제가 아니다. 사용자의 별도15검산과는 별개이다.
- 동일 c20의 ±1ULP 이웃은 모두 support를 통과한다. 한 이웃은 원점과 같은 생산Q(+6.94e-18)를 가지므로 Q 잔여값 하나만으로 실패를 설명하지 못한다. 새 원점 HVP는 이웃 gradient 변화1.88e-15를 예측하지만 minus 변화는3.85e-13이다. 기계 간 잡음이 아니라 같은 입력에서 재현되는 부동소수점 민감성의 증거이며, 큰 고차 곡률/연산 원인까지 확정하지 않는다.
- 현재점의 replay on/off 비용·잔차·360단계 q/qx/qy·분기가 동일하다. 접선 불일치는 off에서도3.83770e-13로 남는다. 이 checkpoint toggle은 해결책에서 제외한다. 직전 두 점은 off 새 계산과 on 보관값 비교이며, 새로운 P2 승인으로 해석하지 않는다.
- 원래 양측 q-state hash는 `stage142`(0기준,143번째 기록)부터218개 단계에서 달라지지만 유량·sign·selector는 같다. 600초 관측잔차의 두 성분만 차이를 보이며 표준화/whitening 후 L2 차이는1.63689669e-14다.

## 비용 gradient로의 전파를 직접 측정

정확한 loss 좌표의 잔차 r±와 Jacobian D±에 대해 Φ=∇pseudo-Huber(r)로 두고,

`g+−g− = (D+−D−)ᵀΦ+ + D−ᵀ(Φ+−Φ−)`

를 두 잔차 tape/세 VJP로 계산했다. side-independent prior·smoothness는 소거된다. projected cotangent 항3.84270e-13, projected Jacobian 항7.54723e-16이며 cotangent 항의 전체접선벡터와 cosine은0.9999989다. 실제 data-gradient jump와 보관 full-objective jump의 L2 차이는2.47e-18로 닫힌다. 이 분해 순서에서 작은 잔차 차이의 loss-cotangent 전파가 거의 전부를 설명한다. 분해 순서를 반대로 한 네번째 pullback은 수행하지 않았으므로 유일한 인과 분해라고 선언하지 않는다. 입력 관측 불량·실제 기상 전환·참 gradient 정확성의 인증도 아니다.

## 검증한 최소 해소 후보

`src/advar/transport.py:354`의 minmod Euler만

```python
q - dt * (outgoing / area) + dt * (incoming / area)
```

에서

```python
q + dt * ((incoming - outgoing) / area)
```

로 **진단 프로세스 안에서만** 재결합했다. 경계·상태·계수·유량·δ·관측·prior·시간·분기 함수는 그대로다. flux를0으로 덮어쓰거나 gradient/잔차를 보정하거나 detach하거나 ε를 늘리지 않았다. helper는 원래 callable을 정상/예외 종료에서 복원하며 실제 소스파일을 수정하지 않는다.

현재556a에서 생산Q는여전히+6.9388939e-18인데 양측 잔차차이가0, 접선 jump7.7579192e-18, 기존허용값 대비0.00097274배로 통과했다. 진단은2gradient/value와2잔차forward,9.977초/569786368bytes로 끝났다. 이 결과는 원래 갱신의 부동소수점 합산 순서에 현재 거부가 민감함을 직접 보여준다. 더 정확한 참 해를 보였다는 주장은 아니다.

비용은원래점보다−1.2101431e-14, 개별gradient는L2 약3.57e-12/3.66e-12 이동했다. **공통면 검사 통과가 기존P2 재사용을 허용하지 않는다.** 새 계산법의 수치 정체성을 따로 고정하고 같은 제어점의 새 비용·gradient·θ·fullG·면·분기를 독립 재자격해야 한다.

작은 fully-known minmod(CFL0.2, 한계0.5)에서는 양성·보존성·branch·AD를 비교했고 zero-state/subnormal 유입도 유지됐다. 원래 영향을 받는 FV/minmod derivative/selected-face 시험67개를 임시 kernel에서 실행해1.00초에 통과했다(기존 torch.jit.script 경고18개). PR297의65개·사용자외부15개와 합산하지 않는다. 극단 스케일 전체의 우월성이나 미래예측은 검증하지 않았다.

## 적용 방안과 남은 경계

구체적인 미적용 패치는 PROPOSED_MINMOD_NET_FLUX.patch, 조건부 실행안은 REMEDIATION_PLAN.json이다. 우선순위는 새로운 solver/허용상수 변경보다 이1줄 수치 evaluator의 분리와 재자격이다. 승인된 기존 control을 다른 값으로 옮기거나 과거 원시값을 고치지 않는다. 진단HVP e20을 다음 검색 방향HVP로 재사용하지 않는다.

다음 고정 실행은 새 evaluator에서 current-point qualification을 먼저 닫고, 새로운 방향/HVP2개→실제J/R 후보→독립P2/fullG확정의 한 주기(최대1확정/24후보/600초·660초/2GiB, GN0)를 검증한다. 그 주기는 이번에 수행하지 않았다. 적격 최소점·정확 수반/VJP·섭동 재최적화·독립 미래검증은 계속 열린 항목이다.

GREEN은 이 방식을 가장 작은 검증된 수치 후보로 평가했다. RED는 한 점의 support 개선과67시험으로 일반 정확성/근본 원인/생산 적용을 확정할 수 없다고 경계를 남겼다. 주 agent는 후보와 구체적 패치를 준비하되 생산 코드·엄격지원검사·기존ε는 그대로 유지했다.

## 실패 진단과 기록의 분리

진단 준비 중 과거 y[3,2] 유량 probe는 폐기하고 y[4,3]로 바로잡았다. import/axis-label 오류와 replay clone의 NaN metadata 자기비교 오류는 실제 수치 비교 전에 중단돼0호출이다. 모든 실패 log/guard를 보존했다. metadata 비교는 float의 실제 byte를 비교하도록 고친 별도 진단 코드와4pure회귀로 검증했으며 물리 검사를 건너뛰지 않았다. 이 오류는 생산 gradient 불일치의 원인이 아니다.

원시 PR297 실패는그대로execution failed/numerical preflight이며 소급 정상화하지 않았다. 현재 prototype의 after-runtime필드는 별도로 기록하지 않았으므로 before-runtime/input/source/callable복원 근거와 구분한다. 자세한 guard별 호출/자원은 VERIFICATION_SUMMARY.json 및 각팀원시json을 참조한다.
