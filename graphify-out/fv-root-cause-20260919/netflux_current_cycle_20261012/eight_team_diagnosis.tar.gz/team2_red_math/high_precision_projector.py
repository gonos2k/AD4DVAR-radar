"""Recompute the frozen common-face projector from receipt floats only."""
from __future__ import annotations

from decimal import Decimal, localcontext
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
BASELINE = HERE.parent / "BASELINE.json"
PINNED_DIAGNOSTIC = HERE.parents[1] / "GRADIENT_RESUME_COMMON_FACE_DIAGNOSTIC_20261011.json"


def D(values: list[float]) -> list[Decimal]:
    return [Decimal.from_float(value) for value in values]


def main() -> None:
    baseline = json.loads(BASELINE.read_text())
    common = baseline["common_face"]
    pinned = json.loads(PINNED_DIAGNOSTIC.read_text())
    for key in ("control_sha256", "jump_norm", "tangent_jump_norm", "support_budget",
                "ratio", "tangent_jump", "normal", "gradient_minus", "gradient_plus"):
        if common[key] != pinned[key]:
            raise ValueError(f"baseline field {key} differs from the pinned diagnostic")

    with localcontext() as ctx:
        ctx.prec = 80
        gm = D(common["gradient_minus"])
        gp = D(common["gradient_plus"])
        n = D(common["normal"])
        stored_projector = D(common["tangent_jump"])
        jump = [b - a for a, b in zip(gm, gp)]
        normal_squared = sum(value * value for value in n)
        normal_dot_jump = sum(a * b for a, b in zip(n, jump))
        projected = [
            dj - ni * normal_dot_jump / normal_squared
            for dj, ni in zip(jump, n)
        ]
        projected_squared = sum(value * value for value in projected)
        projected_norm = projected_squared.sqrt()
        zero_normal_indices = [i for i, value in enumerate(n) if value == 0]
        zero_normal_squared = sum(projected[i] ** 2 for i in zero_normal_indices)
        focus_indices = [13, 18, 25]
        focus_squared = sum(projected[i] ** 2 for i in focus_indices)
        stored_squared = sum(value * value for value in stored_projector)
        difference = [a - b for a, b in zip(stored_projector, projected)]
        difference_norm = sum(value * value for value in difference).sqrt()

        result = {
            "scope": "80-digit Decimal.from_float recomputation from BASELINE.json receipt vectors only; no FV or AD calls",
            "control_sha256": common["control_sha256"],
            "precision_decimal_digits": ctx.prec,
            "baseline_matches_pinned_diagnostic_fields": True,
            "high_precision_tangent_jump_norm": str(projected_norm),
            "saved_tangent_jump_norm": common["tangent_jump_norm"],
            "high_precision_minus_saved_norm": str(projected_norm - Decimal.from_float(common["tangent_jump_norm"])),
            "support_budget": common["support_budget"],
            "support_ratio_high_precision": str(projected_norm / Decimal.from_float(common["support_budget"])),
            "zero_normal_coordinate_indices": zero_normal_indices,
            "zero_normal_projector_squared_norm": str(zero_normal_squared),
            "zero_normal_projector_energy_fraction": str(zero_normal_squared / projected_squared),
            "zero_normal_projector_norm_fraction": str(zero_normal_squared.sqrt() / projected_norm),
            "coordinates_13_18_25": focus_indices,
            "coordinates_13_18_25_projected_values": [str(projected[i]) for i in focus_indices],
            "coordinates_13_18_25_energy_fraction": str(focus_squared / projected_squared),
            "coordinates_13_18_25_norm_fraction": str(focus_squared.sqrt() / projected_norm),
            "saved_projector_vs_80_digit_vector_error_norm": str(difference_norm),
            "saved_projector_vs_80_digit_error_energy_fraction": str(difference_norm**2 / projected_squared),
            "high_precision_jump_norm": str(sum(value * value for value in jump).sqrt()),
            "high_precision_normal_norm": str(normal_squared.sqrt()),
            "projection_formula": "d - n*(n·d)/(n·n), d=g_plus-g_minus; n is unnormalized",
        }
    (HERE / "high_precision_projector.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
