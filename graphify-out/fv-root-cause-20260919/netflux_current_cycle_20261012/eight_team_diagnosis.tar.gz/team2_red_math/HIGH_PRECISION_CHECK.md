# High-precision common-face projector check

Recomputed the projector from the three-point `BASELINE.json` receipt using
`Decimal.from_float` at 80 decimal digits. The script uses only the saved
`gradient_minus`, `gradient_plus`, and `normal` vectors; it makes no FV, AD,
objective, or HVP calls.

The 80-digit result is
`||d - n(n·d)/(n·n)||₂ = 3.8377756618179298775697007001729537726e-13`, where
`d=g_plus-g_minus`. This is `48.1204392` times the saved support budget
`7.975354596702747e-15`. It differs from the saved double-precision norm by
`1.18920e-19`, so projector rounding does not explain the refusal.

The support residual is concentrated in coordinates where the face normal is
exactly zero in the receipt. Those coordinates are
`[0..20, 25]` excluding `21..24`; their squared norm is `99.8593701%` of the
80-digit projected jump. The subset `[13, 18, 25]` contributes `89.7181500%`
of projected squared norm. For `n_i=0`, the projector component is exactly
`d_i`, so normalization and normal-coordinate cancellation cannot create
these residual coordinates. The saved projector vector agrees closely with
the high-precision result: vector error norm `7.04310e-17`, error energy
`3.36797e-8` of the projected-jump energy.

Receipt cross-checks passed: the common-face fields in `BASELINE.json` match
the pinned diagnostic JSON. At HEAD `c0b94f9`, the Git blob for
`GRADIENT_RESUME_COMMON_FACE_DIAGNOSTIC_20261011.json` is
`bd5cb98e26552de3e1e2dc888b2fc69f3968911d`, identical to
`git hash-object` of the working file. The production-face diagnostic blob is
`1c08c49e85adc15afc2ce13276730caa949904fc`, also identical to its working
file. The untracked baseline file's SHA-256 is
`7c38906045ba2effa8cc94562a9e2729f9823e918ec08521dd4e066910389da6`.

Artifacts:

- `high_precision_projector.py` — reproducible receipt-only calculation.
- `high_precision_projector.json` — full-precision result and hashes/metrics.

Run from repository root with
`python graphify-out/fv-root-cause-20260919/common_face_diagnosis_20261012/team2_red_math/high_precision_projector.py`.

This independently confirms the stored nonzero common-face projection. It does
not identify why the side gradients have this residual or validate the next
replay. User-supplied external tests remain separate and were not run or
combined with this calculation.
