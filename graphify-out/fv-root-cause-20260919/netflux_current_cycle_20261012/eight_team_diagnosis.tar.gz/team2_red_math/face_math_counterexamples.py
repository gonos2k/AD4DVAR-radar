"""Small analytic checks for common-face gradient support assumptions.

No ADVAR forward, objective, HVP, or frozen artifact is evaluated here.
"""
from __future__ import annotations

import json
from pathlib import Path


def dot(a: tuple[float, ...], b: tuple[float, ...]) -> float:
    return sum(x * y for x, y in zip(a, b))


def norm(a: tuple[float, ...]) -> float:
    return dot(a, a) ** 0.5


def project_tangent(g: tuple[float, float], n: tuple[float, float]) -> tuple[float, float]:
    nn = dot(n, n)
    alpha = dot(g, n) / nn
    return (g[0] - alpha * n[0], g[1] - alpha * n[1])


def main() -> None:
    # A continuous pair across q=x=0 whose off-face gradients disagree
    # tangentially. At (eps, 0), q>0 selects F_plus. At q=0 both traces
    # coincide and the tangent derivatives agree exactly.
    eps = 1.0e-8
    c = 1.0
    y = 0.0
    # F_minus=c*y; F_plus=c*y - (2*c/eps)*x*y.
    # Both values equal on x=0. At x=eps, grad_y(F_minus)=c and
    # grad_y(F_plus)=-c, so the half mixture has zero tangent component,
    # although the active (+) branch has derivative -c.
    f_minus = c * y
    f_plus = c * y - (2.0 * c / eps) * eps * y
    g_minus = (0.0, c)
    g_plus = (-2.0 * c * y / eps, c - 2.0 * c)
    n = (1.0, 0.0)
    mixture = (0.5 * (g_minus[0] + g_plus[0]), 0.5 * (g_minus[1] + g_plus[1]))
    active_tangent_slope = g_plus[1]

    # At a simultaneous second switch, crossing the x-face while also
    # changing the sign of y compares opposite quadrants of |x|+|y|.
    # The jump then has a y-tangent component of magnitude 2. Holding the
    # y-side fixed instead gives the supported x-only jump (2, 0).
    two_switch = {
        "cross_both": ((-1.0, 1.0), (1.0, -1.0)),
        "cross_x_only": ((-1.0, 1.0), (1.0, 1.0)),
    }
    two_switch_results = {}
    for name, (gm, gp) in two_switch.items():
        jump = (gp[0] - gm[0], gp[1] - gm[1])
        two_switch_results[name] = {
            "jump": jump,
            "tangent_jump_norm": norm(project_tangent(jump, n)),
        }

    result = {
        "scope": "analytic two-variable examples only; no production evaluation",
        "off_face_counterexample": {
            "switch": "q(x,y)=x",
            "functions": ["F_minus=c*y", "F_plus=c*y-(2*c/eps)*x*y"],
            "eps": eps,
            "values_at_(eps,0)": [f_minus, f_plus],
            "gradients_at_(eps,0)": [g_minus, g_plus],
            "interface_tangent_gradient_at_x0": c,
            "off_face_tangent_jump_norm": norm(project_tangent((g_plus[0] - g_minus[0], g_plus[1] - g_minus[1]), n)),
            "half_mixture_tangent_gradient": mixture[1],
            "active_plus_branch_tangent_slope": active_tangent_slope,
            "interpretation": "The branch functions agree on x=0 and have equal tangential derivatives there. At finite x>0, the inactive extension can cancel the active derivative in a mixture, so this average is not a derivative of the physical function at that point.",
        },
        "simultaneous_switch_counterexample": {
            "function": "abs(x)+abs(y)",
            "selected_face_normal": n,
            "trace_pairs": two_switch_results,
            "interpretation": "A pair that crosses another switch has tangential jump 2 relative to the x-face. Matching the other branch signature removes this pair; broadening only the common-face tolerance would admit it.",
        },
    }
    path = Path(__file__).with_name("counterexamples.json")
    path.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
