# Team 2 RED: common-face math and domain counterexamples

## Scope

Reviewed the frozen 556a receipts and PR297 source at `c0b94f9`. No production
source, frozen source, plan, raw result, FV forward, objective, HVP, or search was
changed or run. The only executable artifact is
`face_math_counterexamples.py`, which evaluates two analytic functions in
ordinary Python.

The root structural graph (`graphify-out/GRAPH_REPORT.md`) is from commit
`296ecef5`, so it is stale for PR297. The preserved scoped AST graph at
`gradient_resume_graph_20261011/graphify-out/GRAPH_REPORT.md` covers four
endpoint files (32 nodes, 58 edges, 6 communities), not the tangent/transport
mathematics. I consulted both as navigation and relied on pinned source and
receipts for numerical claims.

## When the common-face identity is valid

Let `S={c:q(c)=0}` be a smooth codimension-one surface with resolved normal
`n=∇q(c₀)`. Suppose two `C¹` objective branches `F₋` and `F₊` agree as
functions on `S`, and no other active branch changes in the traces being
compared. For every tangent vector `v` with `n·v=0`, differentiating the
identity `F₋|S=F₊|S` gives `(∇F₊−∇F₋)·v=0`. Thus the limiting jump is normal:
`P_T(∇F₊−∇F₋)=0`. A convex mixture of those *on-face limiting* gradients has
the same tangent derivative.

This does not establish the identity for two branch extensions evaluated at a
point with `q≠0`. Agreement of values only on `S` gives no bound on tangential
gradient disagreement away from `S` unless an additional derivative
regularity/error bound is supplied. In `src/advar/transport.py:59-71`,
`selected_face_extension` is explicitly an extension at a zero-flux kink and
outside its selected side is a research chart, not a physical upwind rule.
`_volume_parts` replaces the signed split only at the selected face
(`transport.py:189-208`). Therefore using both extensions at finite nonzero
production flux is not automatically a pair of physical one-sided gradients.

The held-other-switch condition is also substantive. The trace records compare
all 360 stages, minmod choices, and all non-target face signs while omitting
only the selected flux (`fv_point_3h_nonsmooth_coupled_probe.py:153-235`);
the pair gate requires complete traces, identical choices/signs, and a target
flux within its near-zero bound
(`fv_point_3h_candidate_requalification.py:121-138`). That is relevant support
for a single-face interpretation, but finite sampled signatures are not a
general proof against every nonsmooth gate or a bound on off-face gradient
error.

## Counterexamples to proposed shortcuts

The script's first example uses `q(x,y)=x`, `F₋=c y`, and
`F₊=c y-(2c/ε)xy`. Both functions agree on `x=0`, with the same tangent
derivative `c` there. At `(x,y)=(ε,0)`, however, the gradients are `(0,c)` and
`(0,-c)`. For positive `x`, `F₊` is the active branch; a half mixture gives
zero tangent gradient even though the active branch's tangent derivative is
`-c`. This disproves replacing disagreeing off-face side gradients by a
projected common mixture and calling it the physical derivative. It also
shows why setting `q` to zero by coercion is not derivative-preserving: the
point moves to the switch, where the tangent derivative is `c`, reversing the
active finite-`q` derivative. Here `ε` may be arbitrarily small because the
assumptions provide no Lipschitz bound on branch gradients in `q`.

For `|x|+|y|` at the intersection of two switches, comparing gradients
`(-1,1)` and `(1,-1)` across the selected `x` face gives tangential jump 2.
Holding the `y` branch fixed gives `(-1,1)` and `(1,1)`, whose jump `(2,0)` is
supported by the `x` face. A much wider global threshold could therefore hide
a second active switch; retaining signature parity is essential. The
counterexample is order-one, so the current 48.12× exceedance alone does not
justify widening the threshold to admit it.

## Exact-zero neighbor vs forcing the flux

The separate frozen face receipt says formula `Q=0`, production
`Q=6.938893903907228e-18`, face audit budget `5.265468033312829e-16`, and
production/formula normal `L∞=0` (`GRADIENT_RESUME_PRODUCTION_FACE_DIAGNOSTIC_20261011.json`).
It checks flux decoding and the normal only; it does not regenerate the two
objective gradients. The support refusal remains measured from pinned side
gradients: tangent jump `3.837774472618545e-13` against
`7.975354596702747e-15`, ratio `48.1204243`
(`GRADIENT_RESUME_COMMON_FACE_DIAGNOSTIC_20261011.json`).

An exact representable neighbor can be a useful **new diagnostic point** if it
is produced by solving the face constraint in control coordinates, then the
native flux, full objective, and both side gradients are recomputed there and
receipted under the new control hash. It does not preserve the old control or
its P2/gradient receipt merely because the coordinate moved by one ULP. A
rounded neighbor is a sample, not a differentiable projection map; it cannot
by itself establish derivatives with respect to the original control. A
derivative-preserving local chart instead uses the implicit face relation
(`dc_p/dc_i = -n_i/n_p`) and keeps the flux/control computation in the
objective graph.

Forcing a production flux entry to zero is different: it changes the
conservative operator's input and the branch used in the physical forward.
Even though a shared-face flux cancels globally in a conservative sum, replacing
a nonzero flux changes the adjacent-cell updates and drops the flux's
control derivative. It is not a valid way to obtain the selected one-sided
derivative. At exact zero, native `maximum/minimum` uses the framework's tie
derivative; the selected-face context explicitly chooses a signed extension
for kink derivatives. Keep that selection local to the derivative diagnostic.

## Finding and decision bar

The mathematical identity is sound at a genuine, isolated common face for
limiting gradients with matching other branch signatures. The current receipts
do not establish that the 48.12× residual is a physical second switch; they
also do not establish it is only roundoff. Normal parity and `Q`'s roundoff
residual are insufficient to infer side-gradient parity. Do not project away
the residual, force the production flux to zero, or widen the global support
budget. First compare the fresh AD gradients at a representable exact-face
neighbor, preserving the point's distinct hash and full-flow contract, and
requalify the traces there. Any accepted fix needs a source-level cause or an
explicit scale-aware gradient error bound, plus restoration of the face
restriction identity and existing input/P2 checks.

## Artifacts

- `face_math_counterexamples.py` — analytic counterexamples; no FV calls.
- `counterexamples.json` — output from running that script with system Python.

Reproduction: `python graphify-out/fv-root-cause-20260919/common_face_diagnosis_20261012/team2_red_math/face_math_counterexamples.py`.
