"""Two-dimensional algebra checks for the conditional side-slope argument."""


def dot(a: tuple[float, ...], b: tuple[float, ...]) -> float:
    return sum(x * y for x, y in zip(a, b))


def check(gminus: tuple[float, float], gplus: tuple[float, float]) -> dict[str, object]:
    jump = (gplus[0] - gminus[0], gplus[1] - gminus[1])
    theta = -dot(gminus, jump) / dot(jump, jump)
    mixed = tuple((1.0 - theta) * a + theta * b for a, b in zip(gminus, gplus))
    # Q=x, so P removes the x component.
    direction = (0.0, -mixed[1])
    return {
        "theta": theta,
        "tangent_jump": jump[1],
        "side_slopes": (dot(gminus, direction), dot(gplus, direction)),
        "mixture_slope": dot(mixed, direction),
    }


both_descend = check((0.0, -2.0), (2.0, -1.0))
assert 0.0 < both_descend["theta"] < 1.0
assert both_descend["tangent_jump"] != 0.0
assert max(both_descend["side_slopes"]) < 0.0
assert both_descend["mixture_slope"] < 0.0

mixture_only = check((0.0, 1.0), (2.0, -3.0))
assert 0.0 < mixture_only["theta"] < 1.0
assert mixture_only["mixture_slope"] < 0.0
assert mixture_only["side_slopes"][0] < 0.0 < mixture_only["side_slopes"][1]

print("both-side descent with nonnormal jump:", both_descend)
print("mixture descent while one side ascends:", mixture_only)
