# GREEN math review: common-face gradient jump

## Result

The 556a preflight failure is mathematically meaningful: for two smooth side
objectives that agree on a regular common face, their gradient difference must
be normal to that face. The saved 556a jump violates the current support gate
by 48.12x. The preceding two archived points satisfy it by wide margins. The
available evidence does **not** identify whether the 556a tangential residual
comes from an off-face floating-point residual, inaccurate/inconsistent side
gradients, or a projection/gradient accumulation error. It supports keeping
the guard closed and investigating those sources separately; it does not
support increasing the tolerance or invalidating the preceding accepted
points.

## Governing identity

Let the regular face be `Q(c)=0`, with `n=∇Q(c) != 0`, unit normal
`u=n/||n||`, and orthogonal tangent projector `P=I-u uᵀ`. Set
`F(c)=J_+(c)-J_-(c)`. If the two side objectives have the same restriction
to the face, `F=0` whenever `Q=0`. In local coordinates `(y,q)` with `q=Q`,

```text
F(y,q) = q λ(y,q),
∇F    = λ ∇Q + Q ∇λ,
P∇F   = Q P∇λ.
```

Thus `P(g_+−g_-)=0` on the exact face. At a computed point with nonzero `Q`,
the tangential defect can instead be `Q P∇λ`; a small `Q` alone is not a bound
unless a bound on `P∇λ` is also available. The saved production residual is
`6.938893903907228e-18` while formula `Q=0`; explaining the observed
`3.837774472618545e-13` entirely this way requires
`||P∇λ|| ≈ 5.53e4` in the corresponding units. No such sensitivity estimate is
saved, so this possibility is unproven, not excluded. Production and formula
face normals agree exactly in the saved diagnostic, which rules out a normal
definition mismatch there but not residual sensitivity.

The same identity applies to the finite-volume *discrete* map only if both
side objectives are the restrictions of the same production map on the
selected face, with the same fixed inputs, stage/limiter branch choices, and
chart. Floating-point forward values can leave `Q` at an ULP-scale residual;
AD differentiates the implemented arithmetic graph with rounded intermediates
and fixed branch choices, not the discontinuous rounding decisions themselves.
Therefore the real-arithmetic identity is a target invariant, while the
computed JVP/VJP discrepancy needs an operation- and conditioning-aware error
budget.

## Receipt evidence

I consulted the saved structural graph first (`graphify-out/GRAPH_REPORT.md`,
graph built at `296ecef5`; it is older than this diagnosis branch), then read
`GRADIENT_RESUME_FINDINGS_20261011.md` and the two pinned common-face and
production-face diagnostics. `endpoint.load_endpoint()` validated the closed
three-step receipt without FV evaluation. Arithmetic replay of its pinned
baseline is in `receipt_projection.py` and reproduces:

| Closed point | `||g+−g−||₂` | `||P(g+−g−)||₂` | Existing budget | Ratio |
|---|---:|---:|---:|---:|
| 9660… (first archived endpoint) | 2.8078539881e-1 | 6.2834356733e-17 | 7.9804010173e-15 | 0.00787 |
| 1b74… (second archived endpoint) | 2.8059157950e-1 | 7.4729342396e-16 | 7.9748923412e-15 | 0.0937 |
| 556a… (current closed endpoint) | 2.8060784367e-1 | 3.8377744726e-13 | 7.9753545967e-15 | 48.12 |

At 556a, `||Pj||∞=2.3881591149e-13`. The archived individual side
gradients, theta, objective, and `R` remain closed by the existing endpoint
receipt. This new tangent support failure is evidence about the next
continuation direction only; it is not a retroactive failure of those checks.
The saved diagnostics say the continuation stopped before any HVP or candidate
evaluation.

## Roundoff assessment and tests

The current check in
`examples/weather_scenarios/fv_point_3h_tangent_continuation.py:152-160`
forms `j=g+−g−`, normalizes `n`, projects `j`, then compares the result to
`128 eps max(||g−||₂, ||g+||₂, ||j||₂)`. This is a scale heuristic for the
projection check, not a derived bound for the full FV AD gradients. The
projection's own arithmetic error can be bounded componentwise from the
actual inputs and operations. For example, subtraction contributes at most
`u(|g+_i|+|g-_i|)` per component (`u` is unit roundoff); dot products use a
`γ_k = ku/(1-ku)` factor against the sum of absolute products; normalization,
component products, and final subtraction get their own corresponding terms.
Propagating these gives a bound based on the actual projection expression,
not a free multiplier. It still omits any error already present in `g±` from
the 360-step FV reverse/forward accumulation. A valid total bound needs either
an error estimate for that AD path (including cancellation/absolute
accumulator scales) or an independent derivative comparison.

An independent, well-conditioned check is chart-space parity. For a local
chart `c(y)` with Jacobian `C`, both side objectives have the same restricted
function, so `Cᵀ(g+−g−)=0`. Compute it without forming a normalized normal and
bound each dot product from `γ_k |C|ᵀ(|g+|+|g−|)` plus separately measured
gradient uncertainty. This is mathematically equivalent when `C` spans the
face tangent, and tests a different numerical path from `Pj`.

The finite-volume AD audit should hold the 556a control, parameters,
observations, face, and branch signature fixed; compare both side JVPs along
the chart columns (or a set spanning them) and compare with reverse-mode
`Cᵀg±`. Record production `Q`, branch/stage identity, the absolute
intermediate contribution scales for accumulated derivatives, and per-side
JVP/VJP disagreement. A common-face restricted directional derivative must
agree within a bound derived from those sums and operation counts. This
separates off-face `Q` sensitivity from projection arithmetic and from side
gradient construction. No full objective, HVP, optimizer, or tolerance change
was run here.

## Source locations and disposition

- Saved graph summary/freshness: `graphify-out/GRAPH_REPORT.md`.
- Previous failed continuation and scope: `graphify-out/fv-root-cause-20260919/GRADIENT_RESUME_FINDINGS_20261011.md`.
- Reproduced jump and support budget: `graphify-out/fv-root-cause-20260919/GRADIENT_RESUME_COMMON_FACE_DIAGNOSTIC_20261011.json`.
- Formula/production `Q` and matching normal: `graphify-out/fv-root-cause-20260919/GRADIENT_RESUME_PRODUCTION_FACE_DIAGNOSTIC_20261011.json`.
- Face and normal definition: `examples/weather_scenarios/fv_point_3h_face_transition_diagnostic.py:84-93`.
- Existing support computation and `128 eps` gate: `examples/weather_scenarios/fv_point_3h_tangent_continuation.py:152-160`.
- Receipt-only loader contract: `examples/weather_scenarios/fv_point_3h_current_gradient_endpoint.py:192-215`.

**Disposition:** preserve the rejection. First resolve the fixed-point two-side
AD/chart-parity discrepancy and quantify the multiplier sensitivity to
production `Q`; only then choose whether the support tolerance has omitted a
defensible, operation-scaled term. Do not widen it using the observed residual
as its own calibration.
