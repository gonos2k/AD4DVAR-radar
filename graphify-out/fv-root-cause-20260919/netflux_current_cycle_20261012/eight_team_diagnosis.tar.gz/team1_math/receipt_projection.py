"""Pure arithmetic replay of side-gradient support from the pinned receipt baseline."""
import json
from pathlib import Path
import torch

BASE = Path(__file__).resolve().parents[1] / "BASELINE.json"
weights = torch.tensor([0.0, -0.08, -0.28, -0.14, -0.84], dtype=torch.float64)
receipt = json.loads(BASE.read_text())
for index, point in enumerate(receipt["points"]):
    control = torch.tensor(point["control"], dtype=torch.float64)
    gm = torch.tensor(point["side_gradients"]["-1"], dtype=torch.float64)
    gp = torch.tensor(point["side_gradients"]["1"], dtype=torch.float64)
    normal = torch.zeros_like(control)
    normal[20:25] = weights * (1.0 - torch.tanh(control[20:25]).square())
    unit = normal / torch.linalg.vector_norm(normal)
    jump = gp - gm
    tangent = jump - unit * torch.dot(unit, jump)
    budget = 128.0 * torch.finfo(control.dtype).eps * max(
        float(torch.linalg.vector_norm(gm)),
        float(torch.linalg.vector_norm(gp)),
        float(torch.linalg.vector_norm(jump)),
    )
    print(
        f"point={index} J={point['objective']:.17g} R={point['F_squared']:.17g} "
        f"jump_l2={torch.linalg.vector_norm(jump).item():.17g} "
        f"tangent_l2={torch.linalg.vector_norm(tangent).item():.17g} "
        f"tangent_linf={tangent.abs().max().item():.17g} "
        f"budget={budget:.17g} ratio={torch.linalg.vector_norm(tangent).item()/budget:.9g}"
    )
