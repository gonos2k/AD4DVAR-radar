"""Check the active minimum-mixture theta' identity on a synthetic smooth pair."""
import torch

torch.set_default_dtype(torch.float64)
c0 = torch.zeros(2)
normal = torch.tensor([1.0, 0.0])  # Q(x,y)=x


def fminus(c: torch.Tensor) -> torch.Tensor:
    return -2.0 * c[1] + 1.5 * c[1].square()


def fplus(c: torch.Tensor) -> torch.Tensor:
    return 2.0 * c[0] - c[1] - 0.25 * c[1].square()


gminus_fn = torch.func.grad(fminus)
gplus_fn = torch.func.grad(fplus)


def mixture(c: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    gm, gp = gminus_fn(c), gplus_fn(c)
    jump = gp - gm
    theta = -torch.dot(gm, jump) / torch.dot(jump, jump)
    return (1.0 - theta) * gm + theta * gp, theta, jump


mixed0, theta0, jump0 = mixture(c0)
direction = torch.tensor([0.0, -mixed0[1]])  # -P g_theta
hm, = (torch.func.jvp(gminus_fn, (c0,), (direction,))[1],)
hp, = (torch.func.jvp(gplus_fn, (c0,), (direction,))[1],)
hmix = (1.0 - theta0) * hm + theta0 * hp
delta_h = hp - hm
theta_prime = -(torch.dot(jump0, hmix) + torch.dot(mixed0, delta_h)) / torch.dot(jump0, jump0)
closed_form = hmix + jump0 * theta_prime
direct, = (torch.func.jvp(lambda c: mixture(c)[0], (c0,), (direction,))[1],)

assert 0.0 < float(theta0) < 1.0
assert float(torch.abs(jump0[1])) > 0.0  # nonzero tangential jump
assert torch.allclose(closed_form, direct, rtol=1e-13, atol=1e-14)
assert torch.dot(gminus_fn(c0), direction) < 0.0
assert torch.dot(gplus_fn(c0), direction) < 0.0
print({
    "theta": float(theta0),
    "jump": jump0.tolist(),
    "direction": direction.tolist(),
    "theta_prime": float(theta_prime),
    "closed_form_mixture_derivative": closed_form.tolist(),
    "direct_ad_mixture_derivative": direct.tolist(),
    "max_abs_difference": float((closed_form - direct).abs().max()),
})
