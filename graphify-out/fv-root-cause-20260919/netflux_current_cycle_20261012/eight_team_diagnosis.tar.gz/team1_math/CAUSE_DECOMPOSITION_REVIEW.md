# GREEN math review: residual-cotangent versus Jacobian-branch terms

## Identity and validity conditions

For the robust observation contribution, let `r±(c)` be the exact residual
vector passed to pseudo-Huber after standardization, whitening, censoring, and
valid-row masking; let `D±=Dr±/Dc` on the two selected-face extensions. At the
same control and with the same fixed observations, whitener, mask, parameters,
and common prior `p(c)`,

```text
g− = D−ᵀ φ(r−) + p(c)
g+ = D+ᵀ φ(r+) + p(c)

A−       = D−ᵀ φ(r−)
A_common = D−ᵀ φ(r+)
A+       = D+ᵀ φ(r+)

g+ − g− = (A+ − A_common) + (A_common − A−).
```

The common prior cancels. Therefore, with the same current face projector `P`,

```text
P(g+−g−) = P(D+−D−)ᵀ φ(r+) + P D−ᵀ[φ(r+)−φ(r−)].
             Jacobian/branch term       residual-cotangent term
```

This is an exact algebraic split, not a small-perturbation approximation. It
is valid only if every `D` and `r` uses the same residual definition, shape and
ordering, control, frozen observations/quality weights/whitener, masks,
parameters, and face-side convention. `A_common` must apply the plus residual's
cotangent to the *minus* residual map's VJP at the same point. The residual
must be the value actually consumed by `robust_objective`; a raw 3×4 dBZ
residual cannot be substituted for its standardized/whitened residual without
inserting the corresponding fixed transforms in both `D` and `φ`.

For the code's pseudo-Huber cost
`ρδ(r)=δ²(sqrt(1+(r/δ)²)−1)`,

```text
φδ(r) = ρδ'(r) = δ r / sqrt(δ²+r²),
φδ'(r) = δ³ / (δ²+r²)^(3/2) ∈ (0,1].
```

Thus `φδ` is 1-Lipschitz, coordinatewise monotone, and
`||φ(r+)−φ(r−)||₂ ≤ ||r+−r−||₂` (with the same fixed validity mask). This
gives the useful upper bound
`||P D−ᵀ Δφ||₂ ≤ ||P D−ᵀ||₂ ||Δr||₂`. If the supplied residual difference is
already in the loss's whitened coordinate and has norm `1.63674463494e−14`,
then producing the full observed tangent jump `3.83777447262e−13` from this
term alone requires `||P D−ᵀ||₂ ≥ 23.4476`. If the reported residual is raw
dBZ, this ratio is only a scale illustration: the exact quality/standard
deviation/whitener transform and valid mask must be applied first.

## What the decomposition can establish

The proposed three VJPs can establish the **proximate numerical source** of
the measured gradient jump:

- `b=P(A_common−A−)` measures the change from the residual cotangent while
  holding the minus Jacobian fixed.
- `k=P(A+−A_common)` measures the change from the side Jacobian while holding
  the plus cotangent fixed.
- `j_t=P(A+−A−)` should satisfy `j_t=b+k`, up to the measured arithmetic
  closure error.

For attribution, report `||b||₂`, `||k||₂`, `||j_t||₂`,
`cos(b,j_t)`, `||j_t−b||₂/||j_t||₂`, and signed `bᵀk`. The cotangent term is a
credible dominant proximate cause only if it is close in vector direction and
magnitude to `j_t` **and** the Jacobian term is correspondingly smaller; mere
`||b||>||k||` is insufficient if the terms cancel. The decomposition
recombination should also be checked componentwise against a floating-point
bound for the final three 26-vectors and projector. A failure of that closure
means inputs or arithmetic paths are not aligned, and no causal attribution
should be made.

If `b` dominates and aligns, that identifies a residual-value-induced
cotangent contribution under a fixed minus map. It does **not** identify
“observation quantization” as the cause: the observations are fixed, and the
two changed residual entries may come from side-specific forecast values,
whitening, censoring, or another forward-map difference. Compare raw
observation data, unwhitened prediction residual, standardized residual, and
the exact robust-objective residual separately before naming that cause. A
dominant `k` instead identifies sensitivity to the side Jacobian/branch map,
not a residual-cotangent error. If both are material or cancel, the result is
mixed rather than a single cause.

An exact side objective that agrees on a regular common face has a normal
gradient jump. Hence a robust `b+k` with nonzero tangent sum also says at least
one premise is numerically or structurally imperfect: residual maps may not
represent the same restricted production objective, the side Jacobians may
not be consistent derivatives of those maps, or finite-precision evaluation
may violate the ideal equality. A dominant term explains this computed jump;
it does not repeal the common-face theorem or prove a valid physical branch
transition.

## Supplied evidence and limits

The parent supplied the diagnostic summary: first side `q` hash difference at
stage 142, 218 total differing stages, and only two of the 12 observation
residual entries differing at `t6002`, by `−2.47e−15` and `+1.618e−14`
(`L2=1.63674463494e−14`). The latter compared with the archived tangent jump
gives the conditional scale ratio above. These facts alone do not determine
`b`, `k`, their alignment, or which stage/operation generated the residual
difference. They were not independently re-evaluated here. The authorized
guard-5 decomposition results are needed before ranking causes or recommending
a production change.

Source review: `src/advar/variational.py:6514-6549` shows the whitened
residual, valid-row mask, and common control/field priors in the robust
objective; `src/advar/variational.py:6552-6605` implements the algebraically
equivalent stable pseudo-Huber branches. This review performed no FV forward,
AD/VJP, HVP, source change, or tolerance change.

## Conditional remedies and scope

No remedy is currently justified from the supplied residual norm alone.
After guard 5, keep the scope conditional:

| Guard-5 outcome | Supported next step | Scope |
|---|---|---|
| `b` is aligned with and accounts for `j_t`; `k` is smaller; residual path is pointwise consistent with the intended face map | Trace the two changed values back through raw prediction, standardization, whitening, and face-stage arithmetic. Only if a common-value identity is proved, consider a shared/canonical face-value evaluation that preserves each side derivative. | Forward residual representation at the selected face; no gradient snapping or threshold change. |
| `k` accounts for `j_t`; `b` is smaller | Audit the selected-face extension's reverse Jacobian against tangent chart JVPs and branch traces. Change it only if a derivative mismatch is reproduced. | Side derivative path only. |
| `b` and `k` are comparable/cancelling, or the decomposition does not close at a derived arithmetic scale | Preserve the current refusal and isolate path/precision contributions before any fix. | Diagnosis only. |

Any numerical scale should be the measured `b` and `k` themselves plus a
componentwise operation-scale closure bound. The residual scale is the exact
loss-coordinate `||Δr||`, transformed through fixed weighting/whitening; the
gradient scale is the corresponding projected cotangent/Jacobian VJP. Do not
turn either observed component into a new support tolerance. Even if a narrow
forward or derivative repair is justified, it does not certify a local
minimum, response, or forecast skill.
