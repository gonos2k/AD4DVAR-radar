# Follow-up: explicit side slopes as a conditional direction gate

## Mathematical answer

Let `Q(c)=0` be a regular face, `P=I-nnᵀ/(nᵀn)`, `gθ=(1−θ)g−+θg+`,
and choose `d=−P gθ`. Then `nᵀd=0`. Without assuming `g+−g−` is normal,
the two side slopes are

```text
g−ᵀd = −g−ᵀP gθ,
g+ᵀd = −g+ᵀP gθ.
```

If both are strictly negative by margins larger than their **side-specific
derivative uncertainty and dot-product rounding bounds**, then every convex
mixture has negative slope:

```text
gθᵀd = (1−θ)g−ᵀd + θ g+ᵀd < 0.
```

More strongly, for a tied two-branch objective whose active branch along the
direction can be either side, both negative slopes imply first-order descent
for either branch. For `C¹` side functions and a chart path `c(s)` with
`c(0)=c0`, `c'(0)=d`, `J±(c(s)) = J±(c0) + s g±ᵀd + o(s)`. If both margins are
resolved, both local linear terms decrease. This is a valid **conditional
directional-descent certificate**; it is not a proof that the side functions
agree on a neighborhood of the face, that the chosen face represents the
production objective, or that any finite trial decreases it. Actual candidate
J, face, branch, and Armijo checks remain necessary.

The exact common-face theorem still says that if `J+ = J−` on a regular face
neighborhood, then `P(g+−g−)=0`. Explicit side slopes do not establish that
structural identity; they can only show the current computed direction is a
descent direction for both measured side gradients despite their discrepancy.
The toy counterexample in `direction_gate_identity.py` has a strict-interior
minimum-norm mixture and two negative side slopes while its gradient jump has
a nonzero tangent component. The side values tie at the base point but differ
off it, so the example demonstrates conditional descent without demonstrating
a valid common-face model.

## Scope and existing model gates

As a narrow native-`J` direction screen, replacing the jump-normality *direction
refusal* with both resolved side-slope checks is mathematically defensible if
the face chart is tangent, the base production face is qualified, and side
branches cover every local direction. A suitable roundoff floor must be based
on `γ_k Σ_i |g±_i d_i|`; the stronger error margin must separately bound
uncertainty in each FV side gradient. A raw `128 eps ||g±|| ||d||` floor
addresses neither arbitrary AD cancellation nor branch/face model error by
itself.

The active PR297 path is `current_gradient_resume.py:221-230`, which calls
`tangent_mixing_minimum_probe.py:237-292` after the two fresh side HVPs. That
model's `theta_prime` is the full derivative of the strict-interior
minimum-norm mixture and is valid without jump-normality. Write
`j=g+−g−`, `gθ=g−+θj`, and `H±d = Dg±[d]`. Interior stationarity is
`jᵀgθ=0`; differentiating it along the face chart gives

```text
0 = (H+−H−)d · gθ + j · (H−d + θ(H+−H−)d + θ' j)
θ' = −(j·hmix + gθ·(h+−h−)) / (j·j),
hmix = (1−θ)h− + θ h+.
```

This is exactly the implementation at `tangent_mixing_minimum_probe.py:248-258`.
It requires a resolved, strict-interior minimum and consistent smooth side
gradients/HVPs along the same fixed-face path; it does not require `j` to be
normal. The envelope derivative at the minimum is then
`D(0.5||gθ||²)[d]=gθᵀhmix` (plus the explicit face-residual term when `Q≠0`),
because `gθᵀj=0`. The implemented residual-dot/envelope-slope parity gate
checks this identity, while the model also records both side slopes and
requires `both_side_gradients_descend` in
`current_gradient_resume.py:228-230`. So the active minimum/HVP/G-model path
does not inherit the legacy helper's normal-jump theta formula. The support
assertion still runs earlier in `tangent_direction` (`:192-193`), and must be
relaxed there or made a diagnostic before these already-existing gates can
actually qualify the point.

Therefore the default policy should stay strict pending the fixed-point AD and
chart-parity audit. A narrowly scoped test could treat support as diagnostic
and let the already-implemented strict-mixture, fresh two-side HVP, resolved
both-side descent, envelope-slope parity, actual-J, face, trace, and Armijo
gates decide direction/candidate qualification. This is better supported than
the legacy-normal-form concern, but remains a proposal: at a genuine common
face the exact gradient-jump theorem still holds, and current per-side AD
accuracy is unresolved. It does not certify a local minimum, active-set
stability, response, or forecast skill.

## Toy identity check

`direction_gate_identity.py` uses `Q(x,y)=x`, `n=(1,0)`,
`g−=(0,−2)`, `g+=(2,−1)`. The strict-interior Euclidean mixture minimizer is
`θ=0.4`; hence `d=−P gθ=(0,1.6)`. The jump's tangent component is `1`, while
`g−ᵀd=−3.2` and `g+ᵀd=−1.6`. Both branches descend to first order although
the common-face support identity fails. A second case has an interior mixture
with mixture slope negative but a positive `g+ᵀd`, confirming that a mixture
slope alone is insufficient. These are algebraic toy cases only; no
production objective or frozen run was evaluated.

The formula for the active `theta_prime` was also checked with a synthetic
float64 `torch.func.jvp` example (`theta_prime_ad_check.py`). It compares the
closed-form stationarity derivative with direct AD of the changing
minimum-mixture gradient for nonlinear side objectives whose jump has a
tangent component. The check passes at the toy point; it exercises no
production FV code.
