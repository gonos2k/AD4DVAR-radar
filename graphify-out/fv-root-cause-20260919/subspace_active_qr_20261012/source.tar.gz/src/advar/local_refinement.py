"""Conditional matrix-free stationarity refinement for research adapters.

The caller supplies the objective's fixed branch check.  This module performs
only a local inexact-Newton root solve; it makes no minimum, path, or global
positive-definiteness claim.
"""
from __future__ import annotations

from collections.abc import Callable
import copy
from dataclasses import dataclass
import math
from numbers import Integral
from typing import Any

import torch
from torch import Tensor

from .matrix_free import pcg


_STATIONARITY_TOLERANCE = 1.0e-10
_PCG_RELATIVE_TOLERANCE = 1.0e-10
_ARMIJO_CONSTANT = 1.0e-4


class _NonFiniteEvaluation(ValueError):
    """A numerically invalid objective evaluation at a candidate control."""


class RefinementNumericalRefusal(RuntimeError):
    """A declared Newton/PCG convergence or curvature refusal."""


class RefinementCallbackError(RuntimeError):
    """An optional diagnostic or acceptance callback failed its contract."""


@dataclass(frozen=True)
class RefinementResult:
    """Result of a conditional local stationarity refinement."""

    control: Tensor
    gradient_max: float
    iterations: int
    hvp_count: int
    history: list[dict[str, Any]]


@dataclass(frozen=True)
class RefinementTrial:
    """Finite measured endpoint data for an optional research acceptance rule."""

    iteration: int
    backtrack: int
    current_objective: float
    candidate_objective: float
    current_gradient_norm: float
    candidate_gradient_norm: float
    current_gradient_max: float
    candidate_gradient_max: float
    current_branch: Any
    candidate_branch: Any
    step_scale: float
    normalized_slope: float
    armijo_ratio: float


def _require_vector(
    name: str,
    value: Tensor,
    *,
    dtype: torch.dtype | None = None,
    require_finite: bool = True,
) -> None:
    if not isinstance(value, Tensor) or value.ndim != 1:
        raise TypeError(f"{name} must be a one-dimensional tensor")
    if dtype is not None and value.dtype is not dtype:
        raise TypeError(f"{name} must have dtype {dtype}")
    if value.numel() == 0:
        raise ValueError(f"{name} must be nonempty")
    if require_finite and not bool(torch.isfinite(value).all()):
        raise ValueError(f"{name} must be finite")


def _finite_scalar(name: str, value: Tensor) -> float:
    if not isinstance(value, Tensor) or value.ndim != 0:
        raise ValueError(f"{name} must return a scalar tensor")
    if not bool(torch.isfinite(value)):
        raise _NonFiniteEvaluation(f"{name} must be finite")
    return float(value)


def _branch(
    branch_check: Callable[[Tensor, Tensor], tuple[Any, str]],
    control: Tensor,
    parameters: Tensor,
) -> tuple[Any, str]:
    if not callable(branch_check):
        raise TypeError("branch_check is required")
    result = branch_check(control, parameters)
    if not isinstance(result, tuple) or len(result) != 2:
        raise ValueError("branch_check must return (signature, scope)")
    signature, scope = result
    if not isinstance(scope, str) or not scope.strip():
        raise ValueError("branch_check scope must be a nonempty string")
    return signature, scope


def _validate_option(name: str, value: object) -> int:
    if isinstance(value, bool) or not isinstance(value, Integral):
        raise TypeError(f"{name} must be an integer")
    result = int(value)
    if result <= 0:
        raise ValueError(f"{name} must be positive")
    return result


def _evaluate(
    objective: Callable[[Tensor, Tensor], Tensor],
    gradient: Callable[[Tensor, Tensor], Tensor],
    control: Tensor,
    parameters: Tensor,
) -> tuple[float, Tensor, float, float]:
    objective_value = _finite_scalar("objective", objective(control, parameters))
    current_gradient = gradient(control, parameters)
    _require_vector(
        "objective gradient", current_gradient, dtype=control.dtype, require_finite=False
    )
    if current_gradient.shape != control.shape:
        raise ValueError("objective gradient shape must match control")
    if not bool(torch.isfinite(current_gradient).all()):
        raise _NonFiniteEvaluation("objective gradient must be finite")
    gradient_norm = float(torch.linalg.vector_norm(current_gradient))
    gradient_max = float(current_gradient.abs().max())
    if not math.isfinite(gradient_norm) or not math.isfinite(gradient_max):
        raise _NonFiniteEvaluation("objective gradient norm must be finite")
    return objective_value, current_gradient, gradient_norm, gradient_max


def refine_stationary(
    objective: Callable[[Tensor, Tensor], Tensor],
    control: Tensor,
    p: Tensor,
    *,
    branch_check: Callable[[Tensor, Tensor], tuple[Any, str]],
    max_iterations: int = 8,
    max_backtracks: int = 16,
    pcg_max_iterations: int | None = None,
    trial_acceptance: Callable[[RefinementTrial], tuple[bool, str] | None] | None = None,
    trial_observer: Callable[[dict[str, Any]], None] | None = None,
) -> RefinementResult:
    """Refine a nearby stationary control with exact matrix-free Newton steps.

    Each Newton equation uses exact gradient-JVP products and PCG.  The
    objective is used only to validate finite evaluations; acceptance is based
    on the gradient merit ``||g||²/2`` and its measured Newton slope.  The
    objective and branch callback must be deterministic and must not mutate
    their tensor arguments; the copied parameters protect the caller tensor,
    but cannot isolate shared callback state.  A
    ``ValueError`` from the branch checker rejects one trial; a ``RuntimeError``
    from it propagates to the caller.  Detected nonfinite candidate controls,
    objectives, gradients, and gradient norms reject that trial and continue
    backtracking; malformed outputs and callback exceptions propagate.
    Optional trusted research callbacks receive copies of finite trial
    diagnostics; ``None`` acceptance preserves the usual Armijo decision.
    """
    if not callable(objective):
        raise TypeError("objective must be callable")
    if trial_acceptance is not None and not callable(trial_acceptance):
        raise TypeError("trial_acceptance must be callable")
    if trial_observer is not None and not callable(trial_observer):
        raise TypeError("trial_observer must be callable")
    _require_vector("control", control)
    _require_vector("p", p)
    if control.dtype is not torch.float64 or p.dtype is not torch.float64:
        raise TypeError("local refinement requires float64 control and parameters")
    if control.device.type != "cpu" or p.device != control.device:
        raise TypeError("local refinement requires CPU control and parameters")
    max_iterations_value = _validate_option("max_iterations", max_iterations)
    max_backtracks_value = _validate_option("max_backtracks", max_backtracks)
    if pcg_max_iterations is None:
        pcg_limit = 4 * control.numel()
    else:
        pcg_limit = _validate_option("pcg_max_iterations", pcg_max_iterations)

    parameters = p.detach().clone()
    current = control.detach().clone()
    gradient = torch.func.grad(objective, argnums=0)
    current_branch, _ = _branch(branch_check, current, parameters)
    current_objective, current_gradient, gradient_norm, gradient_max = _evaluate(
        objective, gradient, current, parameters
    )
    if gradient_max < _STATIONARITY_TOLERANCE:
        return RefinementResult(
            control=current,
            gradient_max=gradient_max,
            iterations=0,
            hvp_count=0,
            history=[],
        )

    history: list[dict[str, Any]] = []
    hvp_count = 0

    def record_trial(record: dict[str, Any], candidate: Tensor) -> None:
        if trial_observer is not None:
            record["candidate_control"] = candidate.detach().tolist()
        history.append(record)
        if trial_observer is not None:
            try:
                trial_observer(copy.deepcopy(record))
            except Exception as error:
                raise RefinementCallbackError(
                    f"trial_observer failed: {type(error).__name__}: {error}"
                ) from error

    for iteration in range(1, max_iterations_value + 1):
        def hessian_vector(direction: Tensor) -> Tensor:
            nonlocal hvp_count
            hvp_count += 1
            result = torch.func.jvp(
                lambda c: gradient(c, parameters), (current,), (direction,)
            )[1]
            _require_vector("HVP", result, dtype=current.dtype)
            if result.shape != current.shape:
                raise ValueError("HVP shape must match control")
            return result

        try:
            solve = pcg(
                hessian_vector,
                -current_gradient,
                rtol=_PCG_RELATIVE_TOLERANCE,
                max_iterations=pcg_limit,
            )
        except RuntimeError as error:
            known_pcg_errors = (
                "residual norm is not finite", "preconditioner must be positive definite",
                "operator must be symmetric positive definite", "PCG step is not finite",
                "true residual norm is not finite", "PCG direction update is not finite",
            )
            if str(error).startswith(known_pcg_errors):
                raise RefinementNumericalRefusal(str(error)) from error
            raise
        if not solve.converged:
            raise RefinementNumericalRefusal("matrix-free Newton PCG did not converge")

        step = solve.solution
        _require_vector("Newton step", step, dtype=current.dtype)
        hessian_step = hessian_vector(step)
        linear_residual = hessian_step + current_gradient
        linear_relative = float(torch.linalg.vector_norm(linear_residual)) / gradient_norm
        if not math.isfinite(linear_relative) or linear_relative > _PCG_RELATIVE_TOLERANCE:
            raise RefinementNumericalRefusal("matrix-free Newton PCG true residual exceeds tolerance")
        normalized_slope = float(
            torch.dot(current_gradient / gradient_norm, hessian_step / gradient_norm)
        )
        if not math.isfinite(normalized_slope):
            raise RefinementNumericalRefusal("Newton merit slope is nonfinite")
        if normalized_slope >= 0.0:
            raise RefinementNumericalRefusal("Newton step is not a descent direction for gradient merit")

        accepted = False
        last_trial_norm: float | None = None
        for backtrack in range(max_backtracks_value):
            scale = 0.5**backtrack
            candidate = current + scale * step
            if not bool(torch.isfinite(candidate).all()):
                record_trial({
                    "iteration": iteration,
                    "backtrack": backtrack,
                    "step_scale": scale,
                    "accepted": False,
                    "rejection": "nonfinite_candidate",
                    "hvp_count": hvp_count,
                }, candidate)
                continue
            try:
                branch_signature, _ = _branch(branch_check, candidate, parameters)
            except ValueError as error:
                record_trial({
                    "iteration": iteration,
                    "backtrack": backtrack,
                    "step_scale": scale,
                    "accepted": False,
                    "rejection": "branch",
                    "branch_reason": str(error),
                    "hvp_count": hvp_count,
                }, candidate)
                continue
            try:
                candidate_objective, candidate_gradient, candidate_norm, candidate_max = _evaluate(
                    objective, gradient, candidate, parameters
                )
            except _NonFiniteEvaluation:
                record_trial({
                    "iteration": iteration,
                    "backtrack": backtrack,
                    "step_scale": scale,
                    "accepted": False,
                    "rejection": "nonfinite_candidate",
                    "hvp_count": hvp_count,
                }, candidate)
                continue
            last_trial_norm = candidate_norm
            norm_ratio = candidate_norm / gradient_norm
            armijo_limit_squared = 1.0 + 2.0 * _ARMIJO_CONSTANT * scale * normalized_slope
            armijo_limit = math.sqrt(max(0.0, armijo_limit_squared))
            armijo_ratio = norm_ratio / armijo_limit if armijo_limit > 0.0 else math.inf
            finite_endpoint = (
                math.isfinite(candidate_objective)
                and math.isfinite(candidate_norm)
                and math.isfinite(candidate_max)
                and math.isfinite(norm_ratio)
            )
            armijo_finite = math.isfinite(armijo_ratio)
            accepted_trial = bool(finite_endpoint and armijo_finite and armijo_ratio <= 1.0)
            policy_reason: str | None = None
            if finite_endpoint and trial_acceptance is not None:
                try:
                    decision = trial_acceptance(RefinementTrial(
                        iteration=iteration,
                        backtrack=backtrack,
                        current_objective=current_objective,
                        candidate_objective=candidate_objective,
                        current_gradient_norm=gradient_norm,
                        candidate_gradient_norm=candidate_norm,
                        current_gradient_max=gradient_max,
                        candidate_gradient_max=candidate_max,
                        current_branch=copy.deepcopy(current_branch),
                        candidate_branch=copy.deepcopy(branch_signature),
                        step_scale=scale,
                        normalized_slope=normalized_slope,
                        armijo_ratio=armijo_ratio,
                    ))
                except Exception as error:
                    raise RefinementCallbackError(
                        f"trial_acceptance failed: {type(error).__name__}: {error}"
                    ) from error
                if decision is not None:
                    if (not isinstance(decision, tuple) or len(decision) != 2
                            or type(decision[0]) is not bool
                            or not isinstance(decision[1], str)
                            or not decision[1].strip()):
                        raise RefinementCallbackError(
                            "trial_acceptance must return (bool, nonempty reason) or None"
                        )
                    accepted_trial, policy_reason = decision
            record = {
                "iteration": iteration,
                "backtrack": backtrack,
                "step_scale": scale,
                "accepted": accepted_trial,
                "objective": candidate_objective,
                "gradient_norm": candidate_norm,
                "gradient_max": candidate_max,
                "normalized_slope": normalized_slope,
                "norm_ratio": norm_ratio,
                "armijo_limit": armijo_limit,
                "armijo_ratio": (armijo_ratio if armijo_finite or trial_acceptance is None
                                 else None),
                "linear_relative_residual": linear_relative,
                "pcg_relative_residual": solve.relative_residual,
                "pcg_iterations": solve.iterations,
                "hvp_count": hvp_count,
                "branch": branch_signature,
            }
            if policy_reason is not None:
                record["acceptance_policy"] = "trial_acceptance"
                record["policy_reason"] = policy_reason
                if not accepted_trial:
                    record["rejection"] = "policy"
            record_trial(record, candidate)
            if record["accepted"]:
                current = candidate.detach().clone()
                current_objective = candidate_objective
                current_branch = branch_signature
                current_gradient = candidate_gradient
                gradient_norm = candidate_norm
                gradient_max = candidate_max
                accepted = True
                break
        if not accepted:
            trials = [record for record in history if record["iteration"] == iteration]
            branch_rejections = sum(record.get("rejection") == "branch" for record in trials)
            nonfinite_rejections = sum(
                record.get("rejection") == "nonfinite_candidate" for record in trials
            )
            policy_rejections = sum(record.get("rejection") == "policy" for record in trials)
            finite_armijo_rejections = (
                len(trials) - branch_rejections - nonfinite_rejections - policy_rejections
            )
            branch_reason_counts: dict[str, int] = {}
            for record in trials:
                if record.get("rejection") == "branch":
                    reason = str(record["branch_reason"])
                    branch_reason_counts[reason] = branch_reason_counts.get(reason, 0) + 1
            trial_detail = (
                f"last_trial_gradient_norm={last_trial_norm}"
                if last_trial_norm is not None
                else "no finite candidate evaluation"
            )
            policy_detail = (
                f"; policy_rejections={policy_rejections}"
                if trial_acceptance is not None else ""
            )
            step_name = "Armijo" if trial_acceptance is None else "admissible"
            raise RefinementNumericalRefusal(
                f"stationarity refinement failed to find an {step_name} step: "
                f"iteration={iteration}; {trial_detail}; "
                f"branch_rejections={branch_rejections}; "
                f"branch_reason_counts={branch_reason_counts}; "
                f"nonfinite_candidate_rejections={nonfinite_rejections}; "
                f"finite_armijo_rejections={finite_armijo_rejections}{policy_detail}"
            )
        if gradient_max < _STATIONARITY_TOLERANCE:
            return RefinementResult(
                control=current,
                gradient_max=gradient_max,
                iterations=iteration,
                hvp_count=hvp_count,
                history=history,
            )

    raise RefinementNumericalRefusal(
        "stationarity refinement iteration budget exhausted: "
        f"gradient_max={gradient_max}"
    )
