"""Command-line entry point for NumPy radar volumes."""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any

import numpy as np
from numpy.typing import NDArray
import torch

from .calibration import (
    OperationalCalibrationManifest,
    OperationalDataIdentity,
)
from .nowcast import (
    ForecastResult,
    NowcastConfig,
    RadarGridTimeContract,
    nowcast,
)
from .run_artifact import (
    atomic_savez_compressed,
    forecast_run_arrays,
    seal_forecast_run_arrays,
)
from .variational import (
    AnalysisConfig,
    AnalysisResult,
    estimate_common_bias_resources,
    observation_common_bias_group_map_digest,
    observation_common_bias_mode_weights_digest,
    variational_nowcast,
)


OUTPUT_CONTRACT_VERSION = "nowcast-npz-v76"


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Forecast 18 radar frames from 3 ten-minute dBZ frames."
    )
    parser.add_argument("input", type=Path, help=".npy file shaped [3, H, W]")
    parser.add_argument("output", type=Path, help="output .npz file")
    parser.add_argument("--min-dbz", type=float, default=-10.0)
    parser.add_argument("--max-dbz", type=float, default=70.0)
    parser.add_argument("--echo-threshold-dbz", type=float, default=5.0)
    parser.add_argument(
        "--min-publish-support",
        type=float,
        default=0.95,
        help="minimum propagated source support required for publication",
    )
    parser.add_argument(
        "--minimum-publish-verified-support",
        type=float,
        help="minimum pair-verified support required for publication",
    )
    parser.add_argument(
        "--minimum-publish-confidence",
        type=float,
        help="minimum lead-dependent confidence required for publication",
    )
    parser.add_argument(
        "--minimum-publish-observation-verified-support",
        type=float,
        help="minimum radar-verified support required for publication",
    )
    parser.add_argument(
        "--maximum-publish-background-fraction",
        type=float,
        help="maximum current-state background fraction for publication",
    )
    parser.add_argument(
        "--forecast-velocity-uncertainty-mps",
        type=float,
        help="minimum forecast velocity uncertainty",
    )
    parser.add_argument(
        "--forecast-confidence-length-scale-m",
        type=float,
        help="position-error scale used by live forecast confidence",
    )
    parser.add_argument(
        "--forecast-log-growth-uncertainty-per-step",
        type=float,
        help="minimum per-step uncertainty of effective log-echo tendency",
    )
    parser.add_argument(
        "--forecast-log-growth-confidence-scale",
        type=float,
        help="log-echo uncertainty scale used by live confidence",
    )
    parser.add_argument(
        "--p1-motion-saturation-safe-margin-mps",
        type=float,
        help="minimum safe P1 margin below the physical speed limit",
    )
    parser.add_argument(
        "--p1-growth-saturation-safe-margin-per-step",
        type=float,
        help="minimum safe P1 margin below the log-growth limit",
    )
    parser.add_argument(
        "--p1-posterior-saturation-sigma-multiplier",
        type=float,
        help="posterior standard deviations required inside P1 limits",
    )
    parser.add_argument(
        "--p1-saturation-uncertainty-multiplier",
        type=float,
        help="maximum saturation uncertainty in model-error multiples",
    )
    parser.add_argument(
        "--single-pair-uncertainty-multiplier",
        type=float,
        help="uncertainty multiplier when only one tendency pair is usable",
    )
    parser.add_argument(
        "--persistence-uncertainty-multiplier",
        type=float,
        help="uncertainty multiplier when no tendency pair is usable",
    )
    parser.add_argument(
        "--background-tendency-age-uncertainty-scale-minutes",
        type=float,
        help="background age that adds one dynamics uncertainty multiple",
    )
    parser.add_argument(
        "--variational",
        action="store_true",
        help="jointly analyze the three frames before forecasting",
    )
    parser.add_argument(
        "--mode",
        choices=("research", "operational"),
        default="research",
        help="research diagnostics or a calibrated fail-closed P0/P1 profile",
    )
    parser.add_argument(
        "--operational-calibration-id",
        help="optional assertion matching the calibration manifest identifier",
    )
    parser.add_argument(
        "--operational-calibration-manifest",
        type=Path,
        help="canonical hindcast calibration provenance manifest",
    )
    parser.add_argument(
        "--approved-operational-calibration-manifest-digest",
        help="deployment allowlist entry for the calibration manifest",
    )
    parser.add_argument("--radar-class")
    parser.add_argument("--qc-pipeline-digest")
    parser.add_argument("--observation-error-model-digest")
    parser.add_argument("--background-model-digest")
    parser.add_argument(
        "--observation-std-dbz",
        type=float,
        help="observation error used by --variational",
    )
    parser.add_argument(
        "--observation-common-bias-std-dbz",
        type=float,
        help="additive radar-bias standard deviation used by --variational",
    )
    parser.add_argument(
        "--observation-common-bias-scope",
        choices=("per_frame", "all_times"),
        help="whether the additive radar-bias mode varies by input frame",
    )
    parser.add_argument(
        "--observation-common-bias-tile-size-px",
        type=int,
        help=(
            "square common-bias tile size; zero means one domain-wide mode"
        ),
    )
    parser.add_argument(
        "--observation-common-bias-group-map",
        type=Path,
        help=(
            "optional integer .npy site/group map shaped [H,W] or [3,H,W]"
        ),
    )
    parser.add_argument(
        "--observation-common-bias-mode-weights",
        type=Path,
        help=(
            "optional float .npy overlapping modes shaped [K,H,W] or "
            "[3,K,H,W]"
        ),
    )
    parser.add_argument(
        "--motion-increment-scale-mps",
        type=float,
        help="projected x/y velocity increment scale used by --variational",
    )
    parser.add_argument(
        "--amplitude-information-policy",
        choices=("research_degraded", "operational_fallback"),
        help=(
            "P1 behavior when precursor amplitude information is insufficient"
        ),
    )
    parser.add_argument(
        "--amplitude-confidence-policy",
        choices=("research_degraded", "operational_fallback"),
        help="P1 behavior when amplitude amount, area, or growth is implausible",
    )
    parser.add_argument("--maximum-detected-error-std", type=float)
    parser.add_argument("--minimum-local-verification-precision", type=float)
    parser.add_argument(
        "--maximum-local-analysis-verification-error-dbz",
        type=float,
    )
    parser.add_argument("--maximum-unresolved-amplitude-fraction", type=float)
    parser.add_argument("--minimum-amplitude-total-quality-weight", type=float)
    parser.add_argument("--minimum-amplitude-effective-pixel-count", type=float)
    parser.add_argument(
        "--minimum-integrated-echo-ratio-for-confidence",
        type=float,
    )
    parser.add_argument(
        "--maximum-integrated-echo-ratio-for-confidence",
        type=float,
    )
    parser.add_argument(
        "--minimum-soft-echo-area-ratio-for-confidence",
        type=float,
    )
    parser.add_argument(
        "--maximum-soft-echo-area-ratio-for-confidence",
        type=float,
    )
    parser.add_argument(
        "--maximum-established-excess-growth-fraction-for-confidence",
        type=float,
    )
    parser.add_argument(
        "--minimum-object-count-ratio-for-confidence",
        type=float,
    )
    parser.add_argument(
        "--qc-mask",
        type=Path,
        help="optional boolean .npy mask shaped [3, H, W]",
    )
    parser.add_argument(
        "--background",
        type=Path,
        help="optional time-aligned previous-cycle .npy background",
    )
    parser.add_argument(
        "--background-age-minutes",
        type=float,
        help="required age of --background in minutes",
    )
    parser.add_argument(
        "--maximum-background-age-minutes",
        type=float,
        default=60.0,
    )
    parser.add_argument("--maximum-motion-speed-mps", type=float)
    parser.add_argument("--minimum-phase-correlation-psr", type=float)
    parser.add_argument("--pair-echo-dilation-m", type=float)
    parser.add_argument("--phase-correlation-sidelobe-radius-m", type=float)
    parser.add_argument(
        "--maximum-pair-motion-disagreement-px",
        type=float,
    )
    parser.add_argument(
        "--maximum-pair-velocity-disagreement-mps",
        type=float,
    )
    parser.add_argument(
        "--maximum-pair-growth-disagreement",
        type=float,
    )
    parser.add_argument(
        "--maximum-local-growth-log-error-per-step",
        type=float,
    )
    parser.add_argument(
        "--minimum-pair-psr-advantage",
        type=float,
    )
    parser.add_argument(
        "--minimum-pair-confidence-ratio",
        type=float,
    )
    parser.add_argument(
        "--long-pair-confidence-penalty",
        type=float,
    )
    parser.add_argument("--minimum-growth-overlap-support", type=float)
    parser.add_argument("--minimum-growth-overlap-area-km2", type=float)
    parser.add_argument("--valid-times", nargs=3)
    parser.add_argument("--background-valid-times", nargs=3)
    parser.add_argument("--dx-m", type=float)
    parser.add_argument("--dy-m", type=float)
    parser.add_argument("--projection")
    parser.add_argument("--grid-hash")
    parser.add_argument(
        "--pixel-to-projected-matrix-m",
        type=float,
        nargs=4,
        metavar=("XX", "XR", "YX", "YR"),
    )
    parser.add_argument("--causal-support-uncertainty-m", type=float)
    parser.add_argument("--amplitude-displacement-tolerance-m", type=float)
    parser.add_argument(
        "--audit",
        action="store_true",
        help="include optional positivity and transport audits",
    )
    args = parser.parse_args()
    operational_calibration_manifest = None
    if args.operational_calibration_manifest is not None:
        try:
            operational_calibration_manifest = (
                OperationalCalibrationManifest.load(
                    args.operational_calibration_manifest
                )
            )
        except ValueError as error:
            parser.error(str(error))
    operational_data_identity = None
    identity_values = (
        args.radar_class,
        args.qc_pipeline_digest,
        args.observation_error_model_digest,
        args.background_model_digest,
    )
    if any(value is not None for value in identity_values):
        if any(value is None for value in identity_values):
            parser.error("operational data identity must be complete")
        try:
            operational_data_identity = OperationalDataIdentity(
                radar_class=args.radar_class,
                qc_pipeline_digest=args.qc_pipeline_digest,
                observation_error_model_digest=(
                    args.observation_error_model_digest
                ),
                background_model_digest=args.background_model_digest,
            )
        except ValueError as error:
            parser.error(str(error))
    if args.output.suffix != ".npz":
        parser.error("output path must end with .npz")
    if (
        args.mode != "operational"
        and (
            args.operational_calibration_id is not None
            or operational_calibration_manifest is not None
            or args.approved_operational_calibration_manifest_digest is not None
            or operational_data_identity is not None
        )
    ):
        parser.error(
            "operational calibration options require --mode operational"
        )
    if args.mode == "operational" and operational_calibration_manifest is None:
        parser.error(
            "operational mode requires --operational-calibration-manifest"
        )
    if (
        args.mode == "operational"
        and args.approved_operational_calibration_manifest_digest is None
    ):
        parser.error(
            "operational mode requires "
            "--approved-operational-calibration-manifest-digest"
        )
    if (
        operational_calibration_manifest is not None
        and args.operational_calibration_id is not None
        and args.operational_calibration_id
        != operational_calibration_manifest.calibration_id
    ):
        parser.error("operational calibration identifier mismatch")
    if operational_calibration_manifest is not None and (
        args.approved_operational_calibration_manifest_digest
        != operational_calibration_manifest.digest
    ):
        parser.error("operational calibration manifest is not approved")
    if operational_calibration_manifest is not None and (
        operational_calibration_manifest.profile_kind
        != ("p1" if args.variational else "p0")
    ):
        parser.error("operational calibration manifest profile kind mismatch")
    if (
        operational_calibration_manifest is not None
        and operational_data_identity
        != operational_calibration_manifest.data_identity
    ):
        parser.error("operational data identity is not calibrated")
    if not args.variational and (
        args.amplitude_information_policy is not None
        or args.amplitude_confidence_policy is not None
        or args.observation_std_dbz is not None
        or args.observation_common_bias_std_dbz is not None
        or args.observation_common_bias_scope is not None
        or args.observation_common_bias_tile_size_px is not None
        or args.observation_common_bias_group_map is not None
        or args.observation_common_bias_mode_weights is not None
        or args.motion_increment_scale_mps is not None
        or args.maximum_detected_error_std is not None
        or args.minimum_local_verification_precision is not None
        or args.maximum_local_analysis_verification_error_dbz is not None
        or args.maximum_unresolved_amplitude_fraction is not None
        or args.minimum_amplitude_total_quality_weight is not None
        or args.minimum_amplitude_effective_pixel_count is not None
        or args.minimum_integrated_echo_ratio_for_confidence is not None
        or args.maximum_integrated_echo_ratio_for_confidence is not None
        or args.minimum_soft_echo_area_ratio_for_confidence is not None
        or args.maximum_soft_echo_area_ratio_for_confidence is not None
        or (
            args.maximum_established_excess_growth_fraction_for_confidence
            is not None
        )
        or args.minimum_object_count_ratio_for_confidence is not None
        or args.causal_support_uncertainty_m is not None
        or args.amplitude_displacement_tolerance_m is not None
    ):
        parser.error(
            "P1 analysis settings require --variational"
        )

    frames = np.load(args.input, allow_pickle=False)
    if frames.ndim != 3 or frames.shape[0] != 3:
        raise ValueError("input must have shape [3, height, width]")
    qc_mask = None
    if args.qc_mask is not None:
        qc_array = np.load(args.qc_mask, allow_pickle=False)
        if qc_array.shape != frames.shape or qc_array.dtype != np.bool_:
            raise ValueError("QC mask must be boolean with the input shape")
        qc_mask = torch.as_tensor(qc_array, dtype=torch.bool)
    common_bias_group_index = None
    common_bias_group_digest = None
    if args.observation_common_bias_group_map is not None:
        group_array = np.load(
            args.observation_common_bias_group_map,
            allow_pickle=False,
        )
        if (
            group_array.shape not in (frames.shape[1:], frames.shape)
            or not np.issubdtype(group_array.dtype, np.integer)
        ):
            raise ValueError(
                "common-bias group map must be integer with shape [H, W] "
                "or [3, H, W]"
            )
        common_bias_group_index = torch.as_tensor(
            group_array,
            dtype=torch.long,
        )
        common_bias_group_digest = observation_common_bias_group_map_digest(
            common_bias_group_index,
            temporal_scope=(
                AnalysisConfig().observation_common_bias_scope
                if args.observation_common_bias_scope is None
                else args.observation_common_bias_scope
            ),
        )
    common_bias_mode_weights = None
    common_bias_mode_digest = None
    if args.observation_common_bias_mode_weights is not None:
        mode_array = np.load(
            args.observation_common_bias_mode_weights,
            allow_pickle=False,
            mmap_mode="r",
        )
        if (
            mode_array.ndim not in (3, 4)
            or tuple(mode_array.shape[-2:]) != frames.shape[-2:]
            or (mode_array.ndim == 4 and mode_array.shape[0] != 3)
            or not np.issubdtype(mode_array.dtype, np.floating)
        ):
            raise ValueError(
                "common-bias mode weights must be floating with shape "
                "[K,H,W] or [3,K,H,W]"
            )
        common_bias_scope = (
            AnalysisConfig().observation_common_bias_scope
            if args.observation_common_bias_scope is None
            else args.observation_common_bias_scope
        )
        resource_estimate = estimate_common_bias_resources(
            tuple(mode_array.shape),
            (frames.shape[0], frames.shape[1], frames.shape[2]),
            dtype=torch.float32,
            temporal_scope=common_bias_scope,
        )
        if not resource_estimate.within_budget:
            reasons = ", ".join(resource_estimate.rejection_reasons)
            raise ValueError(
                f"common-bias mode preflight rejected: {reasons}"
            )
        common_bias_mode_weights = torch.as_tensor(
            np.array(mode_array, copy=True),
            dtype=torch.float32,
        )
        common_bias_mode_digest = (
            observation_common_bias_mode_weights_digest(
                common_bias_mode_weights
            )
        )
    background = None
    if args.background is not None:
        background_array = np.load(args.background, allow_pickle=False)
        if background_array.shape != frames.shape:
            raise ValueError("background must have the input shape")
        background = torch.as_tensor(background_array, dtype=torch.float32)
    if args.background_age_minutes is not None and background is None:
        parser.error("--background-age-minutes requires --background")
    if background is not None and args.background_age_minutes is None:
        parser.error("--background requires --background-age-minutes")
    grid_time_contract = _grid_time_contract_from_args(
        parser,
        args,
        background_present=background is not None,
    )
    if args.mode == "operational":
        _require_operational_values(
            parser,
            _operational_nowcast_calibrated_values(
                args,
                operational_calibration_manifest,
                operational_data_identity,
            ),
            grid_time_contract,
        )

    default_nowcast_config = NowcastConfig()
    config = NowcastConfig(
        min_dbz=args.min_dbz,
        max_dbz=args.max_dbz,
        echo_threshold_dbz=args.echo_threshold_dbz,
        min_publish_support=args.min_publish_support,
        minimum_publish_verified_support=(
            args.minimum_publish_verified_support
        ),
        minimum_publish_confidence=args.minimum_publish_confidence,
        minimum_publish_observation_verified_support=(
            args.minimum_publish_observation_verified_support
        ),
        maximum_publish_background_fraction=(
            args.maximum_publish_background_fraction
        ),
        forecast_velocity_uncertainty_mps=(
            default_nowcast_config.forecast_velocity_uncertainty_mps
            if args.forecast_velocity_uncertainty_mps is None
            else args.forecast_velocity_uncertainty_mps
        ),
        forecast_confidence_length_scale_m=(
            default_nowcast_config.forecast_confidence_length_scale_m
            if args.forecast_confidence_length_scale_m is None
            else args.forecast_confidence_length_scale_m
        ),
        forecast_log_growth_uncertainty_per_step=(
            default_nowcast_config.forecast_log_growth_uncertainty_per_step
            if args.forecast_log_growth_uncertainty_per_step is None
            else args.forecast_log_growth_uncertainty_per_step
        ),
        forecast_log_growth_confidence_scale=(
            default_nowcast_config.forecast_log_growth_confidence_scale
            if args.forecast_log_growth_confidence_scale is None
            else args.forecast_log_growth_confidence_scale
        ),
        p1_motion_saturation_safe_margin_mps=(
            default_nowcast_config.p1_motion_saturation_safe_margin_mps
            if args.p1_motion_saturation_safe_margin_mps is None
            else args.p1_motion_saturation_safe_margin_mps
        ),
        p1_growth_saturation_safe_margin_per_step=(
            default_nowcast_config.p1_growth_saturation_safe_margin_per_step
            if args.p1_growth_saturation_safe_margin_per_step is None
            else args.p1_growth_saturation_safe_margin_per_step
        ),
        p1_posterior_saturation_sigma_multiplier=(
            default_nowcast_config.p1_posterior_saturation_sigma_multiplier
            if args.p1_posterior_saturation_sigma_multiplier is None
            else args.p1_posterior_saturation_sigma_multiplier
        ),
        p1_saturation_uncertainty_multiplier=(
            default_nowcast_config.p1_saturation_uncertainty_multiplier
            if args.p1_saturation_uncertainty_multiplier is None
            else args.p1_saturation_uncertainty_multiplier
        ),
        single_pair_uncertainty_multiplier=(
            default_nowcast_config.single_pair_uncertainty_multiplier
            if args.single_pair_uncertainty_multiplier is None
            else args.single_pair_uncertainty_multiplier
        ),
        persistence_uncertainty_multiplier=(
            default_nowcast_config.persistence_uncertainty_multiplier
            if args.persistence_uncertainty_multiplier is None
            else args.persistence_uncertainty_multiplier
        ),
        background_tendency_age_uncertainty_scale_minutes=(
            default_nowcast_config
            .background_tendency_age_uncertainty_scale_minutes
            if args.background_tendency_age_uncertainty_scale_minutes is None
            else args.background_tendency_age_uncertainty_scale_minutes
        ),
        maximum_background_age_minutes=(
            args.maximum_background_age_minutes
        ),
        maximum_motion_speed_mps=args.maximum_motion_speed_mps,
        minimum_phase_correlation_psr=(
            default_nowcast_config.minimum_phase_correlation_psr
            if args.minimum_phase_correlation_psr is None
            else args.minimum_phase_correlation_psr
        ),
        pair_echo_dilation_m=args.pair_echo_dilation_m,
        phase_correlation_sidelobe_radius_m=(
            args.phase_correlation_sidelobe_radius_m
        ),
        maximum_pair_motion_disagreement_px=(
            default_nowcast_config.maximum_pair_motion_disagreement_px
            if args.maximum_pair_motion_disagreement_px is None
            else args.maximum_pair_motion_disagreement_px
        ),
        maximum_pair_velocity_disagreement_mps=(
            default_nowcast_config.maximum_pair_velocity_disagreement_mps
            if args.maximum_pair_velocity_disagreement_mps is None
            else args.maximum_pair_velocity_disagreement_mps
        ),
        maximum_pair_growth_disagreement=(
            default_nowcast_config.maximum_pair_growth_disagreement
            if args.maximum_pair_growth_disagreement is None
            else args.maximum_pair_growth_disagreement
        ),
        maximum_local_growth_log_error_per_step=(
            default_nowcast_config.maximum_local_growth_log_error_per_step
            if args.maximum_local_growth_log_error_per_step is None
            else args.maximum_local_growth_log_error_per_step
        ),
        minimum_pair_psr_advantage=(
            default_nowcast_config.minimum_pair_psr_advantage
            if args.minimum_pair_psr_advantage is None
            else args.minimum_pair_psr_advantage
        ),
        minimum_pair_confidence_ratio=(
            default_nowcast_config.minimum_pair_confidence_ratio
            if args.minimum_pair_confidence_ratio is None
            else args.minimum_pair_confidence_ratio
        ),
        long_pair_confidence_penalty=(
            default_nowcast_config.long_pair_confidence_penalty
            if args.long_pair_confidence_penalty is None
            else args.long_pair_confidence_penalty
        ),
        minimum_growth_overlap_support=(
            default_nowcast_config.minimum_growth_overlap_support
            if args.minimum_growth_overlap_support is None
            else args.minimum_growth_overlap_support
        ),
        minimum_growth_overlap_area_km2=(
            args.minimum_growth_overlap_area_km2
        ),
    )
    frames_tensor = torch.as_tensor(frames, dtype=torch.float32)
    if args.variational:
        analysis_config = _analysis_config_from_args(
            parser,
            args,
            grid_time_contract=grid_time_contract,
            operational_calibration_manifest=(
                operational_calibration_manifest
            ),
            operational_data_identity=operational_data_identity,
            common_bias_group_map_digest=common_bias_group_digest,
            common_bias_mode_weights_digest=common_bias_mode_digest,
        )
        result, analysis = variational_nowcast(
            frames_tensor,
            nowcast_config=config,
            analysis_config=analysis_config,
            observation_std_dbz=analysis_config.observation_std_dbz,
            qc_mask=qc_mask,
            observation_common_bias_group_index=common_bias_group_index,
            observation_common_bias_mode_weights=common_bias_mode_weights,
            background_frames_dbz=background,
            background_age_minutes=args.background_age_minutes,
            grid_time_contract=grid_time_contract,
            operational_calibration_manifest=(
                operational_calibration_manifest
            ),
            operational_calibration_approval_digest=(
                args.approved_operational_calibration_manifest_digest
            ),
            operational_data_identity=operational_data_identity,
            audit=args.audit,
        )
    else:
        result = nowcast(
            frames_tensor,
            config,
            qc_mask=qc_mask,
            background_frames_dbz=background,
            background_age_minutes=args.background_age_minutes,
            grid_time_contract=grid_time_contract,
            operational_calibration_manifest=(
                operational_calibration_manifest
            ),
            operational_calibration_approval_digest=(
                args.approved_operational_calibration_manifest_digest
            ),
            operational_data_identity=operational_data_identity,
            audit=args.audit,
        )
        analysis = None

    args.output.parent.mkdir(parents=True, exist_ok=True)
    output = _output_arrays(result, analysis, config)
    if args.audit:
        output.update(_audit_arrays(result, analysis))
    atomic_savez_compressed(
        args.output,
        seal_forecast_run_arrays(output),
    )

    dy, dx = result.state.displacement_yx.tolist()
    print(
        f"saved {config.forecast_steps} frames to {args.output} "
        f"(motion dy={dy:.2f}, dx={dx:.2f} px/step)"
    )


def _operational_nowcast_calibrated_values(
    args: argparse.Namespace,
    manifest: OperationalCalibrationManifest | None,
    data_identity: OperationalDataIdentity | None,
) -> dict[str, object | None]:
    return {
        "--operational-calibration-manifest": manifest,
        "--approved-operational-calibration-manifest-digest": (
            args.approved_operational_calibration_manifest_digest
        ),
        "operational data identity": data_identity,
        "--minimum-phase-correlation-psr": args.minimum_phase_correlation_psr,
        "--pair-echo-dilation-m": args.pair_echo_dilation_m,
        "--phase-correlation-sidelobe-radius-m": (
            args.phase_correlation_sidelobe_radius_m
        ),
        "--long-pair-confidence-penalty": args.long_pair_confidence_penalty,
        "--maximum-pair-velocity-disagreement-mps": (
            args.maximum_pair_velocity_disagreement_mps
        ),
        "--maximum-pair-growth-disagreement": (
            args.maximum_pair_growth_disagreement
        ),
        "--maximum-local-growth-log-error-per-step": (
            args.maximum_local_growth_log_error_per_step
        ),
        "--minimum-pair-psr-advantage": args.minimum_pair_psr_advantage,
        "--minimum-pair-confidence-ratio": (
            args.minimum_pair_confidence_ratio
        ),
        "--minimum-growth-overlap-support": (
            args.minimum_growth_overlap_support
        ),
        "--minimum-growth-overlap-area-km2": (
            args.minimum_growth_overlap_area_km2
        ),
        "--minimum-publish-verified-support": (
            args.minimum_publish_verified_support
        ),
        "--minimum-publish-confidence": args.minimum_publish_confidence,
        "--minimum-publish-observation-verified-support": (
            args.minimum_publish_observation_verified_support
        ),
        "--maximum-publish-background-fraction": (
            args.maximum_publish_background_fraction
        ),
        "--forecast-velocity-uncertainty-mps": (
            args.forecast_velocity_uncertainty_mps
        ),
        "--forecast-confidence-length-scale-m": (
            args.forecast_confidence_length_scale_m
        ),
        "--forecast-log-growth-uncertainty-per-step": (
            args.forecast_log_growth_uncertainty_per_step
        ),
        "--forecast-log-growth-confidence-scale": (
            args.forecast_log_growth_confidence_scale
        ),
        "--single-pair-uncertainty-multiplier": (
            args.single_pair_uncertainty_multiplier
        ),
        "--persistence-uncertainty-multiplier": (
            args.persistence_uncertainty_multiplier
        ),
        "--background-tendency-age-uncertainty-scale-minutes": (
            args.background_tendency_age_uncertainty_scale_minutes
        ),
        "--maximum-motion-speed-mps": args.maximum_motion_speed_mps,
    }


def _require_operational_values(
    parser: argparse.ArgumentParser,
    values: dict[str, object | None],
    grid_time_contract: RadarGridTimeContract | None,
) -> None:
    missing = [name for name, value in values.items() if value is None]
    if grid_time_contract is None:
        missing.append("grid/time metadata")
    if missing:
        parser.error(
            "operational mode requires explicitly calibrated values for: "
            + ", ".join(missing)
        )


def _analysis_config_from_args(
    parser: argparse.ArgumentParser,
    args: argparse.Namespace,
    *,
    grid_time_contract: RadarGridTimeContract | None,
    operational_calibration_manifest: (
        OperationalCalibrationManifest | None
    ),
    operational_data_identity: OperationalDataIdentity | None,
    common_bias_group_map_digest: str | None,
    common_bias_mode_weights_digest: str | None,
) -> AnalysisConfig:
    defaults = AnalysisConfig()
    calibrated_values = {
        **_operational_nowcast_calibrated_values(
            args,
            operational_calibration_manifest,
            operational_data_identity,
        ),
        "--observation-std-dbz": args.observation_std_dbz,
        "--observation-common-bias-std-dbz": (
            args.observation_common_bias_std_dbz
        ),
        "--observation-common-bias-scope": (
            args.observation_common_bias_scope
        ),
        "--observation-common-bias-tile-size-px": (
            args.observation_common_bias_tile_size_px
        ),
        "--p1-motion-saturation-safe-margin-mps": (
            args.p1_motion_saturation_safe_margin_mps
        ),
        "--p1-growth-saturation-safe-margin-per-step": (
            args.p1_growth_saturation_safe_margin_per_step
        ),
        "--p1-posterior-saturation-sigma-multiplier": (
            args.p1_posterior_saturation_sigma_multiplier
        ),
        "--p1-saturation-uncertainty-multiplier": (
            args.p1_saturation_uncertainty_multiplier
        ),
        "--motion-increment-scale-mps": args.motion_increment_scale_mps,
        "--causal-support-uncertainty-m": (
            args.causal_support_uncertainty_m
        ),
        "--amplitude-displacement-tolerance-m": (
            args.amplitude_displacement_tolerance_m
        ),
        "--maximum-detected-error-std": args.maximum_detected_error_std,
        "--minimum-local-verification-precision": (
            args.minimum_local_verification_precision
        ),
        "--maximum-local-analysis-verification-error-dbz": (
            args.maximum_local_analysis_verification_error_dbz
        ),
        "--maximum-unresolved-amplitude-fraction": (
            args.maximum_unresolved_amplitude_fraction
        ),
        "--minimum-amplitude-total-quality-weight": (
            args.minimum_amplitude_total_quality_weight
        ),
        "--minimum-amplitude-effective-pixel-count": (
            args.minimum_amplitude_effective_pixel_count
        ),
        "--minimum-integrated-echo-ratio-for-confidence": (
            args.minimum_integrated_echo_ratio_for_confidence
        ),
        "--maximum-integrated-echo-ratio-for-confidence": (
            args.maximum_integrated_echo_ratio_for_confidence
        ),
        "--minimum-soft-echo-area-ratio-for-confidence": (
            args.minimum_soft_echo_area_ratio_for_confidence
        ),
        "--maximum-soft-echo-area-ratio-for-confidence": (
            args.maximum_soft_echo_area_ratio_for_confidence
        ),
        "--maximum-established-excess-growth-fraction-for-confidence": (
            args.maximum_established_excess_growth_fraction_for_confidence
        ),
        "--minimum-object-count-ratio-for-confidence": (
            args.minimum_object_count_ratio_for_confidence
        ),
    }
    if args.mode == "operational":
        _require_operational_values(
            parser,
            calibrated_values,
            grid_time_contract,
        )
        if args.amplitude_information_policy not in (
            None,
            "operational_fallback",
        ) or args.amplitude_confidence_policy not in (
            None,
            "operational_fallback",
        ):
            parser.error(
                "operational mode requires operational_fallback amplitude "
                "policies"
            )
    information_policy = args.amplitude_information_policy or (
        "operational_fallback"
        if args.mode == "operational"
        else defaults.amplitude_information_policy
    )
    confidence_policy = args.amplitude_confidence_policy or (
        "operational_fallback"
        if args.mode == "operational"
        else defaults.amplitude_confidence_policy
    )

    def value(name: str, default: float) -> float:
        candidate = getattr(args, name)
        return default if candidate is None else candidate

    return AnalysisConfig(
        execution_mode=args.mode,
        operational_calibration_id=(
            None
            if operational_calibration_manifest is None
            else operational_calibration_manifest.calibration_id
        ),
        detection_limit_dbz=args.echo_threshold_dbz,
        observation_std_dbz=value(
            "observation_std_dbz",
            defaults.observation_std_dbz,
        ),
        observation_common_bias_std_dbz=value(
            "observation_common_bias_std_dbz",
            defaults.observation_common_bias_std_dbz,
        ),
        observation_common_bias_scope=(
            defaults.observation_common_bias_scope
            if args.observation_common_bias_scope is None
            else args.observation_common_bias_scope
        ),
        observation_common_bias_tile_size_px=(
            defaults.observation_common_bias_tile_size_px
            if args.observation_common_bias_tile_size_px is None
            else args.observation_common_bias_tile_size_px
        ),
        observation_common_bias_group_map_digest=(
            common_bias_group_map_digest
        ),
        observation_common_bias_mode_weights_digest=(
            common_bias_mode_weights_digest
        ),
        motion_increment_scale_mps=args.motion_increment_scale_mps,
        maximum_latest_detected_error_std=value(
            "maximum_detected_error_std",
            defaults.maximum_latest_detected_error_std,
        ),
        minimum_local_verification_precision=value(
            "minimum_local_verification_precision",
            defaults.minimum_local_verification_precision,
        ),
        maximum_local_analysis_verification_error_dbz=value(
            "maximum_local_analysis_verification_error_dbz",
            defaults.maximum_local_analysis_verification_error_dbz,
        ),
        maximum_unresolved_amplitude_fraction=value(
            "maximum_unresolved_amplitude_fraction",
            defaults.maximum_unresolved_amplitude_fraction,
        ),
        minimum_amplitude_total_quality_weight=value(
            "minimum_amplitude_total_quality_weight",
            defaults.minimum_amplitude_total_quality_weight,
        ),
        minimum_amplitude_effective_pixel_count=value(
            "minimum_amplitude_effective_pixel_count",
            defaults.minimum_amplitude_effective_pixel_count,
        ),
        amplitude_information_policy=information_policy,
        amplitude_confidence_policy=confidence_policy,
        minimum_integrated_echo_ratio_for_confidence=value(
            "minimum_integrated_echo_ratio_for_confidence",
            defaults.minimum_integrated_echo_ratio_for_confidence,
        ),
        maximum_integrated_echo_ratio_for_confidence=value(
            "maximum_integrated_echo_ratio_for_confidence",
            defaults.maximum_integrated_echo_ratio_for_confidence,
        ),
        minimum_soft_echo_area_ratio_for_confidence=value(
            "minimum_soft_echo_area_ratio_for_confidence",
            defaults.minimum_soft_echo_area_ratio_for_confidence,
        ),
        maximum_soft_echo_area_ratio_for_confidence=value(
            "maximum_soft_echo_area_ratio_for_confidence",
            defaults.maximum_soft_echo_area_ratio_for_confidence,
        ),
        maximum_established_excess_growth_fraction_for_confidence=value(
            "maximum_established_excess_growth_fraction_for_confidence",
            defaults.maximum_established_excess_growth_fraction_for_confidence,
        ),
        minimum_object_count_ratio_for_confidence=value(
            "minimum_object_count_ratio_for_confidence",
            defaults.minimum_object_count_ratio_for_confidence,
        ),
        causal_support_uncertainty_m=args.causal_support_uncertainty_m,
        amplitude_displacement_tolerance_m=(
            args.amplitude_displacement_tolerance_m
        ),
    )


def _grid_time_contract_from_args(
    parser: argparse.ArgumentParser,
    args: argparse.Namespace,
    *,
    background_present: bool,
) -> RadarGridTimeContract | None:
    required = (
        args.valid_times,
        args.dx_m,
        args.dy_m,
        args.projection,
        args.grid_hash,
    )
    if not any(value is not None for value in required):
        physical_metadata = (
            args.background_valid_times,
            args.pixel_to_projected_matrix_m,
            args.maximum_motion_speed_mps,
            args.pair_echo_dilation_m,
            args.phase_correlation_sidelobe_radius_m,
            args.maximum_pair_velocity_disagreement_mps,
            args.motion_increment_scale_mps,
            args.minimum_growth_overlap_area_km2,
            args.causal_support_uncertainty_m,
            args.amplitude_displacement_tolerance_m,
        )
        if any(value is not None for value in physical_metadata):
            parser.error("physical settings require grid/time metadata")
        return None
    if any(value is None for value in required):
        parser.error(
            "--valid-times, --dx-m, --dy-m, --projection, and --grid-hash "
            "must be provided together"
        )
    if background_present != (args.background_valid_times is not None):
        parser.error(
            "--background-valid-times must match --background availability"
        )
    try:
        return RadarGridTimeContract(
            valid_times=tuple(args.valid_times),
            dx_m=args.dx_m,
            dy_m=args.dy_m,
            projection=args.projection,
            grid_hash=args.grid_hash,
            pixel_to_projected_matrix_m=(
                None
                if args.pixel_to_projected_matrix_m is None
                else (
                    (
                        args.pixel_to_projected_matrix_m[0],
                        args.pixel_to_projected_matrix_m[1],
                    ),
                    (
                        args.pixel_to_projected_matrix_m[2],
                        args.pixel_to_projected_matrix_m[3],
                    ),
                )
            ),
            background_valid_times=(
                None
                if args.background_valid_times is None
                else tuple(args.background_valid_times)
            ),
        )
    except (TypeError, ValueError) as error:
        parser.error(str(error))


def _output_arrays(
    result: ForecastResult,
    analysis: AnalysisResult | None,
    config: NowcastConfig,
) -> dict[str, Any]:
    output = forecast_run_arrays(result)
    output.update(
        {
            "output_contract_version": np.asarray(OUTPUT_CONTRACT_VERSION),
            "min_publish_support": np.asarray(config.min_publish_support),
            "minimum_publish_verified_support": np.asarray(
                np.nan
                if config.minimum_publish_verified_support is None
                else config.minimum_publish_verified_support
            ),
            "minimum_publish_confidence": np.asarray(
                np.nan
                if config.minimum_publish_confidence is None
                else config.minimum_publish_confidence
            ),
            "minimum_publish_observation_verified_support": np.asarray(
                np.nan
                if config.minimum_publish_observation_verified_support is None
                else config.minimum_publish_observation_verified_support
            ),
            "maximum_publish_background_fraction": np.asarray(
                np.nan
                if config.maximum_publish_background_fraction is None
                else config.maximum_publish_background_fraction
            ),
            "lead_minutes": np.arange(
                config.interval_minutes,
                config.horizon_minutes + 1,
                config.interval_minutes,
            ),
        }
    )
    if analysis is None:
        output.update(
            analysis_used=np.asarray(False),
            analysis_converged=np.asarray(False),
            analysis_outer_converged=np.asarray(False),
            analysis_final_linearization_stationary=np.asarray(False),
            analysis_final_robust_stationary=np.asarray(False),
            analysis_final_irls_fixed_point=np.asarray(False),
            analysis_p1_forecast_eligible=np.asarray(False),
            analysis_posterior_eligible=np.asarray(False),
            analysis_fso_eligible=np.asarray(False),
            analysis_degraded=np.asarray(False),
            analysis_used_fallback=np.asarray(False),
            analysis_reason=np.asarray("not_requested"),
        )
    else:
        output.update(
            analysis_used=np.asarray(True),
            analysis_converged=np.asarray(analysis.converged),
            analysis_outer_converged=np.asarray(analysis.outer_converged),
            analysis_final_linearization_stationary=np.asarray(
                analysis.final_linearization_stationary
            ),
            analysis_final_robust_stationary=np.asarray(
                analysis.final_robust_stationary
            ),
            analysis_final_irls_fixed_point=np.asarray(
                analysis.final_irls_fixed_point
            ),
            analysis_p1_forecast_eligible=np.asarray(
                analysis.p1_forecast_eligible
            ),
            analysis_posterior_eligible=np.asarray(
                analysis.posterior_eligible
            ),
            analysis_fso_eligible=np.asarray(analysis.fso_eligible),
            analysis_degraded=np.asarray(analysis.degraded),
            analysis_used_fallback=np.asarray(analysis.used_fallback),
            analysis_reason=np.asarray(analysis.reason),
            analysis_initial_objective=np.asarray(
                analysis.initial_objective
            ),
            analysis_final_objective=np.asarray(analysis.final_objective),
            analysis_robust_gradient_norm=np.asarray(
                np.nan
                if analysis.robust_gradient_norm is None
                else analysis.robust_gradient_norm
            ),
            analysis_linearization_field_gradient_rms=np.asarray(
                np.nan
                if analysis.linearization_field_gradient_rms is None
                else analysis.linearization_field_gradient_rms
            ),
            analysis_linearization_field_gradient_max=np.asarray(
                np.nan
                if analysis.linearization_field_gradient_max is None
                else analysis.linearization_field_gradient_max
            ),
            analysis_linearization_dynamics_gradient_max=np.asarray(
                np.nan
                if analysis.linearization_dynamics_gradient_max is None
                else analysis.linearization_dynamics_gradient_max
            ),
            analysis_robust_field_gradient_rms=np.asarray(
                np.nan
                if analysis.robust_field_gradient_rms is None
                else analysis.robust_field_gradient_rms
            ),
            analysis_robust_field_gradient_max=np.asarray(
                np.nan
                if analysis.robust_field_gradient_max is None
                else analysis.robust_field_gradient_max
            ),
            analysis_robust_dynamics_gradient_max=np.asarray(
                np.nan
                if analysis.robust_dynamics_gradient_max is None
                else analysis.robust_dynamics_gradient_max
            ),
            analysis_robust_relative_stationarity=np.asarray(
                np.nan
                if analysis.robust_relative_stationarity is None
                else analysis.robust_relative_stationarity
            ),
            analysis_irls_relative_weight_change=np.asarray(
                np.nan
                if analysis.irls_relative_weight_change is None
                else analysis.irls_relative_weight_change
            ),
            analysis_outer_iterations=np.asarray(analysis.outer_iterations),
            analysis_pcg_iterations=np.asarray(analysis.pcg_iterations),
            analysis_minimum_reachability_margin=np.asarray(
                np.nan
                if analysis.minimum_reachability_margin is None
                else analysis.minimum_reachability_margin
            ),
            analysis_unresolved_amplitude_fraction=np.asarray(
                np.nan
                if analysis.unresolved_amplitude_fraction is None
                else analysis.unresolved_amplitude_fraction
            ),
            analysis_unresolved_amplitude_fraction_by_time=(
                _optional_pair_array(
                    analysis.unresolved_amplitude_fraction_by_time
                )
            ),
            analysis_unresolved_pixel_fraction_by_time=_optional_pair_array(
                analysis.unresolved_pixel_fraction_by_time
            ),
            analysis_amplitude_violation_score=np.asarray(
                np.nan
                if analysis.amplitude_violation_score is None
                else analysis.amplitude_violation_score
            ),
            analysis_amplitude_violation_score_by_time=_optional_pair_array(
                analysis.amplitude_violation_score_by_time
            ),
            analysis_integrated_echo_ratio_by_time=_optional_pair_array(
                analysis.integrated_echo_ratio_by_time
            ),
            analysis_displacement_tolerant_soft_echo_area_ratio_by_time=(
                _optional_pair_array(
                    analysis
                    .displacement_tolerant_soft_echo_area_ratio_by_time
                )
            ),
            analysis_amplitude_diagnostics_source=np.asarray(
                analysis.amplitude_diagnostics_source
            ),
            analysis_effective_precursor_pixel_count_by_time=(
                _optional_pair_array(
                    analysis.effective_precursor_pixel_count_by_time
                )
            ),
            analysis_bad_quality_weight_by_time=_optional_pair_array(
                analysis.bad_quality_weight_by_time
            ),
            analysis_total_quality_weight_by_time=_optional_pair_array(
                analysis.total_quality_weight_by_time
            ),
            analysis_amplitude_information_sufficient_by_time=(
                _optional_bool_pair_array(
                    analysis.amplitude_information_sufficient_by_time
                )
            ),
            analysis_insufficient_amplitude_information=np.asarray(
                analysis.insufficient_amplitude_information
            ),
            analysis_amplitude_confidence_failed=np.asarray(
                analysis.amplitude_confidence_failed
            ),
            analysis_precursor_object_count_by_time=_optional_int_pair_array(
                analysis.precursor_object_count_by_time
            ),
            analysis_insufficient_amplitude_object_count_by_time=(
                _optional_int_pair_array(
                    analysis.insufficient_amplitude_object_count_by_time
                )
            ),
            analysis_maximum_object_unresolved_fraction_by_time=(
                _optional_pair_array(
                    analysis.maximum_object_unresolved_fraction_by_time
                )
            ),
            analysis_minimum_object_integrated_echo_ratio_by_time=(
                _optional_pair_array(
                    analysis.minimum_object_integrated_echo_ratio_by_time
                )
            ),
            analysis_maximum_object_integrated_echo_ratio_by_time=(
                _optional_pair_array(
                    analysis.maximum_object_integrated_echo_ratio_by_time
                )
            ),
            analysis_minimum_object_soft_echo_area_ratio_by_time=(
                _optional_pair_array(
                    analysis.minimum_object_soft_echo_area_ratio_by_time
                )
            ),
            analysis_maximum_object_soft_echo_area_ratio_by_time=(
                _optional_pair_array(
                    analysis.maximum_object_soft_echo_area_ratio_by_time
                )
            ),
            analysis_minimum_object_count_ratio_by_time=(
                _optional_pair_array(
                    analysis.minimum_object_count_ratio_by_time
                )
            ),
            analysis_established_echo_excess_growth_fraction=np.asarray(
                np.nan
                if analysis.established_echo_excess_growth_fraction is None
                else analysis.established_echo_excess_growth_fraction
            ),
            analysis_established_echo_excess_growth_fraction_by_time=(
                _optional_pair_array(
                    analysis
                    .established_echo_excess_growth_fraction_by_time
                )
            ),
            analysis_maximum_growth_envelope_ratio=np.asarray(
                np.nan
                if analysis.maximum_growth_envelope_ratio is None
                else analysis.maximum_growth_envelope_ratio
            ),
            analysis_maximum_growth_envelope_ratio_by_time=(
                _optional_pair_array(
                    analysis.maximum_growth_envelope_ratio_by_time
                )
            ),
            analysis_relative_objective_reduction=np.asarray(
                np.nan
                if analysis.relative_objective_reduction is None
                else analysis.relative_objective_reduction
            ),
            analysis_causal_control_cell_count=np.asarray(
                analysis.causal_control_cell_count
            ),
            analysis_causal_seed_cell_count=np.asarray(
                analysis.causal_seed_cell_count
            ),
            analysis_causal_seed_prior_cost=np.asarray(
                analysis.causal_seed_prior_cost
            ),
            analysis_dynamics_data_gram_eigenvalues=(
                _optional_triple_array(
                    analysis.dynamics_data_gram_eigenvalues
                )
            ),
            analysis_dynamics_data_information_trace=np.asarray(
                np.nan
                if analysis.dynamics_data_information_trace is None
                else analysis.dynamics_data_information_trace
            ),
            analysis_dynamics_data_numerical_rank=np.asarray(
                -1
                if analysis.dynamics_data_numerical_rank is None
                else analysis.dynamics_data_numerical_rank
            ),
            analysis_dynamics_data_effective_dimension=np.asarray(
                np.nan
                if analysis.dynamics_data_effective_dimension is None
                else analysis.dynamics_data_effective_dimension
            ),
            analysis_dynamics_data_to_prior_ratio_by_mode=(
                _optional_triple_array(
                    analysis.dynamics_data_to_prior_ratio_by_mode
                )
            ),
            analysis_field_conditioned_dynamics_data_gram_eigenvalues=(
                _optional_triple_array(
                    analysis
                    .field_conditioned_dynamics_data_gram_eigenvalues
                )
            ),
            analysis_field_conditioned_dynamics_data_information_trace=(
                np.asarray(
                    np.nan
                    if analysis
                    .field_conditioned_dynamics_data_information_trace
                    is None
                    else analysis
                    .field_conditioned_dynamics_data_information_trace
                )
            ),
            analysis_field_conditioned_dynamics_data_effective_dimension=(
                np.asarray(
                    np.nan
                    if analysis
                    .field_conditioned_dynamics_data_effective_dimension
                    is None
                    else analysis
                    .field_conditioned_dynamics_data_effective_dimension
                )
            ),
            analysis_field_conditioning_maximum_relative_residual=np.asarray(
                np.nan
                if analysis.field_conditioning_maximum_relative_residual
                is None
                else analysis.field_conditioning_maximum_relative_residual
            ),
            analysis_regularized_dynamics_hessian_eigenvalues=(
                _optional_triple_array(
                    analysis.regularized_dynamics_hessian_eigenvalues
                )
            ),
            analysis_regularized_dynamics_hessian_condition_number=(
                np.asarray(
                    np.nan
                    if analysis.regularized_dynamics_hessian_condition_number
                    is None
                    else analysis.regularized_dynamics_hessian_condition_number
                )
            ),
            analysis_field_smoothness_prior_cost=np.asarray(
                analysis.field_smoothness_prior_cost
            ),
            analysis_motion_control_coordinate_system=np.asarray(
                analysis.motion_control_coordinate_system
            ),
            analysis_field_smoothness_coordinate_system=np.asarray(
                analysis.field_smoothness_coordinate_system
            ),
            analysis_motion_saturation_margin_yx=(
                _optional_pair_array(analysis.motion_saturation_margin_yx)
            ),
            analysis_motion_speed_saturation_margin_mps=np.asarray(
                np.nan
                if analysis.motion_speed_saturation_margin_mps is None
                else analysis.motion_speed_saturation_margin_mps
            ),
            analysis_growth_saturation_margin=np.asarray(
                np.nan
                if analysis.growth_saturation_margin is None
                else analysis.growth_saturation_margin
            ),
            analysis_field_growth_jacobian_cosine=np.asarray(
                np.nan
                if analysis.field_growth_jacobian_cosine is None
                else analysis.field_growth_jacobian_cosine
            ),
            analysis_field_motion_jacobian_cosine_by_control=(
                _optional_nullable_pair_array(
                    analysis.field_motion_jacobian_cosine_by_control
                )
            ),
        )
    return output


def _optional_pair_array(
    value: tuple[float, float] | None,
) -> NDArray[Any]:
    return np.asarray((np.nan, np.nan) if value is None else value)


def _optional_bool_pair_array(
    value: tuple[bool, bool] | None,
) -> NDArray[Any]:
    return np.asarray((False, False) if value is None else value)


def _optional_int_pair_array(
    value: tuple[int, int] | None,
) -> NDArray[Any]:
    return np.asarray((0, 0) if value is None else value)


def _optional_nullable_pair_array(
    value: tuple[float | None, float | None] | None,
) -> NDArray[Any]:
    if value is None:
        return np.asarray((np.nan, np.nan))
    return np.asarray(
        tuple(np.nan if item is None else item for item in value)
    )


def _optional_triple_array(
    value: tuple[float, float, float] | None,
) -> NDArray[Any]:
    return np.asarray((np.nan, np.nan, np.nan) if value is None else value)


def _audit_arrays(
    result: ForecastResult,
    analysis: AnalysisResult | None,
) -> dict[str, Any]:
    if result.audit is None:
        raise RuntimeError("audit output was requested but no audit was produced")
    final = result.audit.forecast_final
    transport = result.audit.transport
    output: dict[str, Any] = {
        "forecast_minimum_before_fix": np.asarray(final.minimum_before_fix),
        "forecast_corrected_count": np.asarray(final.corrected_count),
        "forecast_corrected_integral": np.asarray(final.corrected_integral),
        "echo_integral_before_transport": np.asarray(
            [item.echo_integral_before for item in transport]
        ),
        "echo_integral_after_transport": np.asarray(
            [item.echo_integral_after for item in transport]
        ),
        "boundary_outflow_integral": np.asarray(
            [item.boundary_outflow_integral for item in transport]
        ),
        "echo_budget_error": np.asarray(
            [item.echo_budget_error for item in transport]
        ),
    }
    if analysis is not None:
        output.update(
            analysis_minimum_before_fix=np.asarray(
                analysis.audit.minimum_before_fix
            ),
            analysis_corrected_count=np.asarray(
                analysis.audit.corrected_count
            ),
            analysis_corrected_integral=np.asarray(
                analysis.audit.corrected_integral
            ),
        )
    return output


if __name__ == "__main__":
    main()
