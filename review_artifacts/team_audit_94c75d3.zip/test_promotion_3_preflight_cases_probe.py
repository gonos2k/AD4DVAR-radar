from __future__ import annotations

import importlib.util
from dataclasses import replace

import advar.promotion as p


spec = importlib.util.spec_from_file_location(
    "promotion_test_module", "/Users/yhlee/ADVAR/tests/test_promotion.py"
)
module = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(module)
fixture = module.NeuralPriorPromotionTests()
plan = fixture.plan()
policy = fixture.policy()

# Make every requirement demand many distinct cases while keeping its physical
# event threshold at one.  The preflight API receives only event-count tuples,
# so it cannot see this case requirement.
metric_requirements = tuple(
    replace(item, minimum_cases=9999, minimum_physical_events=1)
    for item in policy.required_range_metrics
)
issuance_requirements = tuple(
    replace(item, minimum_cases=9999, minimum_physical_events=1)
    for item in policy.required_range_issuance
)
policy = replace(
    policy,
    allow_shadow_small_sample_bootstrap=False,
    required_range_metrics=metric_requirements,
    required_range_issuance=issuance_requirements,
)

metric_counts = tuple(
    (
        item.weather_regime,
        item.range_regime,
        item.metric_name,
        item.lead_minutes,
        21,
        1,
    )
    for item in metric_requirements
)
issuance_counts = tuple(
    (
        item.weather_regime,
        item.range_regime,
        item.lead_minutes,
        21,
        1,
    )
    for item in issuance_requirements
)
subset_counts = fixture.classifier_subset_counts(10_000, policy=policy)
result = p.promotion_sample_size_preflight(
    plan,
    policy,
    available_physical_events=10_000,
    metric_cell_event_counts=metric_counts,
    issuance_cell_event_counts=issuance_counts,
    classifier_subset_event_counts=subset_counts,
)
print(
    {
        "policy_metric_minimum_cases": tuple(
            item.minimum_cases for item in metric_requirements
        ),
        "policy_issuance_minimum_cases": tuple(
            item.minimum_cases for item in issuance_requirements
        ),
        "preflight_cell_feasible": result.cell_feasible,
        "preflight_classifier_subset_feasible": result.classifier_subset_feasible,
        "preflight_automatic_inference": result.automatic_inference,
        "preflight_required_physical_events": result.required_physical_events,
        "preflight_feasible": result.feasible,
        "physical_events_supplied": result.available_physical_events,
        "preflight_only_counts_physical_events": tuple(
            item[-2:] for item in result.metric_cell_event_counts
        ),
    }
)
