# test_promotion_2 audit (GREEN)

Baseline: `94c75d3323c986b6fb2963336b906acc85384e12`

## Confirmed findings

None. No production contract violation or reproducible defect was found in the assigned test range.

## Scope and production contracts checked

I read `tests/test_promotion.py` lines 5201–10400 in bounded chunks. The assignment begins inside `test_semantic_replay_raw_input_must_match_forecast_run`; lines 5193–5205 were also read to recover that test's complete context. The final test beginning at line 10398 was continued through line 10490 for context.

The legacy replay tests exercise the actual decoder in `src/advar/ledger.py` (`_decode_scoring_replay_bundle_manifest`) and the actual `EpisodeLedger.load_neural_prior_scoring_replay_bundle` path. The constructors and decoder enforce generation-specific tensor-role sets, unique ordered case IDs, digest syntax, and recomputed bundle digests. The loader enforces the ledger path boundary, exact member allow-list, file/member checksums, evaluation ordering/digests, and rejects `cases=` for every legacy manifest as `audit-only`. The v13/v14/v15 and v24 durable fixtures use the required tensor generations and correctly computed archive/shard and JSON checksums. These tests deliberately insert synthetic ledger rows directly, so they cover durable-storage loading and legacy compatibility, while bypassing the append/registration producer path.

The uncertainty-target tests reach `PriorUncertaintyTarget.from_verification_bundle`, which validates the current target contract, observation-error-plan digest, mask/censor/floor contracts, quantization metadata, source/QC/grid identity, and unique target time. They cover a wrong source digest, a legacy verification bundle, and a changed observation-error plan. `VerificationTargetIdentityArtifact.from_scoring_target` is also exercised after mutating the target's observation-error digest, and correctly rejects the mismatch.

`test_input_plan_must_match_actual_operational_identity` calls the private `_validate_input_plan_resolution` helper directly. The helper is reachable from both `ForecastRunContract.from_inputs` and `ForecastRunContract.__post_init__`; it checks radar product, QC, background-cycle, mask, grid digest, valid times, and observation valid time. The test uses a `SimpleNamespace` grid rather than constructing a full run, so it is helper-level evidence rather than public-constructor end-to-end evidence.

The promotion guard tests construct current `PriorHoldoutEvaluation` products and sealed scoring artifacts through the test fixture, then invoke the real `compute_neural_prior_promotion`. The production score is normalized by the configured metric scale and separately checks end-to-end degradation, finite issuance values, absolute and candidate-vs-parent uncertainty limits, and state-head limits. The pure-clear floor-invariance test is mathematically consistent with `_prior_uncertainty_scores`: with no echo support, the truncated-Gaussian branch is unused, while the clear-sky score depends only on event probabilities, so changing the floor representation cannot change the result.

## Mock-only boundaries and evidence limits

`test_scoring_replay_reproduces_evaluation_digest` builds real replay products, raw receipts, provenance artifacts, signed process receipts, shard archives, ledger rows, checksum attacks, promotion storage, concurrent certificate issuance, and operational decision artifacts. It therefore gives meaningful integration evidence for those contracts. However, it patches `PriorHoldoutEvaluation.from_forecasts` to return the prebuilt evaluation by case ID. `ScoringReplayCaseArtifact.recompute_evaluation` calls that method, so the test does not independently prove the metric, uncertainty, classifier, or issuance arithmetic. The digest-reproduction assertion is consequently mock-assisted; it should not be counted as standalone scorer end-to-end evidence.

The same large test patches trust-store loaders, runtime-closure validation, and the promotion computation used by one ledger append step, and manually inserts several ledger rows. Those are controlled boundary fixtures. The actual ledger/checksum/concurrency transitions still run, but external trust-store parsing, runtime closure, and the patched append-time promotion calculation are outside its evidence.

`test_promotes_only_independent_material_holdout_cases` and the rejection tests use direct fixture-built evaluation values. They exercise promotion validation and decision guards, not production forecast-to-evaluation derivation. The targeted replay/audit tests executed below do not include this large scorer test because it is expensive; no unexecuted test is reported as passed.

## Unconfirmed candidates

The scorer patch described above is a coverage limitation, not a confirmed production defect. A separate unpatched product-scorer test exists outside the assigned range, but it was not treated as executed evidence in this audit.

## GREEN tests and rationale

- Legacy v1/v2 and pre-source v12–v24 manifests decode to their typed audit classes; durable v13/v14/v15/v24 bundles load with byte verification and reject semantic replay as audit-only.
- Planned verification-source identity rejects wrong source/QC/observation-error lineage and rejects the legacy verification bundle contract.
- Operational input identity changes are rejected for radar, background-cycle, and mask digests.
- The unreliable-state promotion guard test rejects a candidate Gaussian NLL of `100.0` against the policy limit.

## Commands and results

All probes used `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1` and `/Users/yhlee/ADVAR/.venv/bin/python -I`.

1. Legacy/audit paths:
   `test_pr110_snapshot_bundle_remains_audit_loadable`, `test_pre_source_composition_replay_generations_are_audit_only`, and `test_pr144_v24_durable_replay_loads_as_audit_only` — **3 passed, 4 subtests passed** in 116.10 s.
2. Target and promotion guard paths:
   `test_uncertainty_target_requires_its_planned_verification_source`, `test_input_plan_must_match_actual_operational_identity`, and `test_probability_skill_cannot_hide_unreliable_state_uncertainty` — **3 passed, 3 subtests passed** in 73.73 s.

Runnable command script and captured summaries are [test_promotion_2_probes.sh](/tmp/advar-team-audit-94c75d3/test_promotion_2_probes.sh) and [test_promotion_2_probe_output.txt](/tmp/advar-team-audit-94c75d3/test_promotion_2_probe_output.txt).

No full baseline, promotion, variational, sensitivity, or ledger suite was run.
