# promotion_1 audit (GREEN)

Baseline: `94c75d3323c986b6fb2963336b906acc85384e12`  
Model/reasoning: `gpt-5.6-luna` / `xhigh`  
Scope: `src/advar/promotion.py:1-5700`, including reachable temporal, raw-observation, source-coverage, training-target, archive, and normalization callers needed to interpret those contracts.

## Confirmed findings

None in the supported public promotion/ledger paths examined. No source or test files were changed.

## Unconfirmed candidates and bounded behavior

1. `GlobalRawVolumeResolutionReceipt.issue()` (`promotion.py:1685-1758`) accepts a subset or entirely unreserved `slot_identity_bindings`. The constructor (`1601-1658`) has only the reservation receipt digest and cannot compare the bindings with the reservation object. The saved probe creates a reservation for two slots and a signed resolution for one unrelated slot; the helper accepts it. This is helper-level permissiveness: the reachable holdout commit path checks exact bindings against the plan's sampling unit and reservation at `ledger.py:8199-8215`, and semantic replay checks the same relation at `promotion.py:15715-15751`. I therefore do not count it as an unsafe public-path finding.

2. `weighted_training_target_loss()` (`promotion.py:4685-4717`) accepts finite floating inputs at the representable extremes, but `(max - (-max))**2` overflows and returns `inf`. The target artifact constructor accepts finite values (`4537-4566`) and does not impose a physical dBZ range. The probe reproduces `float64 inf`; ordinary radar-valued inputs and the selected training tests remain finite. This is a bounded numerical-domain candidate requiring a realistic producer-path range/contract decision, not a demonstrated forecast failure.

3. `TrainingTargetSourceTrustStore.issue()` (`promotion.py:4121-4161`) signs the unsorted input authority order, while the constructor canonicalizes authorities by sorting before signature verification (`4036-4106`), so two valid authorities supplied in descending order are rejected as “unsigned.” This is a fail-closed false negative in the convenience issuer; current source production loads canonical serialized trust stores, and no unsafe acceptance was found. It should only be changed if the issuer's input-order contract is intended to be order-independent.

## GREEN preserved

- `NeuralPriorInputPlan` canonicalizes timezone-aware timestamps, requires exactly three strictly increasing valid times ending at `observation_valid_time`, and enforces `valid <= available <= deadline < publication` (`promotion.py:2818-2875`). The probe confirms canonicalization and rejection of two malformed temporal plans.
- Raw volume creation and decoding preserve the registered binary32/QC contract. Invalid cells become reflectivity `-10 dBZ`, quality `0`, and observation standard deviation `1`; valid values remain unchanged (`promotion.py:395-655`). The probe confirms this small masked example.
- Mosaic source coverage computes resolved masks from nominal coverage, source availability, outage, and dynamic QC, checks registered source indices and issue windows, and signs the retained tensors (`promotion.py:3333-3736`). The selected tests cover dynamic source resolution and temporal gating.
- Training targets require finite nonempty tensors, a nonempty valid mask, zero values and quality outside the mask, positive valid quality mass, signed source lineage, and source time inside the training window (`promotion.py:4416-4682`, reachable derivation checks `promotion.py:6117-6331`).
- Content-addressed training shards use a single descriptor-backed immutable byte snapshot, checksum, NPZ no-pickle loading, dtype/shape/digest checks, and post-read metadata comparison (`promotion.py:4802-5135`). The probe and selected archive test confirm a float/bool round trip.
- Normalization is recomputed from train features only in float64 using population variance and is rechecked against the exact normalization shard (`promotion.py:5208-5392`, `5423-5717`). The selected training tests cover target chronology and shard limits.

## Commands and results

- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I -m pytest -q tests/test_review_promotion_contracts.py` -> **19 passed**.
- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I -m pytest -q tests/test_promotion.py -k 'sampling_unit_is_independent_of_processing_contracts or dynamic_source_coverage_resolves_after_input_availability or training_targets_are_finite_nonempty_and_inside_windows or training_shard_rejects_oversized_file_before_hashing or raw_quality_weight_is_rejected_outside_unit_interval'` -> **5 passed, 7 subtests** (222 deselected).
- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-team-audit-94c75d3/promotion_1_probe.py` -> deterministic JSON in [promotion_1_probe.json](/tmp/advar-team-audit-94c75d3/promotion_1_probe.json); runnable source is [promotion_1_probe.py](/tmp/advar-team-audit-94c75d3/promotion_1_probe.py).

## Limitations

No full baseline or promotion suite was run. No operational deployment command, package installation, source mutation, or unsupported backend probe was performed. The two helper-level candidates were not promoted to findings because the actual holdout/ledger callers rebind them to the registered plan, and the numerical overflow probe uses representable extremes outside demonstrated radar-value workloads.
