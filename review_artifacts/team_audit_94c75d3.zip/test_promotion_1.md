# test_promotion_1 audit

Baseline: `94c75d3323c986b6fb2963336b906acc85384e12`  
Role: RED; assigned range `tests/test_promotion.py:1-5200`.

## Confirmed findings

No confirmed production defect from this assigned range. The earlier complete-outage candidate was downgraded after checking the public artifact constructors and public append path.

## Unconfirmed candidate: synthetic all-missing raw channels would be rejected, but that state is not constructible through the current public mosaic coverage contract

`MissingRawObservationReceipt.issue(...)` can create signed typed receipts, and the mosaic derivation helper supports missing sites when a source map does not select them. The focused test `test_complete_mosaic_outage_uses_signed_missing_receipts` exercises that supported partial outage semantics: one input time has both sites missing, another time remains resolved, and the derivation produces the canonical invalid fill, false mask, zero quality, and unit observation standard deviation (`tests/test_promotion.py:16076-16189`; `src/advar/promotion.py:2211-2314`).

The prior concern came from the private tensor validator. `ScoringReplayCaseArtifact._live_replay_tensors` filters raw roles to `ResolvedRawObservationReceipt` and would emit `(0,H,W)` raw channels only if every receipt in a case were missing (`src/advar/promotion.py:15947-15978`). `_validate_scoring_replay_case_tensors` rejects zero-element tensors (`src/advar/ledger.py:3725-3727`), and the bounded synthetic probe demonstrates that rejection. This probe only injected malformed zero-row tensors into the private validator; it did not construct a valid replay case or call public archive append with such a case.

The public mosaic coverage factory makes the all-input-time/all-cell outage state unavailable: `ResolvedSourceCoverageArtifact.from_observations` computes resolved cell counts and raises `ValueError("resolved source coverage is empty")` when any lead has no selected source (`src/advar/promotion.py:3375-3486`). If a source map selects a site, `_derive_analysis_inputs_from_raw_products` rejects a Missing receipt for that selected site (`src/advar/promotion.py:2217-2240`). Consequently, a valid dynamic mosaic replay case must contain at least one resolved source volume for every lead/current coverage artifact, so its raw channels are not empty. The all-missing probe creates six typed Missing receipts, then reaches the coverage factory and exits with `resolved source coverage is empty`; it never reaches `ScoringReplayCaseArtifact.from_products` or ledger append.

This leaves a contract question rather than an actionable confirmed bug. If future requirements intentionally allow a complete all-input-time outage while retaining a dynamic coverage artifact, the zero-row validator would block archival and the failure would remain fail-closed. Under the current constructors, that workload is rejected earlier as an empty source-coverage artifact, so no claim is made that the public archive append currently mishandles a supported complete outage. The raw provenance decoder does account for Missing receipt payloads and counts only resolved products (`src/advar/ledger.py:4431-4504`), but that observation alone does not establish support for an all-missing replay case.

## Unconfirmed candidates and coverage gaps

- The assigned full-product semantic replay test reaches the real ledger append/load path with typed resolved raw receipts and passes (`tests/test_promotion.py:3270-5052`). It does not append a case containing Missing receipts.
- The complete mosaic outage test reaches `_derive_analysis_inputs_from_raw_products` directly and passes, but it does not build a `ScoringReplayCaseArtifact` or call `EpisodeLedger.append_neural_prior_scoring_replay_bundle`.
- The synthetic private-validator probe is useful sensitivity evidence only. It is not public-path evidence because the zero-row tensor was supplied directly and no valid product artifact generated it.
- `ScoringReplayCaseArtifact._validate_product_integrity` and the ledger append path were inspected for a separate vacuous bypass; no reachable bypass was confirmed.

## GREEN preserved

- Current semantic replay rejects wrong role dtypes, mixed tensor devices, wrong learned-input time shape, wrong background shape, and raw inputs that disagree with the forecast run. The selected eight replay-integrity tests passed.
- The product replay case requires exact current product types and revalidates frozen tensor snapshots before recomputation. The selected current-plan and generation-boundary tests passed.
- The full-product semantic replay test executes the public append/load path and reaches promotion without patching the scorer; it passed.
- Current promotion evidence construction binds the current replay generation, CPU backend, typed scoring artifacts, and ledger replay recomputation. Legacy contracts remain audit-only in the inspected paths.

## Commands and results

All probes used `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1` and the repository venv.

1. `pytest -q tests/test_promotion.py -k 'semantic_replay_role_schema_rejects_wrong_dtype or semantic_replay_requires_one_device_across_every_role or scoring_backend_is_cpu_only or semantic_replay_requires_factory_and_exact_product_types or semantic_replay_detects_forecast_tensor_after_rehash_attempt or semantic_replay_requires_time_resolved_quality_weight or semantic_replay_requires_exact_background_time_shape or semantic_replay_raw_input_must_match_forecast_run' --maxfail=1` → **8 passed**, 219 deselected, 18 warnings, 4 subtests, 284.20 s.
2. `pytest -q tests/test_promotion.py -k 'physical_applicability_contract_versions_are_new_generations or holdout_plan_requires_every_preregistered_observation_error_plan or current_holdout_rejects_legacy_observation_error_plan or semantic_replay_generation_stops_before_operational_deployment' --maxfail=1` → **4 passed**, 223 deselected, 127.92 s.
3. `pytest -q tests/test_promotion.py::NeuralPriorPromotionTests::test_complete_mosaic_outage_uses_signed_missing_receipts` → **1 passed**, 1.24 s. This confirms only the supported one-time partial-outage derivation path.
4. `pytest -q tests/test_promotion.py::NeuralPriorPromotionTests::test_full_product_semantic_replay_reaches_promotion_without_scorer_patch` → **1 passed**, 18 warnings, 5.83 s. This confirms public append/load for the normal resolved dynamic case, not an all-missing case.
5. `python /tmp/advar-team-audit-94c75d3/test_promotion_1_missing_receipts_probe.py` → **exit 0**; created 6 signed typed `MissingRawObservationReceipt` values, then the public `ResolvedSourceCoverageArtifact.from_observations` constructor rejected the all-missing history with `resolved source coverage is empty`.
6. `python /tmp/advar-team-audit-94c75d3/test_promotion_1_complete_outage_probe.py` → **exit 0**; direct private-validator injection of zero-row raw channels raised `scoring replay tensor is invalid`. This is explicitly synthetic helper-only evidence.

No repository source, test, branch, or other agent output was modified. Only the prefixed probe and audit artifacts in `/tmp/advar-team-audit-94c75d3/` were written.
