import torch
from advar.variational import AnalysisConfig, prepare_analysis


def main() -> None:
    frames = torch.full((3, 3, 3), 5.0, dtype=torch.float64)
    observations, frozen = prepare_analysis(
        frames,
        analysis_config=AnalysisConfig(detection_limit_dbz=5.0),
    )
    print("threshold", frozen.analysis_config.detection_limit_dbz)
    print("detected_count", int(observations.detected_mask.sum()))
    print("censored_count", int(observations.censored_mask.sum()))
    print("first_detected", bool(observations.detected_mask[0, 0, 0]))
    print("first_censored", bool(observations.censored_mask[0, 0, 0]))


if __name__ == "__main__":
    main()
