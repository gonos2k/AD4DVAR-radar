from dataclasses import replace
from pathlib import Path
import tempfile
import sys

sys.path.insert(0, "/Users/yhlee/ADVAR/tests")

from test_ledger import _computed_snapshot, _contract
from advar.ledger import EpisodeLedger, SensitivityEpisode


snapshot = _computed_snapshot()
bad_names = tuple("wrong_" + str(i) for i in range(len(snapshot.context_feature_names)))
bad_snapshot = replace(snapshot, context_feature_names=bad_names)
episode = SensitivityEpisode(
    episode_id="bad-context-names",
    issue_time="2026-07-26T05:00:00+00:00",
    radar_id="KTLX",
    contract=_contract(bad_snapshot),
    snapshot=bad_snapshot,
)
with tempfile.TemporaryDirectory() as directory:
    ledger = EpisodeLedger(Path(directory))
    target = ledger.append(episode)
    print("append_returned", target.is_dir())
    try:
        ledger.verify(episode.episode_id)
    except Exception as error:
        print(type(error).__name__, str(error))
    else:
        print("verify_succeeded")
