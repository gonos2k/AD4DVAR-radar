from pathlib import Path
import importlib.util
import json
import sqlite3
from unittest.mock import patch

from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey as RealKey,
)


spec = importlib.util.spec_from_file_location(
    "test_ledger_probe", Path("tests/test_ledger.py")
)
module = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(module)
from advar.ledger import EpisodeLedger  # noqa: E402


keys = []


class KeyFactory:
    @staticmethod
    def generate(*args, **kwargs):
        key = RealKey.generate(*args, **kwargs)
        keys.append(key)
        return key

    @staticmethod
    def from_private_bytes(*args, **kwargs):
        return RealKey.from_private_bytes(*args, **kwargs)


original_append = EpisodeLedger.append_realized_intervention_receipt
state = {}


def wrapped_append(self, decision, receipt, **kwargs):
    result = original_append(self, decision, receipt, **kwargs)
    if not state:
        duplicate = module.RealizedInterventionReceipt.from_decision(
            decision,
            actual_input_before_context=kwargs["actual_input_before_context"],
            actual_input_before_run=kwargs["actual_input_before_run"],
            actual_input_after_context=kwargs["actual_input_after_context"],
            actual_input_after_run=kwargs["actual_input_after_run"],
            action_policy=kwargs["action_policy"],
            action_generator=kwargs["action_generator"],
            executor_key_id=receipt.executor_key_id,
            executor_trust_store_digest=receipt.executor_trust_store_digest,
            executor_private_key=keys[0],
            executor_sequence_number=receipt.executor_sequence_number + 1,
            applied_time=receipt.applied_time,
            receipt_time=receipt.receipt_time,
        )
        try:
            original_append(self, decision, duplicate, **kwargs)
        except Exception as error:
            state["error"] = (type(error).__name__, str(error))
        state["orphan_digest"] = duplicate.receipt_digest
        state["artifact_dirs"] = tuple(
            sorted(path.name for path in self.interventions_dir.iterdir())
        )
        with sqlite3.connect(self.index_path) as connection:
            state["indexed_receipts"] = tuple(
                row[0]
                for row in connection.execute(
                    "SELECT receipt_digest FROM realized_intervention_receipts"
                )
            )
    return result


case = module.EpisodeLedgerTests(
    "test_prospective_decision_and_executor_receipt_round_trip"
)
case.setUp()
try:
    with patch.object(module, "Ed25519PrivateKey", KeyFactory), patch.object(
        EpisodeLedger,
        "append_realized_intervention_receipt",
        wrapped_append,
    ):
        case.test_prospective_decision_and_executor_receipt_round_trip()
    print(json.dumps(state, sort_keys=True))
finally:
    case.tearDown()
