"""Small deterministic probes for the run-artifact audit."""
from pathlib import Path
import tempfile
import zipfile

import numpy as np
import torch

from advar.nowcast import nowcast
import advar.run_artifact as ra


def main() -> None:
    result = nowcast(torch.full((3, 4, 4), 20.0, dtype=torch.float64))
    arrays = ra.forecast_run_arrays(result)
    print("array_count", len(arrays))
    print("missing_core", sorted(set(ra._CORE_ARRAY_NAMES) - set(arrays)))
    print("extra", sorted(set(arrays) - set(ra._CORE_ARRAY_NAMES)))
    print("digest_valid", ra._forecast_run_artifact_digest(arrays) == arrays["forecast_run_artifact_digest"].item())
    with tempfile.TemporaryDirectory() as directory:
        path = Path(directory) / "run.npz"
        ra.save_forecast_run(result, path)
        loaded = ra.load_forecast_run(path)
        print("roundtrip_digest_equal", loaded.forecast_run_digest == result.forecast_run_digest)
        print("roundtrip_forecast_equal", torch.equal(loaded.forecast_dbz, result.forecast_dbz))
        print("roundtrip_valid_equal", torch.equal(loaded.valid_mask, result.valid_mask))
        with np.load(path, allow_pickle=False) as archive:
            member_count = len(archive.files)
        try:
            ra.load_forecast_run(path, maximum_member_count=member_count - 1)
        except ValueError as error:
            print("member_limit", str(error))
        else:
            print("member_limit", "ACCEPTED_UNEXPECTEDLY")
    with tempfile.TemporaryDirectory() as directory:
        path = Path(directory) / "hostile.npz"
        header = __import__("io").BytesIO()
        np.lib.format.write_array_header_1_0(header, {"descr": np.dtype(np.float64).str, "fortran_order": False, "shape": (1_000_000_000,)})
        with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as archive:
            archive.writestr("forecast_dbz.npy", header.getvalue())
        try:
            ra.load_forecast_run(path, maximum_member_bytes=1024)
        except ValueError as error:
            print("declared_limit", str(error))
        else:
            print("declared_limit", "ACCEPTED_UNEXPECTEDLY")


if __name__ == "__main__":
    main()
