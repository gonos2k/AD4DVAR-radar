import sys

import torch

sys.path.insert(0, "tests")

from test_sensitivity import _current_verification_bundle
from advar.nowcast import (
    CURRENT_RADAR_METRIC_DOMAIN,
    CURRENT_RADAR_METRIC_DOMAIN_EVIDENCE,
    CURRENT_RADAR_METRIC_DOMAIN_EVIDENCE,
    NowcastConfig,
    RadarGridTimeContract,
    nowcast,
    RADAR_PROJECTED_GRID_CELL_CENTER_CONVENTION,
    RADAR_PROJECTED_GRID_COORDINATE_DTYPE,
    radar_projected_crs_semantic_digest,
)
from advar.sensitivity import (
    CURRENT_RADAR_METRIC_DOMAIN,
    SensitivityConfig,
    compute_sensitivity_snapshot,
)


def main() -> None:
    config = NowcastConfig(horizon_minutes=10)
    grid = RadarGridTimeContract(
        valid_times=(
            "2026-08-05T00:00:00Z",
            "2026-08-05T00:10:00Z",
            "2026-08-05T00:20:00Z",
        ),
        dx_m=1000.0,
        dy_m=1000.0,
        projection="EPSG:5179",
        grid_hash="a" * 64,
        spatial_grid_contract="radar-spatial-grid-identity-v6",
        grid_shape_yx=(4, 4),
        projected_crs_digest=radar_projected_crs_semantic_digest("EPSG:5179"),
        metric_domain_digest=CURRENT_RADAR_METRIC_DOMAIN.digest,
        metric_domain_evidence_digest=CURRENT_RADAR_METRIC_DOMAIN_EVIDENCE.digest,
        cell_center_origin_xy_m=(1_000_000.0, 2_000_000.0),
        grid_coordinate_dtype=RADAR_PROJECTED_GRID_COORDINATE_DTYPE,
        cell_center_convention=RADAR_PROJECTED_GRID_CELL_CENTER_CONVENTION,
    )
    frames = torch.full((3, 4, 4), 20.0, dtype=torch.float64)
    result = nowcast(frames, config, grid_time_contract=grid)
    verification = result.forecast_dbz.detach().clone()
    verification[0, 0, 0] = float("nan")
    bundle = _current_verification_bundle(
        verification,
        valid_times=("2026-08-05T00:30:00Z",),
        grid_time_contract=grid,
    )
    sensitivity = SensitivityConfig(
        metric_names=("log_echo_mse",), full_map_lead_minutes=(10,)
    )
    snapshot = compute_sensitivity_snapshot(
        frames[-1], result, bundle, sensitivity_config=sensitivity
    )
    print("contract", bundle.contract)
    print("state_00", int(bundle.observation_state_code[0, 0, 0]))
    print("fso_metric_weight_00", float(bundle.fso_metric_weight[0, 0, 0]))
    print("snapshot_score", float(snapshot.forecast_scores[0, 0]))
    assert bundle.contract == "radar-verification-bundle-v22"
    assert float(bundle.fso_metric_weight[0, 0, 0]) == 0.0
    assert float(snapshot.forecast_scores[0, 0]) > 0.0


if __name__ == "__main__":
    main()
