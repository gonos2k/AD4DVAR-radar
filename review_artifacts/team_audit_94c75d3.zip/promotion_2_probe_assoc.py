import sys
sys.path.insert(0, '/Users/yhlee/ADVAR')
from advar.promotion import (
    PhysicalEventCatalogEvidence,
    PhysicalEventCatalogPlan,
    PhysicalEventCatalogResult,
    PhysicalEventCaseSpatialEvidence,
    PhysicalEventTrackArtifact,
    regime_reference_public_key_hex,
)
import advar.promotion as p
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

key = Ed25519PrivateKey.from_private_bytes(bytes([0x51]) * 32)
start_a, end_a = '2026-08-10T00:05:00Z', '2026-08-10T00:15:00Z'
start_b, end_b = '2026-08-10T00:00:00Z', '2026-08-10T00:10:00Z'
track_a = PhysicalEventTrackArtifact(
    timestamps=(start_a, end_a), centroid_xy_m=((0., 0.), (0., 0.)),
    object_mask_digests=('a'*64, 'b'*64), source_radar_ids=('radar', 'radar'),
    association_edge_digests=('c'*64,), spatial_reference_digest='d'*64)
track_b = PhysicalEventTrackArtifact(
    timestamps=(start_b, end_b), centroid_xy_m=((0., 0.), (20_000., 0.)),
    object_mask_digests=('e'*64, 'f'*64), source_radar_ids=('radar', 'radar'),
    association_edge_digests=('1'*64,), spatial_reference_digest='d'*64)
common = dict(
    spatial_envelope_xy_m=(-1., -1., 1., 1.),
    participating_radar_ids=('radar',), association_algorithm_digest='2'*64,
    adjudication_policy_digest='3'*64, adjudicator_id='labeler',
    adjudicator_private_key=key)
event_a = PhysicalEventCatalogEvidence.from_members(
    event_id='a', member_case_ids=('case-a',), member_full_analysis_input_digests=('4'*64,),
    start_time=start_a, end_time=end_a, object_track_artifact=track_a, **common)
event_b = PhysicalEventCatalogEvidence.from_members(
    event_id='b', member_case_ids=('case-b',), member_full_analysis_input_digests=('5'*64,),
    start_time=start_b, end_time=end_b, object_track_artifact=track_b,
    spatial_envelope_xy_m=(-1., -1., 20_001., 1.), **{k:v for k,v in common.items() if k != 'spatial_envelope_xy_m'})
plan = PhysicalEventCatalogPlan(
    holdout_case_ids=('case-a', 'case-b'), association_algorithm_digest='2'*64,
    spatial_membership_rule_digest='6'*64, adjudication_policy_digest='3'*64,
    adjudicator_id='labeler', adjudicator_public_key_hex=regime_reference_public_key_hex(key),
    catalog_completion_deadline='2026-08-10T01:00:00Z', spatial_reference_digest='d'*64,
    motion_association_rule_digest='7'*64, scheduler_id='scheduler',
    scheduler_public_key_hex=regime_reference_public_key_hex(Ed25519PrivateKey.from_private_bytes(bytes([0x52])*32)),
    scheduler_trust_store_digest='8'*64)
def spatial(event, case, full, index=0):
    return PhysicalEventCaseSpatialEvidence(
        case_id=case, full_analysis_input_digest=full,
        physical_event_identity_digest=event.physical_event_identity_digest,
        observed_spatial_envelope_xy_m=event.spatial_envelope_xy_m,
        event_spatial_envelope_xy_m=event.spatial_envelope_xy_m,
        spatial_membership_rule_digest='6'*64,
        source_object_evidence_digest=event.object_track_artifact.object_mask_digests[index],
        track_artifact_digest=event.object_track_artifact.artifact_digest,
        track_sample_index=index, track_sample_time=event.object_track_artifact.timestamps[index],
        track_object_mask_digest=event.object_track_artifact.object_mask_digests[index],
        input_available_time='2026-08-10T00:00:00Z', spatial_reference_digest='d'*64)
spatial_a = spatial(event_a, 'case-a', '4'*64)
spatial_b = spatial(event_b, 'case-b', '5'*64)
print('association_a_b', p._events_associate(event_a, event_b, plan))
print('association_b_a', p._events_associate(event_b, event_a, plan))
result = PhysicalEventCatalogResult.from_plan(
    plan, event_evidences=(event_b, event_a),
    case_spatial_membership_evidences=(spatial_a, spatial_b),
    cataloged_at='2026-08-10T00:30:00Z', adjudicator_private_key=key)
print('accepted_ordered_split_result', result.result_digest)
try:
    PhysicalEventCatalogResult.from_plan(
        plan, event_evidences=(event_a, event_b),
        case_spatial_membership_evidences=(spatial_a, spatial_b),
        cataloged_at='2026-08-10T00:30:00Z', adjudicator_private_key=key)
except ValueError as exc:
    print('reverse_order_rejected', str(exc))
else:
    print('reverse_order_accepted')
