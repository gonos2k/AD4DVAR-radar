import sys

import torch

sys.path.insert(0, "/Users/yhlee/ADVAR/tests")

from test_sensitivity import _current_verification_bundle
from advar.nowcast import (
    CURRENT_RADAR_METRIC_DOMAIN,
    CURRENT_RADAR_METRIC_DOMAIN_EVIDENCE,
    NowcastConfig,
    RadarGridTimeContract,
    RADAR_PROJECTED_GRID_CELL_CENTER_CONVENTION,
    RADAR_PROJECTED_GRID_COORDINATE_DTYPE,
    nowcast,
    radar_projected_crs_semantic_digest,
)
from advar.physics import dbz_to_echo
from advar.sensitivity import (
    SensitivityConfig,
    compute_sensitivity_snapshot,
    forecast_metric,
)


def main() -> None:
    grid = RadarGridTimeContract(
        valid_times=(
            "2026-08-05T00:00:00Z",
            "2026-08-05T00:10:00Z",
            "2026-08-05T00:20:00Z",
        ),
        dx_m=1000.0,
        dy_m=1000.0,
        projection="EPSG:5179",
        grid_hash="a" * 64,
        spatial_grid_contract="radar-spatial-grid-identity-v6",
        grid_shape_yx=(4, 4),
        projected_crs_digest=radar_projected_crs_semantic_digest("EPSG:5179"),
        metric_domain_digest=CURRENT_RADAR_METRIC_DOMAIN.digest,
        metric_domain_evidence_digest=CURRENT_RADAR_METRIC_DOMAIN_EVIDENCE.digest,
        cell_center_origin_xy_m=(1_000_000.0, 2_000_000.0),
        grid_coordinate_dtype=RADAR_PROJECTED_GRID_COORDINATE_DTYPE,
        cell_center_convention=RADAR_PROJECTED_GRID_CELL_CENTER_CONVENTION,
    )
    config = NowcastConfig(horizon_minutes=10)
    result = nowcast(
        torch.full((3, 4, 4), 20.0, dtype=torch.float64),
        config,
        grid_time_contract=grid,
    )
    verification = result.forecast_dbz.detach().clone()
    verification[0, 0, 0] = float("nan")
    bundle = _current_verification_bundle(
        verification,
        valid_times=("2026-08-05T00:30:00Z",),
        grid_time_contract=grid,
    )
    snapshot = compute_sensitivity_snapshot(
        result.run.latest_frame_dbz,
        result,
        bundle,
        sensitivity_config=SensitivityConfig(
            metric_names=("log_echo_mse",), full_map_lead_minutes=(10,)
        ),
    )
    clean_truth = torch.nan_to_num(
        bundle.frames_dbz[0],
        nan=config.min_dbz,
        posinf=config.max_dbz,
        neginf=config.min_dbz,
    )
    expected_weighted_score = forecast_metric(
        "log_echo_mse",
        dbz_to_echo(result.forecast_dbz[0], min_dbz=config.min_dbz, max_dbz=config.max_dbz),
        dbz_to_echo(clean_truth, min_dbz=config.min_dbz, max_dbz=config.max_dbz),
        bundle.fso_metric_weight[0],
        config,
        SensitivityConfig(metric_names=("log_echo_mse",), full_map_lead_minutes=(10,)),
    )
    print("contract", bundle.contract)
    print("state_00", int(bundle.observation_state_code[0, 0, 0]))
    print("valid_mask_00", bool(bundle.valid_mask[0, 0, 0]))
    print("fso_metric_weight_00", float(bundle.fso_metric_weight[0, 0, 0]))
    print("snapshot_score", float(snapshot.forecast_scores[0, 0]))
    print("expected_fso_weighted_score", float(expected_weighted_score))
    print("forecast_sensitivity_00", float(snapshot.forecast_sensitivity[0, 0, 0, 0]))
    print("forecast_sensitivity_other", float(snapshot.forecast_sensitivity[0, 0, 0, 1]))


if __name__ == "__main__":
    main()
