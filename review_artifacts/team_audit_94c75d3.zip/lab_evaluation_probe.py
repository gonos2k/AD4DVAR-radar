#!/usr/bin/env python3
import importlib.util
import json
import sys
from pathlib import Path

path = Path('/Users/yhlee/ADVAR/examples/initial_field_lab/server.py')
spec = importlib.util.spec_from_file_location('lab_evaluation_server_probe', path)
assert spec is not None and spec.loader is not None
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)

for age in (0, 10, 30, 60):
    result = module.run_experiment(module.ExperimentSettings(background_age_minutes=age))
    print(json.dumps({'case': age, 'metrics': result['metrics'], 'state': result['state']}, sort_keys=True))

for lead in (10, 30, 180):
    result = module.run_experiment(module.ExperimentSettings(lead_minutes=lead))
    print(json.dumps({'case': f'lead-{lead}', 'metrics': {
        key: result['metrics'][key]
        for key in ('valid_fraction', 'scored_fraction', 'scored_pixels',
                    'forecast_mae_dbz', 'persistence_mae_dbz', 'skill_dbz',
                    'mean_confidence')
    }}, sort_keys=True))

for coverage in (25, 50, 75, 100):
    result = module.run_experiment(module.ExperimentSettings(coverage_percent=coverage))
    print(json.dumps({'case': f'coverage-{coverage}', 'case_metadata': result['case'],
                      'metrics': {
                          key: result['metrics'][key]
                          for key in ('scored_fraction', 'scored_pixels',
                                      'missing_pixels', 'forecast_mae_dbz')
                      }}, sort_keys=True))

def compare(reference, candidate, persistence, target):
    return module._compare_forecasts(reference, candidate, persistence, target)

import torch
reference = torch.tensor([[2.0, 2.0], [2.0, float('nan')]])
persistence = torch.full((2, 2), 3.0)
target = torch.zeros((2, 2))
print(json.dumps({'case': 'ab-fixed-domain', 'comparison': compare(
    reference, torch.ones((2, 2)), persistence, target)}, sort_keys=True))
print(json.dumps({'case': 'ab-candidate-missing', 'comparison': compare(
    reference, torch.tensor([[float('nan'), 1.0], [1.0, 1.0]]), persistence, target)}, sort_keys=True))

for payload in ({'lead_minutes': 25}, {'background_age_minutes': float('nan')},
                {'background_age_minutes': 61}, {'coverage_percent': 50.0}):
    try:
        module.ExperimentSettings.from_payload(payload)
    except ValueError as exc:
        print(json.dumps({'case': 'reject', 'payload': repr(payload), 'error': str(exc)}, sort_keys=True))
    else:
        print(json.dumps({'case': 'unexpected-accept', 'payload': repr(payload)}, sort_keys=True))
