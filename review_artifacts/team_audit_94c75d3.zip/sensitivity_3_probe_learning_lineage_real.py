import sys
sys.path[:0] = ['/Users/yhlee/ADVAR/tests', '/Users/yhlee/ADVAR/src']
from dataclasses import replace
import torch
import test_sensitivity as ts
from advar.nowcast import (RadarGridTimeContract, radar_projected_crs_semantic_digest,
    RADAR_PROJECTED_GRID_COORDINATE_DTYPE, RADAR_PROJECTED_GRID_CELL_CENTER_CONVENTION,
    CURRENT_RADAR_METRIC_DOMAIN, CURRENT_RADAR_METRIC_DOMAIN_EVIDENCE)
from advar.sensitivity import (SensitivityConfig, VariationalAdjointConfig,
    MetricTaylorThreshold, AutomatedLearningPolicy, VariationalObservationPerturbation,
    FirstOrderValidation, LearningEligibility, LearningApprovalEvidence,
    VariationalLearningImpact, compute_variational_fsoi,
    validate_variational_learning_impact, _variational_impact_digest)

torch.set_num_threads(1)
torch.set_num_interop_threads(1)
ts.VariationalFSOTests.setUpClass()
fixture = ts.VariationalFSOTests
grid = RadarGridTimeContract(
    valid_times=('2026-08-05T00:00:00Z','2026-08-05T00:10:00Z','2026-08-05T00:20:00Z'),
    dx_m=1000.0, dy_m=1000.0, projection='EPSG:5179', grid_hash='4'*64,
    spatial_grid_contract='radar-spatial-grid-identity-v6', grid_shape_yx=tuple(fixture.frames.shape[-2:]),
    projected_crs_digest=radar_projected_crs_semantic_digest('EPSG:5179'),
    metric_domain_digest=CURRENT_RADAR_METRIC_DOMAIN.digest,
    metric_domain_evidence_digest=CURRENT_RADAR_METRIC_DOMAIN_EVIDENCE.digest,
    cell_center_origin_xy_m=(1_000_000.0, 2_000_000.0),
    grid_coordinate_dtype=RADAR_PROJECTED_GRID_COORDINATE_DTYPE,
    cell_center_convention=RADAR_PROJECTED_GRID_CELL_CENTER_CONVENTION)
forecast, analysis = ts.variational_nowcast(
    fixture.frames, nowcast_config=fixture.nowcast_config,
    analysis_config=fixture.analysis_config, grid_time_contract=grid)
linearization = analysis.linearization
assert linearization is not None
verification_frames = torch.where(torch.isfinite(forecast.forecast_dbz), forecast.forecast_dbz - 0.5, forecast.forecast_dbz)
verification = ts._current_verification_bundle(
    verification_frames, valid_times=('2026-08-05T00:30:00Z',), grid_time_contract=grid)
policy = AutomatedLearningPolicy(
    sensitivity_config=replace(SensitivityConfig.for_automated_learning(radar_product_digest='5'*64, qc_pipeline_digest='6'*64), metric_names=('log_echo_mse',), full_map_lead_minutes=(10,), tile_size=4),
    adjoint_config=replace(VariationalAdjointConfig.for_automated_learning(), lead_minutes=(10,)),
    algorithm_bundle_digest=linearization.algorithm_bundle_digest,
    numerical_runtime_digest=linearization.numerical_runtime_digest,
    ranking_objective='absolute_influence',
    metric_taylor_thresholds=(MetricTaylorThreshold('log_echo_mse', 1e-6, 1e-8),))
delta = torch.zeros_like(linearization.observations.dbz)
index = tuple(int(value) for value in torch.nonzero(linearization.observations.detected_mask, as_tuple=False)[0])
delta[index] = 5.0e-6
perturbation = VariationalObservationPerturbation.from_radar_dbz_delta(delta, linearization)
fsoi = compute_variational_fsoi(forecast, analysis, verification, perturbation, sensitivity_config=policy.sensitivity_config, adjoint_config=policy.adjoint_config)
impact = fsoi.observation.baseline_branch_trusted_total
assert impact is not None
sha = lambda ch: ch * 64
validation = FirstOrderValidation(
    source_fsoi_digest=fsoi.variational_fsoi_digest, nominal_forecast_digest=forecast.forecast_run_digest,
    nominal_input_bundle_digest=forecast.run.input_bundle_digest, nominal_full_analysis_input_digest=forecast.run.full_analysis_input_digest,
    full_step_prediction=torch.ones((1,1)), full_step_resolved_metric_change=torch.ones((1,1)), full_step_absolute_error=torch.zeros((1,1)),
    half_step_prediction=torch.ones((1,1)), half_step_resolved_metric_change=torch.ones((1,1)), half_step_absolute_error=torch.zeros((1,1)),
    metric_available=torch.ones((1,1), dtype=torch.bool), full_step_resolved_analysis_converged=True, half_step_resolved_analysis_converged=True,
    active_branch_valid=True, full_step_valid=True, half_step_valid=True, sign_consistent_for_material_impacts=True,
    material_metric_count=1, maximum_material_impact=1.0, aggregate_material_impact_norm=1.0, first_order_valid=True,
    full_step_analysis_digest=sha('a'), half_step_analysis_digest=sha('b'), full_step_forecast_digest=sha('c'), half_step_forecast_digest=sha('d'))
def evidence(nominal_full):
    return LearningApprovalEvidence(
        policy_digest=policy.digest, trust_store_digest=sha('e'), fsoi_digest=fsoi.variational_fsoi_digest,
        full_step_analysis_digest=sha('a'), half_step_analysis_digest=sha('b'), full_step_forecast_digest=sha('c'), half_step_forecast_digest=sha('d'),
        first_order_validation_digest=validation.validation_digest, learning_impact_digest=_variational_impact_digest(impact),
        approved_action_digest=fsoi.perturbation_digest, nominal_input_bundle_digest=validation.nominal_input_bundle_digest,
        nominal_full_analysis_input_digest=nominal_full)
eligibility = LearningEligibility(eligible=True, reasons=(), policy_digest=policy.digest)
legitimate = VariationalLearningImpact(eligibility=eligibility, fsoi=fsoi, first_order_validation=validation, frozen_domain_learning_impact=impact, approval_evidence=evidence(validation.nominal_full_analysis_input_digest))
forged = VariationalLearningImpact(eligibility=eligibility, fsoi=fsoi, first_order_validation=validation, frozen_domain_learning_impact=impact, approval_evidence=evidence(sha('f')))
validate_variational_learning_impact(legitimate)
validate_variational_learning_impact(forged)
print('fso_contract', fsoi.fso.contract, 'fsoi_contract', fsoi.contract)
print('nominal_full_analysis_validation', validation.nominal_full_analysis_input_digest)
print('nominal_full_analysis_evidence', forged.approval_evidence.nominal_full_analysis_input_digest)
print('forged_validation_passed', True)
