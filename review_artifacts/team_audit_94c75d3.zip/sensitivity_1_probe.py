from __future__ import annotations

from fractions import Fraction
import math
import torch

import advar.sensitivity as s


def check_square_intervals() -> tuple[int, int]:
    gen = torch.Generator().manual_seed(101)
    lower = (torch.rand(1000, generator=gen, dtype=torch.float64) - 0.5) * 1e5
    upper = lower + torch.rand(1000, generator=gen, dtype=torch.float64) * 1e5
    lo, hi = s._directed_tensor_square_interval(lower, upper)
    misses = 0
    first = None
    for a, b, l, u in zip(lower.tolist(), upper.tolist(), lo.tolist(), hi.tolist()):
        fa, fb, fl, fu = map(Fraction.from_float, (a, b, l, u))
        exact_lo = Fraction(0) if fa <= 0 <= fb else min(fa * fa, fb * fb)
        exact_hi = max(fa * fa, fb * fb)
        if fl > exact_lo or fu < exact_hi:
            misses += 1
            if first is None:
                first = (a, b, l, u, float(exact_lo), float(exact_hi), fl > exact_lo, fu < exact_hi,
                         str(fl - exact_lo), str(fu - exact_hi))
    print("square_first_miss", first)
    return misses, len(lower)


def check_ground_range_intervals() -> tuple[int, int]:
    gen = torch.Generator().manual_seed(102)
    projected = torch.rand(1000, generator=gen, dtype=torch.float64) * 300.0
    lo, hi = s._ground_range_interval_km_float64(projected)
    error = Fraction.from_float(s.CURRENT_RADAR_METRIC_DOMAIN.maximum_linear_scale_error)
    misses = 0
    for p, l, u in zip(projected.tolist(), lo.tolist(), hi.tolist()):
        fp, fl, fu = map(Fraction.from_float, (p, l, u))
        exact_lo = fp / (Fraction(1) + error)
        exact_hi = fp / (Fraction(1) - error)
        misses += int(fl > exact_lo or fu < exact_hi)
    return misses, len(projected)


def check_range_pipeline_enclosure() -> tuple[int, int]:
    gen = torch.Generator().manual_seed(104)
    raw_dx = (torch.rand(1000, generator=gen, dtype=torch.float64) - 0.5) * 1e5
    raw_dy = (torch.rand(1000, generator=gen, dtype=torch.float64) - 0.5) * 1e5
    scales = torch.tensor([1e-300, 1e-200, 1e-100, 1e-10, 1.0, 1e10, 1e100, 1e150, 1e200, 1e300], dtype=torch.float64)
    raw_dx = torch.cat((raw_dx, scales, -scales))
    raw_dy = torch.cat((raw_dy, -scales, scales))
    neg = torch.full_like(raw_dx, -torch.inf)
    pos = torch.full_like(raw_dx, torch.inf)
    dx_lower, dx_upper = torch.nextafter(raw_dx, neg), torch.nextafter(raw_dx, pos)
    dy_lower, dy_upper = torch.nextafter(raw_dy, neg), torch.nextafter(raw_dy, pos)
    dx2_lower, dx2_upper = s._directed_tensor_square_interval(dx_lower, dx_upper)
    dy2_lower, dy2_upper = s._directed_tensor_square_interval(dy_lower, dy_upper)
    squared_lower = torch.nextafter(dx2_lower + dy2_lower, neg).clamp_min(0.0)
    squared_upper = torch.nextafter(dx2_upper + dy2_upper, pos)
    projected_lower = torch.nextafter(torch.nextafter(torch.sqrt(squared_lower), neg) / 1000.0, neg)
    projected_upper = torch.nextafter(torch.nextafter(torch.sqrt(squared_upper), pos) / 1000.0, pos)
    misses = 0
    for a, b, c, d, l, u in zip(dx_lower.tolist(), dx_upper.tolist(), dy_lower.tolist(), dy_upper.tolist(), projected_lower.tolist(), projected_upper.tolist()):
        if not all(math.isfinite(v) for v in (a, b, c, d, l, u)):
            continue
        fa, fb, fc, fd, fl, fu = map(Fraction.from_float, (a, b, c, d, l, u))
        exact_lo = Fraction(0) if fa <= 0 <= fb else min(fa * fa, fb * fb)
        exact_lo += Fraction(0) if fc <= 0 <= fd else min(fc * fc, fd * fd)
        exact_hi = max(fa * fa, fb * fb) + max(fc * fc, fd * fd)
        # Compare squared meters to avoid independent sqrt rounding.
        misses += int(fl * 1000 * fl * 1000 > exact_lo or fu * 1000 * fu * 1000 < exact_hi)
    return misses, len(raw_dx)


def check_top2_oracle() -> bool:
    gen = torch.Generator().manual_seed(103)
    lower = torch.rand((5, 2, 2, 3), generator=gen, dtype=torch.float64)
    upper = lower + torch.rand(lower.shape, generator=gen, dtype=torch.float64)
    eligible = torch.rand(lower.shape, generator=gen, dtype=torch.float64) > 0.2
    lower = torch.where(eligible, lower, torch.zeros_like(lower))
    upper = torch.where(eligible, upper, torch.zeros_like(upper))
    expected = []
    for i in range(lower.shape[0]):
        rivals = torch.cat((upper[:i], upper[i + 1 :]), dim=0).amax(dim=0)
        expected.append(torch.where(eligible[i] & (lower[i] > rivals), lower[i], torch.zeros_like(lower[i])))
    actual = s._strictly_dominating_source_scores(
        score_lower=lower, score_upper=upper, eligible=eligible
    )
    return torch.equal(actual, torch.stack(expected))


if __name__ == "__main__":
    square = check_square_intervals()
    ground = check_ground_range_intervals()
    pipeline = check_range_pipeline_enclosure()
    top2 = check_top2_oracle()
    print({"square_interval_misses": square[0], "square_cases": square[1],
           "ground_interval_misses": ground[0], "ground_cases": ground[1],
           "range_pipeline_misses": pipeline[0], "range_pipeline_cases": pipeline[1],
           "top2_oracle": top2})
    if ground[0] or pipeline[0] or not top2:
        raise SystemExit(1)
