# sensitivity_4 audit (GREEN assignment)

Baseline: `94c75d3323c986b6fb2963336b906acc85384e12`

## Confirmed finding

### Endpoint-only P0 branch certification accepts an interior FFT-peak switch (P1)

Location: `src/advar/sensitivity.py:16869-16877`, especially the fixed checks at scales `0.5` and `1.0`.

`_baseline_dynamics_branch_certification()` labels a physical perturbation `certified` when the nominal P0 branch signature equals the signature at `observations + 0.5*delta` and `observations + delta`.  The P0 signature contains discrete FFT integer peaks and pair/growth selections (`_p0_tendency_branch_signature`, lines 16880-16949).  Equality at those two endpoints does not imply equality throughout the interpolation interval: a discrete peak can switch and switch back.

The runnable fixture probe `sensitivity_4_branch_probe.py` uses the actual `compute_variational_fsoi()` path on `VariationalFSOTests`' converged 3x8x8 P1 fixture.  A deterministic seed-22 candidate (loop index 80) changes 30 detected pixels by raw `randn * 0.15` values; the realized maximum absolute delta is `0.3136172199` dBZ and the realized dBZ L2 norm is `0.8682211608` (both within the configured local/trust limits).  The signatures are equal to nominal at scales `[0.5, 0.75, 1.0]` but differ at `0.25`; pair `(1, 0)` has nominal peak `(0, 0)` and quarter-step peak `(1, 0)`.  `_baseline_branch_is_stable()` nevertheless returns `True`.  With the explicitly allowed `VariationalAdjointConfig(maximum_perturbed_fraction=1.0, maximum_perturbed_pixel_count=100, require_baseline_dynamics_branch_validity=True)`, the public `compute_variational_fsoi()` call is accepted and reports `baseline_dynamics_branch_status='certified'`.

The fixture uses a raw verification Tensor, so its FSOI is explicitly exploratory (`legacy-verification-tensor-v1`), with one requested lead and one metric.  `observation.total.sum_by_time` has shape `(1, 1, 3)`; the reported scalar sums only its three input-time components for that one lead/metric.  The nominal FSO forecast score is `0.013254745276196113`, matching an independent `forecast_metric` evaluation on the same issued metric domain.  The resolved comparison uses the exact issued-domain weight from `_metric_domain_weight` (49 valid cells).  The resulting signed FSOI metric change is `-3056.3544135606753`, while a converged robust `variational_nowcast()` re-solve at the same full delta changes that same `log_echo_mse` by `+8.34792977572503e-05`.  This is a reachable public-path mismatch when a caller selects the permitted larger perturbation-area budget.  The default 0.05 fraction rejects this particular 30-pixel fixture; the branch certifier itself has no guarantee for the configured interval, and the strict branch gate does not repair that.

## Automated-learning gate separation

The branch certificate is not evidence that this candidate is learning-approved.  Running the actual `_learning_impact_from_fsoi`/`compute_variational_fsoi_for_learning` path with a policy-shaped shim matching the fixture's exploratory metric and strict branch gate performs the separate full/half robust re-solves: it returns `eligible=False`, reason `first_order_validation_failed`, and `first_order_valid=False` (both full and half Taylor checks fail).  A second policy-shaped shim using `SensitivityConfig.for_automated_learning(...)` rejects the same raw Tensor earlier with `complete verification lineage requires VerificationBundle`.  A real `AutomatedLearningPolicy` additionally requires current typed verification, physical grid settings, and approved digests.  Therefore this probe demonstrates a certified FSOI false positive in the public diagnostic path; it does not claim that the shown raw exploratory fixture passed automated learning approval.

Impact boundary: this does not claim every perturbation is wrong, and the existing local tests cover smooth/single-path perturbations.  It demonstrates that the branch-validity certificate is unsound for non-monotone discrete P0 signatures, allowing a first-order impact to cross an unobserved branch and materially disagree with the resolved forecast.

## GREEN preserved

The metric helpers were checked against independent scalar oracles on 2x2 tensors.  `log_echo_mse`, 1-pixel soft FSS, centroid error, joint evidence ratios, tile layout/norms, output-cap bound, and conflict trust penalty matched (soft FSS difference `1.64e-9`, attributable to dBZ/echo round trip).  Physical footprint/centroid tests and adjoint/perturb-and-resolve tests passed.  No source or test files in the repository were modified.

## Commands/results and limitations

- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-team-audit-94c75d3/sensitivity_4_probe.py` — independent helper checks completed.
- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-team-audit-94c75d3/sensitivity_4_branch_probe.py` — branch counterexample, exact one-lead/one-metric aggregation, resolved issued-domain comparison, exploratory FSOI label, first-order learning rejection, and raw-Tensor lineage rejection completed.
- `... pytest -q tests/test_sensitivity.py -k 'soft_fss_is_zero_for_identity_and_symmetric_for_a_miss or joint_evidence_rejects_spatially_disjoint_marginals or physical_metric_uncertainty_reaches_soft_fss_footprint'` — 2 passed (one requested name was not selected).
- `... pytest -q tests/test_sensitivity.py -k 'physical_fss_uses_exact_anisotropic_affine_footprint or scalar_observation_sensitivity_sign_is_independent or variational_fso_matches_dense_and_finite_difference'` — 3 passed.
- `... pytest -q tests/test_sensitivity.py -k 'correlated_observation_fso_matches_perturb_and_resolve or censored_and_weight_sensitivity_match_perturb_and_resolve or variational_fsoi_requires_and_applies_explicit_perturbation'` — 3 passed.
- `... pytest -q tests/test_sensitivity.py -k 'empty_centroid_and_invalid_configs_are_explicit or soft_fss_handles_a_grid_smaller_than_its_window or m0_uses_the_issued_forecast_confidence'` — 3 passed / 15 subtests.
- `... pytest -q tests/test_sensitivity.py -k 'variational_fso_matches_observation_perturb_and_resolve'` — 1 passed.
- `python -I -m compileall -q src/advar/sensitivity.py` — passed.

No full baseline or broad sensitivity suite was run.  The branch counterexample uses the repository's test fixture and a permitted non-default perturbation fraction; it is saved as executable code and output in `/tmp/advar-team-audit-94c75d3/sensitivity_4_branch_probe.py` and `.stdout.txt`.
