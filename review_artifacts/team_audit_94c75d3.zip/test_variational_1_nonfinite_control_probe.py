import sys

import torch

sys.path.insert(0, "/Users/yhlee/ADVAR/src")

from advar.variational import (
    analysis_trajectory,
    initial_control,
    observation_residual_dbz,
    prepare_analysis,
    residual_vector,
    whitened_observation_residual,
)


frames = torch.full((3, 2, 2), 20.0, dtype=torch.float64)
observations, frozen = prepare_analysis(frames)
base = initial_control(frozen)
print("control_shape", tuple(base.shape), "active", int(frozen.active_field_index.numel()))
for value in (float("nan"), float("inf"), float("-inf")):
    control = base.clone()
    control[0] = value
    print("value", repr(value))
    try:
        trajectory = analysis_trajectory(control, frozen)
        print(
            " trajectory_accepted", True,
            "allfinite_frames", bool(torch.isfinite(trajectory.frames_linear).all()),
            "allfinite_displacement", bool(torch.isfinite(trajectory.displacement_yx).all()),
            "allfinite_growth", bool(torch.isfinite(trajectory.log_growth_per_step).all()),
        )
    except Exception as exc:
        print(" trajectory_error", type(exc).__name__, str(exc))
    for name, fn in (
        ("observation", observation_residual_dbz),
        ("whitened", whitened_observation_residual),
    ):
        try:
            value_tensor = fn(control, observations, frozen)
            print(
                "", name, "accepted", True,
                "allfinite", bool(torch.isfinite(value_tensor).all()),
                "nan_count", int(torch.isnan(value_tensor).sum()),
                "inf_count", int(torch.isinf(value_tensor).sum()),
            )
        except Exception as exc:
            print("", name, "error", type(exc).__name__, str(exc))
    try:
        residual = residual_vector(control, observations, frozen)
        print(
            " residual_accepted", True,
            "allfinite", bool(torch.isfinite(residual).all()),
            "nan_count", int(torch.isnan(residual).sum()),
            "inf_count", int(torch.isinf(residual).sum()),
        )
    except Exception as exc:
        print(" residual_error", type(exc).__name__, str(exc))
