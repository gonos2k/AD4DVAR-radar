# promotion_5 audit (GREEN)

Baseline: `94c75d3323c986b6fb2963336b906acc85384e12`. The assigned range `src/advar/promotion.py:22801-28050` was read completely in bounded chunks. I also traced the scientific scoring caller (`ScoringReplayCaseArtifact.recompute_evaluation`), EpisodeLedger operational callers, and `run_artifact`'s authoritative current-forecast loader.

## Confirmed findings

None.

The assigned range is mostly signed deployment and operational-ledger artifact handling. The current scientific path is `PriorHoldoutEvaluation.from_forecasts` plus `ScoringReplayCaseArtifact.recompute_evaluation`; operational deployment selection is separately gated by the current package's explicit `OperationalDeploymentUnsupportedError` entry point. No reachable scientific computation accepted an unsigned deployment artifact or bypassed the exact classifier/input replay checks.

## Unconfirmed candidates

1. `src/advar/promotion.py:13627-13675` normalizes omitted classifier channels to tensors and always passes them to `NeuralPriorRegimeClassifier.classify`, while `src/advar/promotion.py:23629-23637` deliberately rejects any channels for a legacy v4 classifier. The runnable probe shows direct v4 classification without channels succeeds and the same classifier with channels raises `legacy classifier cannot accept learned input channels`. This is an API compatibility hazard if a caller invokes `PriorHoldoutEvaluation.from_forecasts` with a legacy classifier and omits channels. The current authoritative replay object requires the v5 learned feature contract and always supplies these channels (`promotion.py:15905+`), so no current promotion/scoring path was shown to hit it; retain as a legacy compatibility candidate only.

2. `_validate_operational_deployment_decision_certificate` (`src/advar/promotion.py:27159+`) requires that `authority_trust_store_digest` be a valid digest but does not directly compare it to the currently loaded authority trust store, unlike the release/runtime validators (`25069`, `25423`). This is a defense-in-depth lineage omission. In the public artifact path, the same artifact also carries release approval and runtime activation receipts, each of which is checked against the current trust-store digest, and the operational signer is checked against current role/revocation data. I found no realistic acceptance path using this omission alone; keep unconfirmed and low priority.

## GREEN preserved

- `NeuralPriorRegimeClassifier` binds input tensor digest, model state digest, exported graph digest, runtime identity, dtype, and device before classification. Learned-channel inputs are shape/device/range/finiteness checked by `learned_radar_input_features` and cross-checked against `ForecastRunContract` digests.
- Softmax/sigmoid are evaluated in float64 and entropy clamps probabilities before `log`; an extreme-logit probe produced finite probabilities and entropy and passed evidence digest/integrity validation.
- Release and runtime loaders enforce absolute paths, `O_NOFOLLOW`, root ownership, non-writable files, bounded reads, canonical JSON bytes, digest equality, current trust validity, and (for current runtime loads) runtime closure validation. The legacy loader regression tests pass.
- Operational replay recomputes selection from signed evidence/policy and checks exact semantic products when running in the ledger issuance path. The public deployment artifact validator verifies current trust stores, signed receipt lineage, external policy approval, provenance commitments, operational grid identity, and current runtime when requested.
- `validate_neural_prior_deployment_decision_artifact` and the forecast artifact caller are deployment artifact validators; they do not turn promotion evidence into scientific inference. `infer_deployed_neural_prior` and `_validate_operational_deployment_generation` explicitly reject operational selection in the scientific package.

## Commands/results and limitations

- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -m pytest -q tests/test_review_legacy_loaders.py tests/test_numerical_review.py -q` — 18 passed.
- Focused classifier/replay tests (`tests/test_promotion.py -k ...`) — 5 passed, 222 deselected.
- `tests/test_contract_registry.py::ContractRegistryTests::test_current_package_explicitly_rejects_operational_deployment` — 1 passed.
- Probes and their output are saved as `/tmp/advar-team-audit-94c75d3/promotion_5_classifier_probe.py`, `promotion_5_classifier_probe.out`, `promotion_5_legacy_classifier_probe.py`, and `promotion_5_legacy_classifier_probe.out`.
- No source, test, branch, deployment artifact, or running producer was modified. No full baseline or broad promotion/ledger suite was run. The two candidates above were not promoted to confirmed findings because their current authoritative callers either require the learned v5 contract or bind sibling artifacts to the current authority trust digest.
