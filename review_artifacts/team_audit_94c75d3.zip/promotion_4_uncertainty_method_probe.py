from types import SimpleNamespace

import advar.promotion as promotion


def run(bootstrap_samples: int):
    policy = SimpleNamespace(
        maximum_exact_sign_clusters=1,
        bootstrap_samples=bootstrap_samples,
        confidence_level=0.95,
        allow_shadow_small_sample_bootstrap=False,
    )
    clusters = tuple(f"event-{index}" for index in range(20))
    # Nonzero variance forces the branch that would use random multipliers.
    values = tuple(-0.02 + 0.001 * index for index in range(20))
    result = promotion._simultaneous_uncertainty_upper_bounds(
        (
            promotion._UncertaintyComparison(
                component="support",
                group=None,
                values=values,
                clusters=clusters,
            ),
        ),
        policy,
        candidate_family_size=16,
    )
    return {
        "bootstrap_samples": bootstrap_samples,
        "method": result.method,
        "effective_replicates": result.effective_replicates,
        "randomized_multiplier": result.randomized_multiplier,
        "tail_replicates": result.tail_replicates,
        "bound": result.comparison_bounds[("support", None)],
    }


if __name__ == "__main__":
    first = run(1_024)
    second = run(16_384)
    print({"small": first, "large": second})
    assert first["method"] == second["method"] == "support_bounded_hybrid"
    assert first["randomized_multiplier"] is True
    assert first["effective_replicates"] == 1_024
    assert second["effective_replicates"] == 16_384
    # Automatic mode computes the bounded UCB, so changing bootstrap count
    # must not change the bound (apart from exact arithmetic identity).
    assert first["bound"] == second["bound"]
    assert first["tail_replicates"] < second["tail_replicates"]
    assert first["tail_replicates"] < 20.0 < second["tail_replicates"]
