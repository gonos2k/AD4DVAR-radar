import importlib.util
import sqlite3
from pathlib import Path

spec = importlib.util.spec_from_file_location("test_ledger_probe", Path("tests/test_ledger.py"))
module = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(module)

module.EpisodeLedgerTests.setUpClass()
case = module.EpisodeLedgerTests("test_duplicate_episode_id_is_rejected")
case.setUp()
try:
    case.ledger.append(case.episode("row-mismatch"))
    with sqlite3.connect(case.ledger.index_path) as connection:
        connection.execute("DROP TRIGGER episodes_no_update")
        connection.execute(
            "UPDATE episodes SET radar_id = 'CORRUPTED' "
            "WHERE episode_id = 'row-mismatch'"
        )
    try:
        case.ledger.verify("row-mismatch")
        verification = "PASS"
    except Exception as error:  # probe output only
        verification = f"FAIL {type(error).__name__}: {error}"
    print({"verify": verification, "list_radar_id": case.ledger.list_episodes()[0]["radar_id"]})
finally:
    case.tearDown()
