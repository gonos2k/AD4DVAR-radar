# build_geometry audit (RED)

Baseline: `94c75d3323c986b6fb2963336b906acc85384e12`

## Confirmed finding

### BG-01 — Linux ARM bundle builds but cannot verify

- Files: `.github/scripts/build_deployment_bundle.py:829-830`, `:945`, `:1009-1013`.
- Assumption violated: the `build` command accepts every Linux host (it only rejects non-Linux), and writes the host architecture into `manifest["platform"]`; `verify_bundle` then requires the fixed identity `linux-x86_64-cpu`.
- Minimal reachable reproduction: `build_geometry_platform_probe.py` patches the normal platform calls to `system() == "Linux"`, `machine() == "aarch64"`, and uses the existing candidate fixture shape. The build succeeds and writes `built_platform linux-aarch64-cpu`; verifying the resulting bundle fails with `ValueError: deployment bundle identity or digest is invalid`.
- Expected behavior: reject non-x86 Linux before writing a bundle, or have verification accept exactly the supported architecture set. A successfully built bundle should be self-verifiable under the same platform identity.
- Impact boundary: reachable on Linux ARM64 (or any Linux machine string other than `x86_64`) through the public `build` CLI/API. Current GitHub Actions runners are x86_64, so existing CI is unaffected; this is a legacy deployment scaffold per README and does not affect the scientific package path.

## Unconfirmed candidates

- `.github/scripts/generate_metric_domain_evidence.py:640-702` constructs an “inscribed” projected rectangle from 10,001 samples on each geographic boundary, then checks only the sampled projected rectangle boundary after inverse projection. There is no analytic or exhaustive interior proof in the generator. A 100,001-sample boundary and a 201x201 inverse projected-rectangle lattice found the same integer bounds and zero points outside the EPSG geographic box, so no concrete counterexample was found.
- `generate_metric_domain_evidence.py --check` is intentionally environment-bound by the recorded executable/library hashes. On this host, Python 3.12.13 and upgraded Homebrew libraries produce a nonmatching report; Python 3.10.11 matches projection/sample reductions but still differs in current dynamic-library closure (the committed report records older JPEG/TIFF versions). This is consistent with the report’s independent sealed-environment requirement; CI currently runs source binding and Linux closure self-test, not full report reproducibility. Treat as reproducibility/CI coverage risk, not a confirmed scientific defect.

## GREEN preserved

- `tests/test_deployment_bundle.py tests/test_review_legacy_loaders.py`: 10 tests passed, 8 subtests passed.
- Targeted metric evidence tests in `tests/test_nowcast.py`: 4 passed, 163 deselected, 28 subtests passed.
- Generator source binding passed and loader override rejection behaved as designed.
- Boundary probe: 10,001 and 100,001 samples yielded the same projected bounds `(592664, 1576674, 976711, 2251910)`; a 201x201 projected rectangle inverse lattice had 0 points outside the EPSG area-of-use box.
- Directed affine interval probe over 20,000 deterministic random finite matrices found 0 norm-enclosure failures and 0 determinant-enclosure failures.

## Commands and limitations

- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 .venv/bin/python -I -m pytest -q tests/test_deployment_bundle.py tests/test_review_legacy_loaders.py`
- `env -u LD_LIBRARY_PATH ... .venv/bin/python -I .github/scripts/generate_metric_domain_evidence.py --check-source-only --output src/advar/data/epsg5179_metric_domain_evidence_v4.json`
- `env -u LD_LIBRARY_PATH ... .venv/bin/python -I .github/scripts/generate_metric_domain_evidence.py --check ...` failed because this machine is not the sealed environment represented by the committed report; no source/report files were changed.
- No deployment, package installation, source edits, or broad suites were run.
