# Independent cross-check: sensitivity_4 P0 endpoint branch certificate

Baseline: `94c75d3323c986b6fb2963336b906acc85384e12`

## Confirmed finding

`src/advar/sensitivity.py:16859-16877` certifies a nonzero observation perturbation by comparing the nominal `_p0_tendency_branch_signature` only at interpolation scales `0.5` and `1.0`.  The signature includes discrete FFT integer peaks and pair/growth selections (`:16880-17190`).  Equality at two sampled endpoints does not imply equality over `[0, 1]`: a discrete signature can change and change back.  The public error text at `:16718-16720` calls this a frozen P0 tendency branch crossing, so the implementation's two-point test is insufficient for a path-wide branch certificate.

The independent deterministic probe `root_xbranch_probe.py` reproduces candidate 80 from `sensitivity_4_branch_probe.py` on the converged 3x8x8 CPU P1 fixture.  Its P0 signatures are unequal at `0.25` (pair `(1, 0)` peak changes from `(0, 0)` to `(1, 0)`) and equal at `0.5` and `1.0`; therefore `_baseline_branch_is_stable()` returns `True` and the public `compute_variational_fsoi()` accepts it with `require_baseline_dynamics_branch_validity=True`, reporting `certified`.  This is a mathematical counterexample to the endpoint test, independent of metric interpretation.

The perturbation correction is material: 30 nonzero pixels out of 192 valid analysis pixels (`0.15625` fraction), observed `max(abs(delta)) = 0.31361721990461344 dBZ`, and L2 norm `0.8682211607599049 dBZ`.  The generator multiplies standard normal values by `0.15`; `0.15` is not an observed per-pixel maximum.  The default `maximum_perturbed_fraction=0.05` rejects this fixture with `observation perturbation exceeds its area fraction`; the counterexample reaches the public FSOI only with the permitted explicit fraction `1.0` and pixel limit `100`.

## FSOI versus nonlinear resolve: what the probe establishes

For this fixture the comparison is metric-aligned.  The FSOI has one issued lead `(10,)`, one metric `('log_echo_mse',)`, and domain `issued`; its domain weight sum is `49`, exactly the 49 finite verification cells used by the resolve probe.  Thus the original numbers are not an all-metrics versus one-metric mismatch.  `sum_by_time` has shape `(1, 1, 3)`: the reported FSOI scalar `-3056.3544135606753` is the sum over the three input-time derivative channels for that one lead and metric.  Its per-input-time totals are `[3.578421319542092e-05, -3056.3512791346548, -0.003170210233832803]`.

The converged direct `variational_nowcast()` re-solve at the same full physical delta changes the issued `log_echo_mse` by `+8.34792977572503e-05`.  The FSOI total is numerically dominated by its `baseline_dynamics_dbz` channel (`-3056.3516969780694`), which is consistent with the P0 branch issue.  It does not prove that the entire FSOI-versus-resolve difference is caused solely by that one interior FFT branch.  The resolve changes the nonlinear P0/P1 state and metric together; possible contributors include the branch switch, nonlinear metric terms at a `0.3136 dBZ` perturbation, all other observation/initial-state paths, and any P1 re-solve effects.  The probe has no same-input controlled decomposition that holds every other path fixed while toggling only the interior P0 branch.  The defensible conclusion is that the certificate permits an unobserved P0 branch crossing, making the frozen first-order result untrusted for that candidate; the sole-cause attribution is unproven.

## Automated-learning gate is separate

The source separates direct FSOI from learning approval:

- `VariationalAdjointConfig.for_automated_learning()` (`src/advar/sensitivity.py:8908-8921`) enables active-set, feasibility, GN, and baseline-branch gates but leaves the `0.05` fraction and `4096` pixel defaults.  Therefore this exact 30-pixel fixture is rejected by the default fraction before learning validation.
- `compute_variational_fsoi_for_learning()` (`:13860-13921`) additionally requires a root-approved policy, physical radar perturbations, approved algorithm/runtime digests, and a complete verification lineage.  Applying the actual automated policy to this raw Tensor fixture rejects it with `complete verification lineage requires VerificationBundle`; this fixture is an exploratory `legacy-verification-tensor-v1` FSOI, not a current lineage-complete promotion case.
- The learning validator (`:14324-14439`) performs full and half nonlinear re-solves and requires convergence, P1 active-branch validity, both Taylor checks, sign consistency, and a material metric.  On the same exploratory fixture, using a valid-digest local policy shim only to exercise this gate, both re-solves converge and `active_branch_valid=True`, but `full_step_valid=False`, `half_step_valid=False`, and sign consistency is false; the wrapper returns `first_order_validation_failed`.  This is a separate downstream safeguard.  Its `active_branch_valid` check compares retained P1 analysis remap cells and neural-prior masks (`:14648-14665`), so it is not an independent whole-path proof of the P0 FFT signature.

README claims that baseline branch status distinguishes certified/invalid and that automated learning re-solves full and half physical steps (`README.md:1625-1628`, `:2620-2626`).  It does not document that certification means only the two sampled scales; the code therefore overstates the path guarantee implied by the status name and error contract.

## Probe and limitations

- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-team-audit-94c75d3/root_xbranch_probe.py` — passed.  Output is in `root_xbranch_probe.stdout.txt`.
- The public FSOI/resolve numbers use the repository's legacy raw-Tensor fixture, because that fixture has no grid/verification bundle.  The shared branch certifier is directly exercised, but a lineage-complete current `VerificationBundle` reproduction was not established here.
- No repository source or tests were modified.  Full MPS P1 remains the separately recorded NO-GO and is outside this CPU branch finding.
