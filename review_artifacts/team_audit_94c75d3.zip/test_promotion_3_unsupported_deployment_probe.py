import torch

import advar.promotion as promotion


for label, args, kwargs in (
    ("no_arguments", (), {}),
    (
        "mismatched_geometry_and_frame",
        (torch.zeros((3, 4, 4)),),
        {
            "range_geometry_contract": object(),
            "grid_x_m": torch.zeros((2, 2)),
            "grid_y_m": torch.zeros((2, 2)),
        },
    ),
):
    try:
        promotion.infer_deployed_neural_prior(*args, **kwargs)
    except Exception as error:
        print(label, type(error).__name__, str(error))
