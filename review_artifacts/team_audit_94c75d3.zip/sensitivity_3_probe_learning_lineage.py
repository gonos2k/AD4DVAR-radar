import sys
sys.path.insert(0, '/Users/yhlee/ADVAR/src')
from types import SimpleNamespace
from unittest.mock import patch
import torch
import advar.sensitivity as s

torch.set_num_threads(1)
torch.set_num_interop_threads(1)
d = lambda ch: ch * 64
shape = (1, 1)
validation = s.FirstOrderValidation(
    source_fsoi_digest=d('b'), nominal_forecast_digest=d('c'),
    nominal_input_bundle_digest=d('d'), nominal_full_analysis_input_digest=d('e'),
    full_step_prediction=torch.ones(shape),
    full_step_resolved_metric_change=torch.ones(shape),
    full_step_absolute_error=torch.zeros(shape),
    half_step_prediction=torch.ones(shape),
    half_step_resolved_metric_change=torch.ones(shape),
    half_step_absolute_error=torch.zeros(shape),
    metric_available=torch.ones(shape, dtype=torch.bool),
    full_step_resolved_analysis_converged=True,
    half_step_resolved_analysis_converged=True,
    active_branch_valid=True, full_step_valid=True, half_step_valid=True,
    sign_consistent_for_material_impacts=True, material_metric_count=1,
    maximum_material_impact=1.0, aggregate_material_impact_norm=1.0,
    first_order_valid=True, full_step_analysis_digest=d('f'),
    half_step_analysis_digest=d('0'), full_step_forecast_digest=d('1'),
    half_step_forecast_digest=d('2'),
)
impact = s.VariationalImpactChannel(
    maps=torch.zeros((1, 1, 3, 1, 1)),
    sum_by_time=torch.zeros((1, 1, 3)),
    tile_sum_by_time=torch.zeros((1, 1, 3, 1, 1)),
)
fake_fso = SimpleNamespace(contract='fake-fso', forecast_run_digest=d('c'))
fake_fsoi = SimpleNamespace(
    contract=s.CURRENT_VARIATIONAL_FSOI_CONTRACT,
    fso=fake_fso, variational_fsoi_digest=d('b'), perturbation_digest=d('3'),
)
eligibility = s.LearningEligibility(eligible=True, reasons=(), policy_digest=d('4'))

def make_evidence(nominal_full_digest):
    return s.LearningApprovalEvidence(
        policy_digest=d('4'), trust_store_digest=d('5'), fsoi_digest=d('b'),
        full_step_analysis_digest=d('f'), half_step_analysis_digest=d('0'),
        full_step_forecast_digest=d('1'), half_step_forecast_digest=d('2'),
        first_order_validation_digest=validation.validation_digest,
        learning_impact_digest=s._variational_impact_digest(impact),
        approved_action_digest=d('3'), nominal_input_bundle_digest=d('d'),
        nominal_full_analysis_input_digest=nominal_full_digest,
    )

with patch.object(s, 'validate_variational_fso', return_value=None), patch.object(s, 'validate_variational_fsoi', return_value=None):
    legitimate = s.VariationalLearningImpact(
        eligibility=eligibility, fsoi=fake_fsoi,
        first_order_validation=validation,
        frozen_domain_learning_impact=impact,
        approval_evidence=make_evidence(d('e')),
    )
    forged = s.VariationalLearningImpact(
        eligibility=eligibility, fsoi=fake_fsoi,
        first_order_validation=validation,
        frozen_domain_learning_impact=impact,
        approval_evidence=make_evidence(d('6')),
    )
    s.validate_variational_learning_impact(legitimate)
    s.validate_variational_learning_impact(forged)
    print('legitimate_nominal_full_analysis_digest', legitimate.approval_evidence.nominal_full_analysis_input_digest)
    print('validation_nominal_full_analysis_digest', validation.nominal_full_analysis_input_digest)
    print('forged_nominal_full_analysis_digest', forged.approval_evidence.nominal_full_analysis_input_digest)
    print('forged_validation_passed', True)
