import sys
from dataclasses import replace

import torch

sys.path.insert(0, "/Users/yhlee/ADVAR/tests")

from test_ledger import _computed_snapshot, _contract  # noqa: E402
from advar.ledger import EpisodeLedger, SensitivityEpisode  # noqa: E402


snapshot = _computed_snapshot()
unavailable = torch.zeros_like(snapshot.metric_available)
unavailable[0, 0] = True
available = ~unavailable
def mask_tensor(value):
    cloned = value.clone()
    cloned[unavailable] = float("nan")
    return cloned

mutated_forecast_scores = snapshot.forecast_scores.clone()
mutated_forecast_scores[unavailable] = float("nan")
mutated_control = snapshot.control_sensitivity.clone()
mutated_control[unavailable] = float("nan")
mutated_path = mask_tensor(snapshot.path_evidence_by_metric)
mutated_source = mask_tensor(snapshot.observation_source_fraction_by_metric)
mutated_verified = mask_tensor(snapshot.observation_verified_evidence_by_metric)
mutated_background = mask_tensor(snapshot.background_verified_evidence_by_metric)
mutated_norm = mask_tensor(snapshot.direct.norm)
mutated_tile_norm = mask_tensor(snapshot.direct.tile_norm)
mutated_snapshot = replace(
    snapshot,
    forecast_scores=mutated_forecast_scores,
    metric_available=available,
    control_sensitivity=mutated_control,
    path_evidence_by_metric=mutated_path,
    observation_source_fraction_by_metric=mutated_source,
    observation_verified_evidence_by_metric=mutated_verified,
    background_verified_evidence_by_metric=mutated_background,
)
direct = replace(
    snapshot.direct,
    norm=mutated_norm,
    tile_norm=mutated_tile_norm,
    impact=mutated_snapshot.direct.impact.clone(),
    tile_impact=mutated_snapshot.direct.tile_impact.clone(),
)
assert direct.impact is not None and direct.tile_impact is not None
direct.impact[unavailable] = float("nan")
direct.tile_impact[unavailable] = 17.0
mutated = replace(mutated_snapshot, direct=direct)
episode = SensitivityEpisode(
    episode_id="tile-unavailable-finite",
    issue_time="2026-07-26T05:00:00+00:00",
    radar_id="KTLX",
    contract=_contract(snapshot),
    snapshot=mutated,
    action_features=(1.25, -0.5),
)

with __import__("tempfile").TemporaryDirectory() as tmp:
    ledger = EpisodeLedger(tmp)
    target = ledger.append(episode)
    ledger.verify(episode.episode_id)
    loaded = ledger.load(episode.episode_id)
    print("accepted", target.name, "tile_unavailable_value", loaded.arrays["tile_direct_observation_impact"][0, 0].tolist())


def nan_tensor(shape, dtype=None):
    dtype = dtype or snapshot.forecast_scores.dtype
    return torch.full(shape, float("nan"), dtype=dtype)


zero_direct = replace(
    snapshot.direct,
    maps=nan_tensor((len(snapshot.full_map_lead_minutes), 1, 0, 0)),
    norm=nan_tensor(snapshot.metric_available.shape),
    tile_norm=nan_tensor((len(snapshot.lead_minutes), 1, 0, 0)),
    whitened_tile_norm=None,
    impact=None,
    tile_impact=None,
    reward=None,
)
zero_snapshot = replace(
    snapshot,
    metric_available=torch.zeros_like(snapshot.metric_available),
    forecast_scores=nan_tensor(snapshot.forecast_scores.shape),
    control_sensitivity=nan_tensor(snapshot.control_sensitivity.shape),
    forecast_sensitivity=nan_tensor((len(snapshot.full_map_lead_minutes), 1, 0, 0)),
    forecast_cap_active_mask=torch.zeros((len(snapshot.full_map_lead_minutes), 0, 0), dtype=torch.bool),
    forecast_confidence=torch.empty((len(snapshot.lead_minutes), 0, 0)),
    path_evidence_by_metric=nan_tensor(snapshot.metric_available.shape),
    observation_source_fraction_by_metric=nan_tensor(snapshot.metric_available.shape),
    observation_verified_evidence_by_metric=nan_tensor(snapshot.metric_available.shape),
    background_verified_evidence_by_metric=nan_tensor(snapshot.metric_available.shape),
    direct=zero_direct,
    latest_sensitivity_mask=torch.empty((0, 0), dtype=torch.bool),
    observation_std_dbz=None,
    observation_innovation_dbz=None,
    observation_innovation_mask=None,
)
zero_episode = replace(episode, episode_id="zero-spatial", snapshot=zero_snapshot)
with __import__("tempfile").TemporaryDirectory() as tmp:
    ledger = EpisodeLedger(tmp)
    target = ledger.append(zero_episode)
    ledger.verify(zero_episode.episode_id)
    print("accepted_zero_spatial", target.name)


nonzero_maps = snapshot.direct.maps.clone()
nonzero_maps[0, 0, 0, 0] = 3.0
nonzero_norm = snapshot.direct.norm.clone()
nonzero_norm[2, 0] = 3.0
nonzero_tile_norm = snapshot.direct.tile_norm.clone()
nonzero_tile_norm[2, 0, 0, 0] = 3.0
arbitrary_whitened = replace(
    snapshot.direct,
    maps=nonzero_maps,
    norm=nonzero_norm,
    tile_norm=nonzero_tile_norm,
    whitened_tile_norm=torch.full_like(snapshot.direct.tile_norm, 999.0),
)
whitened_snapshot = replace(
    snapshot,
    direct=arbitrary_whitened,
    observation_std_dbz=torch.ones_like(snapshot.latest_sensitivity_mask, dtype=snapshot.forecast_scores.dtype),
)
whitened_episode = replace(
    episode,
    episode_id="arbitrary-whitened-norm",
    snapshot=whitened_snapshot,
)
with __import__("tempfile").TemporaryDirectory() as tmp:
    ledger = EpisodeLedger(tmp)
    target = ledger.append(whitened_episode)
    ledger.verify(whitened_episode.episode_id)
    print("accepted_arbitrary_whitened", target.name, "stored_value", ledger.load(whitened_episode.episode_id).arrays["tile_whitened_direct_sensitivity_norm"][2, 0].tolist(), "expected_with_std_one", [[3.0]])
