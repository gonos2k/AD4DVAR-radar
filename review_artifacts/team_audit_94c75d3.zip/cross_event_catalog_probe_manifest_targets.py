import sys
from dataclasses import replace

sys.path.insert(0, "/Users/yhlee/ADVAR/tests")

import advar.promotion as p
from test_promotion import NeuralPriorPromotionTests


fixture = NeuralPriorPromotionTests("runTest")
plan = fixture.plan()
first_plan_case, second_plan_case = plan.cases
shared_plan_case = replace(
    second_plan_case,
    uncertainty_target_plan_digest=first_plan_case.uncertainty_target_plan_digest,
    state_calibration_target_plan_digest=first_plan_case.state_calibration_target_plan_digest,
)
shared_plan = replace(
    plan,
    cases=(first_plan_case, shared_plan_case),
    uncertainty_target_plans=(plan.uncertainty_target_plans[0],),
    state_calibration_target_plans=(plan.state_calibration_target_plans[0],),
    verification_observation_error_plans=(
        plan.verification_observation_error_plans[0],
        plan.verification_observation_error_plans[2],
    ),
)

manifest = fixture.manifest()
first_case, second_case = manifest.holdout_cases
first_identity = first_case.verification_target_identity
shared_second_case = replace(
    second_case,
    uncertainty_target_plan_digest=first_case.uncertainty_target_plan_digest,
    uncertainty_target_digest=first_case.uncertainty_target_digest,
    verification_target_identity_artifact_json=first_identity.json,
    verification_target_identity_artifact_digest=first_identity.artifact_digest,
    state_calibration_target_plan_digest=first_case.state_calibration_target_plan_digest,
    state_calibration_target_digest=first_case.state_calibration_target_digest,
)
shared_manifest = replace(
    manifest,
    holdout_plan_digest=shared_plan.plan_digest,
    holdout_cases=(first_case, shared_second_case),
)

try:
    p.validate_neural_prior_candidate_manifest(shared_manifest)
except Exception as exc:
    print("manifest_duplicate_target_rejected", type(exc).__name__, str(exc))
else:
    print("manifest_duplicate_target_accepted", shared_manifest.manifest_digest)
    print(
        "manifest_target_identities",
        tuple(
            (
                case.verification_target_identity.source_identity_digest,
                case.verification_target_identity.target_valid_time,
                case.uncertainty_target_digest,
            )
            for case in shared_manifest.holdout_cases
        ),
    )
    scoring_input = p.HoldoutScoringInputArtifact.from_cases(
        shared_plan,
        candidate_prior_digest=shared_manifest.candidate_prior_digest,
        parent_prior_digest=shared_manifest.parent_prior_digest,
        candidate_training_manifest_digest=shared_manifest.candidate_training_manifest_digest,
        parent_training_manifest_digest=shared_manifest.parent_training_manifest_digest,
        holdout_cases=shared_manifest.holdout_cases,
    )
    print("scoring_input_duplicate_target_accepted", scoring_input.artifact_digest)
