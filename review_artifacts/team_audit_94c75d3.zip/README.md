# Second full code audit evidence

Baseline: 94c75d3323c986b6fb2963336b906acc85384e12.
34 GREEN/RED assignments used gpt-5.6-luna with xhigh reasoning.

Read ROOT_ADJUDICATION.md first. It supersedes provisional severity and reachability claims in individual reports. Examples: observation/frozen identity binding and duplicate full-input scorer claims were retracted; a zero-row outage helper probe and replay crash simulation were not promoted to public end-to-end defects. Cross reports distinguish M0, P1 FSO, removal, and learning paths.

manifest.json records the 71-file baseline and assignments. coverage_summary.json validates each assigned read range and the 166,618-line union against baseline Git blobs. EOF beyond a file's real last line is clipped. Extra cross-review ranges are not added to the count.

Unit .md reports explain commands, expected/observed values, use of private helpers or fixture mocks, and limits. Runnable probes and captured outputs are alongside them. Some .json-suffixed stdout is text, not JSON; parse only actual metadata files as JSON. Most probes use /Users/yhlee/ADVAR and its tests path; adapt those explicit paths on another checkout. Use the baseline checkout with Python 3.12.13/PyTorch 2.13.0 and OMP_NUM_THREADS=1 MKL_NUM_THREADS=1. No production data or operational secrets are included; signature fixtures use synthetic test keys.

ci_py310_94c75d3.log and ci_py312_94c75d3.log are completed baseline CI logs. Each has 8 identical failures, 887 passed and 8 skipped. postfix_* logs record fixture repairs, including intermediate failures and final clock success. The repaired eight CI tests and six neighboring tests passed locally (14 unique); this is not a rerun of the full baseline. Production source did not change during this audit.

ARTIFACT_MANIFEST.json lists SHA-256 of each archived file except itself. The ZIP's hash is in the external second_audit_validation.json. Historical first-audit artifacts were preserved.
