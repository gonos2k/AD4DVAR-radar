from dataclasses import replace
import torch
import advar.variational as v


def main() -> None:
    frames = torch.full((3, 3, 3), 20.0, dtype=torch.float64)
    observations, frozen = v.prepare_analysis(
        frames,
        analysis_config=v.AnalysisConfig(observation_common_bias_std_dbz=1.0),
    )
    changed = replace(observations, std_dbz=2.0 * observations.std_dbz)
    changed_dbz = changed.dbz.clone()
    changed_dbz[0, 0, 0] -= 2.0
    changed = replace(changed, dbz=changed_dbz)
    control = v.initial_control(frozen)
    stale = v.whitened_observation_residual(control, changed, frozen)
    standardized = (
        torch.sqrt(changed.quality_weight)
        * v._observation_residual(control, changed, frozen)
        / changed.std_dbz
    )
    fresh = v._apply_observation_error_whitener(
        standardized,
        changed,
        frozen.analysis_config,
        whitener=None,
    )
    print("accepted mismatched observation/frozen pair")
    print("max absolute mismatch", float(torch.amax(torch.abs(stale - fresh))))
    print("stale first", float(stale[0, 0, 0]), "fresh first", float(fresh[0, 0, 0]))


if __name__ == "__main__":
    main()
