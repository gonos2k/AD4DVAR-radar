"""Private-helper probe for non-divisible issuance leads (audit only)."""
from types import SimpleNamespace

import torch

import advar.sensitivity as sensitivity
from advar.sensitivity import SensitivityConfig


class Config:
    interval_minutes = 10
    min_dbz = -10.0
    max_dbz = 70.0


result = SimpleNamespace(
    run=SimpleNamespace(config=Config(), grid_time_contract="grid"),
    state=SimpleNamespace(echo_linear=torch.ones((1, 1), dtype=torch.float64)),
)
verification = SimpleNamespace(
    frames_dbz=torch.ones((6, 1, 1), dtype=torch.float64),
    valid_mask=torch.ones((6, 1, 1), dtype=torch.bool),
    metric_weight=torch.ones((6, 1, 1), dtype=torch.float64),
)
config = SensitivityConfig(
    metric_names=("log_echo_mse",),
    full_map_lead_minutes=(31,),
)
calls = []

originals = {
    "forecast_linear_at_step": sensitivity.forecast_linear_at_step,
    "_freeze_output_cap": sensitivity._freeze_output_cap,
    "_metric_has_support": sensitivity._metric_has_support,
    "forecast_metric": sensitivity.forecast_metric,
}
sensitivity.forecast_linear_at_step = (
    lambda state, step, nowcast: calls.append(step)
    or torch.ones((1, 1), dtype=torch.float64)
)
sensitivity._freeze_output_cap = lambda forecast, nowcast: (forecast, False)
sensitivity._metric_has_support = lambda *args: True
sensitivity.forecast_metric = lambda *args: torch.tensor(2.0)
try:
    scores, available = sensitivity._resolved_forecast_scores(
        result,
        result.state,
        verification,
        (31,),
        config,
        domain_weights=torch.ones((1, 1), dtype=torch.float64),
    )
finally:
    for name, value in originals.items():
        setattr(sensitivity, name, value)
print("requested_lead_minutes", 31)
print("interval_minutes", 10)
print("forecast_steps_called", calls)
print("score", scores.tolist(), "available", available.tolist())
