import sys
import torch
sys.path.insert(0, "/Users/yhlee/ADVAR/tests")
from test_sensitivity import _current_verification_bundle
from advar.variational import AnalysisConfig, variational_nowcast
from advar.nowcast import (
    CURRENT_RADAR_METRIC_DOMAIN,
    CURRENT_RADAR_METRIC_DOMAIN_EVIDENCE,
    RADAR_PROJECTED_GRID_COORDINATE_DTYPE,
    RADAR_PROJECTED_GRID_CELL_CENTER_CONVENTION,
    RadarGridTimeContract,
    radar_projected_crs_semantic_digest,
    NowcastConfig,
)
from advar.sensitivity import SensitivityConfig, _metric_domain_weight, _resolve_verification, _resolved_forecast_scores, compute_variational_fso, validate_variational_fso

torch.set_num_threads(1)
coords = torch.arange(8, dtype=torch.float64)
y, x = torch.meshgrid(coords, coords, indexing="ij")
frames = torch.stack(tuple(-10.0 + 40.0 * torch.exp(-((y - center).square() + (x - center).square()) / 4.0) for center in (3.0, 3.5, 4.0)))
grid = RadarGridTimeContract(
    valid_times=("2026-08-05T00:00:00Z", "2026-08-05T00:10:00Z", "2026-08-05T00:20:00Z"),
    dx_m=1000.0,
    dy_m=1000.0,
    projection="EPSG:5179",
    grid_hash="a" * 64,
    spatial_grid_contract="radar-spatial-grid-identity-v6",
    grid_shape_yx=(8, 8),
    projected_crs_digest=radar_projected_crs_semantic_digest("EPSG:5179"),
    metric_domain_digest=CURRENT_RADAR_METRIC_DOMAIN.digest,
    metric_domain_evidence_digest=CURRENT_RADAR_METRIC_DOMAIN_EVIDENCE.digest,
    cell_center_origin_xy_m=(1_000_000.0, 2_000_000.0),
    grid_coordinate_dtype=RADAR_PROJECTED_GRID_COORDINATE_DTYPE,
    cell_center_convention=RADAR_PROJECTED_GRID_CELL_CENTER_CONVENTION,
)
forecast, analysis = variational_nowcast(
    frames,
    nowcast_config=NowcastConfig(horizon_minutes=10),
    analysis_config=AnalysisConfig(
        censored_background_policy="detection_limit",
        maximum_outer_iterations=12,
        maximum_pcg_iterations=100,
        pcg_relative_tolerance=1.0e-8,
    ),
    grid_time_contract=grid,
)
truth = forecast.forecast_dbz.clone()
selected = tuple(int(v) for v in torch.nonzero(forecast.valid_mask[0], as_tuple=False)[0])
print("selected_valid_index", selected, "original_dbz", float(truth[(0, *selected)]))
truth[(0, *selected)] = float("nan")
bundle = _current_verification_bundle(truth, valid_times=("2026-08-05T00:30:00Z",), grid_time_contract=grid)
resolved = _resolve_verification(bundle, forecast, SensitivityConfig())
print("bundle_shape", tuple(bundle.frames_dbz.shape))
print("valid_count", int(bundle.valid_mask.sum()))
print("fso_weight_count", int(torch.count_nonzero(bundle.fso_metric_weight)))
print("bundle_metric_weight_sum", float(bundle.fso_metric_weight.sum()))
domain_only = _metric_domain_weight(forecast, resolved.valid_mask[0], 0, "issued")
print("domain_only_sum", float(domain_only.sum()))
print("resolved_weight_sum", float(resolved.metric_weight[0].sum()))
cfg = SensitivityConfig(
    metric_names=("log_echo_mse",),
    full_map_lead_minutes=(forecast.run.config.interval_minutes,),
    require_verification_lineage=True,
)
try:
    fso = compute_variational_fso(forecast, analysis, bundle, sensitivity_config=cfg)
    print("fso_domain_sum", float(fso.metric_domain_weight_sum[0]))
    print("fso_score", float(fso.forecast_scores[0, 0]))
    validate_variational_fso(fso)
    print("fso_validate", "passed")
    expected_scores, expected_available = _resolved_forecast_scores(
        forecast,
        analysis.state,
        resolved,
        (forecast.run.config.interval_minutes,),
        cfg,
    )
    print("resolved_score", float(expected_scores[0, 0]))
    print("resolved_available", bool(expected_available[0, 0]))
except Exception as e:
    print("compute_error", type(e).__name__, str(e))
