import torch
from advar.variational import prepare_analysis, initial_control, solve_analysis, analysis_trajectory
frames = torch.full((3,4,4), 20., dtype=torch.float64)
obs, frozen = prepare_analysis(frames)
base=initial_control(frozen)
for value in (float('nan'), float('inf'), float('-inf')):
 c=base.clone();c[-1]=value
 for name,fn in [('solve',lambda:solve_analysis(obs,frozen,control=c)),('trajectory',lambda:analysis_trajectory(c,frozen))]:
  try:
   r=fn()
   if name=='solve': print(value,name,r.used_fallback,r.reason,float(r.final_objective),bool(torch.isfinite(r.state.displacement_yx).all()),r.state.displacement_yx)
   else: print(value,name,r.displacement_yx, bool(torch.isfinite(r.frames_linear).all()))
  except Exception as e: print(value,name,type(e).__name__,str(e))
