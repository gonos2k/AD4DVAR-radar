# variational_1 audit (RED)

Baseline: `94c75d3323c986b6fb2963336b906acc85384e12`  
Scope: `src/advar/variational.py:1-4900`, with the listed callers/callees below.  
The repository source and tests were not modified.

## Confirmed findings

### V1-01 · Canonical observation `dbz` can contain NaN and propagate into residuals/objectives (P3 typed-input boundary)

Locations: `src/advar/variational.py:8972-8983` (`_validate_observations`), `:4625-4636` (`whitened_observation_residual`), and `:6128-6138` (`solve_analysis`). `_validate_observations()` delegates `dbz` to `_validate_frames()` (`:8961-8969`), which checks shape/dtype but no finiteness. `std_dbz` and `quality_weight` do have finite checks.

Small CPU probe: prepare a valid `[3,3,3]` float64 case, replace one valid `observations.dbz` element with `NaN`, and call the public residual/objective/solve helpers. The malformed typed observation is accepted; `whitened_observation_residual()` contains NaN, `robust_objective()` is NaN, and `solve_analysis()` returns a fallback with `reason="nonfinite_reference_objective"` rather than rejecting the malformed observation.

`prepare_analysis()` itself canonicalizes raw NaN/Inf frames to finite bounded values at `:4005-4046`, and `solve_analysis()` falls back rather than publishing a nonfinite state. The finding is therefore limited to the typed `AnalysisObservations` boundary (direct construction, replacement, or mutation): reject nonfinite canonical `dbz` before residual/objective evaluation, without changing intentional raw-frame canonicalization.

Evidence: `variational_1_observation_validation_probe.py` and `.stdout.txt`.

## Unconfirmed candidates

### C1 · A changed standard deviation can be paired with a stale common-bias whitener

At `src/advar/variational.py:4693-4712`, `_validate_frozen_observation_whitener()` can detect that the retained mode/correction no longer matches `std_dbz`, but it is called only by `validate_analysis_linearization_content()` (`:9738-9741`). `whitened_observation_residual()` (`:4625-4636`) and `solve_analysis()` (`:6128-6138`) accept `replace(observations, std_dbz=...)` with the old `FrozenOuterState`. With `observation_common_bias_std_dbz=1.0`, a `[3,3,3]` probe changed the std from 2 to 4 and one dbz value; the stale/fresh residual maximum absolute difference was `0.013627766876370295` (stale first entry `0.4752611220124994`, fresh `0.4888888888888697`).

This is a compliance candidate rather than a confirmed numerical defect. The sensitivity contract intentionally uses `replace(observations, dbz=...)` against a frozen state for frozen-selection perturb-and-resolve, and the documented FSOI perturbation keeps observation std fixed. The higher-level linearization content test already rejects a changed std (`tests/test_sensitivity.py:8096-8116`), while the direct residual/solve helpers do not. A future API contract should state that changing std/quality/common-bias geometry requires rebuilding the whitener (or explicitly validate it); adding unconditional observation identity binding would break the supported perturbation workflow.

Evidence: `variational_1_stale_whitener_probe.py` and `.stdout.txt`.

### C2 · Foreign neural-prior application is accepted transiently by `prepare_analysis`

At `src/advar/variational.py:4140-4185`, `prepare_analysis()` validates the prior state contract, shape, dtype, and device, but does not compare `neural_prior.inference_evidence.input_frames_digest` or full input context to the `frames_dbz` argument. A prior inferred from all-`-10` frames was accepted with all-`20` frames and set `initial_background_dbz` to `10.0`. The high-level `variational_nowcast()` rejects the same call early at `:6483-6488`; additionally, calling `solve_analysis()` on the transient prepared state is rejected later by `_validate_control()` (`:9203-9225`) because the retained bound-input frame digest disagrees. Thus this is a real direct-helper validation gap, but downstream guards prevented a wrong solved result in the tested path. Evidence: `variational_1_foreign_prior_probe.py` and `.stdout.txt`.

### C3 · Detection equality differs from the documented strict threshold rule

`prepare_analysis()` classifies `observed_dbz >= analysis_config.detection_limit_dbz` as detected at `:4054-4057`. The README contract says `echo: Z > L` and `censored: Z <= L` (README `:1342`), and the sensitivity contract records the same strict/at-or-below rules (`src/advar/sensitivity.py:342-345`, `:570`). A `[3,3,3]` tensor exactly equal to the default limit gives 27 detected and 0 censored cells in `variational_1_threshold_probe.py`. The prior review notes that other P1/probability and metric paths intentionally use `>=`; therefore this remains a cross-module contract candidate until the owning scientific threshold convention is settled. Evidence: threshold probe and source/documentation comparison.

## GREEN preserved

- The rank-one, grouped, tiled, and overlapping common-bias whitening formulas were checked against their covariance construction and selected dense/partitioned tests. The low-rank eigen correction is detached when frozen (`:4685-4689`); the repeated-eigenvalue helper-gradient NaN is deliberately outside the reachable AD path and is not reported.
- Raw frame NaN/Inf handling is explicit and finite: `prepare_analysis()` builds `valid` from `torch.isfinite` and canonicalizes invalid values before constructing observations (`:4005-4046`).
- Common-bias mode/group digest and resource-budget checks are performed before retained whitening state is created (`:3832-3957`, `:3889-3928`).
- The high-level prior path checks frame identity before preparation (`:6483-6488`) and full run/input-bundle identity after constructing the run (`:6704-6713`).
- A cross-input `observations_a/frozen_b` probe was investigated but is not reported as a defect: the sensitivity implementation intentionally uses `replace(observations, dbz=...)` with a frozen state for perturb-and-resolve (`src/advar/sensitivity.py:14573-14624`), and the README defines this as a frozen-selection local sensitivity. The probe therefore does not justify adding a universal observation/frozen digest binding.

## Commands, results, and limitations

All probes used the required CPU environment (`OMP_NUM_THREADS=1 MKL_NUM_THREADS=1`, `/Users/yhlee/ADVAR/.venv/bin/python`, `-I`):

```text
OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-team-audit-94c75d3/variational_1_observation_pair_probe.py
  exploratory cross observation/frozen pair accepted (not reported as a defect;
  sensitivity intentionally supports changed dbz with frozen structure)
  cross residual mean -5.0; paired residual mean 0.0
  cross solve returned maximum_outer_iterations used_fallback False

OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-team-audit-94c75d3/variational_1_stale_whitener_probe.py
  accepted mismatched observation/frozen pair
  max absolute mismatch 0.013627766876370295

OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-team-audit-94c75d3/variational_1_observation_validation_probe.py
  malformed observation accepted; residual finite False; cost nan
  solve returned nonfinite_reference_objective used_fallback True

OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-team-audit-94c75d3/variational_1_foreign_prior_probe.py
  prepare_analysis(B, prior-from-A): ACCEPTED; initial background [10.0]
  solve_analysis(B, prior-from-A): rejected retained neural-prior state is incomplete
  variational_nowcast(B, prior-from-A): rejected neural-prior application belongs to different input

OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-team-audit-94c75d3/variational_1_threshold_probe.py
  threshold 5.0; detected_count 27; censored_count 0

OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I -m pytest -q tests/test_variational.py -k 'detected_censored_and_once_whitened_residuals or common_bias_whitener_matches_dense_inverse_square_root or overlapping_common_bias_factorization_is_frozen_once or censored_background_is_independent_of_storage_value' --disable-warnings --maxfail=1
  4 passed, 138 deselected, 8 subtests passed in 1.82s
```

No full baseline, MPS/CUDA run, production artifact, or operational deployment was executed. The confirmed findings are typed/module-helper boundary cases; the normal high-level `variational_nowcast()` pairing and raw-frame sanitization remain covered by the GREEN checks above.
