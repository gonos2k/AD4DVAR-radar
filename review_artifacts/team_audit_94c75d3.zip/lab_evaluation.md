# lab_evaluation audit

Baseline: `94c75d3323c986b6fb2963336b906acc85384e12`

## Confirmed findings

No confirmed contract, mathematical, missingness, or reachable UI transition finding in the assigned scope.

The server's age control is metadata/uncertainty input rather than physical aging: `server.py:228-247` passes the selected age to `nowcast`, while `server.py:185-204` leaves the generated background values unchanged. This matches the UI explanation at `index.html:40-43`. The deterministic probe confirms ages 0, 10, 30, and 60 produce identical background fields and MAE/domain, while mean confidence decreases from 0.9677 to 0.8994. The nowcast caller applies age through its uncertainty path (`src/advar/nowcast.py:10030-10037`), so the displayed semantics are internally consistent.

The single-run metric domain is explicitly the finite intersection of forecast, persistence, and truth (`server.py:325-336`), and `_score_forecast` computes MAE and skill only on that supplied domain (`server.py:254-282`). The API's `scored_fraction` therefore means the fraction of the complete grid that has a jointly finite forecast/persistence/truth value; it is not the raw valid forecast fraction. The UI names both separately (`index.html:139-155`) and the method note describes common valid pixels (`index.html:184-191`).

The A/B comparison uses the reference forecast, reference persistence, and target to define one fixed domain (`server.py:285-313`), then scores candidate B on that same domain. Candidate missingness cannot shrink the domain: any missing B pixel makes candidate scores and improvement unavailable. `run_experiment` also rejects different lead times before running (`server.py:316-324`). The direct probe reproduced 3 fixed-domain pixels, improvement `+1.0` for a better candidate, and `missing_pixels=1`/null improvement for an incomplete candidate. The full comparison test also confirms the reference score/domain remain unchanged when B's background changes (`tests/test_initial_field_lab.py:130-140`).

The UI state transitions preserve a pinned reference on failed requests: `run` mutates `lastResult`/`referenceSettings` only after render succeeds (`app.js:87-113`), and `setRunning` disables controls while the request is pending (`app.js:115-123`). The assigned Node state-machine tests cover failed repin and clear/re-pin behavior (`tests/test_initial_field_lab_ui.cjs:84-124`) and passed. No actual browser rendering was performed.

The assigned promotion contract tests exercise production constructors/validators rather than only mocks: input-plan and issuance contracts are constructed through `advar.promotion` (`tests/test_review_promotion_contracts.py:20-81`), the track validator is called after rehashed tampering (`tests/test_review_promotion_contracts.py:84-118`), and `RangeBandEvaluation` is built with the production dataclass (`tests/test_review_promotion_contracts.py:121-221`). The statistics review reaches `compute_neural_prior_promotion` through `test_promotion.NeuralPriorPromotionTests.compute_with_policy` (`tests/test_review_promotion_statistics.py:17-61`, caller `tests/test_promotion.py:8798-8848`).

## Unconfirmed candidates

`app.js:115-123` does not remove the `error` class when a new run starts. After a failed request, the progress text can retain the previous red error styling until the next success. This is a low-impact presentation state and was not promoted to a confirmed finding because no browser rendering was run; the Node harness does not model CSS.

The request code has no request-generation token (`app.js:87-113`), so deliberately overlapping calls could let an older response overwrite a newer display. Normal browser controls are synchronously disabled by `setRunning(true)` and the assigned UI tests exercise the supported serialized flow; no ordinary user path reaching overlap was established. This remains an unconfirmed robustness candidate, not an observed defect.

## GREEN preserved

- Background age is bounded and finite on the HTTP payload path (`server.py:49-55`, `_number` at `server.py:95-108`); booleans, NaN/infinities, out-of-range values, and non-step leads are rejected.
- The synthetic truth horizon has exactly 18 ten-minute frames (`server.py:149-157`), matching the accepted 10–180 minute lead range (`server.py:84-91`); lead indexing is therefore in range (`server.py:240-247`).
- A/B uses the same fixed synthetic case and same target lead; candidate B cannot alter A's persistence/domain (`server.py:325-351`).
- JSON serialization converts NaN/inf field values to JSON `null` and rejects non-finite top-level output (`server.py:207-216`, `server.py:482-488`), preserving an explicit missingness representation.
- CSS media queries provide one-column radar panels and two-column metrics on narrow widths (`styles.css:444-549`). This was inspected statically only.

## Commands/results and limitations

Commands run with `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1` and `/Users/yhlee/ADVAR/.venv/bin/python` where applicable:

- `python -m pytest -q tests/test_initial_field_lab.py` → `10 passed, 10 subtests passed`.
- `node --test tests/test_initial_field_lab_ui.cjs` → `2 passed`.
- `python -m pytest -q tests/test_review_promotion_contracts.py` → `19 passed`.
- `python -m pytest -q tests/test_review_promotion_statistics.py` → `1 passed in 85.46s`.
- `/tmp/advar-team-audit-94c75d3/lab_evaluation_probe.py` → saved output at `/tmp/advar-team-audit-94c75d3/lab_evaluation_probe.out`; it covers age, lead, coverage, fixed A/B/missing candidate, and payload rejection boundaries.

This was read-only investigation. No source/tests/branches were changed. The test UI is a VM harness, not a browser, so layout, canvas painting, CSS support, and real event dispatch remain unverified.
