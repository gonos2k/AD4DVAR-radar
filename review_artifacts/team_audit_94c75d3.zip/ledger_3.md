# ledger_3 audit (GREEN assignment)

Baseline: `94c75d3323c986b6fb2963336b906acc85384e12`  
Model: `gpt-5.6-luna`, reasoning `xhigh`  
Production/tests were not modified.

## Unconfirmed candidate

### P2 engineering candidate · scoring replay append may strand an orphan after a crash between publication and SQLite registration

Locations: [`src/advar/ledger.py:11965`](../../Users/yhlee/ADVAR/src/advar/ledger.py:11965)–11969 and [`src/advar/ledger.py:12161`](../../Users/yhlee/ADVAR/src/advar/ledger.py:12161)–12177.

`append_neural_prior_scoring_replay_bundle()` checks `target.exists()` and then opens its SQLite transaction. Inside that transaction it calls `_publish_durable_directory()`, which renames the fully fsynced temporary directory into `target`; only afterward does it insert `neural_prior_scoring_replay_bundles`. Source inspection therefore identifies a possible process-loss interval after the rename and before the insert. If that interval occurs, the bytes would have no ledger row; on retry, the method would recompute the same digest and raise `FileExistsError` at the pre-transaction `target.exists()` guard, so it could not register or reconcile the orphan. There is no scoring-replay orphan recovery in `EpisodeLedger.__init__` or the replay loader; `load_neural_prior_scoring_replay_bundle()` requires a registered row.

Evidence boundary: [`ledger_3_crash_probe.py`](ledger_3_crash_probe.py) launches a child that calls the private `_publish_durable_directory()` helper with a placeholder `manifest.json`, monkeypatches `Path.rename`, exits immediately after the helper's actual rename, then opens a fresh `EpisodeLedger` and queries the empty ledger table. The probe does not call the public `append_neural_prior_scoring_replay_bundle()`, does not construct a current typed `ScoringReplayCaseArtifact`, and does not prove full public-path end-to-end behavior. It is a private-helper crash-boundary demonstration plus a manual orphan simulation. The saved output is [`ledger_3_crash_probe.stdout.txt`](ledger_3_crash_probe.stdout.txt). Exact output:

```text
{'orphan_target_exists_after_crash': True, 'ledger_row_count': 0, 'target_guard_precedes_sqlite_transaction': True, 'temporary_still_exists': False}
```

The code-level ordering makes this a credible P2 engineering candidate, but the finding remains unconfirmed until a current typed fixture drives the public append while a real process loss is forced at the post-rename/pre-INSERT boundary. The potential impact is bounded to a scoring replay append interrupted at this point: durable replay bytes could consume storage and the same scoring-input digest could be unable to retry without manual cleanup/recovery, blocking downstream scoring completion and promotion. The existing helper-only durability test passes, but it exercises fsync/rename ordering while the process remains alive and does not cover this crash window.

## GREEN preserved

- `ScoringReplayBundleManifest` binds the current contract to exact ordered case IDs, semantic digests, dynamic/background role sets, shard-set digest, dtype/shape/tensor digests, and expanded-byte budget.
- `_ScoringReplayTensorShardStore` rehashes each content-addressed shard and preflights NPZ members before tensor allocation; `load_neural_prior_scoring_replay_bundle()` verifies the manifest, evaluation bytes, raw/verification provenance, and current semantic tensors.
- `_validate_current_raw_provenance_payload()` reconstructs raw volumes from encoded tensors, checks receipt/identity/attestation digests, global resolution bindings, background lineage, source coverage, range geometry, and the raw-to-analysis transform.
- Current promotion load reconstructs the typed v32 evidence and recomputes its digest; append/promotion/deployment paths cross check replay, process receipts, raw trust activation, training lineage, and current target-source trust.
- Operational decision issuance stages publication under SQLite writer locks and uses signed publication, activation, and terminal commit authorization receipts. `_validate_committed_operational_decision()` joins those receipts and checks exact canonical payloads, chain lineage, runtime head, chronology, and usability.

## Verification commands and results

1. `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I -m pytest -q tests/test_ledger.py -k 'replay_v19_through_v26_preserve_frozen_tensor_roles or retrospective_replay_is_a_separate_audit_record' --disable-warnings --maxfail=1`

   Result: `2 passed, 48 deselected, 8 subtests passed in 3.65s`.

2. `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I -m pytest -q tests/test_promotion.py::NeuralPriorPromotionTests::test_scoring_replay_crash_durability --disable-warnings --maxfail=1`

   Result: `1 passed in 2.89s`. This is the helper-only fsync/rename test and does not cover an abrupt process loss after rename.

3. `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONPATH=src /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-team-audit-94c75d3/ledger_3_crash_probe.py`

   Result: the exact dictionary output above; probe source and output are retained beside this report.

4. Two selected current promotion tests were attempted but stopped in test fixture construction before the assigned ledger methods: `tests/test_promotion.py:10105` (`test_scoring_replay_reproduces_evaluation_digest`) and `tests/test_promotion.py:18886` (`test_operational_commit_crossing_deadline_is_rejected`) still replace the current three-time `NeuralPriorInputPlan.valid_times` with one time and fail at `src/advar/promotion.py:2842`. These are test-contract drift after the current v2 plan requirement, not production findings.

## Limitations / unconfirmed candidates

- The orphan candidate is demonstrated at the private durable-directory/process-loss boundary with a child process and ledger row query; I did not run a full end-to-end scoring fixture with a forced OS kill because those fixtures are long and currently contain stale one-time input-plan construction. The evidence does not support calling this a confirmed public append reproduction.
- No claim is made about CUDA/MPS, real radar workloads, or full promotion/variational/sensitivity/ledger suites.
