from __future__ import annotations

import torch
from torch import nn

from advar.nowcast import ForecastRunContract, NowcastConfig
from advar.promotion import NeuralPriorRegimeClassifier


class Fixed(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.anchor = nn.Parameter(torch.zeros(()))

    def forward(self, value: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        del value
        return (
            self.anchor + torch.tensor([1.0e30, -1.0e30, 0.0]),
            self.anchor + torch.tensor([1.0e30, -1.0e30]),
        )


def main() -> None:
    frames = torch.zeros((3, 2, 2), dtype=torch.float32)
    run = ForecastRunContract.from_inputs(
        NowcastConfig(), frames, torch.ones_like(frames, dtype=torch.bool), None
    )
    classifier = NeuralPriorRegimeClassifier(
        Fixed().eval(),
        example_frames=frames,
        regime_labels=("known", "other", "unknown"),
        range_regime_labels=("near", "far"),
        classifier_algorithm_digest="1" * 64,
    )
    result = classifier.classify(frames, input_run=run)
    assert result.regime == "known"
    assert result.range_regime == "near"
    assert result.active_range_regimes == ("near",)
    assert all(torch.isfinite(torch.tensor(result.regime_probabilities)))
    assert all(torch.isfinite(torch.tensor(result.range_regime_probabilities)))
    result.validate_integrity()
    print({
        "regime": result.regime,
        "range_regime": result.range_regime,
        "regime_probabilities": result.regime_probabilities,
        "range_probabilities": result.range_regime_probabilities,
        "entropy": result.regime_entropy,
        "digest_valid": True,
    })


if __name__ == "__main__":
    main()
