import torch
from advar import promotion as promotion_module
from advar.nowcast import ForecastRunContract, NowcastConfig, RadarGridTimeContract

valid_times = (
    "2026-08-09T00:00:00Z",
    "2026-08-09T00:10:00Z",
    "2026-08-09T00:20:00Z",
)
grid = RadarGridTimeContract(
    valid_times=valid_times,
    dx_m=1_000.0,
    dy_m=1_000.0,
    projection="EPSG:5179",
    grid_hash="1" * 64,
)
frames = torch.zeros((3, 2, 2), dtype=torch.float32)
run = ForecastRunContract.from_inputs(
    NowcastConfig(),
    frames,
    torch.ones_like(frames, dtype=torch.bool),
    None,
    grid_time_contract=grid,
)
engine = promotion_module.scoring_metric_engine_identity_digest()
small = promotion_module.MetricSupportContract.from_run(
    "centroid_error_m2", run, metric_engine_digest=engine, grid_shape=(1, 2)
)
exact = promotion_module.MetricSupportContract.from_run(
    "centroid_error_m2", run, metric_engine_digest=engine, grid_shape=(2, 2)
)
print({
    "run_frame_shape": tuple(frames.shape[-2:]),
    "supplied_small_shape": (1, 2),
    "small_diagonal_m": small.derivation_parameters_json,
    "small_upper_bound": small.upper_bound,
    "exact_upper_bound": exact.upper_bound,
    "unsafe_underbound": small.upper_bound < exact.upper_bound,
    "same_spatial_grid_digest": small.spatial_grid_digest == exact.spatial_grid_digest,
})
