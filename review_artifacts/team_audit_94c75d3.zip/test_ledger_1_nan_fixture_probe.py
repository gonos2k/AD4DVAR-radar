import importlib.util
from dataclasses import replace
from pathlib import Path

spec = importlib.util.spec_from_file_location("test_ledger_probe", Path("tests/test_ledger.py"))
module = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(module)
from advar.ledger import EpisodeLedger, SensitivityEpisode  # noqa: E402

module.EpisodeLedgerTests.setUpClass()
case = module.EpisodeLedgerTests("test_duplicate_episode_id_is_rejected")
case.setUp()
try:
    snapshot = module.EpisodeLedgerTests.snapshot
    path = snapshot.path_evidence_by_metric.clone()
    observation = snapshot.observation_verified_evidence_by_metric.clone()
    background = snapshot.background_verified_evidence_by_metric.clone()
    path[0, 0] = 0.5
    observation[0, 0] = 0.4
    background[0, 0] = 0.2
    mutated = replace(
        snapshot,
        path_evidence_by_metric=path,
        observation_verified_evidence_by_metric=observation,
        background_verified_evidence_by_metric=background,
    )
    episode = SensitivityEpisode(
        "nan-fixture",
        "2026-07-26T05:00:00+00:00",
        "KTLX",
        module.EpisodeLedgerTests.contract,
        mutated,
    )
    try:
        case.ledger.append(episode)
    except Exception as error:  # probe output only
        print(
            {
                "base_finite": {
                    name: bool(getattr(snapshot, name)[0, 0].isfinite())
                    for name in (
                        "path_evidence_by_metric",
                        "observation_source_fraction_by_metric",
                        "observation_verified_evidence_by_metric",
                        "background_verified_evidence_by_metric",
                    )
                },
                "exception": f"{type(error).__name__}: {error}",
            }
        )
finally:
    case.tearDown()
