# `test_variational_1` RED audit

Baseline: `94c75d3323c986b6fb2963336b906acc85384e12`  
Assigned range: [`tests/test_variational.py:1`](/Users/yhlee/ADVAR/tests/test_variational.py:1) through [`tests/test_variational.py:6579`](/Users/yhlee/ADVAR/tests/test_variational.py:6579)

## Confirmed findings

No new P1/P2 finding was confirmed in the assigned test range. The known full MPS P1 NO-GO was not counted again.

## Unconfirmed candidate: non-finite direct control is not rejected (P3 boundary)

[`src/advar/variational.py:9147`](/Users/yhlee/ADVAR/src/advar/variational.py:9147) validates control rank, length, floating dtype, device, dtype, active index, and retained prior state, but never checks `torch.isfinite(control)`. [`analysis_trajectory()`](/Users/yhlee/ADVAR/src/advar/variational.py:4495), `observation_residual_dbz()` (line 4575), and `whitened_observation_residual()` (line 4625) therefore accept a non-finite field control. `residual_vector()` (line 5032) does not validate the control at all.

The runnable 2x2 probe [`test_variational_1_nonfinite_control_probe.py`](/tmp/advar-team-audit-94c75d3/test_variational_1_nonfinite_control_probe.py) prepares three constant 20 dBZ frames and replaces one active field control with `NaN`, `+Inf`, or `-Inf`. [`test_variational_1_nonfinite_control_probe.stdout`](/tmp/advar-team-audit-94c75d3/test_variational_1_nonfinite_control_probe.stdout) records:

- `NaN` is accepted by `analysis_trajectory()` and produces an all-finite trajectory; `observation_residual_dbz()` and its whitened form are also all-finite, while `residual_vector()` contains three NaNs.
- `+Inf` is accepted by `analysis_trajectory()` but produces non-finite frames and non-finite residuals.
- `-Inf` is accepted and is silently mapped to the floor in the trajectory/residual wrappers; `residual_vector()` contains three infinities.

This is inconsistent with the finite-control boundary described in the P1 control contract (README lines 1733-1745), and with the fail-closed behavior expected for a public trajectory/residual entry point. The mechanism is [`src/advar/physics.py:34`](/Users/yhlee/ADVAR/src/advar/physics.py:34), where `dbz_to_echo()` applies `nan_to_num`, so an invalid latent field can be silently converted into a physical floor or an overflowed echo. `solve_analysis()` currently validates its supplied control and subsequently rejects a non-finite objective, so the normal top-level producer does not currently reach the bad result from its finite internal controls. Because these low-level functions live in the owning research namespace rather than the package startup API, this remains a P3 boundary candidate rather than a confirmed serious production defect. A focused regression should either require finite controls in `_validate_control` for all checked entry points (and in `residual_vector`) or explicitly document the functions as private/internal and test fail-closed behavior.

## Misleading coverage observed

[`tests/test_variational.py:1365`](/Users/yhlee/ADVAR/tests/test_variational.py:1365) is named `test_prior_runner_rejects_mutated_non_parameter_state`, but line 1380 mutates `model.scale` after runner construction and line 1389-1391 expects the original exported result (`2.0`). It therefore verifies that the exported graph ignores a post-construction Python attribute mutation; it does not verify rejection. The frozen-export behavior is coherent and separately exercised by the digest/reproduction tests, so this is a test naming/premise issue, not a source defect.

## GREEN preserved

The selected checks passed: prior export/state behavior, execution digest binding, P1 input lineage, dense common-bias inverse-square-root agreement, negative remap-cell crossing, accepted-analysis preservation after later PCG failure, and saturated inward bounded controls. [`test_variational_1_targeted_tests.stdout`](/tmp/advar-team-audit-94c75d3/test_variational_1_targeted_tests.stdout) reports `7 passed, 18 warnings, 8 subtests passed`.

The AD and solver review preserved the fixed-IRLS `J^T J + lambda I` flow, actual JVP/VJP checks, remap-cell branch freezing, physical support/causal gating, and matrix-free PCG finite/SPD guards. Numeric smoke checks for dBZ/echo round trips and bounded vector controls were finite on CPU float32/float64. No whole baseline or full variational suite was run. MPS P1 remains the pre-existing documented NO-GO; CUDA and GPU paths were not claimed.

