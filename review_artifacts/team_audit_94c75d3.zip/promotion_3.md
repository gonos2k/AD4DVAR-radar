# promotion_3 audit (GREEN)

## Scope

Baseline: `94c75d3323c986b6fb2963336b906acc85384e12`.

I read `src/advar/promotion.py:11401-17100` in bounded chunks covering every line, including the legacy manifest validators, canonical-time and holdout lineage checks, `RangeBandEvaluation`, `PriorHoldoutEvaluation.from_forecasts`, scoring-replay artifacts, Gaussian observation-error diagnostics, state/prior calibration scores, and range uncertainty component assembly. I also traced the callers/callees needed for the numerical and meteorological contract:

- `src/advar/sensitivity.py:10838-10865`, `11318-11736`, `13050-13125`, `13216-13308`, `8550-8660`, `10963-10975`, and `17841-17849` for metric domains, verification resolution, lead selection, scoring, and forecast-grid indexing.
- `src/advar/range_geometry.py:350-607` for horizontal range partitioning, mosaic source maps, and domain restriction.
- `src/advar/nowcast.py:2368-2425`, `2604-2623`, `3325-3410`, `6540-6870`, and `10090-10153` for directed cell-area intervals, forecast validation, and confidence bounds.
- `src/advar/ledger.py:425-459`, `11605-11750`, `20159-20360`, and `22280-22520` for CPU replay execution, evaluation-audit decoding, scoring-replay recomputation, and promotion area gates.
- `src/advar/variational.py:8140-8169` for the 8-connected object-domain convention.

## Confirmed findings

None. The assigned promotion and Gaussian paths preserve their stated contracts on the tested CPU path.

## Unconfirmed candidate

`PriorHoldoutEvaluation.from_forecasts` accepts `metric_config.full_map_lead_minutes` after checking only equality with `operational_issuance_domain.lead_minutes` (`src/advar/promotion.py:14448-14455`). The downstream scoring, coverage, denominator, and range-band code maps each lead with integer floor division (`14524-14534`, `14744-14747`, and `_forecast_coverage` at `17135-17141`). `OperationalIssuanceDomainPlan` and `SensitivityConfig` likewise require positive unique leads but do not require divisibility by `run.config.interval_minutes` (`src/advar/promotion.py:3242-3277`; `src/advar/sensitivity.py:8558-8619`).

An audit-only private-helper probe with requested lead 31 minutes and a 10-minute run interval called `forecast_linear_at_step(..., 3, ...)`, returned a valid score, and reported `available=True`; thus the arithmetic silently evaluates the 30-minute frame while labeling it 31 minutes. The runnable code/output are [promotion_3_lead_probe.py](/tmp/advar-team-audit-94c75d3/promotion_3_lead_probe.py) and [promotion_3_lead_probe.out](/tmp/advar-team-audit-94c75d3/promotion_3_lead_probe.out). This is private-helper evidence, not a full typed `from_forecasts` producer fixture. The standard defaults and the observation-removal path use grid-aligned leads; therefore I leave this as an unconfirmed boundary candidate. If arbitrary registered metric/issuance plans are supported, the public holdout path should reject leads not divisible by the forecast interval (and leads beyond the horizon) before any floor division.

I did not re-report the prior R08 artifact pixel/area-consistency concern or R09 extreme-scale concern. R08 is already in the checklist, and the normal location-45/scale-1 truncated tail is finite and independently agrees with high-precision arithmetic below. Directed lower cell-area intervals are conservative for the promotion minimum-area gate: they use the lower determinant bound and the geodetic scale interval, so this review found no unsafe area inflation.

## GREEN preserved

- Legacy V14–V18 and V19 manifest checks bind canonical times, holdout plans, input/forecast/prior digests, candidate/parent disjointness, classifier evidence, and issue/verification chronology. `from_forecasts` recomputes the typed evaluation and scoring replay invokes that recomputation before retaining a frozen snapshot.
- `RangeBandEvaluation` requires a complete valid-domain partition, rejects non-finite values and incompatible areas, and derives issuance/range metrics from the common parent domain. Range geometry uses horizontal projected distances and explicit lower-inclusive/upper-exclusive bands with the final band closed.
- Promotion uses `grid.cell_area_interval_m2[0]` for reported candidate area and range-band physical area. The lower directed interval endpoint is appropriate for a conservative minimum-area decision; no upper-bound substitution was found.
- `_standard_normal_log_interval_mass` keeps the narrow-interval Taylor branch, tail reflection, and `logdiffexp` branch in float64; quantized bins share exact boundaries and the truncated diagnostic computes conditional mass above the support threshold. No `.item()`, `float()`, or `detach()` occurs along the diagnostic inputs before the final scalar artifact fields.
- Prior/state uncertainty scoring separates support calibration from echo intensity, uses positive finite weights only on the evaluation mask, reports unavailable component scores as `None`, and counts physical echo/clear samples separately from pixel/object counts. The 8-connected object convention is consistent with the traced variational helper.

## Commands, probes, and results

1. `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I -m pytest -q tests/test_review_numerics.py tests/test_numerical_review.py -q`

   Result: **25 passed**, warnings only from Torch JIT deprecation.

2. `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I -m pytest -q tests/test_promotion.py -k 'truncated_tail_score or quantized_threshold_uses_interval_midpoint_pit or quantized_threshold_bins_form_a_disjoint_partition or quantized_point_diagnostic_uses_local_detection_limit or range_masks_must_cover_the_complete_operational_grid or range_geometry_resolves_a_complete_physical_partition or range_geometry_contract_is_explicitly_horizontal_only or quantized_gaussian_upper_tail_has_finite_large_nll'`

   Result: **8 passed**, 219 deselected.

3. The focused replay/range/mask selection was run with `semantic_replay_detects_forecast_tensor_after_rehash_attempt`, `semantic_replay_requires_time_resolved_quality_weight`, `semantic_replay_raw_input_must_match_forecast_run`, `scoring_replay_reproduces_evaluation_digest`, `dynamic_source_coverage_resolves_after_input_availability`, `mosaic_range_uses_the_resolved_source_radar`, `range_object_component_uses_object_count_not_pixel_count`, and `large_mask_cannot_hide_tiny_valid_band_sample`.

   Result: **8 passed and 1 fixture setup failure** (two subtests passed). The failure is the existing test's intentional invalid setup: it replaces `NeuralPriorInputPlan.valid_times` with one timestamp, and construction correctly raises `ValueError` because the plan requires three increasing times ending at observation time. It is not a product-path failure.

4. [promotion_3_gaussian_probe.py](/tmp/advar-team-audit-94c75d3/promotion_3_gaussian_probe.py) compares `_standard_normal_log_interval_mass` and `_truncated_gaussian_diagnostics` with a 500-digit mpmath oracle using exact binary float endpoints. Narrow central, extreme left/right tails, broad interval, and the location-45/scale-1/reference-5 truncated tail all agree within approximately `1.2e-13`; quantized bounds are `[5,5.25]`, `[5.25,5.75]`, `[5.75,6.25]` with shared boundaries. See [promotion_3_gaussian_probe.out](/tmp/advar-team-audit-94c75d3/promotion_3_gaussian_probe.out).

5. [promotion_3_lead_probe.py](/tmp/advar-team-audit-94c75d3/promotion_3_lead_probe.py) is the private-only non-divisible-lead probe described above.

No source or test files were modified. Full baseline, full promotion, full sensitivity, full ledger, deployment, and non-CPU backend suites were not run per the audit instructions.
