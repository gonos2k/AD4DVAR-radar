# sensitivity_2 GREEN audit

Baseline: `94c75d3323c986b6fb2963336b906acc85384e12`  
Assigned source range: `src/advar/sensitivity.py:4601-9200`  
Additional reachable caller/linearization reads are listed in `sensitivity_2_coverage.json`.

## Confirmed finding

### Current typed verification FSO ignores the bundle-declared FSO metric weight

- Location: `src/advar/sensitivity.py:15296-15303`, in `_compute_variational_products`.
- Contract evidence: `VerificationBundle.fso_metric_weight` at `:8437-8462` is explicitly “quantitative echo with spatial support”; `_resolve_verification` binds it into `_ResolvedVerification.metric_weight` at `:11659-11665`; `_resolved_forecast_scores` correctly multiplies the forecast domain by this weight at `:13295-13307`.
- Violated assumption: a current typed verification bundle's FSO score and its observation adjoint must use the same declared quantitative/spatial verification domain as the resolved scoring path. The FSO code currently passes only `_metric_domain_weight(result, verification_bundle.valid_mask[lead], ...)` to `forecast_metric`, so censored cells and cells outside the preregistered spatial support enter the score. It also records that broader tensor in `metric_domain_weight_sum` and differentiates the wrong objective.
- The repository's scientific protocol states the same invariant in `README.md:1324-1342`: low-quality cells contribute by their declared weight, below-detection cells have point-metric weight zero, and current spatial-age support is part of replayed evidence. `README.md:583-590` separately defines the forecast domain as the intersection with finite verification; that intersection is the outer domain and does not replace the bundle's point/spatial weights.
- Small public-path reproduction: `/tmp/advar-team-audit-94c75d3/sensitivity_2_probe.py`, run with `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python ...`. The probe creates a converged P1 forecast and a current `radar-verification-bundle-v22` through the typed evidence/derivation constructors. It changes one finite forecast verification cell (index `(1, 1)`, original `-1.2846352040201516` dBZ) to a censored NaN report.
- Observed output (`sensitivity_2_probe.out`):

  ```text
  valid_count 64
  fso_weight_count 48
  bundle_metric_weight_sum 48.0
  domain_only_sum 49.0
  resolved_weight_sum 48.0
  fso_domain_sum 49.0
  fso_score 0.082187626240476
  fso_validate passed
  resolved_score 5.101788422681788e-31
  resolved_available True
  ```

  The forecast is the truth on the retained 48-cell FSO domain, so the resolved score is approximately zero. The FSO accepts and seals a materially different score while `validate_variational_fso` passes because it validates the self-consistent, but incorrectly constructed, FSO artifact.
- Reachable impact: current lineage-complete `compute_variational_fso` and `compute_variational_fsoi` use the domain-only score and derivatives. Censored observations and spatially unsupported observations can alter scores, adjoints, sensitivity maps, impacts, and automated learning decisions. The same omission is repeated in `_resolve_learning_step` at `:14827-14842` for first-order validation weights; this must be kept aligned when correcting the root metric-domain construction. The observation-removal path already multiplies by `verification.metric_weight` and is a useful consistency reference.
- Expected correction boundary: for typed bundles, combine the forecast-domain tensor with `verification_bundle.metric_weight`/`fso_metric_weight` before support checks, scoring, and derivatives, and bind that exact combined tensor into the metric-domain digest. Preserve legacy tensor behavior (`valid_mask` weight) and the existing detached domain masks.

## GREEN preserved

- `VerificationObservationMaskDerivationArtifact` and `ObservationErrorDerivationArtifact` replay and digest checks are detached snapshots; the inspected paths preserve their AD boundaries intentionally.
- `_variational_normal_operator`, PCG adjoints, frozen initial-background and baseline-dynamics VJPs preserve the differentiable control path while detaching only diagnostics/artifacts.
- Current bundle shape/device/state checks, censored versus observed cell semantics, source-map validation, and geometry/time lineage checks were retained in review. The typed FSO probe above uses the public constructors and current contract, not an unsupported backend or corrupted storage.
- `_gauss_newton_curvature_diagnostics` fails closed on nonfinite curvature defects, and normal-product accounting is bounded by `_NormalProductBudget`.

## Commands and results

- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python /tmp/advar-team-audit-94c75d3/sensitivity_2_probe.py` — completed; output saved as `sensitivity_2_probe.out`.
- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -m pytest -q tests/test_sensitivity.py::VariationalFSOTests::test_verification_bundle_binds_time_grid_qc_and_content` — `1 passed`, 4 subtests, 18 warnings.

No repository source, tests, branches, or baseline artifacts were changed. CUDA/MPS and full baseline suites were not run.
