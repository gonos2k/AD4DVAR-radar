"""Bounded promotion_1 contract probes; run with the repository venv."""

from __future__ import annotations

import json
import tempfile
from pathlib import Path

import torch

import advar.promotion as promotion
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey


D = "1" * 64


def main() -> None:
    result: dict[str, object] = {}
    plan = promotion.NeuralPriorInputPlan(
        valid_times=(
            "2026-01-01T00:00:00Z",
            "2026-01-01T00:10:00Z",
            "2026-01-01T00:20:00Z",
        ),
        grid_contract_digest=D,
        radar_product_digest="2" * 64,
        qc_pipeline_digest="3" * 64,
        background_cycle_rule_digest="4" * 64,
        mask_policy_digest="5" * 64,
        observation_valid_time="2026-01-01T00:20:00Z",
        input_available_time="2026-01-01T00:21:00+00:00",
        decision_deadline="2026-01-01T00:22:00Z",
        publication_time="2026-01-01T00:23:00Z",
    )
    result["input_plan"] = {
        "canonical_times": plan.valid_times,
        "digest_prefix": plan.plan_digest[:8],
    }
    rejected: list[str] = []
    for values in (
        plan.payload | {"valid_times": list(plan.valid_times[:2])},
        plan.payload
        | {
            "valid_times": [
                plan.valid_times[1],
                plan.valid_times[0],
                plan.valid_times[2],
            ]
        },
    ):
        try:
            promotion.NeuralPriorInputPlan(**values)
        except ValueError as error:
            rejected.append(str(error))
    result["temporal_rejections"] = rejected

    raw = promotion.CanonicalRawGridVolumeArtifact.from_tensors(
        reflectivity_dbz=torch.tensor([[1.0, 2.0]], dtype=torch.float32),
        qc_valid_mask=torch.tensor([[True, False]]),
        quality_weight=torch.tensor([[0.5, 1.0]], dtype=torch.float32),
        observation_std_dbz=torch.tensor([[2.0, 3.0]], dtype=torch.float32),
        radar_site_digest=D,
        acquisition_valid_time=plan.valid_times[0],
        canonical_scan_identity_digest="6" * 64,
        radar_product_digest="2" * 64,
        grid_contract_digest=D,
    )
    frame, valid, quality, std = raw.decode_and_qc()
    result["raw_qc"] = {
        "frame": frame.tolist(),
        "valid": valid.tolist(),
        "quality": quality.tolist(),
        "std": std.tolist(),
    }

    with tempfile.TemporaryDirectory() as directory:
        shard = promotion.write_training_tensor_archive_shard(
            {
                "feature": torch.tensor([1.0, 2.0]),
                "valid": torch.tensor([True, False]),
            },
            directory=Path(directory),
            shard_id="probe",
        )
        loaded = promotion.load_training_tensor_archive_shard(shard)
        result["archive_roundtrip"] = {
            "members": sorted(loaded),
            "size": shard.archive_size_bytes,
        }

    normal = promotion.recompute_training_normalization_statistics(
        (torch.tensor([[1.0, 3.0], [2.0, 4.0]]),),
        channel_definitions=("a", "b"),
    )
    result["normalization"] = normal.tolist()

    maximum = torch.finfo(torch.float64).max
    extreme_loss = promotion.weighted_training_target_loss(
        torch.tensor([maximum], dtype=torch.float64),
        torch.tensor([-maximum], dtype=torch.float64),
        torch.ones(1, dtype=torch.bool),
        torch.ones(1, dtype=torch.float64),
    )
    result["finite_input_loss"] = {
        "value": float(extreme_loss),
        "is_finite": bool(torch.isfinite(extreme_loss)),
    }

    key = Ed25519PrivateKey.from_private_bytes(b"k" * 32)
    reservation = promotion.GlobalSamplingReservationReceipt.issue(
        experiment_scope_digest="c" * 64,
        raw_observation_slot_digests=("a" * 64, "b" * 64),
        registry_id="probe-registry",
        authority_id="probe-authority",
        authority_private_key=key,
        reserved_at="2026-01-01T00:00:00Z",
    )
    resolution = promotion.GlobalRawVolumeResolutionReceipt.issue(
        reservation=reservation,
        slot_identity_bindings=(("d" * 64, "e" * 64),),
        authority_private_key=key,
        resolved_at="2026-01-01T00:01:00Z",
    )
    result["standalone_resolution_binding"] = {
        "reservation_slots": len(reservation.raw_observation_slot_digests),
        "resolution_slots": len(resolution.slot_identity_bindings),
        "accepts_unreserved_slot": resolution.slot_identity_bindings[0][0]
        not in reservation.raw_observation_slot_digests,
    }
    second_key = Ed25519PrivateKey.from_private_bytes(b"l" * 32)
    authority = lambda name, private: (
        name,
        private.public_key().public_bytes_raw().hex(),
        1,
        "2025-01-01T00:00:00Z",
        "2030-01-01T00:00:00Z",
        None,
        ("f" * 64,),
        ("e" * 64,),
    )
    try:
        promotion.TrainingTargetSourceTrustStore.issue(
            authorities=(authority("z-authority", key), authority("a-authority", second_key)),
            root_authority_id="probe-root",
            root_private_key=Ed25519PrivateKey.from_private_bytes(b"m" * 32),
        )
    except ValueError as error:
        result["unsorted_trust_store_issue"] = {"rejected": True, "error": str(error)}
    else:
        result["unsorted_trust_store_issue"] = {"rejected": False}
    print(json.dumps(result, sort_keys=True, separators=(",", ":")))


if __name__ == "__main__":
    main()
