# intervention audit

Baseline: `94c75d3323c986b6fb2963336b906acc85384e12`  
Role: RED  
Scope: `src/advar/intervention.py`, `src/advar/linearization_artifact.py`, `tests/test_review_intervention.py`, `tests/test_review_ledger.py`, plus the reachable ledger callers and variational replay checks needed to assess the assigned contracts.

## Confirmed finding

### P2 — no-op actions are accepted as prospective interventions, then cannot be realized

The decision boundary accepts an action with no approved input change. `ProspectiveInterventionDecision.from_policy()` calls the generator and `_validate_action_safety()` (`src/advar/intervention.py:1824-1923`), but does not require a positive changed-pixel count, a nonzero dBZ norm, a mask/quality transition, or any other change invariant. `EpisodeLedger.append_prospective_intervention_decision()` reproduces that decision and inserts it into `prospective_intervention_decisions` (`src/advar/ledger.py:6130-6264`) without an additional transition check.

The realized boundary has the opposite contract. `validate_intervention_action_transition()` rejects a QC action when both mask and quality digests are unchanged (`src/advar/intervention.py:2579-2597`), and rejects dBZ/override actions when the frame or bundle digest is unchanged (`src/advar/intervention.py:2598-2615`). The receipt dataclass also requires all three input channels to change in aggregate (`src/advar/intervention.py:2193-2205`). This leaves a committed, operator-approved decision that has no possible receipt under the same policy output.

Minimal public-path probe: `/tmp/advar-team-audit-94c75d3/intervention_noop_probe.py` (output: `/tmp/advar-team-audit-94c75d3/intervention_noop_probe.stdout.txt`). With a 3×2×2 finite dBZ input, the generator returned the unchanged QC mask and quality tensor. `from_policy()` returned a decision whose diagnostics reported `changed_pixel_count=0`; a patched trust-store call to the public ledger append inserted one prospective decision row; receipt construction failed with `ValueError: QC receipt did not change mask or quality`.

The broader probe `/tmp/advar-team-audit-94c75d3/intervention_noop_all_probe.py` confirms the same mismatch for all three action types:

- zero dBZ correction: decision accepted, receipt fails `dBZ receipt did not change its radar input bundle`;
- unchanged QC mask and quality: decision accepted, receipt fails `QC receipt did not change mask or quality`;
- operator override selecting one pixel whose replacement equals the current value: decision accepted with `changed_pixel_count=1` and zero dBZ norm, receipt fails the unchanged-bundle check.

Expected contract behavior is to choose one explicit semantic and apply it at both decision and receipt boundaries. Given the current prospective/realized docstrings and the separate `RetrospectiveCounterfactualReplay` audit record (`src/advar/intervention.py:650-695`), the least surprising supported behavior is to reject a no-op before recording the prospective decision. Impact is workflow/ledger integrity: an operator can approve and commit an intervention that cannot be executed or closed with a receipt; this is not a demonstrated unsafe physical change.

## GREEN preserved

The assigned focused regressions pass: `9 passed, 13 subtests passed` for `tests/test_review_intervention.py tests/test_review_ledger.py` under isolated Python 3.12 with one OpenMP/MKL thread. The QC boundary still accepts the intended masked-cell standard-deviation normalization and quality-only deweighting while rejecting an active-observation standard-deviation change.

The fixed P1 artifact path also remains green in the selected checks: the identical-FSO restart and tamper/runtime-mismatch tests pass (`2 passed, 91 deselected`), and the selected intervention ledger tests for signed prospective/realized round-trip, typed action safety, and retrospective replay pass (`3 passed, 47 deselected`). `load_p1_linearization()` independently verifies the artifact digest, current algorithm/runtime identity, content-addressed frozen state, trajectory, stationarity, robust IRLS fixed point, and replayed FSO; no reachable fixed-linearization/replay counterexample was found in this bounded review.

## Unconfirmed candidates and limits

`_validate_loaded_state()` uses `torch.allclose()` without `rtol=0.0` for the retained state (`src/advar/linearization_artifact.py:618-634`), and `validate_analysis_linearization_content()` does not separately recompute the retained remap-cell branch. These are only corrupted/rehashed-artifact candidates in this review: the artifact digest/runtime checks and the existing exact FSO restart test passed, and I did not classify either as a supported-path defect without a producer-generated counterexample.

The no-op ledger probe patches trust-store loaders because operational stores require root-owned files. It exercises the actual public append method and its SQLite insertion, while the signature object itself is generated and verified through the normal `OperatorActionApproval` path. No source or test files were modified.

## Commands and results

```text
OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I -m pytest -q tests/test_review_intervention.py tests/test_review_ledger.py
9 passed, 13 subtests passed in 3.97s

OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I -m pytest -q tests/test_sensitivity.py -k 'p1_linearization_artifact_restarts_identical_fso or p1_linearization_artifact_rejects_tamper_and_runtime_mismatch'
2 passed, 91 deselected in 6.44s

OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I -m pytest -q tests/test_ledger.py -k 'prospective_decision_and_executor_receipt_round_trip or typed_actions_plan_times_and_global_radius_fail_closed or retrospective_replay_is_a_separate_audit_record'
3 passed, 47 deselected in 3.69s

OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-team-audit-94c75d3/intervention_noop_probe.py
decision_created <sha256>; changed_pixel_count=0; receipt_result ValueError QC receipt did not change mask or quality; ledger_decision_rows 1
```

## Limitations

This was a bounded CPU/read-only audit. I did not run the full baseline, full sensitivity/ledger suites, MPS/CUDA, deployment commands, or a full signed operational trust-store installation. The no-op finding is directly reachable through the public typed decision and ledger APIs; no claim is made about a normal production policy generator routinely emitting no-ops.
