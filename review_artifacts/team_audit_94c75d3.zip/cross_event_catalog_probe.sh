#!/bin/sh
set -eu

python_bin=/Users/yhlee/ADVAR/.venv/bin/python
export OMP_NUM_THREADS=1
export MKL_NUM_THREADS=1

"$python_bin" -I /tmp/advar-team-audit-94c75d3/promotion_2_probe_assoc.py
"$python_bin" -I /tmp/advar-team-audit-94c75d3/promotion_2_probe_duplicate_targets.py
"$python_bin" -I /tmp/advar-team-audit-94c75d3/promotion_2_probe_duplicate_inputs.py
"$python_bin" -I /tmp/advar-team-audit-94c75d3/cross_event_catalog_probe_manifest_targets.py
