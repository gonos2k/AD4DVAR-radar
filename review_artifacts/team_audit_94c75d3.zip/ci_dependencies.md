# ci_dependencies audit

- Baseline: `94c75d3323c986b6fb2963336b906acc85384e12`
- Role: GREEN/RED
- Scope: CI workflows, source/type and lock-check scripts, `pyproject.toml`, four Linux CPU lock files, and their direct requirement inputs.

## Confirmed findings

None. I found no actionable dependency or CI-contract defect in the assigned ranges.

## Unconfirmed candidate

`.github/workflows/mps-certification.yml:15-18` creates a fresh Python 3.12 environment but installs the editable project with the open lower bounds from `pyproject.toml` and only pins `pytest==9.1.1`. The manual MPS P0 result can therefore vary with newly resolved torch/runtime packages. This is a reproducibility concern for the optional self-hosted workflow, not a required Linux CI failure: README lines 1710-1720 explicitly describe MPS P0 as a separate support check, keep full MPS P1 NO-GO, and the required CI uses the four hashed Linux CPU closures. I did not classify this as a confirmed support regression.

## GREEN preserved

- The dependency checker at `.github/scripts/check_dependency_locks.py:38-75` accepts all four assigned locks as canonical and rejects missing/duplicate SHA-256 records. Its main contract at lines 127-164 passes against the current repository.
- Parsed closure counts are runtime-py310 14 packages/339 hashes, runtime-py312 14/339, ci-py310 52/701, and ci-py312 49/695. Every pin has at least one hash; no `triton` or `nvidia-*` package is present; all four `torch` pins are the public `2.13.0` version.
- For both Python tags, every runtime package (including version and complete hash set) equals its CI counterpart. Direct project/runtime requirements resolve to `cryptography==50.0.0`, `filelock==3.32.3`, `numpy==2.2.6`, and `torch==2.13.0`; the two Python locks differ only where a transitive wheel needs to (`networkx==3.4.2` on 3.10 versus `3.6.1` on 3.12). The checker intentionally compares the exact cross-generation direct pins from `requirements/runtime.in`.
- The workflow matrix maps Python 3.10 to `ci-py310-linux.lock` and Python 3.12 to `ci-py312-linux.lock` (`ci.yml:24-29`). Required install/audit commands use `--require-hashes`, `--only-binary=:all:`, the PyTorch CPU index, isolated Python mode, `pip-audit --strict --disable-pip --no-deps`, and `pip check` (`ci.yml:42-88`). The package job builds with the CI closure and installs the runtime-py312 wheelhouse offline (`ci.yml:141-199`).
- The source-binding check and execution-environment self-test used by the package job passed with the workflow's `env -u LD_LIBRARY_PATH` behavior. The isolated `pip_audit` canary checks site-packages ownership before auditing (`ci.yml:50-73`, `149-170`).
- `.github/scripts/check_basedpyright.py:33-88` preserves the JSON report/error gate and adds `-I` for CI subprocesses. The local `.venv` lacks `basedpyright`, so no local type result is claimed; the CI lock supplies `basedpyright==1.39.9`.
- `pyproject.toml:10-16` lower compatibility floors are covered by the locked direct runtime pins and `build-system.requires` is synchronized into each CI lock. The README's claims at lines 38-45 and 162-181 match the inspected workflow/checker behavior.

## Commands and results

All probes used `/Users/yhlee/ADVAR/.venv/bin/python -I`; deterministic probe execution used `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1`. No package installation, full test suite, source edit, or workflow rerun was performed.

| Command | Result | Artifact |
| --- | --- | --- |
| `/Users/yhlee/ADVAR/.venv/bin/python -I .github/scripts/check_dependency_locks.py` | PASS: `dependency locks: 4 hashed Linux CPU closures are synchronized` | — |
| `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-team-audit-94c75d3/ci_dependencies_probe.py` | PASS: parser, direct/runtime-to-CI synchronization, CPU exclusions, source and environment probes | [ci_dependencies_probe.py](/tmp/advar-team-audit-94c75d3/ci_dependencies_probe.py), [ci_dependencies_probe.stdout](/tmp/advar-team-audit-94c75d3/ci_dependencies_probe.stdout) |
| `/Users/yhlee/ADVAR/.venv/bin/python -I .github/scripts/generate_metric_domain_evidence.py --check-source-only` | PASS; digest `ceed652ab406b18b5f8550d2213ca0840ae224babe434d4ca1e1fec9ee7a0e62` | — |
| `env -u LD_LIBRARY_PATH OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I .github/scripts/generate_metric_domain_evidence.py --self-test-execution-environment` | PASS; digest `89465071b6cd1bc68e38d10ff7c2fd552515d38125c6b3f629af0abac6ba8b0e` | — |
| `/Users/yhlee/ADVAR/.venv/bin/python -I .github/scripts/check_basedpyright.py` | BLOCKED locally: `No module named basedpyright`; wrapper correctly reports invalid JSON and exits nonzero. This is an environment limitation, not a CI lock result. | — |
| `git diff --check -- <assigned files>` | PASS; assigned files have no working-tree diff | — |

## Read coverage

Assigned ranges were read to EOF in bounded chunks:

```json
[
  {"file":".github/scripts/check_basedpyright.py","start":1,"end":92},
  {"file":".github/scripts/check_dependency_locks.py","start":1,"end":168},
  {"file":".github/workflows/ci.yml","start":1,"end":282},
  {"file":".github/workflows/mps-certification.yml","start":1,"end":35},
  {"file":"pyproject.toml","start":1,"end":28},
  {"file":"requirements/ci-py310-linux.lock","start":1,"end":837},
  {"file":"requirements/ci-py312-linux.lock","start":1,"end":820},
  {"file":"requirements/runtime-py310-linux.lock","start":1,"end":382},
  {"file":"requirements/runtime-py312-linux.lock","start":1,"end":380},
  {"file":"requirements/runtime.in","start":1,"end":6},
  {"file":"requirements/ci.in","start":1,"end":7},
  {"file":".github/scripts/generate_metric_domain_evidence.py","start":1,"end":260},
  {"file":".github/scripts/generate_metric_domain_evidence.py","start":820,"end":961},
  {"file":"README.md","start":30,"end":48},
  {"file":"README.md","start":154,"end":186},
  {"file":"README.md","start":1698,"end":1724}
]
```

## Limitations

The lock checker and source/environment probes were run locally; the GitHub-hosted installs, pip-audit database result, actual Linux wheel download, Node job, and optional MPS runner were not executed. No changing external dependency fact was needed, so no web source was used.
