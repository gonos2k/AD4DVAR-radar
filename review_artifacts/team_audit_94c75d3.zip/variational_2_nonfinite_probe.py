import torch
from advar.variational import prepare_analysis, initial_control, solve_analysis, analysis_trajectory
frames = torch.full((3,4,4), 20., dtype=torch.float64)
obs, frozen = prepare_analysis(frames)
base=initial_control(frozen)
for value in (float('nan'), float('inf'), float('-inf')):
    c=base.clone(); c[-1]=value
    for name, fn in [('solve', lambda:solve_analysis(obs,frozen,control=c)), ('trajectory', lambda:analysis_trajectory(c,frozen))]:
        try:
            fn(); out='accepted'
        except Exception as e:
            out=type(e).__name__+': '+str(e)
        print(value,name,out)
