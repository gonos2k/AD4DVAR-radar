# Cross-artifact contract review

Baseline: `94c75d3323c986b6fb2963336b906acc85384e12`  
Scope: `save_p1_linearization`/`load_p1_linearization` runtime identity and prospective/realized intervention no-op behavior.  
Environment: `/Users/yhlee/ADVAR/.venv/bin/python` 3.12.13, PyTorch 2.13.0, one OpenMP/MKL thread. No source or test files were changed.

## P1 runtime identity: no public round-trip contradiction confirmed

The two equal-named payload keys are different scopes:

- `src/advar/linearization_artifact.py:406-420` writes the NPZ envelope's `numerical_runtime_digest` with `numerical_runtime_identity_digest()` and `:781-785` checks it against the current process identity without a device argument.
- The retained `AnalysisLinearization` is produced with `numerical_runtime_identity_digest(control.device)` at `src/advar/variational.py:7256-7258`. `validate_analysis_linearization_content()` rechecks that device-bound identity at `src/advar/variational.py:9750-9756` after decoding and `map_location`.
- `_runtime.py:167-237` makes the distinction observable: exact runtime identity includes `execution_device`, while the no-argument call records a process/environment identity with a null execution device.

This sequencing is coherent for the public API. The envelope can be checked before decoding, while the state identity is checked against the device of the retained tensors after decoding. A CPU producer/CPU loader therefore has two distinct digest values but both checks pass, and the replay state remains bound to its execution device. The probe saved a real converged P1 artifact and loaded it through the public API:

```text
p1_roundtrip=accepted top_equals_none=True top_equals_cpu=False nested_equals_loaded=True top_equals_nested=False
```

The result is a metadata/schema ambiguity, not a demonstrated acceptance or replay defect. The same field name and README wording (“numerical runtime identity”) can mislead a consumer into expecting equality, and the envelope field does not itself attest to the saved tensor device. However, the nested state check supplies that device binding and rejects a mismatched replay environment. I classify the reported no-device/device mismatch as an **unconfirmed documentation/naming candidate**, not a confirmed public-path finding. A future contract revision could rename the envelope key to an explicit process/envelope identity and the nested field to state execution identity, but no source change was made here.

## Intervention no-op: confirmed decision/receipt contract mismatch

`_compute_action_safety()` at `src/advar/intervention.py:1304-1490` computes `changed_pixel_count` and upper safety limits, but has no positive-change invariant. `ProspectiveInterventionDecision.from_policy()` (`:1804-1934`) accepts the generated action after that safety check. The public ledger method `EpisodeLedger.append_prospective_intervention_decision()` (`src/advar/ledger.py:6130-6264`) replays and verifies the same decision, then inserts it into `prospective_intervention_decisions`.

The realized boundary requires the opposite. `RealizedInterventionReceipt.__post_init__()` rejects equal before/after input digests at `src/advar/intervention.py:2193-2205`; `validate_intervention_action_transition()` rejects unchanged QC mask/quality at `:2588-2597`, unchanged dBZ/override bundles at `:2602-2611`, and unchanged full analysis input at `:2615`. The SQLite schema only makes receipts point to decisions (`src/advar/ledger.py:17385-17415`); it has no terminal no-op receipt/status path.

The tiny public-path probe generated an unchanged QC action, created and accepted the prospective decision, and inserted one ledger row. Receipt construction then failed:

```text
noop_decision=accepted changed_pixel_count=0
noop_receipt=ValueError: QC receipt did not change mask or quality
noop_ledger_rows=1
```

This is reachable with a valid typed generator, policy, input context, operator approval, and trust-store-backed ledger append (the probe patches only the trust-store file loaders because operational stores require root-owned files). The same behavior applies to zero dBZ correction; an operator override whose replacement equals the current value can even report one changed mask pixel while still producing an unchanged input bundle.

The expected contract is a positive transition before recording a prospective intervention, because the documented workflow requires both a decision and an execution receipt before publication (`README.md:794-904`). An alternative explicit design would add a terminal “no action/no-op” decision state and a distinct audit receipt, but the current types and ledger expose neither. As implemented, an approved no-op can remain as an orphan prospective decision that cannot be closed by the receipt API. This is a workflow/ledger-integrity defect with realistic impact on operator approval and deadline accounting; it does not demonstrate an unsafe physical modification.

## Probe and limits

Runnable probe and output:

- [cross_artifact_intervention_probe.py](/tmp/advar-team-audit-94c75d3/cross_artifact_intervention_probe.py)
- [cross_artifact_intervention_probe.stdout.txt](/tmp/advar-team-audit-94c75d3/cross_artifact_intervention_probe.stdout.txt)

The probe uses a real public P1 save/load round trip and a valid public prospective decision/ledger append with a no-op QC generator. It does not modify source, tests, or operational trust-store files. No full suite, deployment command, CUDA/MPS path, or source fix was run.
