import sys

sys.path.insert(0, "/Users/yhlee/ADVAR/src")
sys.path.insert(1, "/Users/yhlee/ADVAR/tests")

import torch
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from advar.intervention import (
    InterventionActionGenerator,
    ProspectiveInterventionDecision,
    RealizedInterventionReceipt,
    ReusableInterventionPolicyEvidence,
)
from test_ledger import _prospective_run_and_context


class ZeroDbz(torch.nn.Module):
    def forward(self, context):
        return torch.zeros_like(context[0]), torch.tensor(
            True, device=context.device
        )


class NoOpQc(torch.nn.Module):
    def forward(self, context):
        return context[1].to(torch.bool), context[2], torch.tensor(
            True, device=context.device
        )


class SameOverride(torch.nn.Module):
    def forward(self, context):
        mask = torch.zeros_like(context[0], dtype=torch.bool)
        mask[0, 0, 0] = True
        return context[0], mask, torch.tensor(True, device=context.device)


frames = torch.zeros((3, 2, 2), dtype=torch.float64)
masks = torch.ones_like(frames, dtype=torch.bool)
before_run, before_context, plan_digest, _ = _prospective_run_and_context(
    frames, masks
)
after_run, after_context, _, _ = _prospective_run_and_context(frames, masks)
times = dict(
    decided_at="2026-08-08T00:22:00Z",
    observation_valid_time="2026-08-08T00:20:00Z",
    input_available_time="2026-08-08T00:21:00Z",
    decision_deadline="2099-08-08T00:30:00Z",
    publication_time="2099-08-08T01:00:00Z",
)
cases = (
    ("realized_sensor_correction", ZeroDbz(), None),
    ("realized_qc_intervention", NoOpQc(), "no-op audit"),
    ("operator_override", SameOverride(), "same-value override"),
)
for index, (kind, model, reason) in enumerate(cases):
    generator = InterventionActionGenerator.from_model(
        model.eval(), before_context,
        intervention_type=kind,
        action_reason=reason,
    )
    policy = ReusableInterventionPolicyEvidence(
        policy_id=f"noop-policy-{index}",
        action_generator_digest=generator.generator_digest,
        context_schema_digest=before_context.context_schema_digest,
        applicability_region_digest=before_context.applicability_region_digest,
        execution_policy_digest="e" * 64,
        allowed_intervention_types=(kind,),
        maximum_absolute_delta_dbz=2.0,
        maximum_changed_fraction=1.0,
        maximum_global_quality_precision_scale_l2=4.0,
        maximum_tile_quality_precision_scale_l2=4.0,
        validation_evidence_digests=("d" * 64,),
    )
    decision = ProspectiveInterventionDecision.from_policy(
        policy,
        action_generator=generator,
        decision_id=f"noop-decision-{index}",
        case_id="case-1",
        radar_id="radar-1",
        intervention_type=kind,
        actual_input_context=before_context,
        actual_input_before_run=before_run,
        input_plan_digest=plan_digest,
        decision_basis_digest="d" * 64,
        decision_policy_digest="e" * 64,
        decision_trust_store_digest="f" * 64,
        **times,
    )
    diagnostics = decision.action_safety_diagnostics_json
    try:
        RealizedInterventionReceipt.from_decision(
            decision,
            actual_input_before_context=before_context,
            actual_input_before_run=before_run,
            actual_input_after_context=after_context,
            actual_input_after_run=after_run,
            action_policy=policy,
            action_generator=generator,
            executor_key_id=f"executor-noop-{index}",
            executor_trust_store_digest="0" * 64,
            executor_private_key=Ed25519PrivateKey.generate(),
            executor_sequence_number=1,
            applied_time="2026-08-08T00:23:00Z",
            receipt_time="2026-08-08T00:23:00Z",
        )
    except Exception as error:
        print(kind, "decision=accepted", "diagnostics=" + diagnostics, "receipt=" + str(error))
    else:
        print(kind, "unexpectedly accepted receipt")
