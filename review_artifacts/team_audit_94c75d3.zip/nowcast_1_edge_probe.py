import math

import torch

from advar.nowcast import (
    CURRENT_RADAR_METRIC_DOMAIN,
    CURRENT_RADAR_METRIC_DOMAIN_EVIDENCE,
    RADAR_PROJECTED_GRID_CELL_CENTER_CONVENTION,
    RADAR_PROJECTED_GRID_COORDINATE_DTYPE,
    RadarGridTimeContract,
    radar_projected_crs_semantic_digest,
)


def main() -> None:
    times = (
        "2026-08-26T00:00:00Z",
        "2026-08-26T00:10:00Z",
        "2026-08-26T00:20:00Z",
    )
    grid = RadarGridTimeContract(
        valid_times=times,
        dx_m=1000.0,
        dy_m=1000.0,
        projection="EPSG:5179",
        grid_hash="1" * 64,
    )
    for seconds in (0.0, -1.0, math.nan):
        try:
            value = grid.projected_ground_speed_upper_from_displacement(
                torch.tensor((1.0, 0.0)), seconds
            )
            print("speed_upper", seconds, value)
        except Exception as error:  # noqa: BLE001 - probe reports the API boundary.
            print("speed_upper", seconds, type(error).__name__, str(error))

    evidence_grid = RadarGridTimeContract(
        valid_times=times,
        dx_m=1000.0,
        dy_m=1000.0,
        projection="EPSG:5179",
        grid_hash="2" * 64,
        spatial_grid_contract="radar-spatial-grid-identity-v6",
        grid_shape_yx=(2, 2),
        projected_crs_digest=radar_projected_crs_semantic_digest("EPSG:5179"),
        metric_domain_digest=CURRENT_RADAR_METRIC_DOMAIN.digest,
        metric_domain_evidence_digest=CURRENT_RADAR_METRIC_DOMAIN_EVIDENCE.digest,
        cell_center_origin_xy_m=(1_000_000.0, 2_000_000.0),
        grid_coordinate_dtype=RADAR_PROJECTED_GRID_COORDINATE_DTYPE,
        cell_center_convention=RADAR_PROJECTED_GRID_CELL_CENTER_CONVENTION,
    )
    print(
        "zero_area",
        evidence_grid.projected_cell_count_area_interval_km2(0.0),
        evidence_grid.cell_count_area_maximum_status(0.0, 0.0),
    )

if __name__ == "__main__":
    main()
