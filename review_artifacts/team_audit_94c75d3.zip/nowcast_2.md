# nowcast_2 (GREEN) audit

## Confirmed findings

None. I found no reachable P0/P1 nowcast defect in the assigned range. No repository source or test file was modified.

## GREEN preserved

- `prepare_input()` separates finite observations, missing values, and QC rejection. A public `nowcast()` probe with one all-missing pixel and one QC-rejected pixel produced `DataStatus.PARTIAL`, retained both pixels as absent from the latest observation mask, and satisfied `valid_mask == isfinite(forecast_dbz)`. The all-missing pixel remained NaN; a QC-rejected pixel can be reconstructed from neighboring source support, which is the intended distinction between source invalidity and forecast support. Finite out-of-range dBZ is intentionally clamped to the configured bounds.
- The background path preserves the intended normalization: three all-missing radar frames plus a 10-minute background produced `STALE_BACKGROUND`, `TendencySource.NONE`, `background_contribution_fraction=1.0`, age `10.0`, and a lead-one field equal to the latest background frame. `ForecastResult.validate_issuance()` passed.
- The moving Gaussian probe recovered displacement `[0.8988, -0.7781]` for a synthetic `[0.8, -0.65]` pixel/step motion (maximum error `0.1282`) and log growth `0.0953683` versus `log(1.10)=0.0953102`. A stationary growth probe recovered the same per-10-minute normalization and lead-one linear ratio `1.1000004`.
- A grid/time contract canonicalized equivalent UTC offsets, reported grid-axis velocity in m/s (`[1.49795, -1.29689]` for the recovered motion at 1000 m pixels and 10 minutes), and rejected an 11-minute interval before estimation.
- Source-support randomized probes preserved `[0,1]` support and contribution-fraction invariants for float32/float64 and several small grids. Existing direct path/mask tests also passed.

## Unconfirmed candidate

`variational_nowcast()` validates `source_available_mask` after `prepare_analysis()` and uses it in the learned five-channel input/run identity, while the direct P1 observation mask remains `observations.valid_mask` (variational.py:4005–4045, 6539–6583). This is consistent with the documented contract that source availability is a learned-input/provenance channel, rather than evidence that the direct radar value is invalid. I did not classify it as a defect; confirm only if an upstream producer intends source outage to invalidate an otherwise finite direct observation.

## Commands and results

- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -m pytest -q tests/test_nowcast.py -k 'stationary_echo_stays_stationary or translation_is_recovered or growth_is_recovered or all_missing_uses_time_aligned_stale_background or background_tendency_preserves_usage_and_age or phase_correlation_psr_accepts_a_distinct_shift or missing_pixel_is_not_published_as_observed_clear or local_dynamics_evidence_requires_a_nearby_past_echo or one_offset_past_echo_verifies_one_current_echo or analysis_window_growth_does_not_decay or growth_uses_normalized_advected_support or forecast_linear'`: **11 passed, 156 deselected**.
- `... pytest ... -k 'background or phase_correlation or grid_time or physical or normalization or missing or stale or provenance or source_path or forecast_evidence'`: **45 passed, 122 deselected, 18 subtests**.
- `... pytest ... -k 'gradient or dtype or device or remap or conservation or boundary or translation or growth or extrapolation or pair_selection'`: **40 passed, 127 deselected, 8 subtests**.
- Isolated `python -I` targeted regression (`stationary_echo_stays_stationary`, `all_missing_uses_time_aligned_stale_background`, `phase_correlation_psr_accepts_a_distinct_shift`, `growth_uses_normalized_advected_support`): **4 passed, 163 deselected**.
- Runnable probe: [`nowcast_2_probe.py`](/tmp/advar-team-audit-94c75d3/nowcast_2_probe.py); output: [`nowcast_2_probe.stdout.json`](/tmp/advar-team-audit-94c75d3/nowcast_2_probe.stdout.json). The same probe also passed under `python -I`.

## Limitations

The probes are deterministic synthetic CPU cases with PyTorch 2.13.0; no full baseline, MPS/CUDA run, or real radar hindcast was executed. The source-availability note is a contract-boundary question, not a reproduced failure.
