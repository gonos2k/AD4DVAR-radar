# `test_promotion_3` audit

Baseline: `94c75d3323c986b6fb2963336b906acc85384e12`  
Role: RED  
Scope: `tests/test_promotion.py:10401-15600` and the production callers needed to assess those tests.  
Status: complete; no repository source, test, branch, or other agent output was modified.

## Confirmed findings

### F-1 — `promotion_sample_size_preflight` can report a required cell as feasible without checking `minimum_cases` (bounded P2 contract gap)

At `src/advar/promotion.py:20727-20920`, `promotion_sample_size_preflight` receives metric and issuance cell tuples whose final two fields are interpreted as available and required **physical-event** counts. `cell_feasible` is only:

```python
all(item[-2] >= item[-1] for item in (*metric_cell_event_counts, *issuance_cell_event_counts))
```

The tuples carry no qualifying-case count, and the preflight does not inspect `RangeMetricRequirement.minimum_cases` or `RangeIssuanceRequirement.minimum_cases`. The actual promotion computation separately rejects a metric cell when `qualifying < requirement.minimum_cases` (`src/advar/promotion.py:22510-22521`) and rejects an issuance cell on the analogous condition (`src/advar/promotion.py:22500-22516`). Thus the preflight result is an optimistic physical-event-only readiness signal.

The runnable probe `test_promotion_3_preflight_cases_probe.py` builds the existing fixture plan, raises every required cell's `minimum_cases` to 9,999, supplies only 21 physical events for each required cell, and supplies the remaining global counts needed for the other preflight gates. It reports:

```text
{'policy_metric_minimum_cases': (9999, 9999),
 'policy_issuance_minimum_cases': (9999, 9999),
 'preflight_cell_feasible': True,
 'preflight_classifier_subset_feasible': True,
 'preflight_automatic_inference': True,
 'preflight_required_physical_events': 21,
 'preflight_feasible': True,
 'physical_events_supplied': 10000,
 'preflight_only_counts_physical_events': ((21, 1), (21, 1))}
```

Expected behavior is either to pass qualifying-case counts into preflight and check both requirements, or to mark the cell/readiness result unknown until the case-level check runs. The current internal promotion path still checks `minimum_cases` and gates `deployment_eligible`, so this is not an observed automatic-deployment bypass. It affects callers that use the public preflight result as a standalone readiness certificate. Assigned tests `test_sample_size_preflight_rejects_an_impossible_small_holdout` (12403-12447) and `test_sample_preflight_fails_a_sparse_metric_cell` (13054-13068) cover physical-event scarcity, but do not vary `minimum_cases` independently.

### F-2 — The three assigned operational geometry tests never exercise geometry validation (confirmed test-oracle gap)

`src/advar/promotion.py:28043-28050` implements `infer_deployed_neural_prior` as an unconditional `OperationalDeploymentUnsupportedError` before reading any argument. The assigned tests `test_operational_range_geometry_must_match_current_run_grid` (10719-10783), `test_operational_range_coordinates_must_match_frame_shape` (10784-10848), and `test_selector_rechecks_operational_partition_grid` (10849-10879) all assert that same unsupported exception. Consequently, their malformed or mismatched geometry, frame shape, and partition values are unreachable by the test.

The probe `test_promotion_3_unsupported_deployment_probe.py` calls the function once with no arguments and once with a 4x4 frame plus 2x2 coordinates and an arbitrary geometry object. Both produce the identical result:

```text
no_arguments OperationalDeploymentUnsupportedError Scientific promotion evidence v32 is not an operational deployment authorization contract.
mismatched_geometry_and_frame OperationalDeploymentUnsupportedError Scientific promotion evidence v32 is not an operational deployment authorization contract.
```

This is a coverage/oracle gap rather than a current deployment defect because the package intentionally rejects operational deployment. If deployment support is enabled later, these tests will not detect the intended grid/partition contract violations.

## Unconfirmed candidates

### U-1 — `MetricSupportContract.from_run` trusts a caller-provided spatial shape

`src/advar/promotion.py:18136-18183` validates that `grid_shape` is a positive 2-tuple, then computes the centroid support from that shape. It does not compare the shape with the run's frame shape or with the registered spatial-grid shape. The runnable probe constructs a run with a 2x2 frame and asks for `(1, 2)` support on the same grid. It reports an upper bound of `1,000,000` versus `2,000,000.0000000007` for the exact `(2, 2)` shape, with the same spatial-grid digest and `unsafe_underbound: True`.

The current production caller (`PriorHoldoutEvaluation.from_forecasts`, `src/advar/promotion.py:14999-15008`) passes `input_frames_dbz.shape[-2:]`, so no internal reachable misuse was found. The public factory may intentionally support a separately supplied forecast output shape; this remains a boundary-contract candidate unless that shape is required to equal the run/grid shape.

### U-2 — Single-site range resolver does not revalidate a mutated contract digest

`src/advar/range_geometry.py:428-476` checks coordinate tensor digests but does not call `RangeGeometryContract.validate_integrity()` before using the contract fields. The probe mutates the frozen contract's radar origin with `object.__setattr__` while retaining the original digest; the resolver changes the masks while retaining the stale digest in the emitted partition. Ordinary construction validates the digest and frozen dataclass fields, so this requires a tampered in-memory object or an equivalent corrupted deserializer state. No normal public construction path reached the condition; it is retained as a private/tamper-boundary candidate only.

## GREEN preserved

- Quantized threshold-bin partitioning, midpoint PIT, float32 decimal-lattice handling, and large-tail finite diagnostics remained mathematically consistent in the inspected paths (`_quantized_bin_bounds`, `_quantized_gaussian_diagnostics`, `_truncated_gaussian_diagnostics`).
- Physical-event track speed/acceleration limits, membership signatures, cross-radar association identity, chronology, and training/holdout disjointness were checked by independent fixture mutations and fail-closed validators.
- Metric support formulas for FSS, bounded log-echo MSE, and affine-grid centroid diameter are coherent; engine and run/grid identity checks reject forged support metadata.
- Automatic cluster uncertainty uses support-bounded empirical-Bernstein bounds and does not treat one-cluster or zero-variance samples as certain; the assigned tests exercise those guards.
- Training archive replay checks content digests, read-only archive state, shard manifests, tensor snapshots, relocation invariance, and corruption rejection. No new reachable archive integrity counterexample was found.

## Commands, results, and limitations

All probes used the required single-thread command form and isolated interpreter:

```text
OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-team-audit-94c75d3/test_promotion_3_preflight_cases_probe.py
OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-team-audit-94c75d3/test_promotion_3_metric_support_shape_probe.py
OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-team-audit-94c75d3/test_promotion_3_range_integrity_probe.py
OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-team-audit-94c75d3/test_promotion_3_unsupported_deployment_probe.py
```

All four exited 0. Probe source and captured output are in `/tmp/advar-team-audit-94c75d3/` with the `test_promotion_3_` prefix. No full baseline or broad promotion suite was run. The preflight probe uses the existing test fixture to demonstrate missing input information; it does not claim that a concrete production evidence set with 21 events has only 21 cases. The range-integrity probe intentionally uses `object.__setattr__` and is therefore a tamper-boundary demonstration, not a normal constructor-path defect.

Because the root agent made a four-line fixture-only edit before this assignment, the assigned test ranges were also read from `git show 94c75d3:tests/test_promotion.py`. `test_promotion_3_baseline_range_read.py` read all nine required chunks (10401-11000 through 15201-15600); every chunk matched the current file after applying that known four-line offset.
