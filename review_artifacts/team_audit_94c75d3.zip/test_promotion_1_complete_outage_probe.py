"""Bounded probe for the complete-mosaic-outage replay boundary."""

from __future__ import annotations

import sys

import torch

sys.path.insert(0, "/Users/yhlee/ADVAR/tests")

import test_promotion as test_module  # noqa: E402
from advar import ledger as ledger_module  # noqa: E402


RAW_ROLES = (
    "raw_source_reflectivity_bits",
    "raw_source_qc_flags",
    "raw_source_quality_bits",
    "raw_source_observation_std_bits",
)


def main() -> None:
    fixture = test_module.NeuralPriorPromotionTests("run")
    case = fixture.scoring_replay_cases((fixture.evaluation(1, -0.2),))[0]
    tensors = case.replay_tensors()
    for role in RAW_ROLES:
        tensors[role] = torch.empty(
            (0, *tensors[role].shape[1:]), dtype=tensors[role].dtype
        )
    try:
        ledger_module._validate_scoring_replay_case_tensors(
            tensors,
            dynamic_source=False,
            background_present=False,
        )
    except ValueError as error:
        print(f"validator rejects all-missing raw channels: {error}")
    else:
        raise AssertionError("validator unexpectedly accepted empty raw channels")


if __name__ == "__main__":
    main()
