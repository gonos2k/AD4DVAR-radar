# Root independent bound check

Baseline: `94c75d3323c986b6fb2963336b906acc85384e12`.

`_event_fractional_rate_interval` uses the empirical-Bernstein radius from Maurer and Pontil (2009), Theorem 4, on event-level [0,1] fractions. The two-sided/family allocation is explicit.

For `_bounded_event_mean_upper_bound`, event means are in [-A,A] and alpha=(1-confidence)/(2*family)<1/2. Scaling Theorem 4 yields radius sqrt(2*s²*log(2/alpha)/n)+14*A*log(2/alpha)/(3*(n-1)). The implementation uses sqrt(2*s²*log(3/alpha)/n)+6*A*log(3/alpha)/n. For n>=5, 6/n >= 14/(3*(n-1)), so both terms dominate the theorem radius. For 2<=n<=4, its linear term is at least 1.5*A*log(6)>2*A, so clipping returns the trivial valid upper support A. For n=1 it explicitly returns A. Thus this implementation is conservative under the theorem's independent, identically distributed bounded-event assumptions.

This is an analytic comparison, not a proof of independence in a meteorological catalog, nor a claim of calibrated coverage on real radar data. The separately reproduced event-association ordering defect matters to that interpretation.

Primary source read: [Maurer and Pontil, Empirical Bernstein Bounds and Sample Variance Penalization (2009), Theorem 4](https://www.cs.mcgill.ca/~colt2009/papers/012.pdf).
