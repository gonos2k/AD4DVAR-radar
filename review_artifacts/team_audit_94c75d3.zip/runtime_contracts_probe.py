"""Focused runtime/input contract probes for the second audit."""

from __future__ import annotations

import json

from advar._digest import json_digest
from advar._input_derivation import validate_analysis_input_derivation_lineage
from advar._runtime import numerical_runtime_identity_digest


def _minimal_lineage() -> dict[str, object]:
    digest = "a" * 64
    return {
        "contract": "analysis-input-derivation-artifact-v4",
        "case_id": "case",
        "input_plan_digest": digest,
        "resolved_raw_observation_receipt_digests": [digest],
        "canonical_raw_volume_identity_digests": [digest],
        "global_raw_resolution_receipt_digest": digest,
        "decoder_version_digest": digest,
        "qc_algorithm_digest": digest,
        "qc_policy_digest": digest,
        "source_selection_evidence_digest": digest,
        "regrid_algorithm_digest": digest,
        "grid_contract_digest": digest,
        "background_cycle_rule_digest": digest,
        "background_valid_times": [],
        "background_source_identity_digest": None,
        "background_input_identity_digests": [],
        "input_frames_digest": digest,
        "observation_masks_digest": digest,
        "observation_quality_weight_digest": digest,
        "observation_std_dbz_digest": digest,
        "background_frames_digest": None,
        "input_bundle_digest": digest,
        "full_analysis_input_digest": digest,
        "processed_at": "2026-01-01T00:00:00Z",
        "processor_id": "processor",
        # Signature is deliberately outside this lineage-only validator.
        "processor_public_key_hex": "x",
        "processor_signature_hex": "y",
    }


def main() -> None:
    print(
        "runtime_digest_none=" + numerical_runtime_identity_digest(),
        "runtime_digest_cpu=" + numerical_runtime_identity_digest("cpu"),
        sep="\n",
    )
    payload = _minimal_lineage()
    canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"))
    validate_analysis_input_derivation_lineage(canonical, json_digest(payload))
    print("lineage_valid=accepted")
    malformed = dict(payload)
    malformed["resolved_raw_observation_receipt_digests"] = [1, "a" * 64]
    text = json.dumps(malformed, sort_keys=True, separators=(",", ":"))
    try:
        validate_analysis_input_derivation_lineage(text, json_digest(malformed))
    except Exception as error:  # noqa: BLE001 - probe records exact contract behavior.
        print(f"mixed_digest_list={type(error).__name__}: {error}")


if __name__ == "__main__":
    main()
