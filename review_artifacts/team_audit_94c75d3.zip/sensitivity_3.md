# sensitivity_3 audit (RED)

Baseline: `94c75d3323c986b6fb2963336b906acc85384e12`  
Scope: `src/advar/sensitivity.py:9201-13800` (all assigned lines read in 500-line bounded chunks; final 100-line chunk read separately). No repository source or tests were modified.

## Confirmed findings

### S3-01 — M0 `SensitivitySnapshot` ignores typed verification metric weights (duplicate sibling finding)

Locations: `_resolve_verification()` at [sensitivity.py:11654](/Users/yhlee/ADVAR/src/advar/sensitivity.py:11654) resolves `VerificationBundle.fso_metric_weight` into `resolved.metric_weight`; `compute_sensitivity_snapshot()` at [sensitivity.py:12610](/Users/yhlee/ADVAR/src/advar/sensitivity.py:12610) builds `valid` only with `_metric_domain_weight(...)` and never multiplies `resolved.metric_weight`. The same module's resolved score path does multiply it at [sensitivity.py:13252](/Users/yhlee/ADVAR/src/advar/sensitivity.py:13252)-[13263](/Users/yhlee/ADVAR/src/advar/sensitivity.py:13263). `VerificationBundle.fso_metric_weight` is explicitly the quantitative/spatial FSO weighting contract at [sensitivity.py:8437](/Users/yhlee/ADVAR/src/advar/sensitivity.py:8437).

This is retained for coverage context only; the parent audit reports this same public-path finding under `sensitivity_2/test_sensitivity_1`, so it is not counted as a new finding here. The violated invariant is that a complete typed verification bundle's quality, inverse-variance, state, and spatial support weights define the metric sample domain consistently across producers and consumers. M0 currently computes scores, gradients, support, evidence, and trust with a binary forecast domain while denial/resolved scoring uses the typed weights.

The runnable probe `sensitivity_3_probe_verification_weight.py` constructs a contract-valid `radar-verification-bundle-v6` with finite truth, all cells valid/observed, `quality_weight=1.0` on the left half and `0.25` on the right, and `observation_std_dbz=2.0`. With the right half 15 dBZ away from the forecast:

```
fso_metric_weight_minmax_nonzero 0.25 1.0 221
weight_diff_nonzero 125
snapshot_score 5.964635374288197
manual_metric_with_bundle_weight 2.385854149715279
resolved_forecast_scores 2.385854149715279 available True
```

With a contract-valid all-zero quality tensor, `compute_sensitivity_snapshot()` reports `metric_available=True` and a finite score, while `_resolved_forecast_scores()` reports unavailable/NaN. This is a reachable public `compute_sensitivity_snapshot()` call with a typed `VerificationBundle`; it is not a device/backend or mocked numerical probe. The v6 bundle is an accepted audit-generation contract in `_resolve_verification`; the same missing multiplication is present in the P1 metric-domain construction outside the assigned range, so current quality/spatial lineage cannot be assumed to be applied by FSO metrics.

Impact is a wrong forecast metric and direct/control sensitivity for quality-weighted verification, false metric support when all typed weights are zero, and disagreement with observation-denial/resolved scoring. A downstream trust/learning or ledger consumer can therefore record or rank a metric whose accepted verification support differs from its typed scientific support.

### S3-02 — v4 learning approval omits full-analysis-input lineage binding

Location: [sensitivity.py:12210](/Users/yhlee/ADVAR/src/advar/sensitivity.py:12210)-[12227](/Users/yhlee/ADVAR/src/advar/sensitivity.py:12227). `FirstOrderValidation` requires `nominal_full_analysis_input_digest` at [sensitivity.py:10312](/Users/yhlee/ADVAR/src/advar/sensitivity.py:10312), and `LearningApprovalEvidence` v4 stores the corresponding field at [sensitivity.py:10506](/Users/yhlee/ADVAR/src/advar/sensitivity.py:10506), but the `expected` dictionary in `validate_variational_learning_impact()` never compares `evidence.nominal_full_analysis_input_digest` with `validation.nominal_full_analysis_input_digest`. The existing producer-side check in `_learning_impact_from_fsoi()` at [sensitivity.py:14003](/Users/yhlee/ADVAR/src/advar/sensitivity.py:14003)-[14004](/Users/yhlee/ADVAR/src/advar/sensitivity.py:14004) only protects normally produced objects.

The probe `sensitivity_3_probe_learning_lineage_real.py` uses an actual converged P1 FSO/FSOI (`p1-variational-fso-v28`, `p1-linearized-observation-impact-v24`) and current verification bundle, then constructs typed validation/evidence records with one changed v4 full-analysis digest. No validator patch is used. Both the matching and forged records pass:

```
nominal_full_analysis_validation c2fd20e13426381969f8734eea4917254abe1ad10031c8f5966445cb1a3fe634
nominal_full_analysis_evidence ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff
forged_validation_passed True
```

The probe's full/half metric tensors are synthetic because it targets the cross-binding validator, so this establishes an artifact-integrity gap rather than a claim that the normal solver emits forged evidence. The actual ledger append path calls this validator before storing the evidence (`ledger.py:5135`), and intervention validation calls it again; a reconstructed or tampered typed approval with recomputed content digests can therefore retain a stale/mismatched full-analysis lineage as approved. Severity is P2 when approval lineage is a gate, otherwise P3 audit-integrity scope.

### S3-03 — Candidate ranking artifact does not bind objective or recompute score from FSO maps (unconfirmed artifact-integrity candidate)

`VariationalCandidateRanking.__post_init__()` at [sensitivity.py:10194](/Users/yhlee/ADVAR/src/advar/sensitivity.py:10194)-[10219](/Users/yhlee/ADVAR/src/advar/sensitivity.py:10219) checks rank/order, candidate/precheck identity, budgets, and the content digest, but does not validate that `ranking_objective` is one of the three declared literal values or that each `VariationalCandidateScore.score` equals `_candidate_ranking_score(...)` from the bound FSO maps and policy. `validate_top_k_learning_impacts()` at [sensitivity.py:13750](/Users/yhlee/ADVAR/src/advar/sensitivity.py:13750)-[13761](/Users/yhlee/ADVAR/src/advar/sensitivity.py:13761) verifies the FSO and ranking digest/policy digest but likewise trusts the supplied score and objective; it does not recompute them. The producer `score_candidate_perturbations()` computes both correctly at [sensitivity.py:13503](/Users/yhlee/ADVAR/src/advar/sensitivity.py:13503), so this is a reconstructed/tampered typed-artifact candidate rather than a demonstrated normal-producer defect.

The runnable narrow artifact probe `sensitivity_3_probe_ranking_binding.py` constructs a typed ranking with a forged objective, arbitrary prediction and score, and a self-consistent ranking digest; the constructor accepts it:

```
constructed True
ranking_objective unsupported-objective
forged_prediction 999.0
forged_score 999.0
digest_self_consistent True
```

Impact would be incorrect top-k ranking metadata or candidate score carried into approval evidence if an untrusted caller can supply a reconstructed ranking. No full public `validate_top_k_learning_impacts()` run with a real forged ranking was performed, and no finding is promoted beyond this unconfirmed candidate.

## GREEN preserved

Zero-gradient sensitivity evidence is correctly allowed to be jointly unavailable. The first probe's exact-zero verification case reports all four evidence channels non-finite/NaN while the metric itself remains available:

```
zero_gradient_evidence_finite [False, False, False, False]
```

This follows `_metric_evidence_ratios()` returning `None` when its sensitivity-weight denominator is at/below epsilon. It must remain distinct from the S3-01 metric-support mismatch; rejecting all-NaN evidence whenever `metric_available=True` would reject this valid producer state.

The selected existing tests passed: `snapshot_shapes_and_m0_scope`, `candidate_ranking_is_dimensionless_and_benefit_directed`, `verification_observation_error_controls_metric_weight`, and `joint_evidence_rejects_spatially_disjoint_marginals` (`4 passed, 89 deselected`).

## Unconfirmed candidates / limits

- Candidate ranking marks non-top candidates `admissible=True` without running `_candidate_full_precheck_reason()` (the full check is deliberately deferred to top-k candidates). This is metadata semantics, not an established execution defect; no finding is raised.
- Direct constructors accept several tensor-shape combinations whose full semantic shape is only checked by later consumers. No separate public artifact path was demonstrated beyond S3-02.
- No full baseline, deployment, MPS/CUDA path, or real radar archive was run. Probe artifacts are under `/tmp/advar-team-audit-94c75d3/`.
