#!/bin/zsh
set -euo pipefail
cd /Users/yhlee/ADVAR
export OMP_NUM_THREADS=1
export MKL_NUM_THREADS=1
/Users/yhlee/ADVAR/.venv/bin/python -I -m pytest -q tests/test_promotion.py \
  -k 'scoring_start_requires_registered_catalog_and_trusted_time or training_completion_requires_a_ledger_backed_start or scoring_algorithm_must_match_the_preregistered_plan' \
  --maxfail=1
/Users/yhlee/ADVAR/.venv/bin/python -I -m pytest -q tests/test_promotion.py \
  -k 'trusted_process_start_receipt_rejects_signature_tampering' \
  --maxfail=1
