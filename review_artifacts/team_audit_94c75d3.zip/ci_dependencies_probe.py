from __future__ import annotations

import importlib.util
import os
import subprocess
import sys
from pathlib import Path


ROOT = Path("/Users/yhlee/ADVAR")
SCRIPT = ROOT / ".github/scripts/check_dependency_locks.py"
spec = importlib.util.spec_from_file_location("ci_lock_checker", SCRIPT)
assert spec is not None and spec.loader is not None
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)


completed = subprocess.run(
    [sys.executable, "-I", str(SCRIPT)],
    cwd=ROOT,
    check=False,
    capture_output=True,
    text=True,
)
assert completed.returncode == 0, completed.stderr
assert "4 hashed Linux CPU closures are synchronized" in completed.stdout

closures = {
    name: module._read_lock(path) for name, path in module.LOCKS.items()
}
for name, pins in closures.items():
    assert pins
    assert all(package.hashes for package in pins.values()), name
    assert "triton" not in pins
    assert not any(package.startswith("nvidia-") for package in pins)
    assert pins["torch"].version == "2.13.0"

for tag in ("310", "312"):
    runtime = closures[f"runtime-py{tag}-linux.lock"]
    ci = closures[f"ci-py{tag}-linux.lock"]
    assert all(ci.get(name) == package for name, package in runtime.items())

runtime_versions = {
    closures[f"runtime-py{tag}-linux.lock"]["networkx"].version
    for tag in ("310", "312")
}
assert runtime_versions == {"3.4.2", "3.6.1"}

for option in ("--check-source-only", "--self-test-execution-environment"):
    command = [
        sys.executable,
        "-I",
        str(ROOT / ".github/scripts/generate_metric_domain_evidence.py"),
        option,
    ]
    completed = subprocess.run(
        command,
        cwd=ROOT,
        env={key: value for key, value in os.environ.items() if key != "LD_LIBRARY_PATH"},
        check=False,
        capture_output=True,
        text=True,
    )
    assert completed.returncode == 0, (option, completed.stderr)
    assert completed.stdout.strip(), option

print("PASS: lock parser, direct/runtime-to-CI synchronization, CPU exclusions, and source/environment probes")
print("INFO: networkx differs by Python tag: 3.10=3.4.2, 3.12=3.6.1")
