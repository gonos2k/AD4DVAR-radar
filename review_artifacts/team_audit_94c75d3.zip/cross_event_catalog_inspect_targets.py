import sys
sys.path.insert(0, '/Users/yhlee/ADVAR/tests')
from dataclasses import replace
from test_promotion import NeuralPriorPromotionTests
import advar.promotion as p
f=NeuralPriorPromotionTests('runTest')
plan=f.plan(); manifest=f.manifest()
for i,c in enumerate(plan.cases):
    print('plan_case', i+1, c.case_id, c.input_plan_digest, c.uncertainty_target_plan_digest, c.state_calibration_target_plan_digest, c.issue_time)
for i,c in enumerate(manifest.holdout_cases):
    ident=c.verification_target_identity
    print('manifest_case',i+1,c.case_id,c.full_analysis_input_digest,c.uncertainty_target_plan_digest,c.uncertainty_target_digest,ident.source_identity_digest,ident.target_valid_time,ident.target_tensor_digest,c.state_calibration_target_plan_digest,c.state_calibration_target_digest)
