import math
import mpmath as mp
import torch
from fractions import Fraction

from advar.promotion import (
    _quantized_bin_bounds,
    _standard_normal_log_interval_mass,
    _truncated_gaussian_diagnostics,
)

mp.mp.dps = 500


def mp_log_mass(lower: float, upper: float) -> float:
    root_two = mp.sqrt(2)
    lower_exact = mp.mpf(Fraction.from_float(lower).numerator) / Fraction.from_float(lower).denominator
    upper_exact = mp.mpf(Fraction.from_float(upper).numerator) / Fraction.from_float(upper).denominator
    mass = mp.mpf("0.5") * (
        mp.erf(upper_exact / root_two)
        - mp.erf(lower_exact / root_two)
    )
    return float(mp.log(mass))


cases = (
    (-1.0e-16, 1.0e-16),
    (-40.000001, -40.0),
    (39.75, 40.25),
    (-2.0, 3.0),
    (-100.0, 100.0),
)
for lower, upper in cases:
    actual = float(
        _standard_normal_log_interval_mass(
            torch.tensor([lower], dtype=torch.float64),
            torch.tensor([upper], dtype=torch.float64),
        )[0]
    )
    expected = mp_log_mass(lower, upper)
    print("interval", lower, upper, "actual", repr(actual), "mp", repr(expected), "abs_err", abs(actual - expected))

reference = torch.tensor([5.0, 5.5, 6.0], dtype=torch.float64)
lower, upper = _quantized_bin_bounds(
    reference,
    reflectivity_resolution_dbz=0.5,
    quantization_origin_dbz=-10.0,
    support_threshold_dbz=5.0,
    threshold_bin_convention="nearest_rounding_threshold_censor",
)
print("bins", lower.tolist(), upper.tolist(), "shared_boundaries", upper[:-1].tolist() == lower[1:].tolist())

location = torch.tensor([45.0], dtype=torch.float64)
scale = torch.tensor([1.0], dtype=torch.float64)
reference = torch.tensor([5.0], dtype=torch.float64)
nll, pit = _truncated_gaussian_diagnostics(
    location,
    scale,
    reference,
    support_threshold_dbz=0.0,
)
threshold = mp.mpf("0")
lo, hi = mp.mpf("4.75"), mp.mpf("5.25")
num = mp.mpf("0.5") * (mp.erf((hi - 45) / mp.sqrt(2)) - mp.erf((lo - 45) / mp.sqrt(2)))
den = mp.mpf("0.5") * (1 + mp.erf((45 - threshold) / mp.sqrt(2)))
expected_nll = float(-mp.log(num / den))
print("truncated_tail", float(nll[0]), expected_nll, "abs_err", abs(float(nll[0]) - expected_nll), "pit", float(pit[0]))
