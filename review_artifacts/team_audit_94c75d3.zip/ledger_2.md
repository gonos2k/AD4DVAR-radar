# ledger_2 audit

Baseline: `94c75d3323c986b6fb2963336b906acc85384e12`. Read the assigned
`src/advar/ledger.py:5601-11200` range in full, plus the EpisodeLedger setup,
artifact replay dependencies, SQLite schema/connection setup, and the typed
promotion fixture used by both probes. This was read-only; no repository source
or tests were changed.

## Confirmed findings

### L2-R01 · P2 · dynamic source coverage can be inserted after its deadline

Location: `src/advar/ledger.py:7827-7864`, public
`EpisodeLedger.append_resolved_source_coverage_artifact`; downstream caller
`append_neural_prior_holdout_scoring_input_artifact` at `11567-11580` only
requires that a coverage row exists.

The method reads `now` once, checks
`resolved_at <= now <= input_plan.decision_deadline` at lines 7834-7835, then
opens SQLite and inserts at lines 7836-7859. There is no clock check while the
write lock is acquired or after the insert. Consequently, a valid artifact can
pass preflight before the deadline and become durable after it. The contract
requires source coverage to be durably appended pre-issue; the downstream
scoring-input append does not inspect `resolved_at` or `created_at`, so the late
row is still accepted as the required pre-issue coverage.

Small public-path reproduction (`ledger_2_coverage_deadline_probe.py`) uses the
repository's typed mosaic issuance, signed source-coverage artifact, and
`OperationalIssuanceDomainArtifact`. It sets preflight time to
`2026-08-09T00:01:30Z`, the plan deadline to `00:02:00Z`, and advances the
trusted clock to `00:03:00Z` when `_connect()` is entered (an induced lock/
filesystem delay). The public call returns the artifact digest and the SQLite
row is present:

```json
{"decision_deadline":"2026-08-09T00:02:00Z","digest_returned":"929f9085b9944470b427115fdfdc7205f65b0da60d13bd5055707613876959d6","insert_now":"2026-08-09T00:03:00+00:00","preflight_now":"2026-08-09T00:01:30+00:00","resolved_at":"2026-08-09T00:01:00Z","row":["929f9085b9944470b427115fdfdc7205f65b0da60d13bd5055707613876959d6","2026-08-09T00:01:00Z"]}
```

The boundary is a durable-timing violation, not a malformed-artifact case.
The smallest fix is to perform the trusted deadline check while holding the
write transaction immediately before commit (and roll back when it has
crossed), or otherwise make the recorded commit time part of the same checked
contract. Any fix must preserve idempotent duplicate handling and the existing
artifact validation.

### L2-R02 · P2 · concurrent provenance recovery is advertised as idempotent but one request fails

Location: `src/advar/ledger.py:10411-10429` and `10431-10440`, public
`EpisodeLedger.reconcile_prepared_analysis_input_provenance`. The method's
transactional activation uses conditional `UPDATE ... status='prepared' ...`
and requires `rowcount == 1`; a concurrent request that read the same prepared
state receives `ValueError("prepared provenance activation raced")` after the
first request commits.

The method docstring at `10178-10185` promises an idempotent activation/recovery
path. For the same artifact, two valid callers should both observe successful
activation (or the already-active result), with final state `active, usable=1`.
The current read/validate/conditional-update sequence is not idempotent under
concurrency: both requests can read `prepared`; one wins the update, the other
gets rowcount zero and raises. A similar race exists in the no-receipt branch at
`10339-10370`, where the second writer fails with a preparation-receipt race.

`ledger_2_concurrent_probe.py` exercises the actual public path with the
repository's complete typed operational plan, signed raw receipts, derivation,
files, trust stores, and public `append_operational_analysis_input_provenance`.
Only its post-commit reconciliation callback is induced to fail, leaving
`("prepared", 0)`. Two concurrent public reconcile calls then produce:

```json
{"artifact_digest":"872a5b60923f99205eee8bd8ef6d9da7d3200848b1e83a28e1359bcccf37bdbb","outcomes":["ok:872a5b60923f99205eee8bd8ef6d9da7d3200848b1e83a28e1359bcccf37bdbb","error:ValueError:prepared provenance activation raced"],"state_after":["active",1],"state_before":["prepared",0]}
```

This is reachable during crash recovery or duplicate workers; the losing
caller cannot tell whether activation succeeded without a separate retry. A
small repair is to reread the row after a zero-row conditional update and
return success when the same immutable artifact is already active, while
retaining identity/trust checks. The no-receipt update needs the same
compare-after-race treatment. The probe does not claim both calls are required
to return simultaneously; it demonstrates the documented idempotent public
operation currently returns an avoidable error for one valid caller.

## Unconfirmed candidates

The same initial-SELECT/transaction pattern means concurrent duplicate calls
to `append_operational_analysis_input_provenance` or the holdout variant can
reach a duplicate `INSERT` after the first call publishes and commits. I did
not report that as a separate finding because the public append has a
sequential retained-row path and its duplicate-call contract is not stated as
idempotent; only the explicitly documented concurrent recovery contract above
was reproduced.

`_validate_operational_raw_resolution_legacy_anchor` reopens
`provenance.json` by pathname after `_snapshot_analysis_input_provenance_directory`
has validated descriptor-pinned bytes (`10631-10645`). This is a possible TOCTOU
surface for a hostile writer, but it needs a race against a live artifact
producer and is outside the two deadline/concurrent-resume hypotheses. No
severity is assigned here.

## GREEN preserved

The global sampling registry append at `7879-7935` is serialized by callers'
`BEGIN IMMEDIATE` and explicitly checks sequence/root contiguity. Raw-resolution
history transitions at `10762-10875` validate previous identity/kind and signed
chronology. Provenance recovery rehashes descriptor-pinned files, reconstructs
raw products, verifies typed plans and current trust snapshots, and fails closed
on replay mismatch. The probes left the final successful state and all source
files unchanged.

## Commands, results, limitations

- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-team-audit-94c75d3/ledger_2_concurrent_probe.py` — public typed append followed by two concurrent public recoveries; one succeeds and one reports the activation race; final row active/usable.
- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-team-audit-94c75d3/ledger_2_coverage_deadline_probe.py` — public typed source-coverage append crossing the deadline; late row retained.

Probe scripts and exact JSON output are saved under
`/tmp/advar-team-audit-94c75d3/ledger_2_*`. No full baseline or broad promotion/
variational/sensitivity/ledger suite was run. The deadline probe injects a
clock transition at `_connect()` to model scheduling/lock delay; it does not
measure wall-clock latency. The concurrent probe uses the repository's typed
fixture and public ledger methods, with only the first post-commit crash
induced to obtain a recoverable prepared row.
