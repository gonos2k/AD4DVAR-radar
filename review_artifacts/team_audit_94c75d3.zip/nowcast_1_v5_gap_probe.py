import pathlib
import tempfile

import torch

from advar.nowcast import (
    CURRENT_RADAR_METRIC_DOMAIN,
    CURRENT_RADAR_METRIC_DOMAIN_EVIDENCE,
    RADAR_PROJECTED_GRID_CELL_CENTER_CONVENTION,
    RADAR_PROJECTED_GRID_COORDINATE_DTYPE,
    NowcastConfig,
    RadarGridTimeContract,
    motion_displacement_limits_yx,
    nowcast,
    radar_projected_crs_semantic_digest,
)
from advar.run_artifact import (
    forecast_run_arrays,
    load_forecast_run,
    save_forecast_run,
)


TIMES = (
    "2026-08-26T00:00:00Z",
    "2026-08-26T00:10:00Z",
    "2026-08-26T00:20:00Z",
)
COMMON = dict(
    valid_times=TIMES,
    dx_m=1000.0,
    dy_m=1000.0,
    projection="EPSG:5179",
    grid_hash="1" * 64,
    grid_shape_yx=(2, 2),
    projected_crs_digest=radar_projected_crs_semantic_digest("EPSG:5179"),
    metric_domain_digest=CURRENT_RADAR_METRIC_DOMAIN.digest,
    cell_center_origin_xy_m=(1_000_000.0, 2_000_000.0),
    grid_coordinate_dtype=RADAR_PROJECTED_GRID_COORDINATE_DTYPE,
    cell_center_convention=RADAR_PROJECTED_GRID_CELL_CENTER_CONVENTION,
)


def make_grid(contract: str) -> RadarGridTimeContract:
    kwargs = dict(COMMON)
    kwargs["spatial_grid_contract"] = contract
    if contract == "radar-spatial-grid-identity-v6":
        kwargs["metric_domain_evidence_digest"] = (
            CURRENT_RADAR_METRIC_DOMAIN_EVIDENCE.digest
        )
    return RadarGridTimeContract(**kwargs)


def main() -> None:
    grid_v5 = make_grid("radar-spatial-grid-identity-v5")
    grid_v6 = make_grid("radar-spatial-grid-identity-v6")
    config = NowcastConfig(maximum_motion_speed_mps=10.0)
    reference = torch.zeros(2, dtype=torch.float64)
    for label, grid in (("v5", grid_v5), ("v6", grid_v6)):
        limits = motion_displacement_limits_yx(config, grid, reference)
        speed = grid.projected_ground_speed_upper_from_displacement(
            torch.tensor((0.0, 6.0), dtype=torch.float64),
            600.0,
        )
        print(
            label,
            "evidence=",
            grid.metric_domain_evidence_digest,
            "limits=",
            limits.tolist(),
            "ground_upper_for_6px=",
            float(speed),
        )

    frames = torch.full((3, 2, 2), 20.0, dtype=torch.float64)
    result = nowcast(frames, config=config, grid_time_contract=grid_v5)
    print(
        "v5_run",
        "evidence=",
        result.run.grid_time_contract.metric_domain_evidence_digest,
        "issuance=",
        result.validate_issuance() is None,
        "arrays=",
        forecast_run_arrays(result) is not None,
    )
    with tempfile.TemporaryDirectory() as temporary:
        path = pathlib.Path(temporary) / "v5-current.npz"
        save_forecast_run(result, path)
        loaded = load_forecast_run(path)
        print(
            "current_artifact_roundtrip",
            "contract=",
            loaded.run.grid_time_contract.spatial_grid_contract,
            "evidence=",
            loaded.run.grid_time_contract.metric_domain_evidence_digest,
        )


if __name__ == "__main__":
    main()
