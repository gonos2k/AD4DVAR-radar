from dataclasses import replace
import torch
from advar.variational import (
    AnalysisConfig,
    initial_control,
    prepare_analysis,
    robust_objective,
    solve_analysis,
    whitened_observation_residual,
)


def main() -> None:
    frames = torch.full((3, 3, 3), 20.0, dtype=torch.float64)
    observations, frozen = prepare_analysis(
        frames,
        analysis_config=AnalysisConfig(observation_common_bias_std_dbz=1.0),
    )
    changed = observations.dbz.clone()
    changed[0, 0, 0] = float("nan")
    malformed = replace(observations, dbz=changed)
    control = initial_control(frozen)
    try:
        residual = whitened_observation_residual(control, malformed, frozen)
        cost = robust_objective(control, malformed, frozen)
    except Exception as error:
        print("malformed observation rejected", type(error).__name__, str(error))
    else:
        print("malformed observation accepted")
        print("residual finite", bool(torch.isfinite(residual).all()))
        print("cost", float(cost.detach()))
        print("residual[0,0,0]", float(residual[0, 0, 0]))
    try:
        result = solve_analysis(malformed, frozen)
    except Exception as error:
        print("solve rejected", type(error).__name__, str(error))
    else:
        print("solve returned", result.reason, "used_fallback", result.used_fallback)


if __name__ == "__main__":
    main()
