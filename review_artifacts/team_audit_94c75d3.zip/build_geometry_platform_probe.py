from __future__ import annotations

import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import types
from unittest import mock

test_spec = importlib.util.spec_from_file_location(
    "deployment_test_helpers",
    Path("tests/test_deployment_bundle.py"),
)
assert test_spec is not None and test_spec.loader is not None
tests = importlib.util.module_from_spec(test_spec)
test_spec.loader.exec_module(tests)
bundle = tests.bundle_module

with tempfile.TemporaryDirectory() as directory:
    root = Path(directory)
    wheel = root / "advar_radar_nowcast-0.93.0-py3-none-any.whl"
    tests._write_test_wheel(wheel, distribution="advar-radar-nowcast", version="0.93.0")
    lock = root / f"runtime-py{sys.version_info.major}{sys.version_info.minor}-linux.lock"
    wheelhouse = root / "wheelhouse"
    wheelhouse.mkdir()
    dependency = wheelhouse / "numpy-2.2.0-py3-none-any.whl"
    tests._write_test_wheel(dependency, distribution="numpy", version="2.2.0")
    lock.write_text(
        f"numpy==2.2.0 \\\n    --hash=sha256:{bundle._sha256(dependency)}\n",
        encoding="utf-8",
    )
    audit = root / "audit.json"
    audit.write_text(
        '{"dependencies":[{"name":"numpy","version":"2.2.0","vulns":[]}]}',
        encoding="utf-8",
    )
    output = root / "bundle"
    key = bundle.Ed25519PrivateKey.from_private_bytes(b"\x31" * 32)
    unsigned = {
        "contract": "advar-import-runtime-tree-v2",
        "runtime_mode": "candidate-smoke",
        "import_root_count": 1,
        "distributions": [
            {"name": "advar-radar-nowcast", "version": "0.93.0"},
            {"name": "numpy", "version": "2.2.0"},
        ],
        "files": [
            {
                "distribution": "numpy",
                "path": "site-0/numpy/__init__.py",
                "size_bytes": 10,
                "sha256": "8" * 64,
            }
        ],
        "omitted_forbidden_files": [],
        "interpreter_closure": {
            "contract": "advar-python-interpreter-closure-v1",
            "bytecode_write_disabled": True,
            "interpreter_closure_digest": bundle._json_digest(
                {
                    "contract": "advar-python-interpreter-closure-v1",
                    "bytecode_write_disabled": True,
                }
            ),
        },
    }
    runtime_tree = unsigned | {"runtime_tree_digest": bundle._json_digest(unsigned)}
    fake_torch = types.SimpleNamespace(
        __version__="2.13.0",
        version=types.SimpleNamespace(cuda=None),
    )
    with (
        mock.patch.dict("sys.modules", {"torch": fake_torch}),
        mock.patch.object(bundle.platform, "system", return_value="Linux"),
        mock.patch.object(bundle.platform, "machine", return_value="aarch64"),
        mock.patch.object(bundle.importlib.metadata, "version", return_value="0.93.0"),
        mock.patch.object(bundle, "_runtime_tree_snapshot", return_value=runtime_tree),
    ):
        bundle.build_bundle(
            wheel=wheel,
            lock=lock,
            audit=audit,
            wheelhouse=wheelhouse,
            output=output,
            source_commit="a" * 40,
            repository="gonos2k/AD4DVAR-radar",
            source_ref="refs/pull/126/merge",
            workflow_sha="b" * 40,
            mode="candidate-smoke",
            signer_id="ci-candidate-smoke",
            signing_key=key,
        )
        manifest = json.loads((output / "manifest.json").read_text(encoding="utf-8"))
        print("built_platform", manifest["platform"])
        try:
            bundle.verify_bundle(
                output,
                trusted_public_key_hex=key.public_key().public_bytes_raw().hex(),
                expected_mode="candidate-smoke",
                expected_repository="gonos2k/ADVAR-radar",
                expected_source_ref="refs/pull/126/merge",
                expected_source_commit="a" * 40,
                expected_workflow_sha="b" * 40,
                expected_signer_id="ci-candidate-smoke",
            )
        except ValueError as error:
            print("verify_error", str(error))
        else:
            print("verify_error", None)
