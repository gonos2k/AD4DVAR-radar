from __future__ import annotations

import inspect
import os
import subprocess
import sys
import tempfile
from pathlib import Path

import advar.ledger as ledger_module
from advar.ledger import EpisodeLedger


def main() -> None:
    with tempfile.TemporaryDirectory(prefix="ledger-3-crash-") as directory:
        root = Path(directory)
        replay_root = root / "scoring_replays"
        replay_root.mkdir(parents=True)
        target = replay_root / ("a" * 64)
        temporary = replay_root / ".orphan-temporary"
        child = r'''
import os
from pathlib import Path
from advar import ledger as ledger_module
root = Path(__import__("sys").argv[1])
temporary = root / ".orphan-temporary"
target = root / ("a" * 64)
temporary.mkdir()
(temporary / "manifest.json").write_text("complete-bytes")
original_rename = Path.rename
def crash_after_publish(source, destination):
    original_rename(source, destination)
    os._exit(0)
Path.rename = crash_after_publish
ledger_module._publish_durable_directory(
    temporary=temporary,
    target=target,
    durable_files=(temporary / "manifest.json",),
    parent=root,
)
'''
        # This child exits at the exact post-rename/pre-SQLite-insert point.
        result = subprocess.run(
            [sys.executable, "-c", child, str(replay_root)],
            check=False,
        )
        if result.returncode != 0:
            raise AssertionError(result.returncode)
        ledger = EpisodeLedger(root)
        with ledger._connect() as connection:
            row_count = connection.execute(
                "SELECT COUNT(*) FROM neural_prior_scoring_replay_bundles"
            ).fetchone()[0]
        source = inspect.getsource(EpisodeLedger.append_neural_prior_scoring_replay_bundle)
        guard = source.index('if target.exists():')
        transaction = source.index('with self._connect() as connection:')
        print({
            "orphan_target_exists_after_crash": target.exists(),
            "ledger_row_count": row_count,
            "target_guard_precedes_sqlite_transaction": guard < transaction,
            "temporary_still_exists": temporary.exists(),
        })


if __name__ == "__main__":
    main()
