from dataclasses import replace
import json
import sys
sys.path.insert(0, "/Users/yhlee/ADVAR/tests")
import test_promotion as fixtures

fixture=fixtures.NeuralPriorPromotionTests("runTest")
evaluations=(fixture.evaluation(1,-0.2),fixture.evaluation(2,-0.3))
template=fixture.policy()
results=[]
for samples in (64,16384):
    policy=replace(template,allow_shadow_small_sample_bootstrap=False,bootstrap_samples=samples,minimum_bootstrap_tail_replicates=20,maximum_exact_sign_clusters=1)
    evidence=fixture.compute_with_policy(evaluations,policy)
    names=[name for name in evidence.__dataclass_fields__ if "reason" in name or "simultaneous" in name]
    row={name:getattr(evidence,name) for name in names}
    row.update(samples=samples,eligible=evidence.eligible,prior_support_brier_increase_upper_bound=evidence.prior_support_brier_increase_upper_bound if hasattr(evidence,"prior_support_brier_increase_upper_bound") else None)
    results.append(row)
print(json.dumps(results,indent=2,default=str))
