from __future__ import annotations

import importlib.util
from decimal import Decimal
from pathlib import Path
import shutil

spec = importlib.util.spec_from_file_location(
    "metric_generator",
    Path(".github/scripts/generate_metric_domain_evidence.py"),
)
assert spec is not None and spec.loader is not None
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

proj = shutil.which("proj") or "proj"
projinfo = shutil.which("projinfo") or "projinfo"
definition, _ = module._epsg_projection_definition(projinfo)
for count in (10_001, 100_001):
    module.COVERAGE_BOUNDARY_SAMPLE_COUNT_PER_EDGE = count
    coverage = module._validated_projected_coverage(
        proj=proj,
        projection_definition=definition,
    )
    print(count, coverage)

# Probe interior points on a 201x201 lattice and report any point outside the
# edge-derived projected rectangle.  This tests the geometric assumption used
# by the inscribed projected bbox construction.
longitudes = module._lattice_values(
    module.MINIMUM_LONGITUDE_DEG, module.MAXIMUM_LONGITUDE_DEG, 201
)
latitudes = module._lattice_values(
    module.MINIMUM_LATITUDE_DEG, module.MAXIMUM_LATITUDE_DEG, 201
)
points = tuple((lon, lat) for lat in latitudes for lon in longitudes)
projected = module._project_points(
    proj=proj,
    projection_definition=definition,
    points=points,
)
coverage = module._validated_projected_coverage(proj=proj, projection_definition=definition)
outside = [
    (point, value)
    for point, value in zip(points, projected, strict=True)
    if not (
        coverage["minimum_easting_m"] <= value[0] <= coverage["maximum_easting_m"]
        and coverage["minimum_northing_m"] <= value[1] <= coverage["maximum_northing_m"]
    )
]
print("geographic_domain_points", len(points), "outside_inscribed_bbox", len(outside))
if outside:
    print("first_outside", outside[:5])

eastings = module._lattice_values(
    Decimal(str(coverage["minimum_easting_m"])),
    Decimal(str(coverage["maximum_easting_m"])),
    201,
)
northings = module._lattice_values(
    Decimal(str(coverage["minimum_northing_m"])),
    Decimal(str(coverage["maximum_northing_m"])),
    201,
)
projected_points = tuple((easting, northing) for northing in northings for easting in eastings)
inverse = module._project_points(
    proj=proj,
    projection_definition=definition,
    points=projected_points,
    inverse=True,
)
outside_domain = [
    (point, value)
    for point, value in zip(projected_points, inverse, strict=True)
    if not (
        float(module.MINIMUM_LONGITUDE_DEG) <= value[0] <= float(module.MAXIMUM_LONGITUDE_DEG)
        and float(module.MINIMUM_LATITUDE_DEG) <= value[1] <= float(module.MAXIMUM_LATITUDE_DEG)
    )
]
print("projected_bbox_points", len(projected_points), "outside_geographic_domain", len(outside_domain))
if outside_domain:
    print("first_outside_domain", outside_domain[:5])
