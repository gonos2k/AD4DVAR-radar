import torch
from dataclasses import replace
import advar.variational as v
import advar.linearization_artifact as la
from advar.physics import RemapCell
from advar._runtime import numerical_runtime_identity_digest
from advar.calibration import algorithm_bundle_digest
frames=torch.full((3,4,4),20.,dtype=torch.float64)
obs,frozen=v.prepare_analysis(frames,nowcast_config=v.NowcastConfig(horizon_minutes=10),analysis_config=v.AnalysisConfig(censored_background_policy='detection_limit'))
control=v.initial_control(frozen)
print('base state',frozen.baseline_state.displacement_yx,frozen.baseline_state.log_growth_per_step,'cells',frozen.analysis_remap_cells)
wrong=replace(frozen,analysis_remap_cells=(frozen.analysis_remap_cells[0],RemapCell(frozen.analysis_remap_cells[1].y-1,frozen.analysis_remap_cells[1].x)))
print('match',v._analysis_remap_cells_match(control,wrong),'frame diff',float((v._analysis_trajectory(control,wrong).frames_linear-v._analysis_trajectory(control,frozen).frames_linear).abs().max()))
def traj(value, fs): return v._analysis_trajectory(value, fs).frames_linear
full=v._analysis_trajectory(control,frozen).frames_linear
wrong_full=v._analysis_trajectory(control,wrong).frames_linear
dyn_jac=lambda fs: torch.func.jacrev(lambda d: traj(torch.cat((control[:-3],d)),fs))(control[-3:])
print('branch_jacobian_difference',float((dyn_jac(frozen)-dyn_jac(wrong)).abs().max()))
st=v._linearization_stationarity(control,obs,wrong)
rob=v._robust_stationarity(control,obs,wrong)
print('st',st,'rob',rob,'weight',v._relative_irls_weight_change(wrong,v.freeze_irls_weights(control,obs,wrong)))
lin=v.AnalysisLinearization(observations=obs,frozen=wrong,residual_norm=st.residual_norm,gradient_norm=st.gradient_norm,field_gradient_rms=st.field_gradient_rms,field_gradient_max=st.field_gradient_max,dynamics_gradient_max=st.dynamics_gradient_max,relative_stationarity=st.relative_stationarity,robust_gradient_norm=rob.gradient_norm,robust_field_gradient_rms=rob.field_gradient_rms,robust_field_gradient_max=rob.field_gradient_max,robust_dynamics_gradient_max=rob.dynamics_gradient_max,robust_relative_stationarity=rob.relative_stationarity,irls_relative_weight_change=v._relative_irls_weight_change(wrong,v.freeze_irls_weights(control,obs,wrong)),polish_iterations=0,feasibility_margins=v.AnalysisFeasibilityMargins(1.,1.,None,1.,None,1.),algorithm_bundle_digest=algorithm_bundle_digest(),numerical_runtime_digest=numerical_runtime_identity_digest(control.device))
lin=v._content_address_linearization(control,replace(lin,forecast_run_digest='a'*64))
state=v._analysis_trajectory(control,wrong)
p=la.P1LinearizationState(control=control,active_field_index=wrong.active_field_index,state=v.RadarState(echo_linear=state.frames_linear[-1],displacement_yx=state.displacement_yx,log_growth_per_step=state.log_growth_per_step),linearization_residual_norm=st.residual_norm,linearization_gradient_norm=st.gradient_norm,linearization_field_gradient_rms=st.field_gradient_rms,linearization_field_gradient_max=st.field_gradient_max,linearization_dynamics_gradient_max=st.dynamics_gradient_max,linearization_relative_stationarity=st.relative_stationarity,robust_gradient_norm=rob.gradient_norm,robust_field_gradient_rms=rob.field_gradient_rms,robust_field_gradient_max=rob.field_gradient_max,robust_dynamics_gradient_max=rob.dynamics_gradient_max,robust_relative_stationarity=rob.relative_stationarity,irls_relative_weight_change=lin.irls_relative_weight_change,linearization_polish_iterations=0,linearization=lin)
try:
 la._validate_loaded_state(p); print('loaded_validator=ACCEPTED')
except Exception as e: print('loaded_validator=',type(e).__name__,str(e))
path='/tmp/advar-team-audit-94c75d3/variational_2_wrong_branch.p1lin'
try:
 la.save_p1_linearization(p,path)
 loaded=la.load_p1_linearization(path)
 print('public_save_load=ACCEPTED','loaded_match',v._analysis_remap_cells_match(loaded.control,loaded.linearization.frozen))
except Exception as e: print('public_save_load=',type(e).__name__,str(e))
