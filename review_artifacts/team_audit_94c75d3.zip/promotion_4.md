# promotion_4 audit

Baseline: `94c75d3323c986b6fb2963336b906acc85384e12`; source was read-only. Assigned range `src/advar/promotion.py:17101-22800` was read in 500-line bounded chunks, with the continuation through `23550` inspected to close the `compute_neural_prior_promotion` caller and its result construction. Relevant caller wiring in `src/advar/ledger.py:13068-13190` and statistical tests in `tests/test_promotion.py` were also inspected.

## Confirmed finding

### Automatic uncertainty UCB is rejected by an unrelated multiplier-bootstrap tail gate

At `src/advar/promotion.py:21055-21140`, `_simultaneous_uncertainty_upper_bounds` selects a random studentized multiplier stream whenever the cluster universe is larger than `policy.maximum_exact_sign_clusters` (lines 21062-21071). In automatic mode (`allow_shadow_small_sample_bootstrap=False`), however, the selected result for every comparison is computed by the deterministic, finite-support `_bounded_event_mean_upper_bound` at lines 21098-21115; the generated multipliers and their critical quantile are not used for the returned bounds. The result is labelled `support_bounded_hybrid` (line 21132), but retains `randomized_multiplier=True` because that flag is derived from the unused underlying `method` (line 21140), and `tail_replicates` still uses `effective_replicates` from the unused multiplier stream (line 21122).

The public promotion path then treats that diagnostic flag as an active method gate at `src/advar/promotion.py:22892-22899`: a low `tail_replicates` appends `insufficient_bootstrap_tail_resolution`, even though the automatic bound did not use bootstrap replicates. With a production-style family size of 16, confidence 0.95, and `bootstrap_samples=1024`, the tail count is `1024 * 0.05 / (2*16) = 1.6`, below the default minimum 20. Increasing only `bootstrap_samples` to 16,384 changes the tail diagnostic to 25.6 but leaves the automatic bounded bound exactly unchanged. Thus the same data and selected inference method can be rejected or accepted solely due to unused multiplier resolution. This is a false negative (over-rejection), not an unsafe candidate promotion.

Small reproducible probe: [`promotion_4_uncertainty_method_probe.py`](/tmp/advar-team-audit-94c75d3/promotion_4_uncertainty_method_probe.py). Output: [`promotion_4_uncertainty_method_probe.out`](/tmp/advar-team-audit-94c75d3/promotion_4_uncertainty_method_probe.out).

Observed output:

```text
{'small': {'bootstrap_samples': 1024, 'method': 'support_bounded_hybrid', 'effective_replicates': 1024, 'randomized_multiplier': True, 'tail_replicates': 1.6000000000000014, 'bound': 1.0}, 'large': {'bootstrap_samples': 16384, 'method': 'support_bounded_hybrid', 'effective_replicates': 16384, 'randomized_multiplier': True, 'tail_replicates': 25.600000000000023, 'bound': 1.0}}
```

The probe uses 20 distinct physical-event cluster IDs and `maximum_exact_sign_clusters=1`, so it reaches the same multiplier-selection branch. The bound is deliberately support-saturated in this minimal input; equality of the returned bound still proves the branch ignores `bootstrap_samples`. A full typed public fixture should verify the resulting rejection reason and eligibility flip; the actual production path reaches this helper unconditionally after constructing uncertainty comparisons, and `ledger.append_neural_prior_promotion` recomputes the same evidence through `compute_neural_prior_promotion`.

## Unconfirmed candidates

- `promotion_sample_size_preflight` accepts caller-supplied metric/issuance cell tuples without checking that every policy-registered key is present. The internal `compute_neural_prior_promotion` caller supplies a complete map, so this is currently a diagnostic helper contract concern and was not classified as a promotion bypass.
- Per-band certification deliberately fails when an optional prior component has no applicable samples (`echo_cases_ok`/`clear_cases_ok`), even with `require_all_registered_regimes_certified=False`. This is conservative rejection and may be intentional; no unsafe promotion was found.

## GREEN preserved

- `_event_fractional_rate_interval` groups repeated case rows by physical-event cluster and averages within each event before applying the bounded interval, preserving equal-event weighting.
- `_bounded_event_mean_upper_bound` validates finite values and an absolute analytic support bound before aggregation; automatic promotion uses this bound for aggregate, uncertainty, and metric-cell means.
- Candidate/parent common metric scoring uses the parent domain as the fixed paired reference, preventing a candidate from hiding withdrawn cells by changing the comparison domain.
- The compute caller validates candidate/parent lineage, scoring artifacts, trust stores, event catalog bindings, and classifier holdout independence before statistical aggregation.

## Commands and results

- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-team-audit-94c75d3/promotion_4_uncertainty_method_probe.py` — passed; output is recorded above.
- `rg`/bounded `sed` inspection covered all assigned source lines and relevant callers/tests. An exploratory two-test pytest process was stopped after it remained queued behind other agents; it is not reported as passed.

## Limitations

The probe directly invokes the statistical helper with its declared inputs and does not fabricate signed manifests or run a full scoring replay. It establishes the selected-method/control-flow inconsistency and the numerical gate flip. A full typed promotion fixture is needed to quantify the final `eligible`/`rejection_reasons` change for a production-sized family.
