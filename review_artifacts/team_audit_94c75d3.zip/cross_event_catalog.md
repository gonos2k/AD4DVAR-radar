# Cross-event catalog independent adjudication

Baseline: `94c75d3323c986b6fb2963336b906acc85384e12`.

This is a read-only follow-up to `promotion_2.md`. I reran the public signed catalog probes and traced the accepted artifacts through the current holdout plan, forecast-run identity, scorer, temporal checks, and cluster aggregation. No repository source or test was changed; no full suite was run.

## Judgement

| Claim | Independent judgement |
| --- | --- |
| Event association depends on serialized event order | **Confirmed production defect.** The public signed result path accepts one permutation and rejects the reverse permutation for the same two tracks. |
| Cases may reuse one uncertainty/state target plan | **Unconfirmed candidate / metadata contract gap, with conditional statistical impact.** Public plan, candidate-manifest, and scoring-input artifacts accept two cases with the same target source/time/bytes. The scorer has no later cross-case target check and clusters by physical event only, but the duplicate-target probe uses different fixture days and would fail the evaluator's per-case target-time check if replayed numerically. A same-time pair with distinct input plans was not fabricated end-to-end. This does not establish that every shared target is invalid, because one field can contain multiple independent precipitation systems and a target may legitimately be shared when the metric is designed to be event-local. If same-time shared targets reach whole-grid scoring across distinct event clusters, the same truth field can be duplicated in outer inference. |
| Distinct physical events can carry the same full-analysis input digest | **Rebutted as a reachable current-run defect.** The catalog constructor accepts the digest-only object, but a valid current holdout run cannot produce it for distinct input plans: the plan requires unique input-plan digests, the fixed-input-context digest includes the input-plan digest, and `ForecastRunContract` recomputes the full digest. The scorer requires the run digest to equal the manifested case digest. A duplicate would require a cryptographic collision or an invalid/forged run. |

## Confirmed: event association is permutation-dependent

`src/advar/promotion.py:8168-8221` sets `earlier = first` for overlapping intervals (`8192-8194`). Overlap does not define an earlier track. `validate_physical_event_catalog_result` then evaluates each pair in the serialized tuple order (`8247-8255`). The graph digest sorts components for canonical hashing, but the association predicate itself is not normalized.

The public probe uses valid `PhysicalEventTrackArtifact`, signed `PhysicalEventCatalogEvidence`, and `PhysicalEventCatalogResult.from_plan`; it does not call a private validator with a forged result. Event A spans 00:05–00:15 at x=0. Event B spans 00:00–00:10 and moves x=0→20,000 m. During the simultaneous overlap, the minimum track distance is 10,000 m, which exceeds the 5,000 m motion buffer; the envelope IoU is 4/40,004 ≈ 0.0001, below the configured IoU threshold. Thus neither existing spatial association condition succeeds. With the one-sided overlap extrapolation, the result is:

```text
association_a_b True
association_b_a False
accepted_ordered_split_result 3aa8cbca804a22f7fe7297d60fb036e0f74f172cf6dc7edc9c66de253bf08871
reverse_order_rejected physical event association graph has split connected components
```

Thus `(event_b, event_a)` is a valid signed two-component catalog while `(event_a, event_b)` is rejected. Promotion uses `PriorHoldoutEvaluation.physical_event_digest` as the outer cluster (`src/advar/promotion.py:20554-20559`), so the adjudicator’s tuple ordering can change the number of independent clusters presented to promotion. The minimum reproducible defect is this two-track geometry; no production catalog is asserted to contain this exact ordering.

## Target-plan reuse: public metadata gap, but not an end-to-end confirmed bypass

The original constructor probe is reproducible through the public types. `NeuralPriorHoldoutPlan.__post_init__` forms sets of the case target-plan digests and retained plan digests (`src/advar/promotion.py:10079-10094`). Two case references to one digest therefore collapse to one set element and pass. It does not require one uncertainty or state target plan per case.

I extended the probe through two additional public artifacts. It replaces case 2's target references and target identity with case 1's, then constructs the normal `NeuralPriorCandidateManifest` and `HoldoutScoringInputArtifact.from_cases`. Both validate successfully:

```text
manifest_duplicate_target_accepted 867a2480bb04862cd7f5f26a39f8e4ab76b7ea3a1e50944c04d18f4fab627487
manifest_target_identities (('6666...6666', '2026-08-09T00:00:00Z', 'c7b8...f57c'), ('6666...6666', '2026-08-09T00:00:00Z', 'c7b8...f57c'))
scoring_input_duplicate_target_accepted ee9250e1aa56b735288935ac4e31186b7d2d4bfcc6dde431487f1e9657b25f29
```

The abbreviated digest display above is only for readability; the complete captured output is in `cross_event_catalog_probe.out`. The public manifest checks holdout case IDs and event membership (`src/advar/promotion.py:11995-12040`) and the scoring-input validator checks ordered case and forecast/evidence digests (`src/advar/promotion.py:17466-17625`), but neither checks cross-case target source identity, valid time, target tensor digest, or target-plan digest.

The actual evaluator does enforce each case’s local lineage and chronology: `PriorHoldoutEvaluation.from_forecasts` matches the target and identity to that case (`src/advar/promotion.py:14037-14070`), requires prior output time to equal the target-plan time (`14127-14143`), and rejects an issue at or after any verification valid time (`src/advar/promotion.py:13600-13615`). Those checks do not compare one case with another. The duplicate-target probe reuses case 1’s target time for fixture case 2, whose feature and issue times are on the following day; the per-case `prior_output_valid_time == target_plan.target_valid_time` guard would reject that numerical replay. The plan contract nevertheless permits different input plans and the same issue/target time, and it has no cross-case target identity check; that same-time construction was not fabricated end-to-end here. If it reaches evaluation, the uncertainty and state scores consume the target tensors over the scoring grid (`src/advar/promotion.py:14168-14245`), with no physical-event mask. Promotion records only `_physical_event_cluster(evaluation)` (`src/advar/promotion.py:21407-21432`) and `_cluster_means` groups only by that event digest (`src/advar/promotion.py:20992-21010`).

This is why the finding is narrower than “same target plan is always pseudoreplication.” A single analysis field can contain separate precipitation systems, and event cataloging is deliberately allowed to split them. A shared truth field can be legitimate if each evaluation restricts metrics to its event. The current uncertainty scoring path uses the full target grid, however. If a valid same-time pair with distinct physical-event clusters reuses the same source identity and valid time, the same target bytes can be scored once per event and the cluster bootstrap treats those rows as separate clusters. The README also states that reusing a holdout verification target with the same source identity and valid time is rejected (`README.md:2181`), while the current cross-case plan/manifest/scoring-input path has no such check. The probe demonstrates metadata acceptance; the statistical inflation remains conditional and was not numerically replayed end-to-end.

## Duplicate full-analysis input digest: catalog acceptance does not reach valid scoring

The catalog-only probe creates two signed event records with the same `member_full_analysis_input_digest`; `PhysicalEventCatalogResult.from_plan` accepts them:

```text
accepted_duplicate_full_input_digest a4f25b051430f6afaa70a236a1175c879cf714e83603d3541de1d7cab9536c31
event_member_input_digests ('4444...4444', '4444...4444')
```

This is a real observation about the catalog contract: `validate_physical_event_catalog_result` checks each case-to-event mapping (`src/advar/promotion.py:8292-8315`) but not global uniqueness of member full-input digests. It is not sufficient evidence of a scorer bypass.

For current valid forecast runs, `NeuralPriorHoldoutPlan.__post_init__` requires distinct case input-plan digests (`src/advar/promotion.py:9975-9982`). `_forecast_fixed_input_context_digest` includes `input_plan_digest` (`src/advar/nowcast.py:5636-5682`), and `_forecast_full_analysis_input_digest` hashes that fixed context with the input frames (`src/advar/nowcast.py:5578-5598`). `ForecastRunContract.validate_integrity` recomputes both (`src/advar/nowcast.py:5487-5495`), while `PriorHoldoutEvaluation.from_forecasts` requires each candidate and parent run full digest and input-plan resolution to equal the manifested case (`src/advar/promotion.py:13730-13905`). Therefore two distinct current holdout input plans cannot legitimately have the same full-analysis digest absent a SHA-256 collision. The fact that the catalog accepts a repeated digest is harmless metadata permissiveness unless a caller supplies an invalid or forged run, which the public scorer rejects.

The fact that one analysis field may contain multiple independent systems does not change this conclusion: event identity and full analysis identity are different contracts. Multiple event rows can be valid members of one field, but distinct holdout cases still require distinct input plans and therefore distinct current full-analysis identities.

## Commands and limitations

The runnable follow-up is `/tmp/advar-team-audit-94c75d3/cross_event_catalog_probe.sh`; captured output is `/tmp/advar-team-audit-94c75d3/cross_event_catalog_probe.out`. Every Python invocation used `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I`. The synthetic values are deliberately minimal, signed public artifacts; they do not claim a live production catalog has duplicate targets or duplicate full-input digests. No full baseline or promotion suite was run. The duplicate-target probe reaches the public manifest and scoring-input artifacts; its cross-day target time is intentionally not presented as valid numerical scorer input. A same-time two-case `from_forecasts` fixture was not fabricated, so the conditional whole-grid inflation statement is derived from the unmodified scorer source and cluster aggregation path rather than an end-to-end duplicate-target run.
