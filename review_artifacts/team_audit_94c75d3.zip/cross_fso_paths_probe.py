import sys
from types import SimpleNamespace
import runpy
import torch

sys.path.insert(0, "/Users/yhlee/ADVAR/tests")
ns = runpy.run_path("/tmp/advar-team-audit-94c75d3/sensitivity_2_probe.py")
forecast = ns["forecast"]
analysis = ns["analysis"]
bundle = ns["bundle"]
from advar.sensitivity import (
    SensitivityConfig,
    ObservationRemovalConfig,
    VariationalObservationPerturbation,
    compute_variational_fsoi,
    validate_variational_fsoi,
    compute_variational_observation_removal_impact,
    validate_observation_removal_impact,
    _resolve_learning_step,
)

cfg = SensitivityConfig(
    metric_names=("log_echo_mse",),
    full_map_lead_minutes=(10,),
    require_verification_lineage=True,
)
linearization = analysis.linearization
assert linearization is not None
index = tuple(
    int(value)
    for value in torch.nonzero(
        linearization.observations.detected_mask,
        as_tuple=False,
    )[0]
)
delta = torch.zeros_like(linearization.observations.dbz)
delta[index] = 0.01
perturbation = VariationalObservationPerturbation.from_radar_dbz_delta(
    delta,
    linearization,
)
fsoi = compute_variational_fsoi(
    forecast,
    analysis,
    bundle,
    perturbation,
    sensitivity_config=cfg,
)
validate_variational_fsoi(fsoi)
print(
    "fsoi_public",
    {
        "fso_domain_sum": float(fsoi.fso.metric_domain_weight_sum[0]),
        "fso_score": float(fsoi.fso.forecast_scores[0, 0]),
        "impact_sum": float(fsoi.observation.total.sum_by_time.sum()),
        "bundle_weight_sum": float(bundle.fso_metric_weight.sum()),
    },
)

removal_mask = torch.zeros_like(linearization.observations.valid_mask)
removal_index = torch.nonzero(
    linearization.observations.valid_mask,
    as_tuple=False,
)[0]
removal_mask[tuple(int(value) for value in removal_index)] = True
removal = compute_variational_observation_removal_impact(
    forecast,
    analysis,
    bundle,
    removal_mask,
    sensitivity_config=cfg,
    removal_config=ObservationRemovalConfig(
        maximum_removed_fraction=1.0,
        maximum_removed_area_km2=None,
    ),
)
validate_observation_removal_impact(removal)
print(
    "removal_public",
    {
        "nominal_score": float(removal.nominal_scores[0, 0]),
        "removed_score": float(removal.removed_scores[0, 0]),
        "metric_change": float(removal.metric_change[0, 0]),
        "available": bool(removal.metric_available[0, 0]),
    },
)

# The learning helper receives a policy-like object only to exercise the same
# production _resolve_learning_step objective; no module function is patched.
policy = SimpleNamespace(sensitivity_config=cfg)
learning_step = _resolve_learning_step(
    forecast,
    analysis,
    bundle,
    fsoi,
    policy,
    scale=1.0,
    metric_domain_contract="frozen_metric_domain",
    neural_prior_runner=None,
    neural_prior_application=None,
)
print(
    "learning_step_private",
    {
        "fso_domain_sum": float(fsoi.fso.metric_domain_weight_sum[0]),
        "bundle_weight_sum": float(bundle.fso_metric_weight.sum()),
        "metric_change": float(learning_step.metric_change[0, 0]),
        "analysis_converged": learning_step.analysis_converged,
        "active_branch_valid": learning_step.active_branch_valid,
    },
)
