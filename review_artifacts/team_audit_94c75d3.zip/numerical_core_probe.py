import json
import math
import tempfile
from pathlib import Path

import torch

from advar.diagnostics import audit_transport, validate_physical_echo
from advar.ensemble_sensitivity import (
    EnsembleFSOStatistics,
    PrecisionWeightedInnovationEvidence,
    compute_ensemble_fso,
)
from advar.matrix_free import (
    gauss_newton_hvp,
    gauss_newton_value_and_gradient,
    hvp,
    jvp,
    pcg,
    vjp,
)
from advar.metrics import mae, rmse
from advar.physics import (
    RemapCell,
    dbz_to_echo,
    echo_to_dbz,
    remap,
    remap_core,
    shift_zero,
)
from advar.range_geometry import (
    RangeGeometryContract,
    RangePartitionEvidence,
    resolve_range_geometry,
    restrict_range_partition_domain,
)
from advar._digest import tensor_digest


def check_close(a, b, **kw):
    torch.testing.assert_close(a, b, **kw)


out = {}
torch.manual_seed(123)

# A hand-built branch oracle for zero-padded bilinear transport.
echo = torch.arange(20, dtype=torch.float64).reshape(4, 5) + 1.0
disp = torch.tensor([1.25, -0.4], dtype=torch.float64)
cell = RemapCell(1, -1)
actual = remap_core(echo, disp, cell)
fy, fx = disp - torch.tensor([cell.y, cell.x], dtype=disp.dtype)
oracle = torch.zeros_like(echo)
for dy, dx, w in (
    (cell.y, cell.x, (1-fy)*(1-fx)),
    (cell.y+1, cell.x, fy*(1-fx)),
    (cell.y, cell.x+1, (1-fy)*fx),
    (cell.y+1, cell.x+1, fy*fx),
):
    for y in range(echo.shape[0]):
        for x in range(echo.shape[1]):
            sy, sx = y-dy, x-dx
            if 0 <= sy < echo.shape[0] and 0 <= sx < echo.shape[1]:
                oracle[y, x] += w * echo[sy, sx]
check_close(actual, oracle, rtol=0, atol=0)
out["remap_oracle_max_abs"] = float((actual-oracle).abs().max())
out["remap_mass_before_after"] = [float(echo.sum()), float(actual.sum())]

# A direct branch-wise loss oracle for transport budget.
audit = audit_transport(echo, disp, cell=cell, moved=actual)
out["transport_audit"] = audit.__dict__
assert audit.echo_budget_error == 0.0

# dBZ/linear inverse and first derivative, including the floor point.
dbz = torch.tensor([-10.0, 0.0, 5.0, 40.0], dtype=torch.float64, requires_grad=True)
linear = dbz_to_echo(dbz, min_dbz=-10.0, max_dbz=50.0)
back = echo_to_dbz(linear, min_dbz=-10.0, max_dbz=50.0)
check_close(back, dbz, rtol=2e-14, atol=2e-14)
transform_grad = torch.autograd.grad(linear.sum(), dbz)[0]
assert bool(torch.isfinite(transform_grad).all())
out["transform_roundtrip_max_abs"] = float((back.detach()-dbz.detach()).abs().max())
out["transform_floor"] = float(dbz_to_echo(torch.tensor([-10.0]), min_dbz=-10.0))

# Homogeneity of continuous metrics under common positive scaling.
metric_x = torch.tensor([3.0, -4.0, 2.0], dtype=torch.float64)
metric_y = torch.tensor([1.0, -1.0, 0.0], dtype=torch.float64)
metric_scale_gaps = []
for scale in (1e-20, 1e-10, 1.0, 1e10, 1e20):
    metric_scale_gaps.append({
        "scale": scale,
        "mae_gap": float((mae(scale*metric_x, scale*metric_y) / scale - mae(metric_x, metric_y)).abs()),
        "rmse_gap": float((rmse(scale*metric_x, scale*metric_y) / scale - rmse(metric_x, metric_y)).abs()),
    })
out["metric_scale_gaps"] = metric_scale_gaps

# shift_zero matches an explicit index oracle and preserves a differentiable edge.
x = torch.randn(4, 5, dtype=torch.float64, requires_grad=True)
shift = shift_zero(x, -3, 2)
expected = torch.zeros_like(x)
for y in range(4):
    for z in range(5):
        sy, sx = y+3, z-2
        if 0 <= sy < 4 and 0 <= sx < 5:
            expected[y, z] = x[sy, sx]
check_close(shift, expected, rtol=0, atol=0)
shift.sum().backward()
out["shift_grad_finite"] = bool(torch.isfinite(x.grad).all())

# Matrix-free AD identities and GN oracle.
matrix = torch.tensor([[2.0, -1.0], [0.5, 3.0], [-2.0, 1.0]], dtype=torch.float64)
point = torch.tensor([0.2, -0.4], dtype=torch.float64)
direction = torch.tensor([0.3, 0.7], dtype=torch.float64)
cotangent = torch.tensor([-0.6, 0.2, 0.9], dtype=torch.float64)
fn = lambda v: torch.sin(matrix @ v)
_, j = jvp(fn, point, direction)
_, v = vjp(fn, point, cotangent)
out["jvp_vjp_dot_gap"] = float((j @ cotangent - direction @ v).abs())
assert out["jvp_vjp_dot_gap"] < 1e-12
residual_fn = lambda v: matrix @ v - torch.tensor([1.0, -2.0, 0.5], dtype=v.dtype)
value, gradient = gauss_newton_value_and_gradient(residual_fn, point)
r = residual_fn(point)
check_close(value, 0.5 * (r @ r))
check_close(gradient, matrix.T @ r)
check_close(gauss_newton_hvp(residual_fn, point, direction, damping=0.2), matrix.T @ matrix @ direction + 0.2*direction)

# PCG direct oracle under large and tiny common scalings.
A = torch.tensor([[4.0, 1.0], [1.0, 3.0]], dtype=torch.float64)
b = torch.tensor([1.0, -2.0], dtype=torch.float64)
pcg_rows = []
for scale in (1e-300, 1.0, 1e300):
    rhs = b * scale
    ans = pcg(lambda v: A @ v, rhs, rtol=1e-12)
    truth = torch.linalg.solve(A, rhs)
    check_close(ans.solution, truth, rtol=1e-11, atol=0.0)
    pcg_rows.append({"scale": scale, "converged": ans.converged, "relative_residual": ans.relative_residual})
out["pcg_scales"] = pcg_rows

# EFSO direct formula and delete-one oracle.
stats = EnsembleFSOStatistics.from_diagonal_r(
    innovation=torch.tensor([2.0, -1.0], dtype=torch.float64),
    inverse_observation_variance=torch.tensor([0.25, 1.0], dtype=torch.float64),
    analysis_observation_perturbations=torch.tensor([[1., 0.], [-.5, 1.], [-.5, -1.]], dtype=torch.float64),
    forecast_error_projection_by_member=torch.tensor([[[-2.]], [[1.]], [[1.]]], dtype=torch.float64),
    lead_minutes=(60,), metric_names=("m",), verification_reference_digest="3"*64,
    observation_error_model_digest="4"*64, observation_ids=("o0", "o1"), ensemble_member_ids=("m0", "m1", "m2"),
)
efso = compute_ensemble_fso(stats)
out["efso_impact"] = efso.observation_impact.detach().tolist()
leave = []
for omitted in range(3):
    keep = torch.arange(3) != omitted
    a = stats.analysis_observation_perturbations[keep]
    f = stats.forecast_error_projection_by_member[keep]
    a = a-a.mean(0)
    f = f-f.mean(0)
    leave.append(torch.einsum("ko,klm,o->lm", a, f, stats.precision_evidence.precision_weighted_innovation)/(3-2))
leave = torch.stack(leave)
expected_jk = torch.sqrt(2/3 * ((leave-leave.mean(0))**2).sum(0))
check_close(efso.total_impact_jackknife_std, expected_jk, rtol=0, atol=0)

# Range geometry tiny partition oracle and duplicate-label malformed evidence probe.
digest = "a"*64
gx = torch.tensor([[0.0, 3.0, 5.0]], dtype=torch.float64)
gy = torch.zeros_like(gx)
contract = RangeGeometryContract(
    radar_site_digest=digest, radar_site_location_digest="b"*64,
    grid_contract_digest="c"*64, radar_x_m=0.0, radar_y_m=0.0,
    range_regime_labels=("near", "far"), radial_distance_edges_m=(0.0, 3.0, 5.0),
    horizontal_range_rule_digest="d"*64, grid_x_m_digest=tensor_digest(gx), grid_y_m_digest=tensor_digest(gy),
)
partition = resolve_range_geometry(contract, grid_x_m=gx, grid_y_m=gy)
assert torch.equal(torch.stack(partition.masks).sum(0), partition.valid_range_domain_mask.to(torch.int64))
out["range_masks"] = [m.tolist() for m in partition.masks]
malformed = RangePartitionEvidence(
    range_geometry_contract_digest=contract.contract_digest,
    grid_contract_digest=contract.grid_contract_digest,
    range_regime_labels=("same", "same"),
    masks=partition.masks,
    valid_range_domain_mask=partition.valid_range_domain_mask,
    range_band_mask_digests=partition.range_band_mask_digests,
    valid_range_domain_mask_digest=partition.valid_range_domain_mask_digest,
    active_range_regimes=("same", "same"),
)
out["duplicate_label_evidence_constructed"] = True
malformed.validate_integrity()
out["duplicate_label_mask_shape"] = list(malformed.mask("same").shape)
restricted_malformed = restrict_range_partition_domain(
    malformed, valid_range_domain_mask=partition.valid_range_domain_mask
)
restricted_malformed.validate_integrity()
out["duplicate_label_restriction"] = True

# Metadata contract probe: diagonal-R evidence currently accepts non-string IDs.
integer_id_evidence = PrecisionWeightedInnovationEvidence.from_diagonal_r(
    innovation=torch.ones(2), inverse_observation_variance=torch.ones(2),
    observation_error_model_digest="e"*64, observation_ids=(1, 2),
)
out["integer_observation_ids_accepted"] = list(integer_id_evidence.observation_ids)
bad_stats = EnsembleFSOStatistics.from_diagonal_r(
    innovation=torch.ones(2), inverse_observation_variance=torch.ones(2),
    analysis_observation_perturbations=torch.tensor([[-1., 0.], [0., 0.], [1., 0.]]),
    forecast_error_projection_by_member=torch.tensor([[[-1.]], [[0.]], [[1.]]]),
    lead_minutes=(60,), metric_names=("m",), verification_reference_digest="f"*64,
    observation_error_model_digest="e"*64, observation_ids=(1, 2),
    ensemble_member_ids=("m0", "m1", "m2"),
)
out["integer_observation_ids_stats_accepted"] = True

# Positivity gate keeps tiny roundoff negatives but rejects substantive negatives.
small = torch.tensor([[ -1e-9, 1.0]], dtype=torch.float64)
try:
    validate_physical_echo(small, name="small")
    out["tiny_negative"] = "accepted"
except Exception as e:
    out["tiny_negative"] = type(e).__name__
try:
    validate_physical_echo(torch.tensor([[-1e-3, 1.0]], dtype=torch.float64), name="large")
    out["large_negative"] = "accepted"
except Exception as e:
    out["large_negative"] = type(e).__name__

print(json.dumps(out, sort_keys=True, default=str))
