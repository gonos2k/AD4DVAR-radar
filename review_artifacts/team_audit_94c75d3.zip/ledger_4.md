# ledger_4 RED audit

Baseline: `94c75d3323c986b6fb2963336b906acc85384e12`  
Scope read: all assigned lines `src/advar/ledger.py:16801-22304`, in contiguous 450–550 line chunks. No repository source or tests were changed.

## Confirmed findings

### 1. Unsupported metric tile impacts are accepted and persisted as finite values

At `src/advar/ledger.py:22153-22163`, `_validate_m0_snapshot` requires the whole-field `direct.impact[~available]` entries to be NaN and checks the tile sum only for `available` entries. It never requires `direct.tile_impact[~available]` to be NaN. The producer explicitly writes both whole-field and tile impact entries to NaN when a metric has no support (`src/advar/sensitivity.py:12648-12665`), so the durable contract should preserve that shared missingness invariant. The analogous tile-norm check already enforces it at `ledger.py:22054-22055`.

The runnable public-path probe `ledger_4_tile_probe.py` starts from the real `_computed_snapshot()` fixture, marks one metric unavailable, leaves its whole-field impact NaN, and sets its tile impact to `17.0`. `EpisodeLedger.append()` followed by `verify()` and `load()` accepts the episode and returns `[[17.0]]` for the unavailable tile. This is a malformed typed caller snapshot rather than corrupted SQLite/storage. The impact boundary is a persisted unsupported-metric diagnostic that can be consumed as if it were valid; current code has no direct reader beyond the ledger, so downstream use is the realistic boundary. Expected behavior is to reject or retain all-NaN tile impacts for unavailable metrics. This does not justify rejecting valid all-NaN evidence on available zero-gradient metrics.

### 2. Whitened tile norm is not checked against the direct map and observation standard deviation

The producer computes the whitened diagnostic as the tile L2 norm of `direct_gradient * observation_std` (`src/advar/sensitivity.py:12704-12709`, `12745-12749`). The ledger only checks shape, floating type, positivity/finiteness of `observation_std_dbz`, and finite/NaN availability of the stored whitened norm (`src/advar/ledger.py:22056-22082`). It does not recompute the value from the persisted direct map and standard deviation.

The same probe makes a selected direct map have one value `3.0`, updates its stored direct norm and tile norm consistently, supplies an all-ones standard-deviation frame, and sets the corresponding whitened tile norm to `999.0`. Append, verify, and load accept and preserve `999.0`; the mathematical value is `3.0`. This is public append with a malformed typed caller snapshot, not corrupted storage. The current repository has no production consumer of this diagnostic beyond persistence/tests, so the immediate impact is an incorrect uncertainty-normalized diagnostic for any future reader or audit. This candidate is lower confidence/severity than the tile-impact missingness issue because no current operational reader was found.

### 3. Zero-area spatial snapshots pass the M0 boundary through vacuous tensor checks

`_validate_m0_snapshot` checks that `latest_sensitivity_mask` is two-dimensional, then derives `height,width` directly from it (`src/advar/ledger.py:21853-21858`); it never requires both dimensions to be positive. With zero dimensions, the shape checks pass and all `torch.all(...)` finite/NaN conditions and selected-map loops are vacuously true. A runnable probe constructs a zero-area snapshot with no available metrics and no impact tensors from the real fixture. `EpisodeLedger.append()`, `verify()`, and `load()` all accept it. The normal producer rejects an empty latest observation before creating a snapshot, so this is a malformed typed-caller path rather than a normal producer regression. Expected M0 episodes should have a non-empty radar grid; otherwise an unusable episode is indexed and searchable. Severity is lower than a reachable producer failure.

## GREEN preserved

- `tests/test_ledger.py -k 'append_load_verify_and_reopen_computed_snapshot or unavailable_optional_arrays_are_omitted'`: 2 passed, 48 deselected.
- `tests/test_review_ledger.py -k 'evidence or trust_components'`: 5 passed, 1 deselected, 11 subtests passed. This preserves unavailable all-NaN evidence, including the valid available zero-gradient/all-NaN case, while finite mixed channels and out-of-range/Boolean trust are rejected.

## Commands and limitations

The probe command was run with `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1` and `/Users/yhlee/ADVAR/.venv/bin/python -I`; its exact output is in `ledger_4_tile_probe.stdout`. The probe is runnable and saved alongside this report. A focused pre-existing test, `tests/test_ledger.py -k 'malformed_or_contradictory_snapshot or append_load_verify_and_reopen_computed_snapshot or unavailable_optional_arrays_are_omitted'`, stopped after one pass because its expected `channels do not close` regex no longer matches the current earlier availability error (`metric evidence channels must share availability`); this is a stale expectation/ordering limitation, not counted as a new source finding. No full baseline or promotion/sensitivity/ledger suite was run.
