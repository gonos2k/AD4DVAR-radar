# test_nowcast_1 audit (GREEN)

- Baseline: `94c75d3323c986b6fb2963336b906acc85384e12`
- Scope: all assigned lines `tests/test_nowcast.py:1-6352`, with corresponding P0 nowcast, physics/remap, diagnostics, grid/time and metric-domain code read as bounded ranges.
- Confirmed findings: none.

The nowcast tests and implementation remain consistent for the audited meteorological and contract paths. The direct analytic Gaussian oracle is independent of the phase-correlation estimate; growth is computed from dBZ-to-linear echo integrals over aligned, fractional support and normalizes long pairs by their actual span. Boundary outflow is handled as zero inflow and audited by a disjoint boundary budget. Missing and QC-invalid values are canonicalized to the dBZ floor while masks remain separate, so missing cells are not published as observed clear; stale background requires explicit age and current-time alignment. Source support is advected with echo and normalized, previous support cannot re-enter after boundary outflow, and direct latest observations take precedence over background contribution. Observation tendency is selected ahead of background tendency; isolated background fallback carries explicit age/provenance. Forecast leads use one direct remap per lead and carry evidence channels through the same remap cell.

Unit/time and numerical contracts were checked against the implementation: `(row,column)` displacement maps through the affine to projected `(x,y)` with seconds per configured interval; physical speed and pair disagreement use the directed metric authority and fail closed on uncertain geodetic annuli; valid-time intervals and latest background age are validated; dBZ/linear conversion round trips; remap preserves nonnegativity and closes mass/outflow budgets; phase peak subpixel gradients remain connected to inputs. No unsupported MPS execution was claimed (the MPS-specific test is skipped in this environment).

## Commands and results

With `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1` and `/Users/yhlee/ADVAR/.venv/bin/python`:

1. Focused motion/missing/background/units tests: `13 passed, 154 deselected, 5 subtests passed`.
2. Focused QC/support/growth/forecast/physical-time tests: `16 passed, 151 deselected, 4 subtests passed`.
3. Focused issuance/metric-domain/affine contract tests: `10 passed, 157 deselected, 38 subtests passed`.
4. Deterministic runnable probe: `/tmp/advar-team-audit-94c75d3/test_nowcast_1_probe.py`; output in `/tmp/advar-team-audit-94c75d3/test_nowcast_1_probe.out`:
   - `meteorological_motion 2`
   - `motion [0.2216444015788582, -0.07908308048363927]`
   - `stale_background STALE_BACKGROUND 10.0`
   - `finite_mask_equal True`

No repository source or test files were modified. Existing untracked `.DS_Store` was left untouched.

## Limitations

This was a bounded read-only audit; no full baseline suite was run. MPS is unavailable, so the conditional MPS end-to-end test was not executed. No external geodetic assertion was introduced; conclusions above are from local implementation/tests and deterministic probes.
