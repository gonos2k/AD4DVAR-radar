import torch
from dataclasses import replace
import advar.variational as v
from advar.physics import RemapCell
for vals in ((20.,19.,18.),(20.,21.,22.)):
 frames=torch.stack([torch.full((8,8),q,dtype=torch.float64) for q in vals])
 q=torch.zeros_like(frames); q[0,1:-1,1:-1]=1; q[1:,2:-2,2:-2]=1
 obs,frozen=v.prepare_analysis(frames,quality_weight=q,nowcast_config=v.NowcastConfig(horizon_minutes=10),analysis_config=v.AnalysisConfig(censored_background_policy='detection_limit',maximum_unresolved_amplitude_fraction=1.0,maximum_outer_iterations=8,maximum_pcg_iterations=100,pcg_relative_tolerance=1e-8))
 b=replace(frozen.baseline_state,displacement_yx=torch.zeros(2,dtype=torch.float64),log_growth_per_step=torch.zeros((),dtype=torch.float64))
 frozen=replace(frozen,baseline_state=b,analysis_remap_cells=(RemapCell(0,0),RemapCell(0,0)))
 r=v.solve_analysis(obs,frozen)
 print('vals',vals,'fallback/converged',r.used_fallback,r.converged,r.reason,'lin',r.linearization is not None,'control dyn',r.control[-3:])
 if r.linearization is None: continue
 lin=r.linearization
 wrong=replace(lin.frozen,analysis_remap_cells=(lin.frozen.analysis_remap_cells[0],RemapCell(-1,lin.frozen.analysis_remap_cells[1].x)))
 wl=v._content_address_linearization(r.control,replace(lin,frozen=wrong))
 try:
  v.validate_analysis_linearization_content(r.control,wl); print('  content ACCEPT wrong cells',wrong.analysis_remap_cells,'match',v._analysis_remap_cells_match(r.control,wrong))
 except Exception as e:print('  content reject',type(e).__name__,e)
 tr=v._analysis_trajectory(r.control,wrong); orig=v._analysis_trajectory(r.control,lin.frozen)
 print('  output diff',float((tr.frames_linear-orig.frames_linear).abs().max()))
 print('  st wrong',v._linearization_stationarity(r.control,obs,wrong))
