# runtime_contracts audit

Baseline: `94c75d3323c986b6fb2963336b906acc85384e12`  
Environment: `/Users/yhlee/ADVAR/.venv/bin/python` 3.12.13, PyTorch 2.13.0; focused probes used `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1`.

## Confirmed finding

`src/advar/linearization_artifact.py:417` writes `numerical_runtime_identity_digest()` without an execution device into every current P1 artifact. The normal producer stores a device-bound runtime digest in the embedded `AnalysisLinearization` at `src/advar/variational.py:7256-7258`, using `control.device`. `_runtime._execution_device_identity(None)` deliberately reports `{"type": None, "index": None, "model": None}`, so the top-level artifact field and the state field differ even on CPU. The focused probe produced different digests for `None` and `"cpu"` (`a4ac6a47…` versus `b2592203…`).

This is reachable through the public `save_p1_linearization()` path and occurs for ordinary CPU analyses. `load_p1_linearization()` checks the top-level field against another no-device digest at lines 781-785 but never compares it with the decoded state’s device-bound digest; `_validate_loaded_state()` later validates the embedded state against its mapped control device. Thus the artifact can load on its matching device while carrying a contradictory top-level runtime identity. The practical boundary is provenance/replay metadata inconsistency; current load validation still catches a cross-device state through the embedded digest. A minimal repair would bind the top-level field to `state.control.device`, or explicitly rename/document it as a process-level identity and validate both identities independently.

## Unconfirmed candidates / bounded findings

- `src/advar/_input_derivation.py:104-105` calls `sorted(raw_receipts)` before checking that every item is a string. A canonical payload with `[1, "a" * 64]` is rejected as `TypeError` (`'<' not supported...`) instead of the module’s normal `ValueError` contract. This is reachable from malformed external `ForecastRunContract.from_inputs()` provenance, but it still fails closed and is a robustness/exception-type issue rather than acceptance.
- `src/advar/_input_derivation.py:161-169` does not enforce ordering or uniqueness of `background_valid_times`/`background_input_identity_digests`; the signed `AnalysisInputDerivationArtifact` constructor in `promotion.py:2420-2483` likewise accepts duplicate/out-of-order background times when called directly. Current run validation compares the tuple to `RadarGridTimeContract.background_valid_times`, so the supported forecast path rejects a mismatch. Direct typed artifact construction remains a private/unsupported boundary candidate.
- `src/advar/action_contracts.py:47-54` validates mask shape/dtype but not canonicalization bounds. Direct `canonicalize_action_frames()` with `minimum > maximum` or NaN bounds returns a tensor or NaNs. All inspected callers obtain bounds from `NowcastConfig`, whose constructor validates finite ordered limits; no supported caller bypass was shown.
- `src/advar/_runtime.py:100-137` reports an unavailable requested backend as if it were the requested device (`numerical_runtime_identity("cuda")` on this CPU process returns `execution_device.type == "cuda"` while `torch.cuda.is_available()` is false). Supported producers pass an actual tensor device, so this is an unsupported/private helper input unless callers treat the helper as a general validator.

## GREEN preserved

The assigned source and tests were read in full. `tests/test_runtime.py`, `tests/test_contract_registry.py`, and `tests/test_runtime_closure.py` pass: 12 tests plus 3 subtests. Runtime manifest compatibility/exact separation works for patched device models and matmul precision; contract registry defaults and README rendering agree; runtime closure rejects symlinks, ambient import roots, shadow files, writable deployable ancestry, and bytecode writes. `learned_radar_input_features()` preserves frame dtype/device, requires finite positive observation std and canonical invalid cells, and stacks the five declared channels. `canonicalize_action_frames()` maps nonfinite/masked cells to fill and its unused branch has finite zero gradients in the focused NaN/Inf probe. Artifact preflight enforces exact NPZ member sets and expanded-byte limits before array allocation.

## Commands and limitations

- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I -m pytest -q tests/test_runtime.py tests/test_contract_registry.py tests/test_runtime_closure.py` → `12 passed, 3 subtests passed in 2.75s`.
- `/tmp/advar-team-audit-94c75d3/runtime_contracts_probe.py` exercises no-device versus CPU runtime digests, a valid v4 lineage payload, and the mixed-type list exception. Output is in `runtime_contracts_probe.stdout.txt`.
- A real `snapshot_current_runtime(runtime_mode="candidate-smoke")` was attempted once; this checkout is editable and is correctly rejected at `site-0/__editable__.advar_radar_nowcast-0.114.0.pth`. No deployment command or broad suite was run. No repository source or test files were changed.
