import torch
from torch import nn

from advar.nowcast import ForecastRunContract, NowcastConfig
from advar.variational import (
    AnalysisConfig,
    NeuralPriorInferenceRunner,
    NeuralPriorProbabilityContract,
    NeuralPriorStateContract,
    neural_prior_state_censor_policy_digest,
    prepare_analysis,
    variational_nowcast,
)


class ConstantPrior(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.register_buffer("anchor", torch.tensor(0.0, dtype=torch.float64))

    def forward(self, value: torch.Tensor) -> torch.Tensor:
        return torch.full_like(value, 10.0) + self.anchor


def main() -> None:
    dtype = torch.float64
    frames_a = torch.full((3, 4, 4), -10.0, dtype=dtype)
    frames_b = torch.full((3, 4, 4), 20.0, dtype=dtype)
    state = NeuralPriorStateContract(
        state_product_digest="a" * 64,
        state_qc_pipeline_digest="b" * 64,
        state_mask_policy_digest="c" * 64,
        state_censor_policy_digest=neural_prior_state_censor_policy_digest(
            detection_limit_dbz=5.0,
            censor_temperature_dbz=1.0,
            censored_background_policy="floor",
            minimum_dbz=-10.0,
            maximum_dbz=70.0,
        ),
        support_threshold_dbz=5.0,
        minimum_state_dbz=-10.0,
        maximum_state_dbz=70.0,
        minimum_state_std_dbz=0.1,
        maximum_state_std_dbz=20.0,
    )
    probability = NeuralPriorProbabilityContract(
        support_threshold_dbz=5.0,
        support_product_digest="a" * 64,
        qc_pipeline_digest="b" * 64,
        reflectivity_resolution_dbz=0.5,
        quantization_origin_dbz=-10.0,
    )
    runner = NeuralPriorInferenceRunner(
        ConstantPrior().eval(),
        lambda value: value[0],
        example_frames=frames_a,
        state_contract=state,
        probability_contract=probability,
        model_contract_digest="d" * 64,
        feature_schema_digest="e" * 64,
        training_manifest_digest="f" * 64,
        dependency="exogenous",
        allow_constant_uncertainty=True,
    )
    run_a = ForecastRunContract.from_inputs(
        NowcastConfig(), frames_a, torch.ones_like(frames_a, dtype=torch.bool), None
    )
    application = runner.infer(frames_a, input_run=run_a, role="candidate")
    print("application input digest", application.inference_evidence.input_frames_digest)
    print("frames A digest", run_a.input_frames_digest)
    print("frames B digest", __import__("advar._digest", fromlist=["tensor_digest"]).tensor_digest(frames_b))
    try:
        observations, frozen = prepare_analysis(frames_b, neural_prior=application)
    except Exception as error:
        print("prepare_analysis(B, prior-from-A): rejected", type(error).__name__, str(error))
    else:
        print("prepare_analysis(B, prior-from-A): ACCEPTED")
        print("initial background unique", torch.unique(frozen.initial_background_dbz).tolist())
        try:
            from advar.variational import solve_analysis
            solve_analysis(observations, frozen)
        except Exception as error:
            print("solve_analysis(B, prior-from-A): rejected", type(error).__name__, str(error))
        else:
            print("solve_analysis(B, prior-from-A): ACCEPTED")
    try:
        variational_nowcast(frames_b, neural_prior=application)
    except Exception as error:
        print("variational_nowcast(B, prior-from-A): rejected", type(error).__name__, str(error))
    else:
        print("variational_nowcast(B, prior-from-A): ACCEPTED")


if __name__ == "__main__":
    main()
