import torch, math
from dataclasses import replace
import advar.variational as v
from advar.physics import RemapCell
for vals in ((20.,21.,22.),(20.,19.,18.),(20.,22.,24.),(20.,20.5,21.)):
 frames=torch.stack([torch.full((8,8),q,dtype=torch.float64) for q in vals])
 obs,frozen=v.prepare_analysis(frames,nowcast_config=v.NowcastConfig(horizon_minutes=10),analysis_config=v.AnalysisConfig(censored_background_policy='detection_limit',maximum_outer_iterations=8,maximum_pcg_iterations=100,pcg_relative_tolerance=1e-8))
 r=v.solve_analysis(obs,frozen)
 print('vals',vals,'fallback/converged',r.used_fallback,r.converged,r.reason,'lin',r.linearization is not None,'control dyn',r.control[-3:])
 if r.linearization is None: continue
 lin=r.linearization
 # replace second remap branch y-1; exact baseline dyn likely 0 but linearized branch differs
 wrong=replace(lin.frozen,analysis_remap_cells=(lin.frozen.analysis_remap_cells[0],RemapCell(lin.frozen.analysis_remap_cells[1].y-1,lin.frozen.analysis_remap_cells[1].x)))
 wl=v._content_address_linearization(r.control,replace(lin,frozen=wrong))
 try: v.validate_analysis_linearization_content(r.control,wl); print('  content ACCEPT wrong cells',wrong.analysis_remap_cells,'match',v._analysis_remap_cells_match(r.control,wrong))
 except Exception as e: print('  content reject',type(e).__name__,e)
 try:
  tr=v._analysis_trajectory(r.control,wrong); orig=v._analysis_trajectory(r.control,lin.frozen)
  print('  output diff',float((tr.frames_linear-orig.frames_linear).abs().max()))
 except Exception as e:print(' traj err',e)
