# test_ledger_1 (RED) audit

Baseline: `94c75d3323c986b6fb2963336b906acc85384e12`.

## Confirmed finding

### F-LDG-001 — failed realized-receipt insert leaves an unindexed artifact directory

`EpisodeLedger.append_realized_intervention_receipt()` writes and renames the durable action artifact at [`src/advar/ledger.py:6380`](/Users/yhlee/ADVAR/src/advar/ledger.py:6380), then inserts the receipt row at line 6390 while still inside the SQLite transaction. The `with self._connect()` context rolls back SQLite on an insert failure, but there is no filesystem cleanup around `_write_intervention_action_artifact()`. A second valid, signed receipt for an already-recorded decision reaches the artifact write and then fails the `UNIQUE (decision_digest)` constraint, leaving bytes under `interventions/<new_receipt_digest>` with no corresponding index row. The post-insert publication-clock failure at line 6404 has the same ordering problem.

The runnable probe [`test_ledger_1_orphan_probe.py`](</tmp/advar-team-audit-94c75d3/test_ledger_1_orphan_probe.py>) exercised the public append path using the existing prospective-action fixture. Its output is in [`test_ledger_1_orphan_probe.out`](</tmp/advar-team-audit-94c75d3/test_ledger_1_orphan_probe.out>): two artifact directories remained, the duplicate receipt digest was absent from `realized_intervention_receipts`, and the failing insert was `UNIQUE constraint failed: realized_intervention_receipts.decision_digest`.

Expected contract behavior is atomic visibility: if the receipt row does not commit, a newly created action directory should be removed (or publication should be staged with equivalent rollback cleanup). The practical boundary is disk/resource leakage and an untracked durable artifact after retries, duplicate requests, or a clock race; the orphan is not returned by any loader and there is no reconciliation/garbage-collection path for `interventions/`.

## Confirmed test-fixture issue (not a production finding)

`test_malformed_or_contradictory_snapshot_is_rejected` currently fails its `"channels do not close"` regex. The `_computed_snapshot()` fixture has all four evidence channels finite=False/NaN at `[0, 0]`; this is valid zero-sensitivity evidence. The test changes only `path_evidence_by_metric`, `observation_verified_evidence_by_metric`, and `background_verified_evidence_by_metric`, leaving `observation_source_fraction_by_metric` NaN. `_validate_m0_snapshot()` therefore correctly rejects the mutation first with `metric evidence channels must share availability`.

The runnable reproduction is [`test_ledger_1_nan_fixture_probe.py`](</tmp/advar-team-audit-94c75d3/test_ledger_1_nan_fixture_probe.py>) with output in [`test_ledger_1_nan_fixture_probe.out`](</tmp/advar-team-audit-94c75d3/test_ledger_1_nan_fixture_probe.out>). To retain the closure assertion, make all four channels finite at that location (for example path/source `0.5`, observation `0.4`, background `0.2`) and keep the expected `source evidence channels do not close` message. Do not weaken the regex or treat the original all-NaN fixture as tampered evidence.

## Unconfirmed candidate: index/manifest duplicate metadata

`_verify_manifest()` validates the indexed contract hash, path, checksums, schema, and safety flags, but does not compare duplicated `episodes.issue_time`, `radar_id`, `model_commit`, `trust_score`, or `impact_available` columns against the manifest at [`src/advar/ledger.py:21358`](/Users/yhlee/ADVAR/src/advar/ledger.py:21358). A probe that deliberately drops the SQLite immutability trigger and changes `episodes.radar_id` makes `verify()` pass while `list_episodes()` reports `CORRUPTED`; see [`test_ledger_1_index_mismatch_probe.py`](</tmp/advar-team-audit-94c75d3/test_ledger_1_index_mismatch_probe.py>) and its output [`test_ledger_1_index_mismatch_probe.out`](</tmp/advar-team-audit-94c75d3/test_ledger_1_index_mismatch_probe.out>). This requires corrupted/tampered storage or trigger bypass, so it is not claimed as a supported-path defect. If that threat model matters, add row/manifest comparisons and a regression test.

## GREEN preserved

The all-NaN evidence state is accepted by the source validator as intended: the four channels share NaN availability and closure is evaluated over the empty finite set. The direct finite four-channel mutation reaches the intended closure error. The selected append/load/reopen, same-ID concurrency, normal SQLite mutation guards, and schema-one compatibility checks passed; the only failure in that five-test run was the stale regex fixture above. The targeted scalar migration and operational raw-history tests also passed (`2 passed`).

## Commands and limitations

- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I -m pytest -q tests/test_ledger.py::EpisodeLedgerTests::test_append_load_verify_and_reopen_computed_snapshot tests/test_ledger.py::EpisodeLedgerTests::test_same_id_concurrent_append_commits_once tests/test_ledger.py::EpisodeLedgerTests::test_sqlite_rows_cannot_be_updated_or_deleted tests/test_ledger.py::EpisodeLedgerTests::test_malformed_or_contradictory_snapshot_is_rejected tests/test_ledger.py::EpisodeLedgerTests::test_schema_one_episode_remains_verifiable` → `4 passed, 1 failed` (the stale regex fixture).
- `...pytest -q ...test_previous_scalar_schema_is_migrated ...test_operational_raw_resolution_history_is_append_only` → `2 passed`.
- `...python -I /tmp/advar-team-audit-94c75d3/test_ledger_1_orphan_probe.py` → reproduced the unindexed artifact.
- No repository source or test files were changed. No full baseline or full ledger suite was run.
