# test_sensitivity_2 GREEN audit

## Scope

Assigned range `tests/test_sensitivity.py:4201-8206`, class `VariationalFSOTests`, was read in bounded chunks. The review traced the verification mask/source ownership replay path, directed interval arithmetic, observation-error and correlated-mode FSO, P1 adjoint/FSOI validation, artifact restart and tamper checks, and the externally approved learning/ranking path into `src/advar/sensitivity.py`.

No repository source or test files were changed. Existing dirty worktree entries were preserved.

## Confirmed findings

None. I found no reproducible violation of the tested mathematical, numerical, or serialization contracts in the assigned range.

## Unconfirmed candidates

None retained. A zero Gauss--Newton normal-product denominator would produce a non-finite relative defect, but the implementation marks that diagnostic unreliable and the automated-learning contract requires the reliability gate; this is an intentional fail-closed boundary rather than an actionable defect in the tested path.

## GREEN preserved

- Ground-range and detection-limit intervals use directed binary64 bounds. The exact rational enclosure checks in `test_ground_range_bounds_control_verification_selection_and_age` agree with `_ground_range_interval_km_float64` and the registered detection-limit interval. At a nominal range boundary, the conservative upper bound correctly rejects the source.
- Source assignment is conservative: unavailable, stale, out-of-domain, QC-invalid, tied, NaN, or non-strictly-dominant candidates receive no ownership. The selected index is harmless when all scores are zero because `source_present` and `eligible` remain false. The score path uses the analytic bounded time-quality expression; it does not make `pow`/`exp` authoritative.
- Float32 reflectivity does not downcast observation geometry or interval computation. Temporal-overlap ambiguity leaves the source unassigned. The current MPS tests remain explicitly skipped unless MPS is available and require the CPU/binary64 boundary where the current contract demands it.
- Observation-derived inputs are audit-only and reject the legacy constructor. Gaussian observation error is diagnostic/report-only. Correlated observation FSO, including restart from its artifact and whitener budgets, matches perturb-and-resolve in the targeted tests.
- `VariationalAdjointConfig` enforces positive/nonnegative budgets and all local-validity gates. Dense Jacobian/normal-equation and finite-difference tests cover detected, censored, observation-weight, initial-background, and dynamics channels. Censored/weight channels use event-specific perturbation factories.
- FSOI requires an explicit perturbation and validates active-set margins, trust radius, physical radar semantics, directional classification, baseline branch identity, and global budgets. Invalid contracts fail closed.
- Linearization artifacts validate content/runtime compatibility, restart deterministically, synchronize file and directory forms, migrate only the supported legacy version, and reject tampering. FSO rejects P0 input, degraded/unpolished P1, digest/diagnostic changes, and failed PCG.
- Learning policy validation requires physical metric domain and approved verification lineage, strict local-validity gates, root-owned trust storage, ranking/approval digests, and first-order validation evidence. The targeted approved-policy and trust-store tests pass.

## Commands and results

Environment for all commands: `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1`, `/Users/yhlee/ADVAR/.venv/bin/python` (Python 3.12.13, Torch 2.13.0).

Bounded representative tests:

```text
pytest -q tests/test_sensitivity.py::VariationalFSOTests::test_ground_range_bounds_control_verification_selection_and_age tests/test_sensitivity.py::VariationalFSOTests::test_variational_fso_matches_dense_and_finite_difference tests/test_sensitivity.py::VariationalFSOTests::test_variational_fsoi_requires_and_applies_explicit_perturbation tests/test_sensitivity.py::VariationalFSOTests::test_learning_policy_is_external_and_requires_physical_input tests/test_sensitivity.py::VariationalFSOTests::test_variational_fso_fails_closed
5 passed, 18 warnings, 10 subtests passed in 12.14s
```

Additional bounded contract tests:

```text
pytest -q tests/test_sensitivity.py::VariationalFSOTests::test_temporal_transcendental_overlap_leaves_source_unassigned tests/test_sensitivity.py::VariationalFSOTests::test_fp32_reflectivity_does_not_downcast_observation_geometry tests/test_sensitivity.py::VariationalFSOTests::test_correlated_observation_fso_matches_perturb_and_resolve tests/test_sensitivity.py::VariationalFSOTests::test_p1_linearization_artifact_restarts_identical_fso tests/test_sensitivity.py::VariationalFSOTests::test_variational_fsoi_rejects_invalid_perturbation_contracts tests/test_sensitivity.py::VariationalFSOTests::test_approved_learning_policy_certifies_physical_branch tests/test_sensitivity.py::VariationalFSOTests::test_learning_policy_trust_store_requires_root_ownership
7 passed, 18 warnings in 24.72s
```

The runnable private-helper probe is [test_sensitivity_2_probe.py](/tmp/advar-team-audit-94c75d3/test_sensitivity_2_probe.py), with output in [test_sensitivity_2_probe.out](/tmp/advar-team-audit-94c75d3/test_sensitivity_2_probe.out). It checks unique-vs-tied strict source dominance and exact rational enclosure of the ground-range interval:

```text
{'one_source': [[[[1.0]]]], 'tied': [[[[0.0]]], [[[0.0]]]], 'range': (99.403578528827, 100.60362173038232)}
```

No full sensitivity, promotion, variational, baseline, or ledger suite was run. The MPS-specific tests were not run because they are backend-skipped on this environment. The direct helper probe is private-helper coverage; public-path confidence comes from the selected `VariationalFSOTests` above.
