"""Reproduce legacy NaN forecast migration behavior."""
from pathlib import Path
import tempfile

import numpy as np
import torch

from advar.nowcast import nowcast
from advar.run_artifact import (
    load_forecast_run,
    save_forecast_run,
    seal_forecast_run_arrays,
)


def main() -> None:
    frames = torch.full((3, 4, 4), 20.0, dtype=torch.float64)
    qc_mask = torch.ones_like(frames, dtype=torch.bool)
    qc_mask[:, 0, 0] = False
    result = nowcast(frames, qc_mask=qc_mask)
    print("producer_nan_count", int(torch.isnan(result.forecast_dbz).sum()))
    print("producer_invalid_count", int((~result.valid_mask).sum()))
    print("torch_equal_self", torch.equal(result.forecast_dbz, result.forecast_dbz))
    with tempfile.TemporaryDirectory() as directory:
        path = Path(directory) / "run.npz"
        save_forecast_run(result, path)
        current = load_forecast_run(path)
        print("current_load_nan_count", int(torch.isnan(current.forecast_dbz).sum()))
        with np.load(path, allow_pickle=False) as archive:
            arrays = {
                name: np.array(archive[name], copy=True)
                for name in archive.files
            }
        arrays["forecast_run_artifact_version"] = np.asarray(
            "forecast-run-v42"
        )
        np.savez_compressed(path, **seal_forecast_run_arrays(arrays))
        try:
            load_forecast_run(path)
        except ValueError as error:
            print("legacy_load", str(error))
        else:
            print("legacy_load", "ACCEPTED")


if __name__ == "__main__":
    main()
