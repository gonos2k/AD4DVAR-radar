import math
from types import SimpleNamespace

import torch

from advar.nowcast import NowcastConfig
from advar.physics import dbz_to_echo
from advar.sensitivity import (
    SensitivityConfig,
    _as_tiles,
    _maximum_linear_echo,
    _maximum_tile_norm,
    _metric_evidence_ratios,
    _metric_has_support,
    _trust_components,
    forecast_metric,
)


torch.set_num_threads(1)
torch.set_num_interop_threads(1)
dtype = torch.float64
nowcast = NowcastConfig(
    min_dbz=-10.0,
    max_dbz=60.0,
    interval_minutes=10,
    horizon_minutes=10,
)
config = SensitivityConfig(
    metric_names=("log_echo_mse", "soft_fss_error_35", "centroid_error"),
    soft_fss_window=1,
    minimum_fss_truth_mass=0.1,
)

truth_dbz = torch.tensor([[35.0, 45.0], [25.0, 40.0]], dtype=dtype)
forecast_dbz = torch.tensor([[35.0, 40.0], [30.0, 45.0]], dtype=dtype)
truth = dbz_to_echo(truth_dbz, min_dbz=nowcast.min_dbz, max_dbz=nowcast.max_dbz)
forecast = dbz_to_echo(forecast_dbz, min_dbz=nowcast.min_dbz, max_dbz=nowcast.max_dbz)
valid = torch.tensor([[True, True], [False, True]])

floor = 10.0 ** (nowcast.min_dbz / 10.0)
valid_f = valid.to(dtype)
expected_log = (
    ((torch.log(forecast + floor) - torch.log(truth + floor)).square() * valid_f).sum()
    / valid_f.sum()
)
actual_log = forecast_metric("log_echo_mse", forecast, truth, valid, nowcast, config)

# A 1-pixel FSS is an independent direct evaluation of the documented formula.
t = config.soft_fss_temperature_dbz
f_event = torch.sigmoid((forecast_dbz - 35.0) / t)
t_event = torch.sigmoid((truth_dbz - 35.0) / t)
df = f_event - t_event
expected_fss = (df.square() * valid_f).sum() / (f_event.square() * valid_f + t_event.square() * valid_f).sum()
actual_fss = forecast_metric("soft_fss_error_35", forecast, truth, valid, nowcast, config)

# Centroid is the weighted coordinate difference under log(1 + linear echo).
w_f = torch.log1p(forecast) * valid_f
w_t = torch.log1p(truth) * valid_f
y = torch.linspace(-1.0, 1.0, 2, dtype=dtype)
x = torch.linspace(-1.0, 1.0, 2, dtype=dtype)
cf = torch.stack(((w_f * y[:, None]).sum() / w_f.sum(), (w_f * x[None, :]).sum() / w_f.sum()))
ct = torch.stack(((w_t * y[:, None]).sum() / w_t.sum(), (w_t * x[None, :]).sum() / w_t.sum()))
expected_centroid = ((cf - ct).square()).sum()
actual_centroid = forecast_metric("centroid_error", forecast, truth, valid, nowcast, config)

weight = torch.tensor([[1.0, 2.0], [3.0, 0.0]], dtype=dtype)
source = torch.tensor([[1.0, 0.5], [0.2, 0.0]], dtype=dtype)
forecast_conf = torch.tensor([[0.8, 0.4], [0.2, 0.0]], dtype=dtype)
obs_source = torch.tensor([[1.0, 0.0], [0.5, 0.0]], dtype=dtype)
obs_verified = torch.tensor([[0.8, 0.0], [0.1, 0.0]], dtype=dtype)
bg_verified = torch.tensor([[0.0, 0.4], [0.1, 0.0]], dtype=dtype)
evidence = _metric_evidence_ratios(weight, source, forecast_conf, obs_source, obs_verified, bg_verified, 1e-12)
den = (weight * source).sum()
oracle_evidence = tuple((weight * e).sum() / den for e in (forecast_conf, obs_source, obs_verified, bg_verified))

tiles = _as_tiles(torch.arange(15, dtype=dtype).reshape(3, 5), (2, 3))
energy = torch.arange(24, dtype=dtype).reshape(2, 3, 4).square()
tile_norm = _maximum_tile_norm(energy, (2, 3))
oracle_tile_norm = max(
    math.sqrt(float(energy[frame, row : row + 2, column : column + 3].sum()))
    for frame in range(2)
    for row in range(0, 3, 2)
    for column in range(0, 4, 3)
)

metadata = SimpleNamespace(motion_pair_conflict=1, growth_pair_conflict=0)
state = SimpleNamespace()
control = torch.zeros(3, dtype=dtype)
trust = _trust_components(
    state,
    metadata,
    control,
    forecast,
    truth.unsqueeze(0),
    valid.unsqueeze(0),
    torch.ones((1, 3, 3), dtype=dtype),
    torch.ones((1, 3), dtype=torch.bool),
    torch.zeros((1, 2, 2), dtype=torch.bool),
    torch.ones((1, 3), dtype=dtype),
    nowcast,
    config,
    None,
)

checks = {
    "log_echo_mse": float((actual_log - expected_log).abs()),
    "soft_fss_error_35": float((actual_fss - expected_fss).abs()),
    "centroid_error": float((actual_centroid - expected_centroid).abs()),
    "evidence": max(float((a - b).abs()) for a, b in zip(evidence, oracle_evidence, strict=True)),
    "tile_layout_shape": tuple(tiles.shape),
    "tile_max_norm_error": abs(tile_norm - oracle_tile_norm),
    "metric_support": _metric_has_support("centroid_error", forecast, truth, valid, nowcast, config),
    "maximum_echo": float(_maximum_linear_echo(forecast, nowcast)),
    "trust_pair_consistency": trust["pair_consistency"],
}
print(checks)
assert checks["log_echo_mse"] < 1e-12
assert checks["soft_fss_error_35"] < 1e-8
assert checks["centroid_error"] < 1e-12
assert checks["evidence"] < 1e-12
assert checks["tile_layout_shape"] == (2, 2, 2, 3)
assert checks["tile_max_norm_error"] < 1e-12
assert checks["metric_support"] is True
assert abs(checks["trust_pair_consistency"] - config.pair_conflict_trust_penalty) < 1e-12
