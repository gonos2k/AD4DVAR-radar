import sys
sys.path[:0] = ['/Users/yhlee/ADVAR/tests', '/Users/yhlee/ADVAR/src']
import torch
from dataclasses import replace
from datetime import datetime, timezone, timedelta
import test_sensitivity as ts
from advar.nowcast import (
    NowcastConfig, RadarGridTimeContract, RadarState,
    radar_projected_crs_semantic_digest,
    RADAR_PROJECTED_GRID_COORDINATE_DTYPE,
    RADAR_PROJECTED_GRID_CELL_CENTER_CONVENTION,
    CURRENT_RADAR_METRIC_DOMAIN,
    CURRENT_RADAR_METRIC_DOMAIN_EVIDENCE,
)
from advar.physics import dbz_to_echo
from advar.sensitivity import (
    SensitivityConfig, compute_sensitivity_snapshot,
    _resolve_verification, _metric_domain_weight, _resolved_forecast_scores,
    VerificationBundle, VerificationCellState,
    VerificationObservationErrorContract,
    VerificationObservationErrorPlan,
)

torch.set_num_threads(1)
torch.set_num_interop_threads(1)
cfg = NowcastConfig(horizon_minutes=10)
h, w = 13, 17
y, x = torch.meshgrid(torch.arange(h, dtype=torch.float64), torch.arange(w, dtype=torch.float64), indexing='ij')
latest = (20.0 + 15.0 * torch.exp(-((y-6.0)**2 + (x-8.0)**2)/20.0)).to(torch.float64)
frames = latest.repeat(3, 1, 1)
state = RadarState(
    echo_linear=dbz_to_echo(latest, min_dbz=cfg.min_dbz, max_dbz=cfg.max_dbz),
    displacement_yx=torch.tensor([0.1, -0.15], dtype=torch.float64),
    log_growth_per_step=torch.tensor(0.01, dtype=torch.float64),
)
grid = RadarGridTimeContract(
    valid_times=(
        '2026-08-05T00:00:00Z', '2026-08-05T00:10:00Z', '2026-08-05T00:20:00Z'),
    dx_m=1000.0, dy_m=1000.0, projection='EPSG:5179', grid_hash='1'*64,
    spatial_grid_contract='radar-spatial-grid-identity-v6', grid_shape_yx=(h,w),
    projected_crs_digest=radar_projected_crs_semantic_digest('EPSG:5179'),
    metric_domain_digest=CURRENT_RADAR_METRIC_DOMAIN.digest,
    metric_domain_evidence_digest=CURRENT_RADAR_METRIC_DOMAIN_EVIDENCE.digest,
    cell_center_origin_xy_m=(1_000_000.0, 2_000_000.0),
    grid_coordinate_dtype=RADAR_PROJECTED_GRID_COORDINATE_DTYPE,
    cell_center_convention=RADAR_PROJECTED_GRID_CELL_CENTER_CONVENTION,
)
result = ts.result_for(state, cfg, frames=frames, accepted_mask=torch.ones_like(frames, dtype=torch.bool), grid_time_contract=grid)
truth = torch.nan_to_num(result.forecast_dbz.clone(), nan=cfg.min_dbz, posinf=cfg.max_dbz, neginf=cfg.min_dbz)
truth[:, :, w // 2:] = truth[:, :, w // 2:] + 15.0
times = ('2026-08-05T00:30:00Z',)
# A complete v6 bundle with deliberately nonuniform quality.  This is a
# contract-valid scientific weight, unlike a legacy finite-mask tensor.
valid = torch.ones_like(truth, dtype=torch.bool)
quality = torch.ones_like(truth)
quality[:, :, w // 2:] = 0.25
std = torch.full_like(truth, 2.0)
states = torch.full_like(truth, int(VerificationCellState.OBSERVED_ECHO), dtype=torch.uint8)
plan = VerificationObservationErrorPlan(
    radar_source_kind='single_site', source_registry_digest='1'*64,
    calibration_registry_digest='2'*64,
    range_elevation_validity_algorithm_digest='3'*64,
    beam_blockage_algorithm_digest='4'*64, attenuation_qc_digest='5'*64,
    censoring_rule_digest='6'*64,
    spatial_correlation_block_algorithm_digest='7'*64,
    quality_weight_interpretation_digest='8'*64,
    quality_weight_algorithm_digest='9'*64,
    observation_std_algorithm_digest='a'*64,
    observation_error_model_digest='b'*64,
    source_assignment_algorithm_digest='c'*64,
    minimum_detectable_echo_dbz=-20.0,
    observation_error_reference_std_dbz=2.0,
)
error = VerificationObservationErrorContract.from_tensors(
    plan=plan, valid_mask=valid, quality_weight=quality,
    observation_std_dbz=std, frames_dbz=truth, observation_state_code=states,
    source_radar_index_map=None, source_calibration_epochs=(('d'*64, 'e'*64),),
    range_elevation_validity_domain_digest='f'*64,
    beam_blockage_visibility_mask_digest='0'*64,
    spatial_correlation_block_digest='1'*64,
)
bundle = VerificationBundle(
    frames_dbz=truth, valid_mask=valid, valid_times=times,
    grid_contract_digest=grid.digest, radar_product_digest='2'*64,
    qc_pipeline_digest='5'*64, mask_policy_digest='4'*64,
    censor_policy_digest='6'*64, reflectivity_resolution_dbz=0.5,
    quantization_origin_dbz=-20.0,
    threshold_bin_convention='nearest_rounding_threshold_censor',
    floor_representation_contract_digest='6'*64,
    quality_weight=quality, observation_std_dbz=std,
    observation_state_code=states, observation_error_contract=error,
    contract='radar-verification-bundle-v6',
)
quality_zero = torch.zeros_like(quality)
error_zero = VerificationObservationErrorContract.from_tensors(
    plan=plan, valid_mask=valid, quality_weight=quality_zero,
    observation_std_dbz=std, frames_dbz=truth, observation_state_code=states,
    source_radar_index_map=None, source_calibration_epochs=(('d'*64, 'e'*64),),
    range_elevation_validity_domain_digest='f'*64,
    beam_blockage_visibility_mask_digest='0'*64,
    spatial_correlation_block_digest='1'*64,
)
bundle_zero = VerificationBundle(
    frames_dbz=truth, valid_mask=valid, valid_times=times,
    grid_contract_digest=grid.digest, radar_product_digest='2'*64,
    qc_pipeline_digest='5'*64, mask_policy_digest='4'*64,
    censor_policy_digest='6'*64, reflectivity_resolution_dbz=0.5,
    quantization_origin_dbz=-20.0,
    threshold_bin_convention='nearest_rounding_threshold_censor',
    floor_representation_contract_digest='6'*64,
    quality_weight=quality_zero, observation_std_dbz=std,
    observation_state_code=states, observation_error_contract=error_zero,
    contract='radar-verification-bundle-v6',
)
resolved = _resolve_verification(bundle, result, SensitivityConfig(metric_names=('log_echo_mse',), full_map_lead_minutes=(10,)))
fw = resolved.metric_weight[0]
base = _metric_domain_weight(result, resolved.valid_mask[0], 0, 'issued')
print('bundle_contract', bundle.contract)
print('fso_metric_weight_minmax_nonzero', float(fw.min()), float(fw.max()), int(torch.count_nonzero(fw)))
print('quality_minmax', float(bundle.quality_weight.min()), float(bundle.quality_weight.max()))
print('std_minmax', float(bundle.observation_std_dbz.min()), float(bundle.observation_std_dbz.max()))
print('state_unique', torch.unique(bundle.observation_state_code).tolist())
print('spatial_true', None if bundle.spatial_metric_valid_mask is None else int(torch.count_nonzero(bundle.spatial_metric_valid_mask)))
print('base_weight_unique', torch.unique(base).tolist())
print('weight_diff_nonzero', int(torch.count_nonzero(fw - base)))
cfgs = SensitivityConfig(metric_names=('log_echo_mse',), full_map_lead_minutes=(10,), metric_domain='issued')
snapshot = compute_sensitivity_snapshot(frames[-1], result, bundle, sensitivity_config=cfgs)
zero_verification = torch.nan_to_num(result.forecast_dbz.clone(), nan=cfg.min_dbz, posinf=cfg.max_dbz, neginf=cfg.min_dbz)
zero_gradient_snapshot = compute_sensitivity_snapshot(frames[-1], result, zero_verification, sensitivity_config=cfgs)
manual_weighted = ts.sensitivity_module.forecast_metric('log_echo_mse',
    ts.sensitivity_module._freeze_output_cap(
        ts.sensitivity_module.forecast_linear_at_step(result.state, 1, cfg), cfg)[0],
    ts.sensitivity_module.dbz_to_echo(torch.nan_to_num(bundle.frames_dbz[0], nan=cfg.min_dbz), min_dbz=cfg.min_dbz, max_dbz=cfg.max_dbz),
    base * fw, cfg, cfgs, grid)
resolved_scores, resolved_available = _resolved_forecast_scores(
    result, result.state, resolved, (10,), cfgs)
zero_snapshot = compute_sensitivity_snapshot(frames[-1], result, bundle_zero, sensitivity_config=cfgs)
zero_resolved, zero_resolved_available = _resolved_forecast_scores(
    result, result.state, _resolve_verification(bundle_zero, result, cfgs), (10,), cfgs)
print('snapshot_score', snapshot.forecast_scores[0,0].item())
print('manual_metric_with_bundle_weight', manual_weighted.item())
print('resolved_forecast_scores', resolved_scores[0,0].item(), 'available', bool(resolved_available[0,0]))
print('zero_weight_snapshot_available', bool(zero_snapshot.metric_available[0,0]), 'score_finite', bool(torch.isfinite(zero_snapshot.forecast_scores[0,0])))
print('zero_weight_resolved_available', bool(zero_resolved_available[0,0]), 'score_is_nan', bool(torch.isnan(zero_resolved[0,0])))
print('snapshot_metric_available', bool(snapshot.metric_available[0,0]))
print('fso_metric_weight_digest', bundle.content_digest)
print('zero_gradient_evidence_finite', [bool(torch.isfinite(getattr(zero_gradient_snapshot, name)[0, 0])) for name in ('path_evidence_by_metric', 'observation_source_fraction_by_metric', 'observation_verified_evidence_by_metric', 'background_verified_evidence_by_metric')])
