# nowcast_1 additional audit (RED)

Baseline: `94c75d3323c986b6fb2963336b906acc85384e12`.

## Confirmed finding

### F1 (P2): evidence-absent `radar-spatial-grid-identity-v5` is accepted as a current scientific run

The contract registry declares `radar-spatial-grid-identity-v6` current and v5 its predecessor (`src/advar/_contract_registry.py:72-79`). README describes v5 evidence-absent payloads as historical/audit bytes and says current run/replay validators must require the exact metric evidence (`README.md:1264-1268`). The nowcast contracts leave a reachable gap:

- `RadarSpatialGridIdentity.__post_init__` permits v5 with `metric_domain_evidence_digest=None` (`src/advar/nowcast.py:2675-2719`, `2789-2809`, `2824-2834`).
- `ForecastRunContract.from_inputs` calls `validate_current_metric_domain_evidence()` only for v6 (`src/advar/nowcast.py:4852-4858`); `ForecastRunContract.validate_integrity` has no v5/v6 eligibility gate (`src/advar/nowcast.py:5270-5291`).
- Every physical helper branches on `!= "...-v6"` and treats v5 projected metres as exact: motion caps (`src/advar/nowcast.py:3757-3764`), speed upper bounds (`src/advar/nowcast.py:3772-3774`), distance footprints (`src/advar/nowcast.py:3987-3996`), and cell area/status (`src/advar/nowcast.py:3342-3351`, `3407-3412`).
- The public `nowcast()` path feeds this contract directly (`src/advar/nowcast.py:9844-9869`). Current artifact writing first calls `result.validate_issuance()` (`src/advar/run_artifact.py:350-364`); current loading only revalidates evidence when the grid is already v6 (`src/advar/run_artifact.py:1434-1443`). Thus the v5 result is also accepted by the current artifact round trip.

The violated invariant is the physical uncertainty contract. The registered EPSG:5179 domain allows up to 0.6% linear scale error (and 1.2036% area error), so a current physical cap must use the ground-distance/speed interval upper bound. For a 1000 m orthogonal cell, 10 m/s over a 600 s step gives a projected 6-pixel displacement. The evidence-absent v5 path reports speed exactly 10.0 m/s and allows 6 pixels. The v6 evidence path reports the directed upper speed `10.060362173038238` m/s and caps the displacement at `5.963999999999998` pixels. A real ground speed at the v5-accepted 6 pixels can therefore exceed the configured 10 m/s cap by the registered scale error. The same omission affects area caps and physical-radius/annulus decisions.

The reproducible public-path probe is [`nowcast_1_v5_gap_probe.py`](/tmp/advar-team-audit-94c75d3/nowcast_1_v5_gap_probe.py), with output in [`nowcast_1_v5_gap_probe.stdout.txt`](/tmp/advar-team-audit-94c75d3/nowcast_1_v5_gap_probe.stdout.txt). It constructs a valid v5 grid with the current metric-domain digest but no evidence digest, compares v5/v6 physical limits, runs `nowcast(..., maximum_motion_speed_mps=10)`, calls `validate_issuance()` and `forecast_run_arrays()`, then saves and loads the current artifact. Observed output:

```text
v5 evidence= None limits= [6.0, 6.0] ground_upper_for_6px= 10.0
v6 evidence= 2a209774a738ed87b3b27ed90b080aaf92af776f4b0c304e90a3ef5666eabf69 limits= [5.963999999999998, 5.963999999999998] ground_upper_for_6px= 10.060362173038238
v5_run evidence= None issuance= True arrays= True
current_artifact_roundtrip contract= radar-spatial-grid-identity-v5 evidence= None
```

The smallest coherent repair is to keep v5 available only for explicitly audit-readable decoding and require v6 plus the exact current evidence digest at current `nowcast` issuance, `ForecastRunContract` integrity, and current artifact save/load. Alternatively every v5 physical consumer would need an explicit fail-closed audit-only route; silently using nominal projected metrics is unsound. This finding concerns the public scientific/current-artifact path; it does not claim operational deployment support, which the repository separately does not provide.

## Unconfirmed candidates

- `RadarGridTimeContract.projected_ground_speed_upper_from_displacement` returns `vector_norm / interval_seconds` immediately for every non-v6 contract (`src/advar/nowcast.py:3674-3680`), without the finite-positive interval validation used by its interval sibling. The direct edge probe returns `inf` for 0 s, `-1000` for -1 s, and `nan` for NaN ([`nowcast_1_edge_probe.py`](/tmp/advar-team-audit-94c75d3/nowcast_1_edge_probe.py), [`nowcast_1_edge_probe.stdout.txt`](/tmp/advar-team-audit-94c75d3/nowcast_1_edge_probe.stdout.txt)). Current internal callers derive a positive interval from `NowcastConfig.interval_minutes`, so this is a public helper boundary issue with no demonstrated current forecast failure.
- `projected_cell_count_area_interval_km2(0.0)` on v6 returns `(0.0, 5e-324)` due unconditional outward `nextafter` (`src/advar/nowcast.py:3370-3395`); consequently `cell_count_area_maximum_status(0.0, 0.0)` is `"uncertain"` rather than exact zero passing. Current area budgets are validated positive and current callers with zero changed/support cells therefore do not cross a realistic configured threshold. Probe result is in the same edge-probe output.
- Legacy/non-v6 `cell_count_area_*_status` and `projected_area_*_status` do not validate threshold finiteness before comparisons (`src/advar/nowcast.py:3397-3455`, `3473-3531`); direct NaN thresholds can be classified as passing. Configured current thresholds are validated upstream, and no reachable current caller was shown to supply NaN.

## GREEN preserved

- v6 construction requires the exact current evidence digest and validates cell-center coverage (`src/advar/nowcast.py:2805-2809`, `2824-2834`); v6 interval upper-bound calculations and affine row/column transforms behaved as expected in the bounded probes.
- Time canonicalization, three-frame spacing, background age, shape, dtype (`float32`/`float64`) and affine conditioning checks were read and did not yield a new counterexample.
- The existing selected grid/affine tests passed: 3 passed, 164 deselected.

## Commands, results, and limitations

- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-team-audit-94c75d3/nowcast_1_v5_gap_probe.py` — reproduced F1 and current artifact round trip.
- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-team-audit-94c75d3/nowcast_1_edge_probe.py` — recorded the two unconfirmed helper edge cases.
- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I -m pytest -q tests/test_nowcast.py -k 'grid_affine_maps_row_col_to_projected_velocity or affine_hard_gates_enclose_each_authoritative_float_operation or current_metric_domain' --disable-warnings --maxfail=1` — 3 passed, 164 deselected.

No repository source or test files were changed. The audit did not run the full baseline, CUDA/MPS P1, deployment, or full promotion/variational/sensitivity suites. Historical v5 semantics beyond the public current path were not altered; the finding is that the current path does not enforce the declared v6 evidence boundary.
