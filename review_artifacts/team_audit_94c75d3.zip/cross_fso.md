# Cross FSO audit: typed v22 metric-weight binding

Baseline: `94c75d3323c986b6fb2963336b906acc85384e12`  
Scope: independent cross-check of `sensitivity_2.md` and its typed `VerificationBundle` FSO probe; no repository edits.

## Confirmed findings

### M0 drops a typed v22 FSO metric weight

`_resolve_verification()` correctly resolves a typed bundle to `verification.fso_metric_weight` at [`src/advar/sensitivity.py:11659-11665`](/Users/yhlee/ADVAR/src/advar/sensitivity.py:11659). The M0 path then discards it: `compute_sensitivity_snapshot()` stores only `verification_bundle.valid_mask` at [`:12459-12473`](/Users/yhlee/ADVAR/src/advar/sensitivity.py:12459), and its lead loop passes that Boolean mask directly to `_metric_domain_weight()` at [`:12610-12617`](/Users/yhlee/ADVAR/src/advar/sensitivity.py:12610). A current v22 censored cell therefore remains in the point metric even though its declared FSO point weight is zero.

This violates the current verification contract: the protocol defines `quality * min(1, (reference_std / observation_std)^2)` as the score weight and says below-detection censored cells remain in lineage but have point-value metric weight zero (README [`:1321-1326`](/Users/yhlee/ADVAR/README.md:1321)). The expected typed objective is the frozen forecast-domain tensor multiplied by the bundle FSO weight. M0 instead converts the censored value to `min_dbz` through `nan_to_num` and differentiates that synthetic point.

The independent public probe (`test_sensitivity_1_derivative_probe.py`, run with `python -I`) produced:

```text
contract radar-verification-bundle-v22
state_00 5
valid_mask_00 True
fso_metric_weight_00 0.0
snapshot_score 2.9823176871440986
expected_fso_weighted_score 0.0
forecast_sensitivity_00 0.008634694098727665
forecast_sensitivity_other 1.1102230246251558e-18
```

The fixture sets one original finite forecast cell to NaN; the production v22 mask/error derivation classifies it as `BELOW_DETECTION_CENSORED` (`state_code=5`) while retaining `valid_mask=True` and `fso_metric_weight=0`. `compute_sensitivity_snapshot()` is a public call, and the nonzero score/gradient is the reachable defect.

### P1 FSO and FSOI use the same wrong domain-only objective

The earlier “P1 normal” statement in `test_sensitivity_1.md` refers to `_resolved_forecast_scores()`, which is used by the observation-removal path. It does not describe `compute_variational_fso()` or `compute_variational_fsoi()`.

The actual P1 wrappers call `_compute_variational_products()` at [`src/advar/sensitivity.py:12899-12929`](/Users/yhlee/ADVAR/src/advar/sensitivity.py:12899) and [`:12932-12989`](/Users/yhlee/ADVAR/src/advar/sensitivity.py:12932). `_compute_variational_products()` builds `metric_domain_weights` only from `verification_bundle.valid_mask` and `_metric_domain_weight()` at [`:15287-15315`](/Users/yhlee/ADVAR/src/advar/sensitivity.py:15287). That tensor is passed as `valid` to `_variational_forecast_score()` ([`:15916-15942`](/Users/yhlee/ADVAR/src/advar/sensitivity.py:15916)), so both the P1 score and its adjoint differentiate the domain-only objective.

The current typed v22 probe independently reproduced:

```text
valid_count 64
fso_weight_count 48
bundle_metric_weight_sum 48.0
domain_only_sum 49.0
resolved_weight_sum 48.0
fso_domain_sum 49.0
fso_score 0.082187626240476
fso_validate passed
resolved_score 5.101788422681788e-31
resolved_available True
```

The retained weighted domain is forecast-equal to truth, so the correctly weighted score is approximately zero. The public FSO accepts and validates a materially different score because validation checks artifact self-consistency/digests, not whether the declared metric weight was used. Public FSOI calls the same `_compute_variational_products()` and showed the same score/domain:

```text
fsoi_public {'fso_domain_sum': 49.0, 'fso_score': 0.082187626240476,
            'impact_sum': 1.4318452779659663e-05,
            'bundle_weight_sum': 48.0}
```

A separate production-derived spatial-support counterexample was run. With acquisition offset `-60 s`, the v22 derivation yielded `spatial_metric_valid_mask.sum() == 0` and `fso_metric_weight.sum() == 0`. Changing one forecast-valid finite truth cell `(0,1,1)` from `-1.2846352040201516` to `3.7153647959798484` gave:

```text
spatial_counterexample {
  'valid_count': 64, 'spatial_support_count': 0, 'fso_weight_sum': 0.0,
  'domain_only_sum': 49.0, 'fso_domain_sum': 49.0,
  'fso_score': 0.02705050056366528,
  'resolved_available': False, 'resolved_score': nan
}
```

Thus the issue is independently visible for spatial support, not only censored truth. The typed bundle has no supported metric after spatial gating, while current P1 FSO still scores the changed cell.

### Automated-learning re-solves inherit the same omission

`_resolve_learning_step()` resolves the typed input and computes `finite_truth` at [`src/advar/sensitivity.py:14780-14800`](/Users/yhlee/ADVAR/src/advar/sensitivity.py:14780), but constructs `nominal_weight`/`changed_weight` from `_metric_domain_weight()` alone at [`:14827-14842`](/Users/yhlee/ADVAR/src/advar/sensitivity.py:14827). The nominal and changed metric calls then use those weights at [`:14867-14925`](/Users/yhlee/ADVAR/src/advar/sensitivity.py:14867). This is the same domain-only objective used to create the current FSOI, so first-order validation can be internally consistent while both nominal score and resolved metric change omit the v22 point/spatial weight.

README explicitly says automated learning approves the nominal `frozen_metric_domain` ([`README.md:1513-1515`](/Users/yhlee/ADVAR/README.md:1513)) and describes the learning result as a conditional impact on the nominal metric domain ([`README.md:2621-2626`](/Users/yhlee/ADVAR/README.md:2621)). The nominal metric domain must therefore include the declared point metric weight; otherwise the FSOI prediction and full/half learning re-solves are all bound to the wrong metric.

The production private helper (no patched module function) returned:

```text
learning_step_private {
  'fso_domain_sum': 49.0, 'bundle_weight_sum': 48.0,
  'metric_change': -8.149138688309798e-06,
  'analysis_converged': True, 'active_branch_valid': True
}
```

A correction to P1 FSO alone would also make the current `_resolve_learning_step()` nominal reproduction check fail at [`:14879-14887`](/Users/yhlee/ADVAR/src/advar/sensitivity.py:14879), so the FSO and learning weight construction must be corrected together.

## Correct path distinguished: observation removal

`compute_variational_observation_removal_impact()` resolves the typed verification and calls `_resolved_forecast_scores()` for both nominal and removed forecasts at [`src/advar/sensitivity.py:13111-13134`](/Users/yhlee/ADVAR/src/advar/sensitivity.py:13111). `_resolved_forecast_scores()` explicitly multiplies the forecast domain by `verification.metric_weight` at [`:13252-13283`](/Users/yhlee/ADVAR/src/advar/sensitivity.py:13252). The public removal probe produced:

```text
removal_public {
  'nominal_score': 5.101788422681788e-31,
  'removed_score': 0.05194965132866034,
  'metric_change': 0.05194965132866034,
  'available': True
}
```

This is why “P1 score path applies weights” was misleading: the removal scorer does, while P1 FSO/FSOI and M0 do not. `_resolved_forecast_domain_weights()` at [`:13287-13308`](/Users/yhlee/ADVAR/src/advar/sensitivity.py:13287) follows the same weighted construction.

## Fixture and probe integrity

The existing `_current_verification_bundle()` helper at `tests/test_sensitivity.py:335-534` uses production `RadarObservationGeometryContract`, signed source registry/evidence, `derive_verification_observation_masks()`, `derive_verification_observation_error()`, and the `VerificationBundle` constructor. Neither `sensitivity_2_probe.py` nor the independent probes patches `torch`, `advar.sensitivity`, validation, PCG, or metric functions; the `unittest.mock.patch` usages in the test module are in unrelated tests and are not active during these scripts. Bundle integrity and current v22 replay validation execute normally.

The helper is synthetic (fixed 8x8 grid, one source, deterministic digests), so it is a minimal contract fixture rather than an operational radar product. That limitation does not weaken this finding: the failing calls are public, the bundle is a fully validated current v22 object, and the defect is the production weight tensor being ignored after resolution. The spatial probe changes only a finite truth value and varies the production-derived acquisition-age support; it does not mutate a sealed bundle or bypass digest checks. The learning probe calls the private `_resolve_learning_step()` with a `SimpleNamespace` exposing only the already-required `sensitivity_config`, solely to exercise that production path; it does not patch any function.

## GREEN preserved

- Typed bundle construction, v22 integrity/replay checks, valid-time/grid binding, and current spatial/censor state derivation passed in every probe.
- `_resolve_verification()` and `_resolved_forecast_scores()` preserve the declared typed metric weight; the public removal path therefore reports the expected near-zero nominal score in the censored counterexample.
- `validate_variational_fso()`/`validate_variational_fsoi()` reject mutation and cross-binding through content digests. Their successful validation here is correctly interpreted as self-consistency, not semantic objective validation.
- Legacy raw verification tensors continue to resolve to their finite-valid mask weight; this audit does not recommend changing that compatibility behavior.
- No repository source, tests, branches, or other agents' outputs were modified. No full suite was run.

## Commands, results, and limitations

All probes used one Torch thread and `python -I`:

- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-team-audit-94c75d3/test_sensitivity_1_derivative_probe.py` — reproduced the public M0 score/gradient mismatch; output [`cross_m0_probe.stdout.txt`](/tmp/advar-team-audit-94c75d3/cross_m0_probe.stdout.txt).
- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-team-audit-94c75d3/cross_fso_probe.py` — reproduced typed v22 censored P1 FSO mismatch and spatial-support counterexample; runnable probe [`cross_fso_probe.py`](/tmp/advar-team-audit-94c75d3/cross_fso_probe.py), output [`cross_fso_probe.stdout.txt`](/tmp/advar-team-audit-94c75d3/cross_fso_probe.stdout.txt).
- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-team-audit-94c75d3/cross_fso_paths_probe.py` — exercised public FSOI, public observation removal, and private learning step; output [`cross_fso_paths_probe.stdout.txt`](/tmp/advar-team-audit-94c75d3/cross_fso_paths_probe.stdout.txt).

No source correction was attempted under the read-only assignment. A correction should form one detached frozen tensor per lead as `forecast_metric_domain_weight * typed_verification.fso_metric_weight` before support checks, scoring, derivatives, metric-domain sums/digests, and learning nominal/changed scores; preserve legacy tensor behavior.
