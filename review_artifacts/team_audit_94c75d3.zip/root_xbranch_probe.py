import sys
import types

import torch

sys.path.insert(0, "/Users/yhlee/ADVAR/tests")
import test_sensitivity as fixture  # noqa: E402

import advar.sensitivity as sensitivity  # noqa: E402
from advar.physics import dbz_to_echo  # noqa: E402
from advar.variational import variational_nowcast  # noqa: E402


torch.set_num_threads(1)
torch.set_num_interop_threads(1)
fixture.VariationalFSOTests.setUpClass()
case = fixture.VariationalFSOTests
linearization = case.analysis.linearization
assert linearization is not None
observations = linearization.observations
frozen = linearization.frozen
base = observations.dbz.detach()
detected = observations.detected_mask
generator = torch.Generator().manual_seed(22)
delta = None
for candidate_index in range(81):
    candidate = torch.randn(
        base.shape,
        generator=generator,
        dtype=base.dtype,
    )
    candidate = torch.where(
        detected,
        candidate * 0.15,
        torch.zeros_like(candidate),
    )
    if candidate_index == 80:
        delta = candidate
        break
assert delta is not None

nominal_signature = sensitivity._p0_tendency_branch_signature(base, frozen)
scales = (0.25, 0.5, 0.75, 1.0)
signatures = tuple(
    sensitivity._p0_tendency_branch_signature(base + scale * delta, frozen)
    for scale in scales
)
endpoint_stable = sensitivity._baseline_branch_is_stable(
    observations,
    frozen,
    delta,
)

perturbation = sensitivity.VariationalObservationPerturbation.from_radar_dbz_delta(
    delta,
    linearization,
)
try:
    sensitivity.compute_variational_fsoi(
        case.forecast,
        case.analysis,
        case.verification,
        perturbation,
        sensitivity_config=case.sensitivity_config,
    )
    default_budget_result = "accepted"
except ValueError as error:
    default_budget_result = str(error)
adjoint_config = sensitivity.VariationalAdjointConfig(
    maximum_perturbed_fraction=1.0,
    maximum_perturbed_pixel_count=100,
    require_baseline_dynamics_branch_validity=True,
)
fsoi = sensitivity.compute_variational_fsoi(
    case.forecast,
    case.analysis,
    case.verification,
    perturbation,
    sensitivity_config=case.sensitivity_config,
    adjoint_config=adjoint_config,
)
same_domain = fsoi.observation.total.sum_by_time
learning_threshold = sensitivity.MetricTaylorThreshold(
    "log_echo_mse", 1.0e-6, 1.0e-6
)
learning_policy = types.SimpleNamespace(
    digest="d" * 64,
    sensitivity_config=case.sensitivity_config,
    adjoint_config=adjoint_config,
    algorithm_bundle_digest=linearization.algorithm_bundle_digest,
    numerical_runtime_digest=linearization.numerical_runtime_digest,
    maximum_whitener_total_operations=10**10,
    maximum_learning_pcg_iterations=100_000,
    maximum_learning_wall_seconds=3_600.0,
    maximum_linearity_relative_error=0.1,
    threshold_for=lambda name: learning_threshold,
)
saved_loader = sensitivity._load_learning_policy_trust_store
sensitivity._load_learning_policy_trust_store = lambda path: sensitivity._LearningPolicyTrustStore(
    frozenset({learning_policy.digest}), "e" * 64
)
try:
    learning_result = sensitivity.compute_variational_fsoi_for_learning(
        case.forecast,
        case.analysis,
        case.verification,
        perturbation,
        policy=learning_policy,
        policy_trust_store_path="/tmp/root-xbranch-learning-trust-store",
    )
finally:
    sensitivity._load_learning_policy_trust_store = saved_loader
automated_policy = sensitivity.AutomatedLearningPolicy(
    sensitivity_config=sensitivity.SensitivityConfig.for_automated_learning(
        radar_product_digest="a" * 64,
        qc_pipeline_digest="b" * 64,
    ),
    adjoint_config=sensitivity.VariationalAdjointConfig.for_automated_learning(),
    algorithm_bundle_digest=linearization.algorithm_bundle_digest,
    numerical_runtime_digest=linearization.numerical_runtime_digest,
)
sensitivity._load_learning_policy_trust_store = lambda path: sensitivity._LearningPolicyTrustStore(
    frozenset({automated_policy.digest}), "f" * 64
)
try:
    automated_learning_result = sensitivity.compute_variational_fsoi_for_learning(
        case.forecast,
        case.analysis,
        case.verification,
        perturbation,
        policy=automated_policy,
        policy_trust_store_path="/tmp/root-xbranch-automated-trust-store",
    )
finally:
    sensitivity._load_learning_policy_trust_store = saved_loader

changed_forecast, changed_analysis = variational_nowcast(
    frozen.input_frames_dbz + delta,
    nowcast_config=frozen.nowcast_config,
    analysis_config=frozen.analysis_config,
    observation_std_dbz=observations.std_dbz,
    quality_weight=observations.quality_weight,
    qc_mask=observations.valid_mask,
    background_frames_dbz=frozen.background_frames_dbz,
    background_age_minutes=frozen.background_age_minutes,
    grid_time_contract=frozen.grid_time_contract,
)
truth = dbz_to_echo(
    case.verification,
    min_dbz=case.forecast.run.config.min_dbz,
    max_dbz=case.forecast.run.config.max_dbz,
)
valid = torch.isfinite(case.verification[0])
nominal_score = sensitivity.forecast_metric(
    "log_echo_mse",
    dbz_to_echo(
        case.forecast.forecast_dbz[0],
        min_dbz=case.forecast.run.config.min_dbz,
        max_dbz=case.forecast.run.config.max_dbz,
    ),
    truth[0],
    valid,
    case.forecast.run.config,
    case.sensitivity_config,
)
resolved_score = sensitivity.forecast_metric(
    "log_echo_mse",
    dbz_to_echo(
        changed_forecast.forecast_dbz[0],
        min_dbz=case.forecast.run.config.min_dbz,
        max_dbz=case.forecast.run.config.max_dbz,
    ),
    truth[0],
    valid,
    case.forecast.run.config,
    case.sensitivity_config,
)
report = {
    "candidate_index": 80,
    "nonzero_pixels": int(torch.count_nonzero(delta)),
    "analysis_valid_count": int(torch.count_nonzero(observations.valid_mask)),
    "analysis_perturbed_fraction": float(torch.count_nonzero(delta)) / int(torch.count_nonzero(observations.valid_mask)),
    "delta_max_abs_dbz": float(delta.abs().max()),
    "delta_min_abs_nonzero_dbz": float(delta.abs()[delta != 0].min()),
    "delta_l2_dbz": float(torch.linalg.vector_norm(delta)),
    "signature_equal_nominal_by_scale": [
        signature == nominal_signature for signature in signatures
    ],
    "nominal_integer_peaks": nominal_signature.integer_peak_yx_by_pair,
    "quarter_integer_peaks": signatures[0].integer_peak_yx_by_pair,
    "half_integer_peaks": signatures[1].integer_peak_yx_by_pair,
    "full_integer_peaks": signatures[3].integer_peak_yx_by_pair,
    "endpoint_stable": endpoint_stable,
    "public_fsoi_branch_status": fsoi.baseline_dynamics_branch_status,
    "public_fsoi_accepted_with_strict_branch_gate": True,
    "learning_wrapper_eligible_with_custom_non_lineage_policy": learning_result.eligibility.eligible,
    "learning_wrapper_reasons_with_custom_non_lineage_policy": learning_result.eligibility.reasons,
    "learning_wrapper_first_order_valid_with_custom_non_lineage_policy": (
        None
        if learning_result.first_order_validation is None
        else learning_result.first_order_validation.first_order_valid
    ),
    "learning_wrapper_validation_details": (
        None
        if learning_result.first_order_validation is None
        else {
            "full_step_valid": learning_result.first_order_validation.full_step_valid,
            "half_step_valid": learning_result.first_order_validation.half_step_valid,
            "active_branch_valid": learning_result.first_order_validation.active_branch_valid,
            "sign_consistent": learning_result.first_order_validation.sign_consistent_for_material_impacts,
            "full_analysis_converged": learning_result.first_order_validation.full_step_resolved_analysis_converged,
            "half_analysis_converged": learning_result.first_order_validation.half_step_resolved_analysis_converged,
            "material_metric_count": learning_result.first_order_validation.material_metric_count,
            "full_prediction": learning_result.first_order_validation.full_step_prediction.tolist(),
            "full_resolved": learning_result.first_order_validation.full_step_resolved_metric_change.tolist(),
            "full_error": learning_result.first_order_validation.full_step_absolute_error.tolist(),
            "half_prediction": learning_result.first_order_validation.half_step_prediction.tolist(),
            "half_resolved": learning_result.first_order_validation.half_step_resolved_metric_change.tolist(),
            "half_error": learning_result.first_order_validation.half_step_absolute_error.tolist(),
        }
    ),
    "actual_automated_policy_with_raw_fixture_eligible": automated_learning_result.eligibility.eligible,
    "actual_automated_policy_with_raw_fixture_reasons": automated_learning_result.eligibility.reasons,
    "default_adjoint_budget_result": default_budget_result,
    "default_fraction": sensitivity.VariationalAdjointConfig().maximum_perturbed_fraction,
    "default_pixel_count": sensitivity.VariationalAdjointConfig().maximum_perturbed_pixel_count,
    "fso_lead_minutes": fsoi.fso.lead_minutes,
    "fso_metric_names": fsoi.fso.metric_names,
    "fso_metric_domain": fsoi.fso.metric_domain,
    "fso_metric_domain_weight_sum": fsoi.fso.metric_domain_weight_sum.tolist(),
    "resolved_valid_count": int(torch.count_nonzero(valid)),
    "resolved_mask_equals_issued_mask": bool(torch.equal(valid, case.forecast.valid_mask[0])),
    "sum_by_time_shape": tuple(same_domain.shape),
    "total_sum_by_time": same_domain.tolist(),
    "component_sums": {
        name: getattr(fsoi.observation, name).sum_by_time.tolist()
        for name in (
            "detected_dbz",
            "censor_threshold_dbz",
            "observation_weight",
            "initial_background_dbz",
            "baseline_dynamics_dbz",
            "total",
        )
    },
    "verification_input_kind": "raw Tensor (legacy-verification-tensor-v1; exploratory FSOI)",
    "fsoi_forecast_score": float(fsoi.fso.forecast_scores[0, 0]),
    "resolved_metric_change": float(resolved_score - nominal_score),
    "analysis_converged": changed_analysis.converged,
}
print(report)
assert report["signature_equal_nominal_by_scale"] == [False, True, True, True]
assert report["endpoint_stable"] is True
assert report["public_fsoi_branch_status"] == "certified"
assert report["analysis_converged"] is True
