# run_artifact audit

Baseline: `94c75d3323c986b6fb2963336b906acc85384e12`

## Confirmed findings

### RED-RA01 — legacy migration rejects valid NaN forecast cells

- Location: `src/advar/run_artifact.py:1955-1961`, specifically the
  `torch.equal(migrated.forecast_dbz, forecast_dbz)` check.
- Public reproduction: `frames=torch.full((3,4,4),20.0,dtype=torch.float64)`
  with a boolean `qc_mask` that is false at `[:,0,0]`; `nowcast` issues a
  result with 18 NaN forecast cells and 18 false `valid_mask` cells, and
  `save_forecast_run` plus current `load_forecast_run` round-trip it.
  Re-sealing the same payload with only
  `forecast_run_artifact_version='forecast-run-v42'` makes
  `load_forecast_run` raise `ValueError: legacy forecast payload cannot be
  migrated`.
- Expected behavior: legacy migration should accept regenerated forecasts
  when finite values and NaN locations agree, because NaN cells are the
  documented representation of unsupported forecast cells and must agree with
  `valid_mask`.
- Cause: PyTorch `torch.equal` returns false for corresponding NaNs even when
  both tensors have the same NaN mask. The valid-mask comparison is boolean
  and does not cause this issue.
- Boundary/impact: this is a public producer-to-legacy-reader path; a legacy
  archive with any unsupported/invalid forecast cell cannot be loaded for
  restart or delayed M0. The probe uses re-sealing to manufacture a historical
  version, as the existing migration tests do; storage corruption is not
  involved.
- Evidence: `run_artifact_nan_probe.py` and
  `run_artifact_nan_probe.stdout`.

### RED-RA02 — integer background age is accepted by producer but cannot round-trip

- Locations: `src/advar/run_artifact.py:520-524` serializes the run age with
  `np.asarray` preserving an integer dtype; loader validation at
  `src/advar/run_artifact.py:1616-1619` calls `_float_scalar`, which requires a
  floating NPY dtype. The producer acceptance is
  `src/advar/nowcast.py:4284-4305`, where `math.isfinite` accepts an integer.
- Public reproduction: `nowcast(frames, background_frames_dbz=frames-1.0,
  background_age_minutes=10)` succeeds; `save_forecast_run` succeeds; loading
  raises `ValueError: run_background_age_minutes must be a floating-point
  scalar`. If the background is actually used, the metadata age can likewise
  fail at the earlier `background_age_minutes` loader field.
- Expected behavior: either reject non-floating ages at the public input
  boundary, or normalize accepted numeric ages to a floating value before
  artifact serialization so save/load is a round-trip.
- Boundary/impact: the annotation says `float`, but runtime validation accepts
  Python integers and common callers use integer minutes. Every accepted
  integer age currently creates an unreadable current artifact.
- Evidence: `run_artifact_int_age_probe.py` and
  `run_artifact_int_age_probe.stdout`.

## GREEN preserved

- Current v72 round-trip preserves the canonical array set, artifact digest,
  forecast and valid mask. The current path also round-trips a forecast with
  NaN unsupported cells.
- The artifact digest is canonical across C- and Fortran-order NumPy arrays;
  generated payloads contain all 151 core members and no extras.
- ZIP/NPY preflight rejects member-count overflow and hostile declared array
  size before materialization; the same opened file is used after preflight.
- The assigned focused tests pass: 54 passed, 38 subtests, 18 unrelated
  PyTorch deprecation warnings, 92.96 seconds.
- Current input bundle/background presence checks, deployment lineage replay,
  v42/v44/v49-v71 audit migration cases, grid/velocity checks, and tamper
  checks are covered by the assigned tests. The v42 legacy regression uses a
  finite forecast and therefore does not exercise RED-RA01.

## Commands and results

`OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -m pytest -q tests/test_run_artifact.py tests/test_review_run_identity.py`

Result: `54 passed, 18 warnings, 38 subtests passed in 92.96s`.

Probe files and outputs are in `/tmp/advar-team-audit-94c75d3/` with the
`run_artifact_` prefix. `run_artifact_probe.py` reports 151 core arrays,
digest-valid sealing, current round-trip equality, and resource preflight
rejections.

## Limitations

No source or test files were changed. No full baseline or deployment command
was run. Legacy migration was exercised by deterministic version transformation
and digest resealing, matching the existing test mechanism; no historical
binary from an external producer was available.
