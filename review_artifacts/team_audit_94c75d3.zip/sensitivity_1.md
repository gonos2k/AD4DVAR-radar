# sensitivity_1 audit

Baseline: `94c75d3323c986b6fb2963336b906acc85384e12`  
Role: RED, assigned `src/advar/sensitivity.py:1-4600`

## Confirmed findings

None. I did not find a confirmed defect on a supported public producer/replay path.

## Unconfirmed candidate

`src/advar/sensitivity.py:2694-2721`, `_directed_tensor_square_interval`, returns a lower square bound that is one representable value too high when both interval endpoints are negative. The lower endpoint for a negative interval is `upper**2`; the implementation computes `upper_square = nextafter(upper * upper, +inf)` and then selects it with `minimum`, whereas a lower enclosure needs a downward rounding step. A direct deterministic probe found 133/1000 such internal interval misses; e.g. `[-22363.424237709372, -3780.2301292887314]` returned a lower value above the exact lower square.

The current caller `_registered_observation_range_intervals` adds outward sum/square-root steps after this helper. The same probe checked the complete 2-D range pipeline against exact rational endpoint bounds for 1,020 finite random and scale-stressed cases and found zero enclosure misses; ground-range propagation also had zero misses. The helper has one current caller at lines 2751/2755, and no public supported-path impact was demonstrated. Keep this as an unconfirmed numerical hygiene candidate rather than a finding unless a broader proof or a public threshold classification counterexample is obtained.

## GREEN preserved

- `VerificationObservationErrorPlan` versioned payloads, digest requirements, temporal/geometry/source-selection bindings, and legacy replay restrictions were inspected.
- Current v7 geometry/source registry construction binds float64 affine coordinates, CRS, metric-domain evidence, source coordinates, and spacing. The current issue/replay path rederives range intervals, detection limits, and source scores and compares tensors exactly.
- Source score certification is conservative: temporal transcendental values use the analytic `[0, 1]` codomain, and assignment requires strict lower dominance over all rival upper bounds. A top-2 implementation was compared with a quadratic oracle.
- Detection-limit interval propagation and ground-range intervals remained enclosed in deterministic checks.
- Source identity chronology, Ed25519 signatures, evidence upstream digests, registry binding, and replay-derived tensors were traced through the ledger caller.

## Commands/results and limitations

- Read `AGENTS.md`, `/tmp/advar-team-audit-94c75d3/INSTRUCTIONS.md`, and the assigned source in bounded chunks: `1-500`, `501-1000`, `1001-1500`, `1501-2000`, `2001-2500`, `2501-3000`, `3001-3500`, `3501-4000`, `4001-4500`, `4501-4600`.
- Traced current callers in `src/advar/sensitivity.py:4600-5600`, `src/advar/sensitivity.py:6500-7440`, and `src/advar/sensitivity.py:7580-8470`, plus the ledger replay caller `src/advar/ledger.py:4180-4380`.
- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I -m pytest -q tests/test_sensitivity.py -k 'scientific_geometry_is_generated_from_one_float64_affine or current_source_registry_rejects_radar_outside_metric_domain or source_selection_never_treats_pow_exp_as_authoritative or temporal_transcendental_overlap_leaves_source_unassigned or top2_source_dominance_matches_quadratic_oracle or fp32_reflectivity_does_not_downcast_observation_geometry'`: 6 passed, 87 deselected, 18 warnings, 18.42s.
- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-team-audit-94c75d3/sensitivity_1_probe.py`: exit 0. Output is in `sensitivity_1_probe.stdout.txt`; runnable source is `sensitivity_1_probe.py`. Direct square-helper diagnostic: 133/1000 lower-bound misses for negative intervals. Ground interval: 0/1000 misses. Full 2-D range pipeline: 0/1020 finite cases missed. Top-2 source dominance oracle: true.

Limitations: no full baseline suite, unsupported backends, or operational deployment was run. The negative-square issue was not promoted to a confirmed finding because its only current caller's complete range pipeline remained conservative in the bounded probes and no public classification error was reproduced.
