import sys
sys.path.insert(0, '/Users/yhlee/ADVAR/tests')
from dataclasses import replace
from test_promotion import NeuralPriorPromotionTests

fixture = NeuralPriorPromotionTests('runTest')
plan = fixture.plan()
first, second = plan.cases
shared_case = replace(
    second,
    uncertainty_target_plan_digest=first.uncertainty_target_plan_digest,
    state_calibration_target_plan_digest=first.state_calibration_target_plan_digest,
)
shared = replace(
    plan,
    cases=(first, shared_case),
    uncertainty_target_plans=(plan.uncertainty_target_plans[0],),
    state_calibration_target_plans=(plan.state_calibration_target_plans[0],),
    verification_observation_error_plans=(
        plan.verification_observation_error_plans[0],
        plan.verification_observation_error_plans[2],
    ),
)
print('accepted_shared_target_plans', shared.plan_digest)
print('case_target_plan_digests', tuple(c.uncertainty_target_plan_digest for c in shared.cases))
