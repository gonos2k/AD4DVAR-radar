# Cross-audit: v5 evidence-absent grid versus current run/artifact

## Verdict: RED at the current issuance/artifact boundary

The `radar-spatial-grid-identity-v5` evidence-absent representation is intentional
for historical decoding and byte audit. The defect is that the same representation
is reachable through the public `nowcast()` scientific path and is then serialized
as the current `forecast-run-v72` artifact. This is a current-contract admission
failure, rather than a defect in retaining v5 compatibility or in the v5 helper
semantics themselves.

## Contract semantics and geometry admission

The registry makes the distinction explicit. `src/advar/_contract_registry.py:39-56`
constructs a capability with only `current` in `issuable` and adds the predecessor
to `audit_readable`; `:78-81` declares `radar-spatial-grid-identity-v6` current and
v5 its predecessor. The generated README table repeats that v6 is issuable and
scientific-eligible while v5 is audit-readable only (`README.md:10-17, 20-27`).

The README gives the exact intended compatibility boundary at
`README.md:1251-1268`: sampled coverage is required for current scientific
evidence; evidence-absent v5 payloads remain representable for historical byte
audit; current run/verification/replay outer validators must recheck the exact
evidence digest. It separately states that `forecast-run-v71` and earlier are
audit-only and v72 is the current artifact (`README.md:2055-2082`).

The constructor behavior is consistent with the historical half of that contract:
`RadarSpatialGridIdentity.__post_init__` accepts v5 without an evidence digest
(`src/advar/nowcast.py:2675-2711, 2789-2809`), still checks the current metric
domain digest and sampled cell-center coverage (`:2824-2834`), and the payload
omits the evidence field when it is absent (`:2845-2871`). This is a valid audit
representation. `RadarGridTimeContract.from_payload()` also deliberately accepts
the v5 field shape with no evidence member (`src/advar/nowcast.py:3161-3197,
3251-3284`), which supports legacy decoding. Current verification geometry has its
own correct gate:
`RadarObservationGeometryContract.from_grid_time_contract` requires v6 and exact
evidence (`src/advar/sensitivity.py:1692-1722`), while the registered observation
geometry validator repeats the exact digest requirement (`:2803-2828`). The
focused cross probe therefore constructs v5 but rejects it as current v7 geometry.

## Current-path gap

The nowcast path does not apply that outer current gate. `nowcast()` invokes motion
limits and `RadarGridTimeContract.validate_for()` but does not require v6/evidence
(`src/advar/nowcast.py:9828-9850`). `ForecastRunContract.from_inputs` only calls
`validate_current_metric_domain_evidence()` when the contract is already v6
(`src/advar/nowcast.py:4852-4868`), and `ForecastRunContract.validate_integrity`
checks the grid digest, shape, and timing without a v5/v6 eligibility check
(`src/advar/nowcast.py:5265-5291`). Consequently a v5 grid can be issued and pass
`ForecastResult.validate_issuance()`.

The v5 physical branches explain why this boundary matters, while their existence
alone is not a finding about backward compatibility. The non-v6 branch retains
nominal/projected semantics in `maximum_displacement_yx`
(`src/advar/nowcast.py:3748-3764`), returns projected speed directly from
`projected_ground_speed_upper_from_displacement` (`:3674-3682`), and treats the
projected footprint as certain (`:3972-3996`). v6 instead validates exact evidence
and propagates the registered metric interval. With the registered 0.006 linear
scale bound, a 1000 m cell, 10 m/s cap, and 600 s interval give the reproducible
difference: v5 permits 6.0 pixels and reports a 10.0 m/s upper speed, while v6
permits 5.963999999999998 pixels and reports 10.060362173038238 m/s as the ground
upper bound for 6 pixels. Thus the v5 branch is safe only when confined to the
historical/audit boundary described above.

The current artifact boundary has the same gap. `forecast_run_arrays()` first
calls `result.validate_issuance()` and then writes the registry current artifact
version (`src/advar/run_artifact.py:334-375`); `save_forecast_run()` persists those
arrays without a generation admission (`:826-834`). `load_forecast_run()` only
revalidates metric evidence for a v6 grid (`src/advar/run_artifact.py:1434-1443`),
then calls the general issuance validator (`:1933-1963`). A v5/evidence-absent
run therefore round-trips as a `forecast-run-v72` file instead of being rejected
or explicitly classified as an audit-only artifact.

## Focused reproduction

Runnable probe: [`cross_v5_grid_probe.py`](/tmp/advar-team-audit-94c75d3/cross_v5_grid_probe.py)

Command:

```text
OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-team-audit-94c75d3/cross_v5_grid_probe.py
```

Observed output:

```text
v5_constructed None
v5_verification_geometry ValueError scientific verification requires projected-grid v6
v6_verification_geometry radar-observation-geometry-v7
saved_artifact_version forecast-run-v72
loaded_current_artifact_grid radar-spatial-grid-identity-v5 None
```

The existing public-path physical reproduction independently gives:

```text
v5 evidence= None limits= [6.0, 6.0] ground_upper_for_6px= 10.0
v6 evidence= 2a209774a738ed87b3b27ed90b080aaf92af776f4b0c304e90a3ef5666eabf69 limits= [5.963999999999998, 5.963999999999998] ground_upper_for_6px= 10.060362173038238
v5_run evidence= None issuance= True arrays= True
current_artifact_roundtrip contract= radar-spatial-grid-identity-v5 evidence= None
```

This proves a reachable current path: v5 is admitted by the public nowcast and
current artifact APIs, while current typed verification correctly rejects it. The
repair scope, if requested, is the outer admission/save/load boundary; changing
the v5 decoder or treating its nominal projected speed as a v6 interval would
misdiagnose intended backward compatibility.

## Limitations

No repository source or tests were modified. The probe uses the supported CPU
public API and a temporary artifact only. It does not claim operational deployment
support, CUDA/MPS behavior, or historical cold-replay certification. The conclusion
is limited to the demonstrated public `nowcast()` plus current `forecast-run-v72`
save/load path and the separately checked current verification geometry gate.
