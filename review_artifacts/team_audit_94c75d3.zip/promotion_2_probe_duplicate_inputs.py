import sys
sys.path.insert(0, '/Users/yhlee/ADVAR/tests')
from test_promotion import NeuralPriorPromotionTests
import advar.promotion as p

fixture = NeuralPriorPromotionTests('runTest')
plan = fixture.event_catalog_plan()
first = p.PhysicalEventCatalogEvidence.from_members(
    event_id='same-input-a', member_case_ids=('case-1',),
    member_full_analysis_input_digests=('4'*64,),
    start_time='2026-08-09T00:00:00Z', end_time='2026-08-09T02:00:00Z',
    spatial_envelope_xy_m=(0., 0., 100_000., 100_000.),
    object_track_artifact=fixture.event_track(1),
    participating_radar_ids=('radar-1',), association_algorithm_digest='3'*64,
    adjudication_policy_digest='6'*64, adjudicator_id=plan.adjudicator_id,
    adjudicator_private_key=fixture.regime_labeler_key())
second = p.PhysicalEventCatalogEvidence.from_members(
    event_id='same-input-b', member_case_ids=('case-2',),
    member_full_analysis_input_digests=('4'*64,),
    start_time='2026-08-10T00:00:00Z', end_time='2026-08-10T02:00:00Z',
    spatial_envelope_xy_m=(0., 0., 100_000., 100_000.),
    object_track_artifact=fixture.event_track(2),
    participating_radar_ids=('radar-1',), association_algorithm_digest='3'*64,
    adjudication_policy_digest='6'*64, adjudicator_id=plan.adjudicator_id,
    adjudicator_private_key=fixture.regime_labeler_key())
result = p.PhysicalEventCatalogResult.from_plan(
    plan, event_evidences=(first, second),
    case_spatial_membership_evidences=(
        fixture.event_spatial_evidence(first, case_id='case-1', full_analysis_input_digest='4'*64, source_object_evidence_digest='d'*64),
        fixture.event_spatial_evidence(second, case_id='case-2', full_analysis_input_digest='4'*64, source_object_evidence_digest='e'*64),
    ), cataloged_at='2026-08-11T00:00:00Z', adjudicator_private_key=fixture.regime_labeler_key())
print('accepted_duplicate_full_input_digest', result.result_digest)
print('event_member_input_digests', tuple(d for e in result.event_evidences for d in e.member_full_analysis_input_digests))
