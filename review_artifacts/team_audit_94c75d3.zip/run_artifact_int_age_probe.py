"""Check integer background-age acceptance and artifact round-trip."""
from pathlib import Path
import tempfile

import torch

from advar.nowcast import nowcast
from advar.run_artifact import load_forecast_run, save_forecast_run


def main() -> None:
    frames = torch.full((3, 4, 4), 20.0, dtype=torch.float64)
    result = nowcast(
        frames,
        background_frames_dbz=frames - 1.0,
        background_age_minutes=10,
    )
    print("producer_age", result.run.background_age_minutes, type(result.run.background_age_minutes).__name__)
    with tempfile.TemporaryDirectory() as directory:
        path = Path(directory) / "run.npz"
        save_forecast_run(result, path)
        try:
            load_forecast_run(path)
        except ValueError as error:
            print("load", str(error))
        else:
            print("load", "ACCEPTED")


if __name__ == "__main__":
    main()
