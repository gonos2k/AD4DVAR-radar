import sys
import types

import torch

sys.path.insert(0, "/Users/yhlee/ADVAR/tests")
import test_sensitivity as fixture  # noqa: E402

import advar.sensitivity as sensitivity  # noqa: E402
from advar.physics import dbz_to_echo  # noqa: E402
from advar.variational import variational_nowcast  # noqa: E402


torch.set_num_threads(1)
torch.set_num_interop_threads(1)
fixture.VariationalFSOTests.setUpClass()
case = fixture.VariationalFSOTests
linearization = case.analysis.linearization
assert linearization is not None
observations = linearization.observations
frozen = linearization.frozen
base = observations.dbz.detach()
detected = observations.detected_mask
generator = torch.Generator().manual_seed(22)
delta = None
for candidate_index in range(81):
    candidate = torch.randn(
        base.shape,
        generator=generator,
        dtype=base.dtype,
    )
    candidate = torch.where(
        detected,
        candidate * 0.15,
        torch.zeros_like(candidate),
    )
    if candidate_index == 80:
        delta = candidate
        break
assert delta is not None

nominal_signature = sensitivity._p0_tendency_branch_signature(base, frozen)
scales = (0.25, 0.5, 0.75, 1.0)
signatures = tuple(
    sensitivity._p0_tendency_branch_signature(base + scale * delta, frozen)
    for scale in scales
)
endpoint_stable = sensitivity._baseline_branch_is_stable(
    observations,
    frozen,
    delta,
)

perturbation = sensitivity.VariationalObservationPerturbation.from_radar_dbz_delta(
    delta,
    linearization,
)
adjoint_config = sensitivity.VariationalAdjointConfig(
    maximum_perturbed_fraction=1.0,
    maximum_perturbed_pixel_count=100,
    require_baseline_dynamics_branch_validity=True,
)
fsoi = sensitivity.compute_variational_fsoi(
    case.forecast,
    case.analysis,
    case.verification,
    perturbation,
    sensitivity_config=case.sensitivity_config,
    adjoint_config=adjoint_config,
)

first_order_threshold = sensitivity.MetricTaylorThreshold(
    "log_echo_mse",
    1.0e-6,
    1.0e-6,
)
policy_shim = types.SimpleNamespace(
    digest="d" * 64,
    sensitivity_config=case.sensitivity_config,
    adjoint_config=adjoint_config,
    algorithm_bundle_digest=linearization.algorithm_bundle_digest,
    numerical_runtime_digest=linearization.numerical_runtime_digest,
    maximum_whitener_total_operations=10**10,
    maximum_learning_pcg_iterations=100_000,
    maximum_learning_wall_seconds=3_600.0,
    maximum_linearity_relative_error=0.1,
    threshold_for=lambda name: first_order_threshold,
)
trust_store = sensitivity._LearningPolicyTrustStore(
    frozenset({policy_shim.digest}),
    "t" * 64,
)
load_trust_store = sensitivity._load_learning_policy_trust_store
sensitivity._load_learning_policy_trust_store = lambda path: trust_store
try:
    learning = sensitivity.compute_variational_fsoi_for_learning(
        case.forecast,
        case.analysis,
        case.verification,
        perturbation,
        policy=policy_shim,
        policy_trust_store_path="/tmp/sensitivity-4-probe-trust-store",
    )
finally:
    sensitivity._load_learning_policy_trust_store = load_trust_store

lineage_policy = types.SimpleNamespace(
    digest="c" * 64,
    sensitivity_config=sensitivity.SensitivityConfig.for_automated_learning(
        radar_product_digest="a" * 64,
        qc_pipeline_digest="b" * 64,
    ),
    adjoint_config=adjoint_config,
    algorithm_bundle_digest=linearization.algorithm_bundle_digest,
    numerical_runtime_digest=linearization.numerical_runtime_digest,
    maximum_whitener_total_operations=10**10,
    maximum_learning_pcg_iterations=100_000,
    maximum_learning_wall_seconds=3_600.0,
    maximum_linearity_relative_error=0.1,
    threshold_for=lambda name: first_order_threshold,
)
lineage_trust = sensitivity._LearningPolicyTrustStore(
    frozenset({lineage_policy.digest}),
    "u" * 64,
)
sensitivity._load_learning_policy_trust_store = lambda path: lineage_trust
try:
    lineage_learning = sensitivity.compute_variational_fsoi_for_learning(
        case.forecast,
        case.analysis,
        case.verification,
        perturbation,
        policy=lineage_policy,
        policy_trust_store_path="/tmp/sensitivity-4-probe-lineage-trust-store",
    )
finally:
    sensitivity._load_learning_policy_trust_store = load_trust_store

changed_forecast, changed_analysis = variational_nowcast(
    frozen.input_frames_dbz + delta,
    nowcast_config=frozen.nowcast_config,
    analysis_config=frozen.analysis_config,
    observation_std_dbz=observations.std_dbz,
    quality_weight=observations.quality_weight,
    qc_mask=observations.valid_mask,
    background_frames_dbz=frozen.background_frames_dbz,
    background_age_minutes=frozen.background_age_minutes,
    grid_time_contract=frozen.grid_time_contract,
)
truth = dbz_to_echo(
    case.verification,
    min_dbz=case.forecast.run.config.min_dbz,
    max_dbz=case.forecast.run.config.max_dbz,
)
valid = sensitivity._metric_domain_weight(
    case.forecast,
    torch.isfinite(case.verification[0]),
    0,
    case.sensitivity_config.metric_domain,
)
nominal_score = sensitivity.forecast_metric(
    "log_echo_mse",
    dbz_to_echo(
        case.forecast.forecast_dbz[0],
        min_dbz=case.forecast.run.config.min_dbz,
        max_dbz=case.forecast.run.config.max_dbz,
    ),
    truth[0],
    valid,
    case.forecast.run.config,
    case.sensitivity_config,
)
resolved_score = sensitivity.forecast_metric(
    "log_echo_mse",
    dbz_to_echo(
        changed_forecast.forecast_dbz[0],
        min_dbz=case.forecast.run.config.min_dbz,
        max_dbz=case.forecast.run.config.max_dbz,
    ),
    truth[0],
    valid,
    case.forecast.run.config,
    case.sensitivity_config,
)
report = {
    "candidate_index": 80,
    "nonzero_pixels": int(torch.count_nonzero(delta)),
    "delta_max_abs_dbz": float(delta.abs().max()),
    "delta_l2_dbz": float(torch.linalg.vector_norm(delta)),
    "signature_equal_nominal_by_scale": [
        signature == nominal_signature for signature in signatures
    ],
    "nominal_integer_peaks": nominal_signature.integer_peak_yx_by_pair,
    "quarter_integer_peaks": signatures[0].integer_peak_yx_by_pair,
    "half_integer_peaks": signatures[1].integer_peak_yx_by_pair,
    "full_integer_peaks": signatures[3].integer_peak_yx_by_pair,
    "endpoint_stable": endpoint_stable,
    "public_fsoi_branch_status": fsoi.baseline_dynamics_branch_status,
    "public_fsoi_accepted_with_strict_branch_gate": True,
    "verification_input_kind": "raw Tensor (legacy-verification-tensor-v1; exploratory FSOI)",
    "fsoi_total_sum_by_time_shape": tuple(
        fsoi.observation.total.sum_by_time.shape
    ),
    "fsoi_forecast_score": float(fsoi.fso.forecast_scores[0, 0]),
    "resolved_metric_domain_weight_count": int(torch.count_nonzero(valid)),
    "fsoi_first_order_metric_change": float(
        fsoi.observation.total.sum_by_time.sum(dim=-1)[0, 0]
    ),
    "resolved_metric_change": float(resolved_score - nominal_score),
    "analysis_converged": changed_analysis.converged,
    "learning_wrapper_eligible_with_policy_shim": learning.eligibility.eligible,
    "learning_wrapper_reasons_with_policy_shim": learning.eligibility.reasons,
    "learning_wrapper_first_order_valid_with_policy_shim": (
        None
        if learning.first_order_validation is None
        else learning.first_order_validation.first_order_valid
    ),
    "learning_wrapper_lineage_reasons_on_raw_tensor": (
        lineage_learning.eligibility.reasons
    ),
}
print(report)
assert report["signature_equal_nominal_by_scale"] == [False, True, True, True]
assert report["endpoint_stable"] is True
assert report["public_fsoi_branch_status"] == "certified"
assert report["analysis_converged"] is True
assert report["fsoi_total_sum_by_time_shape"] == (1, 1, 3)
assert report["learning_wrapper_eligible_with_policy_shim"] is False
assert report["learning_wrapper_reasons_with_policy_shim"] == (
    "first_order_validation_failed",
)
assert report["learning_wrapper_first_order_valid_with_policy_shim"] is False
assert report["learning_wrapper_lineage_reasons_on_raw_tensor"] == (
    "complete verification lineage requires VerificationBundle",
)
