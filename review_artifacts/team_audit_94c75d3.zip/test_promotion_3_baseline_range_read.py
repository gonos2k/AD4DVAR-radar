import hashlib
import json
import subprocess


commit = "94c75d3323c986b6fb2963336b906acc85384e12"
path = "tests/test_promotion.py"
ranges = ((10401, 11000), (11001, 11600), (11601, 12200), (12201, 12800),
          (12801, 13400), (13401, 14000), (14001, 14600), (14601, 15200),
          (15201, 15600))
baseline = subprocess.check_output(["git", "show", f"{commit}:{path}"])
current = open(path, "rb").read()
baseline_lines = baseline.splitlines(keepends=True)
current_lines = current.splitlines(keepends=True)
rows = []
for start, end in ranges:
    chunk = b"".join(baseline_lines[start - 1:end])
    # The root's four-line fixture edit is before the assigned range; compare
    # the current file at its shifted location to the frozen baseline chunk.
    shifted = b"".join(current_lines[start + 3:end + 4])
    rows.append({
        "start": start,
        "end": end,
        "lines": len(baseline_lines[start - 1:end]),
        "baseline_sha256": hashlib.sha256(chunk).hexdigest(),
        "current_after_known_offset_matches": chunk == shifted,
    })
print(json.dumps(rows, sort_keys=True))
