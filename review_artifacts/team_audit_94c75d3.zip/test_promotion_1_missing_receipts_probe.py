import sys
from pathlib import Path
sys.path.insert(0, str(Path('/Users/yhlee/ADVAR/tests')))
import torch
import test_promotion as t
from advar import promotion as p

fixture = t.NeuralPriorPromotionTests('run')
fixture.setUp()
try:
    issuance_plan, input_plan, source_registry = fixture.mosaic_issuance_context()
    source_key = fixture.scheduler_key()
    site_digests = source_registry.radar_site_digests
    slots = tuple(
        p.RawObservationSlotPlan(
            radar_site_digest=site_digest,
            acquisition_valid_time=valid_time,
            scan_strategy_rule_digest='5' * 64,
            source_selection_rule_digest=source_registry.source_selection_policy_digest,
            canonical_geodetic_footprint_digest='6' * 64,
        )
        for valid_time in input_plan.valid_times
        for site_digest in site_digests
    )
    receipts = tuple(
        p.MissingRawObservationReceipt.issue(
            slot=slot,
            missing_reason='outage',
            authority_id='trusted-radar-ingestor',
            authority_private_key=source_key,
            observed_at=slot.acquisition_valid_time,
        )
        for slot in slots
    )
    nominal = torch.ones((1, 2, 2), dtype=torch.bool)
    source_history = torch.full(
        (len(input_plan.valid_times), 2, 2), -1, dtype=torch.int64
    )
    try:
        coverage = p.ResolvedSourceCoverageArtifact.from_observations(
        issuance_plan,
        input_plan,
        source_registry,
        nominal_source_coverage_mask=nominal,
        source_radar_index_map=source_history[-1],
        outage_mask=torch.zeros((2, 2), dtype=torch.bool),
        dynamic_qc_valid_mask=torch.ones((2, 2), dtype=torch.bool),
        input_bundle_digest='4' * 64,
        full_analysis_input_digest='5' * 64,
        resolved_at=input_plan.input_available_time,
        data_ingestor_id='trusted-radar-ingestor',
        data_ingestor_private_key=source_key,
            input_history_source_radar_index_map=source_history,
        )
    except ValueError as error:
        print('typed receipts:', len(receipts), 'all missing:', all(type(x) is p.MissingRawObservationReceipt for x in receipts))
        print('coverage factory rejects all-missing history:', str(error))
        raise SystemExit(0)
    frames, masks, quality, observation_std = p._derive_analysis_inputs_from_raw_products(
        input_plan=input_plan,
        resolved_raw_observations=receipts,
        resolved_source_coverage=coverage,
    )
    print('typed receipts:', len(receipts), 'all missing:', all(type(x) is p.MissingRawObservationReceipt for x in receipts))
    print('derived shapes:', tuple(x.shape for x in (frames, masks, quality, observation_std)))
    print('canonical values:', float(frames.min()), bool(masks.any()), float(quality.max()), float(observation_std.min()))
finally:
    fixture.tearDown()
