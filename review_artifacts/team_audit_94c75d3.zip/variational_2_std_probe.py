import torch
from advar.variational import prepare_analysis, initial_control, whitened_observation_residual, robust_objective, solve_analysis
for dtype in (torch.float32,torch.float64):
 frames=torch.stack([torch.full((4,4),20.,dtype=dtype),torch.full((4,4),21.,dtype=dtype),torch.full((4,4),22.,dtype=dtype)])
 for s in (1e20,1e30,torch.finfo(dtype).max):
  try:
   o,f=prepare_analysis(frames,observation_std_dbz=s)
   r=whitened_observation_residual(initial_control(f),o,f)
   obj=robust_objective(initial_control(f),o,f)
   a=solve_analysis(o,f)
   print(dtype,s,'stdfinite',bool(torch.isfinite(o.std_dbz).all()),'wfinite',bool(torch.isfinite(r).all()),'obj',float(obj),'result',a.used_fallback,a.reason)
  except Exception as e: print(dtype,s,type(e).__name__,e)
