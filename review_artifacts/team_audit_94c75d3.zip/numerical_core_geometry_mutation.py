import json
import torch
from advar._digest import tensor_digest
from advar.range_geometry import RangeGeometryContract, resolve_range_geometry

x = torch.tensor([[0.0, 4.0]], dtype=torch.float64)
y = torch.zeros_like(x)
contract = RangeGeometryContract(
    radar_site_digest="a" * 64, radar_site_location_digest="b" * 64,
    grid_contract_digest="c" * 64, radar_x_m=0.0, radar_y_m=0.0,
    range_regime_labels=["near", "far"],
    radial_distance_edges_m=[0.0, 3.0, 5.0],
    horizontal_range_rule_digest="d" * 64,
    grid_x_m_digest=tensor_digest(x), grid_y_m_digest=tensor_digest(y),
)
contract.radial_distance_edges_m[1] = 10.0
row = {"contract_validate": None, "resolve": None}
try:
    contract.validate_integrity()
    row["contract_validate"] = "accepted"
except Exception as exc:
    row["contract_validate"] = type(exc).__name__
try:
    partition = resolve_range_geometry(contract, grid_x_m=x, grid_y_m=y)
    row["resolve"] = {"accepted": True, "masks": [m.tolist() for m in partition.masks]}
except Exception as exc:
    row["resolve"] = {"accepted": False, "error": type(exc).__name__}
print(json.dumps(row))
