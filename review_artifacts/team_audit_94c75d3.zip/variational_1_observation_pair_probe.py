import torch

from advar.variational import (
    AnalysisConfig,
    initial_control,
    prepare_analysis,
    solve_analysis,
    whitened_observation_residual,
)


torch.set_default_dtype(torch.float64)
config = AnalysisConfig(maximum_outer_iterations=4, maximum_pcg_iterations=40)
frames_a = torch.full((3, 3, 3), 20.0)
frames_b = torch.full((3, 3, 3), 10.0)
observations_a, frozen_a = prepare_analysis(
    frames_a, analysis_config=config
)
observations_b, frozen_b = prepare_analysis(
    frames_b, analysis_config=config
)
control_b = initial_control(frozen_b)
cross_residual = whitened_observation_residual(
    control_b, observations_a, frozen_b
)
same_residual = whitened_observation_residual(
    control_b, observations_b, frozen_b
)
print("cross observation/frozen pair accepted")
print("cross residual finite", bool(torch.isfinite(cross_residual).all()))
print("cross residual mean", float(cross_residual.mean()))
print("same residual mean", float(same_residual.mean()))
result = solve_analysis(observations_a, frozen_b, control=control_b)
print("cross solve returned", result.reason, "used_fallback", result.used_fallback)
print("cross objectives", result.initial_objective, result.final_objective)
print("cross result objective finite", all(
    torch.isfinite(torch.tensor((result.initial_objective, result.final_objective)))
))
