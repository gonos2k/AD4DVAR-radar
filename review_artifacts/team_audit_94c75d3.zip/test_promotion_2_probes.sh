#!/bin/zsh
set -euo pipefail
cd /Users/yhlee/ADVAR
export OMP_NUM_THREADS=1
export MKL_NUM_THREADS=1
/Users/yhlee/ADVAR/.venv/bin/python -I -m pytest -q \
  tests/test_promotion.py::NeuralPriorPromotionTests::test_pr110_snapshot_bundle_remains_audit_loadable \
  tests/test_promotion.py::NeuralPriorPromotionTests::test_pre_source_composition_replay_generations_are_audit_only \
  tests/test_promotion.py::NeuralPriorPromotionTests::test_pr144_v24_durable_replay_loads_as_audit_only
/Users/yhlee/ADVAR/.venv/bin/python -I -m pytest -q \
  tests/test_promotion.py::NeuralPriorPromotionTests::test_uncertainty_target_requires_its_planned_verification_source \
  tests/test_promotion.py::NeuralPriorPromotionTests::test_input_plan_must_match_actual_operational_identity \
  tests/test_promotion.py::NeuralPriorPromotionTests::test_probability_skill_cannot_hide_unreliable_state_uncertainty
