# promotion_2 RED audit (baseline `94c75d3323c986b6fb2963336b906acc85384e12`)

## Confirmed findings

### RED-1: physical-event association is argument-order dependent

`src/advar/promotion.py:8168-8221` chooses `earlier = first` whenever the two track intervals overlap (`8192-8194`).  For overlapping intervals this is not a temporal ordering; reversing the same two events changes the extrapolated centroid used by the association predicate.  `validate_physical_event_catalog_result` then calls that predicate only in the serialized event-list order (`8249-8255`), so a catalog can pass or fail solely by permutation.

The runnable probe `promotion_2_probe_assoc.py` creates two valid tracks under the shipped limits: event A covers 00:05–00:15 at x=0; event B covers 00:00–00:10 and moves x=0→20,000 m (33.3 m/s).  Their spatial IoU and simultaneous overlap distance are below the 5 km buffer.  The observed public behavior is:

```
association_a_b True
association_b_a False
accepted_ordered_split_result 3aa8cbca804a22f7fe7297d60fb036e0f74f172cf6dc7edc9c66de253bf08871
reverse_order_rejected physical event association graph has split connected components
```

Thus an adjudicator can serialize the pair as `(B, A)` and have the signed result accepted as two event components, while `(A, B)` is rejected.  Promotion consumes event identity as the outer independent cluster (`_physical_event_cluster`, `20554-20559`), so this can inflate distinct-event support and weaken holdout/training overlap protection.  The issue is reachable through `PhysicalEventCatalogResult.from_plan`, not a mocked helper; the probe is intentionally a small synthetic geometry case.  Association should be symmetric (or normalize an overlap ordering before extrapolation) before the pairwise graph test.

### RED-2: holdout cases can reuse one uncertainty/state target plan and be scored twice

`NeuralPriorHoldoutPlan.__post_init__` compares target-plan references as sets only (`10079-10094`).  It never checks that each case has a distinct `uncertainty_target_plan_digest` or `state_calibration_target_plan_digest`.  The same digest can therefore be referenced by multiple cases; `PriorHoldoutEvaluation.from_forecasts` resolves the target by that digest for every case, while promotion counts one evaluation per case.  This permits repeated target bytes to be counted as independent calibration evidence.

The runnable fixture probe `promotion_2_probe_duplicate_targets.py` starts with the public two-case `NeuralPriorHoldoutPlan` fixture, points case 2 at case 1's uncertainty and state target plans, removes the now-unused second plans, and constructs a new plan through the normal constructor.  It succeeds:

```
accepted_shared_target_plans 498d958d2f3b60d26b22c6bdd7791b3b12243809fc72e622fc7c121a8036afa1
case_target_plan_digests ('f9b18d2fa88bc6ff0e95785db2e55d09a6e90cf686721d3c5ae16feaf72579b4', 'f9b18d2fa88bc6ff0e95785db2e55d09a6e90cf686721d3c5ae16feaf72579b4')
```

The existing plan checks distinct input plans but does not establish one independent target realization per case.  This is a public plan-level contract gap, and it reaches scoring because `validate_holdout_scoring_input_artifact` only checks case IDs and evaluation digests (`17544-17627`), not target identity uniqueness.

### RED-3: distinct physical events may carry the same full-analysis input identity

`PhysicalEventCatalogEvidence`/`validate_physical_event_catalog_result` verify per-case membership (`8292-8300`, `8311-8315`) but never require `member_full_analysis_input_digests` to be unique across cases or events.  The candidate manifest repeats this mapping check (`12021-12040`) without a uniqueness invariant.  Consequently two event components can represent the exact same forecast input while remaining two outer clusters; promotion later uses the signed physical-event digest for cluster resampling.

The runnable probe `promotion_2_probe_duplicate_inputs.py` creates two non-associating, valid events for `case-1` and `case-2`, both carrying the exact same 64-byte full-analysis input digest.  The normal public `PhysicalEventCatalogResult.from_plan` accepts the result:

```
accepted_duplicate_full_input_digest a4f25b051430f6afaa70a236a1175c879cf714e83603d3541de1d7cab9536c31
event_member_input_digests ('4444444444444444444444444444444444444444444444444444444444444444', '4444444444444444444444444444444444444444444444444444444444444444')
```

This is reachable catalog construction with signed evidence, and the downstream candidate/holdout checks only reject training-vs-holdout overlap, not duplicate identities within the holdout.  Such a result can make repeated bytes count as distinct physical-event clusters.

## Unconfirmed candidates

- `PhysicalEventTrackArtifact` is declared frozen but does not tuple-normalize centroid, mask, radar, or edge collections before hashing (`7381-7440`).  Direct callers can pass mutable lists and mutate signed state after construction.  Full catalog validators rehash and catch ordinary tampering, so I did not classify this as an independent promotion bypass.
- `NeuralPriorHoldoutPlan.__post_init__` checks acquisition-time coverage per sampling unit but does not explicitly require the slot sets of different cases to be disjoint (`10011-10022`).  I did not complete a full current-plan fixture with overlapping valid times and all dependent contracts, so this remains a candidate rather than a confirmed finding.
- `RegimeClassifierManifest` metadata for storm/day/radar is not tied field-by-field to the signed training derivation; the physical/input/raw/target identities are bound.  I did not establish a reachable holdout bypass from this alone.

## GREEN preserved

- Track speed, acceleration, finite-coordinate, and projected-CRS checks reject invalid small tracks (`7399-7438`); the association finding is specifically the overlap ordering branch.
- Catalog result signatures, event digests, case coverage, spatial membership, deadline, and pre-scoring chronology remain enforced (`8231-8339`).
- Verification target identity is derived from the actual scoring target tensors and rechecked in `PriorHoldoutEvaluation.from_forecasts`; no target-digest substitution was found.
- Narrow existing checks passed: `tests/test_review_promotion_contracts.py -k 'physical_event or target_identity'` (3 passed, 16 deselected) and `tests/test_promotion.py -k 'cross_radar_motion_components_cannot_be_split or same_physical_storm_across_days_and_radars_is_one_cluster'` (2 passed, 225 deselected).

## Commands and limitations

All probes used `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python`.  Probe source and captured output are in `/tmp/advar-team-audit-94c75d3/` with the `promotion_2_` prefix.  No repository source or tests were modified.  The synthetic geometry probes exercise public constructors and validators; they do not claim that a particular production catalog currently has the adversarial event ordering or duplicate identities.
