import json
import math
import os

import torch

from advar.nowcast import (
    DataStatus,
    NowcastConfig,
    RadarGridTimeContract,
    TendencySource,
    nowcast,
)
from advar.physics import dbz_to_echo, echo_to_dbz, remap


def main():
    torch.set_num_threads(1)
    out = {}
    config = NowcastConfig(horizon_minutes=20)
    y, x = torch.meshgrid(
        torch.arange(48, dtype=torch.float64),
        torch.arange(48, dtype=torch.float64),
        indexing="ij",
    )
    base = 1.0e3 * torch.exp(-((y - 21.0) ** 2 + (x - 23.0) ** 2) / 28.0)
    displacement = torch.tensor((0.8, -0.65), dtype=torch.float64)
    factor = 1.10
    echoes = torch.stack(
        [factor**i * remap(base, i * displacement) for i in range(3)]
    )
    frames = echo_to_dbz(echoes, min_dbz=config.min_dbz, max_dbz=config.max_dbz)
    result = nowcast(frames, config)
    out["moving_gaussian_displacement"] = {
        "estimated": result.state.displacement_yx.tolist(),
        "expected": displacement.tolist(),
        "max_abs_err": float((result.state.displacement_yx - displacement).abs().max()),
        "growth": float(result.state.log_growth_per_step),
        "expected_growth": math.log(factor),
        "valid_fraction": float(result.valid_mask.to(torch.float64).mean()),
        "data_status": result.metadata.data_status.value,
        "tendency_source": result.metadata.tendency_source.value,
    }

    stationary = echo_to_dbz(
        torch.stack((base, base * factor, base * factor**2)),
        min_dbz=config.min_dbz,
        max_dbz=config.max_dbz,
    )
    growth_result = nowcast(stationary, config)
    out["growth_normalization"] = {
        "growth": float(growth_result.state.log_growth_per_step),
        "expected": math.log(factor),
        "lead1_linear_ratio": float(
            dbz_to_echo(growth_result.forecast_dbz[0], min_dbz=config.min_dbz, max_dbz=config.max_dbz).sum()
            / base.mul(factor**2).sum()
        ),
        "lead1_valid": int(growth_result.valid_mask[0].sum()),
    }

    missing = frames.clone()
    missing[:, 0, 0] = torch.nan
    qc = torch.ones_like(missing, dtype=torch.bool)
    qc[:, 1, 1] = False
    partial = nowcast(missing, config, qc_mask=qc)
    out["missing_qc_normalization"] = {
        "status": partial.metadata.data_status.value,
        "missing_finite": bool(torch.isfinite(partial.forecast_dbz[:, 0, 0]).any()),
        "qc_finite": bool(torch.isfinite(partial.forecast_dbz[:, 1, 1]).any()),
        "valid_mask_matches_finite": bool(torch.equal(partial.valid_mask, torch.isfinite(partial.forecast_dbz))),
        "latest_mask_00": bool(partial.run.latest_observation_mask[0, 0]),
        "latest_mask_11": bool(partial.run.latest_observation_mask[1, 1]),
    }

    all_missing = torch.full((3, 8, 8), torch.nan, dtype=torch.float64)
    background = torch.full((3, 8, 8), 20.0, dtype=torch.float64)
    stale = nowcast(all_missing, config, background_frames_dbz=background, background_age_minutes=10.0)
    out["background_fallback"] = {
        "status": stale.metadata.data_status.value,
        "tendency_source": stale.metadata.tendency_source.value,
        "background_used": stale.metadata.background_used,
        "background_fraction": stale.metadata.background_contribution_fraction,
        "age": stale.metadata.background_age_minutes,
        "lead1_dbz": float(stale.forecast_dbz[0, 3, 3]),
        "lead1_matches_input": bool(torch.allclose(stale.forecast_dbz[0], background[-1])),
        "valid_fraction": float(stale.valid_mask.to(torch.float64).mean()),
    }

    # Input values outside the physical dBZ range are intentionally normalized
    # to the configured bounds; infinities become missing before source merge.
    edge = torch.full((3, 8, 8), 20.0, dtype=torch.float64)
    edge[0, 0, 0] = -100.0
    edge[1, 0, 0] = torch.inf
    edge[2, 0, 0] = torch.nan
    edge[:, 0, 1] = torch.nan
    edge_result = nowcast(edge, config)
    out["normalization_bounds"] = {
        "status": edge_result.metadata.data_status.value,
        "all_missing_pixel_output_nan": bool(torch.isnan(edge_result.forecast_dbz[:, 0, 1]).all()),
        "finite_bounded_pixel_output": bool(torch.isfinite(edge_result.forecast_dbz[:, 0, 0]).all()),
        "finite_output_elsewhere": bool(torch.isfinite(edge_result.forecast_dbz[:, 1:, 1:]).all()),
    }

    # Verify the physical time contract rejects off-grid intervals and accepts
    # timezone-equivalent timestamps after canonicalization.
    times = ("2026-01-01T00:00:00Z", "2026-01-01T00:10:00+00:00", "2026-01-01T00:20:00Z")
    grid = RadarGridTimeContract(
        valid_times=times,
        dx_m=1000.0,
        dy_m=1000.0,
        projection="EPSG:5179",
        grid_hash="a" * 64,
    )
    grid_result = nowcast(frames, config, grid_time_contract=grid)
    out["time_grid"] = {
        "canonical_times": grid_result.run.grid_time_contract.valid_times,
        "grid_velocity_shape": tuple(grid_result.grid_velocity_mps_yx.shape),
        "grid_velocity_mps": grid_result.grid_velocity_mps_yx.tolist(),
    }
    try:
        bad_grid = RadarGridTimeContract(
            valid_times=("2026-01-01T00:00:00Z", "2026-01-01T00:11:00Z", "2026-01-01T00:20:00Z"),
            dx_m=1000.0,
            dy_m=1000.0,
            projection="EPSG:5179",
            grid_hash="b" * 64,
        )
        nowcast(frames, config, grid_time_contract=bad_grid)
        out["off_grid_interval_rejected"] = False
    except ValueError as error:
        out["off_grid_interval_rejected"] = type(error).__name__ + ": " + str(error)

    result.validate_issuance()
    stale.validate_issuance()
    out["issuance_validation"] = "passed"
    print(json.dumps(out, sort_keys=True, default=lambda value: list(value) if isinstance(value, tuple) else value))


if __name__ == "__main__":
    main()
