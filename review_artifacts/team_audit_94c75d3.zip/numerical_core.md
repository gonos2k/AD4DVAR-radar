# numerical_core audit

Baseline: `94c75d3323c986b6fb2963336b906acc85384e12`  
Role: GREEN/RED. This was a read-only review; no repository source or tests were changed.

## Confirmed findings

### P3: finite extreme displacements fail before the mathematically zero remap

`src/advar/physics.py:136` converts the frozen Python integer cell back to a tensor with `detached.new_tensor((cell.y, cell.x))`. `src/advar/physics.py:158` performs the analogous Python-int subtraction in `remap_fractions`. The public displacement validator only requires shape, floating dtype, and finiteness (`physics.py:183-199`), so a finite displacement is in the accepted input domain.

Small reproduction (saved in `numerical_core_extreme_remap.py`): a 2x2 finite field and `[1e20, -1e20]` produce `OverflowError: int too big to convert` for both float32 and float64. A whole-domain zero-padded shift should instead return a finite all-zero field; `shift_zero` already handles the corresponding giant integer shift. The same path succeeds for `[1000, -1000]` and returns sum zero.

This is reachable through the public `physics.remap` and `remap_core` helpers. Current high-level nowcast callers bound motion to configured operational limits, so I did not find a normal configured forecast path that emits 1e20-pixel motion. Impact is therefore an extreme finite-input boundary failure rather than a demonstrated operational forecast failure.

### P3: `RangePartitionEvidence` accepts duplicate regime labels

`src/advar/range_geometry.py:353-392` checks mask shapes, digest consistency, active labels, and complete membership, but never requires nonempty unique `range_regime_labels`. The constructor and `validate_integrity()` therefore accept two disjoint masks with `range_regime_labels=("same", "same")` and `active_range_regimes=("same", "same")`. `mask("same")` at `range_geometry.py:420-425` silently returns the first mask. The saved tiny probe also passes this malformed object through `restrict_range_partition_domain` and validates the result.

The physical geometry constructors enforce unique labels and production resolvers derive labels from those contracts. The authoritative replay path compares regenerated range payloads, so this probe does not demonstrate a promotion or deployment bypass. It is nevertheless a public typed-artifact contract gap: a manually constructed or incorrectly decoded evidence object has an ambiguous label-to-mask map.

### P3 candidate: diagonal-R EFSO evidence accepts non-string or empty observation IDs

`src/advar/ensemble_sensitivity.py:311-345` annotates `observation_ids` as `tuple[str, ...]`, while `_new_precision_evidence` only checks length and uniqueness at lines 359-363. The diagonal factory accepts `(1, 2)` and `("", "x")`; `EnsembleFSOStatistics.from_diagonal_r` also accepts integer IDs and computes normally. Full `PrecisionOperatorArtifact` construction has the stricter nonempty-string check, so this inconsistency is limited to the legacy diagonal-R factory. I found no product source caller outside tests, so this remains a contract candidate rather than an operational failure.

### P3 candidate: single-site geometry resolver does not revalidate a mutable contract

`src/advar/range_geometry.py:428-467` checks coordinate digests but does not call `contract.validate_integrity()`, unlike the mosaic resolver at line 493. `RangeGeometryContract` does not normalize list inputs to tuples. A direct constructor with list edges, followed by `contract.radial_distance_edges_m[1] = 10.0`, makes `validate_integrity()` reject the stale digest but `resolve_range_geometry()` accept the changed edges and emit altered masks while retaining the old `contract_digest`. The saved `numerical_core_geometry_mutation.py` reproduces this. Normal artifact loaders convert serialized lists to tuples before construction, and no end-to-end tampered deployment was demonstrated.

## GREEN preserved

- A hand-built bilinear branch oracle matched `remap_core` exactly (`max_abs=0`), including an out-of-domain branch; transport audit had before 210.0, after 97.65, boundary outflow 112.35, and budget error 0.0.
- `dbz_to_echo`/`echo_to_dbz` round-tripped `[-10, 0, 5, 40]` dBZ at `min=-10,max=50` to `7.1e-15` maximum absolute error; the floor maps to exactly zero and its derivative remained finite.
- `shift_zero` matched explicit index copying exactly and retained a finite backward gradient. Random 100-case transport checks had max relative budget error `4.47e-8` in float32 and `1.61e-16` in float64.
- JVP/VJP dot-product gap was 0; Gauss–Newton value, gradient, and damped HVP matched the direct matrix oracle. PCG solved the same SPD system at scales `1e-300`, `1`, and `1e300`, converging with relative residuals `2.59e-14`, `4.44e-16`, and `1.03e-13`.
- MAE/RMSE were common-scale invariant in the tiny oracle to roundoff (`mae` gap at most `4.44e-16`, RMSE gap zero). EFSO direct impact and delete-one jackknife matched an independent formula exactly. Range bands partitioned the tiny grid at the 3.0 edge with the expected half-open/closed convention.
- The selected tests passed under isolated Python: **83 passed, 131 subtests**, with 18 unrelated TorchScript deprecation warnings. No full baseline suite was run.

## Commands and artifacts

- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-team-audit-94c75d3/numerical_core_probe.py`  → `numerical_core_probe_isolated.stdout.json`
- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-team-audit-94c75d3/numerical_core_extreme_remap.py`  → `numerical_core_extreme_remap_isolated.stdout.json`
- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-team-audit-94c75d3/numerical_core_geometry_mutation.py`  → `numerical_core_geometry_mutation.stdout.json`
- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I -m pytest -q tests/test_shift_zero.py tests/test_matrix_free.py tests/test_metrics.py tests/test_pcg.py tests/test_numerical_review.py tests/test_ensemble_sensitivity.py tests/test_calibration.py tests/test_review_numerics.py`  → `numerical_core_pytest.stdout.txt`

Limitations: no source edits, no full baseline suite, no CUDA, and no full MPS P1. The two contract candidates were not promoted to end-to-end deployment findings because production resolvers/loaders or replay checks provide additional guards.
