import json, torch
from advar.physics import remap, remap_core, RemapCell
rows=[]
for dtype in (torch.float32, torch.float64):
  for value in (1e3, 1e20, torch.finfo(dtype).max):
    displacement=torch.tensor((value,-value),dtype=dtype)
    try:
      result=remap(torch.ones((2,2),dtype=dtype), displacement)
      rows.append({'dtype':str(dtype),'value':str(value),'result':'ok','sum':float(result.sum())})
    except Exception as exc:
      rows.append({'dtype':str(dtype),'value':str(value),'result':type(exc).__name__,'message':str(exc)})
print(json.dumps(rows))
