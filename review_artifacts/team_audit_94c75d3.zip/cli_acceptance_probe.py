from __future__ import annotations

import argparse
import importlib.util
import json
from pathlib import Path
import tempfile
import sys
import subprocess

import numpy as np


def load_benchmark():
    path = Path("/Users/yhlee/ADVAR/benchmarks/benchmark_variational_fso.py")
    spec = importlib.util.spec_from_file_location("advar_benchmark_probe", path)
    if spec is None or spec.loader is None:
        raise RuntimeError("benchmark module unavailable")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def cli_physical_setting_error() -> dict[str, object]:
    from advar import cli

    with tempfile.TemporaryDirectory(prefix="advar-cli-probe-") as directory:
        root = Path(directory)
        input_path = root / "input.npy"
        output_path = root / "out.npz"
        np.save(input_path, np.full((3, 4, 4), 20.0, dtype=np.float32), allow_pickle=False)
        results = {}
        for option in (
            "--pair-echo-dilation-m",
            "--phase-correlation-sidelobe-radius-m",
            "--minimum-growth-overlap-area-km2",
        ):
            old_argv = sys.argv
            sys.argv = [
                "advar-nowcast",
                str(input_path),
                str(output_path),
                option,
                "1000",
            ]
            try:
                try:
                    cli.main()
                except BaseException as error:
                    results[option] = {
                        "exception_type": type(error).__name__,
                        "exception": str(error),
                        "output_exists": output_path.exists(),
                    }
                else:
                    results[option] = {
                        "exception_type": None,
                        "output_exists": output_path.exists(),
                    }
            finally:
                sys.argv = old_argv
        return results


def cli_offline_input_statuses() -> dict[str, object]:
    from advar import cli

    cases = {
        "all_nan": np.full((3, 4, 4), np.nan, dtype=np.float32),
        "one_inf": np.full((3, 4, 4), 20.0, dtype=np.float32),
        "complex": np.full((3, 4, 4), 20.0 + 7.0j, dtype=np.complex64),
        "empty_height": np.empty((3, 0, 4), dtype=np.float32),
    }
    cases["one_inf"][1, 1, 1] = np.inf
    statuses: dict[str, object] = {}
    for name, frames in cases.items():
        with tempfile.TemporaryDirectory(prefix="advar-cli-status-") as directory:
            root = Path(directory)
            input_path = root / "input.npy"
            output_path = root / "out.npz"
            np.save(input_path, frames, allow_pickle=False)
            old_argv = sys.argv
            sys.argv = ["advar-nowcast", str(input_path), str(output_path)]
            try:
                try:
                    cli.main()
                except BaseException as error:
                    statuses[name] = {
                        "exception_type": type(error).__name__,
                        "exception": str(error),
                    }
                else:
                    with np.load(output_path, allow_pickle=False) as result:
                        statuses[name] = {
                            "data_status": result["data_status"].item(),
                            "forecast_finite_fraction": float(np.isfinite(result["forecast_dbz"]).mean()),
                            "coverage_by_frame": result["coverage_by_frame"].tolist(),
                        }
            finally:
                sys.argv = old_argv
    return statuses


def cli_pair_velocity_units() -> dict[str, object]:
    from advar import cli

    base = np.zeros((32, 32), dtype=np.float32)
    base[10:16, 10:16] = 40.0
    base[20:24, 25:29] = 20.0
    frames = np.stack([np.roll(base, (shift, shift), (0, 1)) for shift in (0, 1, 2)])
    common = ["--maximum-pair-velocity-disagreement-mps", "0.001"]
    grid = [
        "--valid-times",
        "2026-08-01T00:00:00Z",
        "2026-08-01T00:10:00Z",
        "2026-08-01T00:20:00Z",
        "--dx-m",
        "1000",
        "--dy-m",
        "1000",
        "--projection",
        "EPSG:5179",
        "--grid-hash",
        "0" * 64,
    ]
    outputs: dict[str, object] = {}
    for name, extra in (("without_grid", common), ("with_grid", common + grid)):
        with tempfile.TemporaryDirectory(prefix="advar-cli-units-") as directory:
            root = Path(directory)
            input_path = root / "input.npy"
            output_path = root / "out.npz"
            np.save(input_path, frames, allow_pickle=False)
            old_argv = sys.argv
            sys.argv = ["advar-nowcast", str(input_path), str(output_path), *extra]
            try:
                cli.main()
            finally:
                sys.argv = old_argv
            with np.load(output_path, allow_pickle=False) as result:
                outputs[name] = {
                    "motion_disagreement_px": result["motion_disagreement_px"].item(),
                    "motion_disagreement_mps": result["motion_disagreement_mps"].item(),
                    "motion_pair_conflict": result["motion_pair_conflict"].item(),
                }
    return outputs


def acceptance_backdated_timestamp() -> dict[str, object]:
    from advar.acceptance import RealCaseAcceptanceManifest

    # Only inspect the public decoder's error/normalization behavior; no artifact
    # is synthesized here because the report-only contract intentionally accepts
    # caller-provided case labels without semantic E2E claims.
    payload = {
        "contract": "advar-real-case-acceptance-manifest-v1",
        "mode": "REPORT_ONLY",
        "created_at": "1970-01-01T00:00:00Z",
        "sample_size_preflight_relative_path": "preflight.json",
        "sample_size_preflight_file_sha256": "0" * 64,
        "sample_size_preflight_digest": "1" * 64,
        "required_independent_physical_event_count": 1,
        "cases": [],
    }
    try:
        RealCaseAcceptanceManifest.from_json(json.dumps(payload, sort_keys=True, separators=(",", ":")))
    except BaseException as error:
        return {"exception_type": type(error).__name__, "exception": str(error)}
    return {"exception_type": None}


def acceptance_public_smoke() -> dict[str, object]:
    sys.path.insert(0, "/Users/yhlee/ADVAR/tests")
    from test_acceptance import RealCaseAcceptanceTests

    with tempfile.TemporaryDirectory(prefix="advar-acceptance-probe-") as directory:
        root = Path(directory).resolve()
        manifest = RealCaseAcceptanceTests().fixture(root)
        manifest_path = root / "manifest.json"
        report_path = root / "report.json"
        manifest_path.write_text(manifest.json, encoding="utf-8")
        command = [
            sys.executable,
            "-I",
            "/Users/yhlee/ADVAR/.github/scripts/run_real_case_acceptance.py",
            "--manifest",
            str(manifest_path),
            "--artifact-root",
            str(root),
            "--report",
            str(report_path),
        ]
        completed = subprocess.run(command, check=False, capture_output=True, text=True)
        report = json.loads(report_path.read_text(encoding="utf-8")) if report_path.exists() else None
        return {
            "returncode": completed.returncode,
            "stdout_digest_matches": report is not None and completed.stdout.strip() == report["report_digest"],
            "report_flags": None if report is None else {
                key: report[key]
                for key in (
                    "artifact_index_complete",
                    "observation_error_derivation_replayed",
                    "semantic_e2e_validated",
                    "sample_size_satisfied",
                    "eligible_for_scientific_review",
                    "authorizes_deployment",
                )
            },
            "verified_at": None if report is None else report["verified_at"],
            "stderr": completed.stderr,
        }


def benchmark_parser_bounds() -> dict[str, object]:
    module = load_benchmark()
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--max-wall-seconds", type=float, default=3600.0)
    parsed = parser.parse_args(["--max-wall-seconds", "nan"])
    return {
        "positive_minutes": module._positive_minutes("60,180"),
        "nan_wall_budget": parsed.max_wall_seconds,
        "nan_is_finite": bool(np.isfinite(parsed.max_wall_seconds)),
    }


def benchmark_public_smoke() -> dict[str, object]:
    # Reuse the repository's small 8x8 variational fixture and execute the
    # actual benchmark main with one in-horizon lead. This remains a bounded
    # public-path smoke, not the sensitivity suite.
    sys.path.insert(0, "/Users/yhlee/ADVAR/tests")
    from test_sensitivity import VariationalFSOTests
    from advar.linearization_artifact import save_p1_linearization
    from advar.run_artifact import save_forecast_run

    VariationalFSOTests.setUpClass()
    benchmark = load_benchmark()
    with tempfile.TemporaryDirectory(prefix="advar-benchmark-probe-") as directory:
        root = Path(directory)
        forecast_path = root / "forecast.npz"
        linearization_path = root / "linearization.npz"
        verification_path = root / "verification.npy"
        save_forecast_run(VariationalFSOTests.forecast, forecast_path)
        save_p1_linearization(VariationalFSOTests.analysis, linearization_path)
        np.save(verification_path, VariationalFSOTests.verification.numpy(), allow_pickle=False)
        old_argv = sys.argv
        sys.argv = [
            "benchmark_variational_fso.py",
            str(forecast_path),
            str(linearization_path),
            str(verification_path),
            "--lead-minutes",
            "10",
            "--metrics",
            "log_echo_mse",
            "--tile-size",
            "4",
            "--max-wall-seconds",
            "300",
        ]
        try:
            try:
                benchmark.main()
            except BaseException as error:
                return {"exception_type": type(error).__name__, "exception": str(error)}
            return {"exception_type": None}
        finally:
            sys.argv = old_argv


if __name__ == "__main__":
    print(json.dumps({
        "cli_physical_setting_error": cli_physical_setting_error(),
        "cli_offline_input_statuses": cli_offline_input_statuses(),
        "cli_pair_velocity_units": cli_pair_velocity_units(),
        "acceptance_backdated_timestamp_decoder": acceptance_backdated_timestamp(),
        "acceptance_public_smoke": acceptance_public_smoke(),
        "benchmark_parser_bounds": benchmark_parser_bounds(),
        "benchmark_public_smoke": benchmark_public_smoke(),
    }, sort_keys=True, default=str))
