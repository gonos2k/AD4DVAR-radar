from types import SimpleNamespace
import torch
from advar.sensitivity import (
    SparseRadarPerturbation,
    VariationalCandidatePrecheck,
    VariationalCandidateScore,
    VariationalCandidateRanking,
    _variational_candidate_ranking_digest,
)

p = SparseRadarPerturbation(
    torch.tensor([0], dtype=torch.int64),
    torch.tensor([1.0]),
    (3, 1, 1),
)
pre = VariationalCandidatePrecheck("candidate", p.digest, True, None)
score = VariationalCandidateScore(
    candidate_id="candidate",
    perturbation=p,
    predicted_metric_change=torch.tensor([[999.0]]),
    score=999.0,
    rank=1,
)
# This is intentionally a tiny typed-artifact probe.  Ranking __post_init__
# only needs the FSO digest to compute the ranking digest; validate_top_k later
# performs the separate full FSO validation.
fso_stub = SimpleNamespace(variational_fso_digest="a" * 64)
ranking = VariationalCandidateRanking(
    fso=fso_stub,
    scores=(score,),
    prechecks=(pre,),
    policy_digest="b" * 64,
    ranking_objective="unsupported-objective",  # type: ignore[arg-type]
    candidate_count=1,
    scoring_operations=1,
    whitener_operations_per_apply=1,
    observed_whitener_apply_count=1,
)
print("constructed", True)
print("ranking_objective", ranking.ranking_objective)
print("forged_prediction", float(ranking.scores[0].predicted_metric_change.item()))
print("forged_score", ranking.scores[0].score)
print("digest_self_consistent", ranking.ranking_digest == _variational_candidate_ranking_digest(ranking))
