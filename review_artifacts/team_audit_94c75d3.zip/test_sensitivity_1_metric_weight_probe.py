import sys

import torch

sys.path.insert(0, "tests")

from advar.nowcast import NowcastConfig, RadarGridTimeContract, nowcast
from advar.physics import dbz_to_echo
from advar.sensitivity import (
    SensitivityConfig,
    VerificationBundle,
    VerificationCellState,
    VerificationObservationErrorContract,
    VerificationObservationErrorPlan,
    OBSERVATION_ERROR_DERIVATION_ALGORITHM_DIGEST,
    compute_sensitivity_snapshot,
    forecast_metric,
)


def main() -> None:
    config = NowcastConfig(horizon_minutes=10)
    frames = torch.full((3, 4, 4), 20.0, dtype=torch.float64)
    grid = RadarGridTimeContract(
        valid_times=(
            "2026-08-05T00:00:00Z",
            "2026-08-05T00:10:00Z",
            "2026-08-05T00:20:00Z",
        ),
        dx_m=1000.0,
        dy_m=1000.0,
        projection="EPSG:5179",
        grid_hash="a" * 64,
    )
    result = nowcast(frames, config, grid_time_contract=grid)
    verification = result.forecast_dbz.detach().clone()
    verification[0, 0, 0] = -10.0
    valid = torch.ones_like(verification, dtype=torch.bool)
    state = torch.full_like(
        verification,
        int(VerificationCellState.OBSERVED_ECHO),
        dtype=torch.uint8,
    )
    state[0, 0, 0] = int(VerificationCellState.BELOW_DETECTION_CENSORED)
    quality = torch.ones_like(verification)
    std = torch.full_like(verification, 2.0)
    plan = VerificationObservationErrorPlan(
        radar_source_kind="single_site",
        source_registry_digest="0" * 64,
        calibration_registry_digest="1" * 64,
        range_elevation_validity_algorithm_digest=(
            OBSERVATION_ERROR_DERIVATION_ALGORITHM_DIGEST
        ),
        beam_blockage_algorithm_digest=OBSERVATION_ERROR_DERIVATION_ALGORITHM_DIGEST,
        attenuation_qc_digest="5" * 64,
        censoring_rule_digest="6" * 64,
        spatial_correlation_block_algorithm_digest="7" * 64,
        quality_weight_interpretation_digest="8" * 64,
        quality_weight_algorithm_digest=OBSERVATION_ERROR_DERIVATION_ALGORITHM_DIGEST,
        observation_std_algorithm_digest=OBSERVATION_ERROR_DERIVATION_ALGORITHM_DIGEST,
        observation_error_model_digest="9" * 64,
        source_assignment_algorithm_digest=OBSERVATION_ERROR_DERIVATION_ALGORITHM_DIGEST,
        minimum_detectable_echo_dbz=-10.0,
        observation_error_reference_std_dbz=2.0,
    )
    error = VerificationObservationErrorContract.from_tensors(
        plan=plan,
        frames_dbz=verification,
        valid_mask=valid,
        quality_weight=quality,
        observation_std_dbz=std,
        observation_state_code=state,
        source_radar_index_map=None,
        source_calibration_epochs=(("1" * 64, "2" * 64),),
        range_elevation_validity_domain_digest="3" * 64,
        beam_blockage_visibility_mask_digest="4" * 64,
        spatial_correlation_block_digest="7" * 64,
    )
    bundle = VerificationBundle(
        frames_dbz=verification,
        valid_mask=valid,
        valid_times=("2026-08-05T00:30:00Z",),
        grid_contract_digest=grid.digest,
        radar_product_digest="b" * 64,
        qc_pipeline_digest="5" * 64,
        mask_policy_digest="c" * 64,
        censor_policy_digest="6" * 64,
        reflectivity_resolution_dbz=0.5,
        quantization_origin_dbz=-10.0,
        threshold_bin_convention="nearest_rounding_threshold_censor",
        floor_representation_contract_digest="d" * 64,
        quality_weight=quality,
        observation_std_dbz=std,
        observation_state_code=state,
        observation_error_contract=error,
        contract="radar-verification-bundle-v6",
    )
    sensitivity = SensitivityConfig(
        metric_names=("log_echo_mse",), full_map_lead_minutes=(10,)
    )
    snapshot = compute_sensitivity_snapshot(
        frames[-1], result, bundle, sensitivity_config=sensitivity
    )
    forecast = dbz_to_echo(
        result.forecast_dbz[0], min_dbz=config.min_dbz, max_dbz=config.max_dbz
    )
    truth = dbz_to_echo(
        verification[0], min_dbz=config.min_dbz, max_dbz=config.max_dbz
    )
    point_mask = valid[0].clone()
    point_mask[0, 0] = False
    expected = forecast_metric(
        "log_echo_mse", forecast, truth, point_mask, config, sensitivity
    )
    all_cells = forecast_metric(
        "log_echo_mse", forecast, truth, valid[0], config, sensitivity
    )
    print("bundle_fso_metric_weight_00", float(bundle.fso_metric_weight[0, 0, 0]))
    print("snapshot_score", float(snapshot.forecast_scores[0, 0]))
    print("expected_point_weight_zero_score", float(expected))
    print("all_finite_score", float(all_cells))
    assert float(bundle.fso_metric_weight[0, 0, 0]) == 0.0
    assert torch.allclose(snapshot.forecast_scores[0, 0], all_cells)
    assert not torch.allclose(snapshot.forecast_scores[0, 0], expected)


if __name__ == "__main__":
    main()
