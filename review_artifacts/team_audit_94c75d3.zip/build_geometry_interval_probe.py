from __future__ import annotations

from decimal import Decimal, localcontext
import math
import random
import importlib

nowcast = importlib.import_module("advar.nowcast")

rng = random.Random(940753)
norm_failures = []
area_failures = []
for _ in range(20_000):
    # Keep products finite while covering scale/cancellation and signed entries.
    matrix = tuple(
        tuple(
            math.copysign(
                10.0 ** rng.uniform(-5.0, 5.0),
                -1.0 if rng.randrange(2) else 1.0,
            )
            for _ in range(2)
        )
        for _ in range(2)
    )
    offset = (rng.randint(-10_000, 10_000), rng.randint(-10_000, 10_000))
    value = nowcast._affine_displacement_norm_value_float64(matrix, offset)
    with localcontext() as context:
        context.prec = 100
        (xx, xr), (yx, yr) = (
            tuple(Decimal.from_float(v) for v in row) for row in matrix
        )
        row, column = map(Decimal, offset)
        exact_x = xx * column + xr * row
        exact_y = yx * column + yr * row
        exact_norm = (exact_x * exact_x + exact_y * exact_y).sqrt()
        if not (
            Decimal.from_float(value.lower) <= exact_norm
            <= Decimal.from_float(value.upper)
        ):
            norm_failures.append((matrix, offset, value, exact_norm))
        left = xx * yr
        right = xr * yx
        exact_area = abs(left - right)
    area = nowcast._affine_cell_area_value_float64(matrix)
    if not (
        Decimal.from_float(area.lower) <= exact_area
        <= Decimal.from_float(area.upper)
    ):
        area_failures.append((matrix, area, exact_area))
print("norm_failures", len(norm_failures))
if norm_failures:
    print("first_norm_failure", norm_failures[0])
print("area_failures", len(area_failures))
if area_failures:
    print("first_area_failure", area_failures[0])
