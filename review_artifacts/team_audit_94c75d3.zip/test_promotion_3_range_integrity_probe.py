import torch
from advar import promotion as promotion_module

x = torch.tensor([[0.0, 1000.0]], dtype=torch.float32)
y = torch.zeros_like(x)
contract = promotion_module.RangeGeometryContract(
    radar_site_digest="a" * 64,
    radar_site_location_digest="b" * 64,
    grid_contract_digest="c" * 64,
    radar_x_m=0.0,
    radar_y_m=0.0,
    range_regime_labels=("near", "far"),
    radial_distance_edges_m=(0.0, 750.0, 5000.0),
    horizontal_range_rule_digest="d" * 64,
    grid_x_m_digest=promotion_module.tensor_digest(x),
    grid_y_m_digest=promotion_module.tensor_digest(y),
)
original = promotion_module.resolve_range_geometry(contract, grid_x_m=x, grid_y_m=y)
object.__setattr__(contract, "radar_x_m", 1000.0)
# The frozen contract digest is stale. A boundary resolver should reject it.
accepted = promotion_module.resolve_range_geometry(contract, grid_x_m=x, grid_y_m=y)
print({
    "stale_digest_equals_recomputed": contract.contract_digest == promotion_module.json_digest(contract.payload),
    "original_masks": [mask.tolist() for mask in original.masks],
    "mutated_masks": [mask.tolist() for mask in accepted.masks],
    "partition_retains_stale_digest": accepted.range_geometry_contract_digest == contract.contract_digest,
})
