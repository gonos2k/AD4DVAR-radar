# test_promotion_4 audit

Baseline: `94c75d3323c986b6fb2963336b906acc85384e12`  
Role: GREEN  
Assigned range: `tests/test_promotion.py:15601-20794` (read completely in bounded chunks)

## Confirmed findings

None. I found no reachable production defect in the assigned range or its serialized replay, legacy, event-catalog, scoring-start, training-start, provenance, geometry, and operational-history callers.

## GREEN preserved

- Event catalog registration is a durable prerequisite for both process kinds. `EpisodeLedger.append_trusted_process_start_receipt` validates the scheduler trust snapshot and signed receipt, checks the exact catalog result row, and enforces `started_at` after the catalog append and before the trusted current time (`src/advar/ledger.py:12620-12795`). The scoring branch additionally requires the exact registered scoring-input artifact and its preregistered decision-rule binding.
- Scoring algorithm and metric digests are intentionally digest fields in the retained holdout plan. The live launch path binds them to `algorithm_bundle_digest()`, `scoring_metric_engine_identity_digest()`, the runtime digest, and the execution contract (`src/advar/ledger.py:12620-12665`). The assigned test correctly allows altered plan objects through the audit-only plan validator, then verifies that a mismatched live scoring start/artifact is rejected.
- Training completion cannot be appended without the exact ledger-backed start row. Completion validation also preserves the start lineage, process log digest, scheduler authority, and target-source trust snapshot (`src/advar/ledger.py:12795-13060`).
- Current scoring replay bundles require registered manifest bytes, exact member set/checksums, tensor shape/dtype/digest checks, current raw-trust activation, current raw provenance, and verification provenance. Legacy contracts are decoded into explicit audit types and cannot be used for semantic replay (`src/advar/ledger.py:12222-12620`, `src/advar/ledger.py:20490-20695`). This preserves the intended boundary between historical audit evidence and promotion input.
- Operational legacy anchors are rebuilt from immutable provenance bytes and checked against the v1/v2 resolution payload, observed slot identity/kind, committed artifact, receipt digest, and canonical timestamp. The resulting predecessor is used as the chain base before a new signed history row (`src/advar/ledger.py:10574-10990`). The assigned migration/tampering test exercises deletion/reinsertion and changed-preimage rejection; I found no way for a changed anchor to enter the chain through the public append path.
- Geometry, raw-resolution, holdout provenance, and event-level scoring paths retain their digest and chronology checks. The event weighted estimand averages within event first and then weights events equally, preserving the case-replication invariant (`src/advar/promotion.py:20487-20505`).

## Unconfirmed candidates reviewed

- `_decode_start_receipt` and related JSON decoders can raise a raw `KeyError`/`TypeError` for severely malformed storage before their normal `ValueError` wrapper. This is a fail-closed rejection of corrupted or operator-mutated storage, with no authentication or acceptance bypass found; it is not a production finding.
- `validate_neural_prior_holdout_plan` does not compare the preregistered algorithm digest to the current implementation by itself. That behavior is deliberate for retaining historical/audit plan objects; the reachable scoring-start and completion paths perform the current algorithm/runtime/metric checks above. No issue found.
- `ResolvedRawObservationReceipt.validate_against` relies on its typed attestation construction for signature verification. Bypassing construction with `object.__setattr__` is a private frozen-object tampering probe, while public JSON/ledger decoders reconstruct and validate the signed attestation. No public-path bypass found.

## Commands and results

The runnable deterministic probe and captured output are `/tmp/advar-team-audit-94c75d3/test_promotion_4_probe.sh` and `/tmp/advar-team-audit-94c75d3/test_promotion_4_probe.out`.

- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I -m pytest -q tests/test_promotion.py -k 'scoring_start_requires_registered_catalog_and_trusted_time or training_completion_requires_a_ledger_backed_start or scoring_algorithm_must_match_the_preregistered_plan' --maxfail=1` → `3 passed, 224 deselected in 72.73s`.
- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I -m pytest -q tests/test_promotion.py -k 'trusted_process_start_receipt_rejects_signature_tampering' --maxfail=1` → `1 passed, 226 deselected in 7.69s`.

No full baseline or promotion suite was run. Findings are based on the assigned test range, the production callers listed above, and the selected probes.
