import torch
from dataclasses import replace
import advar.variational as v
from advar.physics import RemapCell
coords=torch.arange(8,dtype=torch.float64); y,x=torch.meshgrid(coords,coords,indexing='ij')
blob=-10+40*torch.exp(-((y-3.5)**2+(x-3.5)**2)/4)
frames=torch.stack((blob,blob-1,blob))
obs,frozen=v.prepare_analysis(frames,nowcast_config=v.NowcastConfig(horizon_minutes=10),analysis_config=v.AnalysisConfig(censored_background_policy='detection_limit',maximum_outer_iterations=8,maximum_pcg_iterations=100,pcg_relative_tolerance=1e-8))
r=v.solve_analysis(obs,frozen)
print('base',r.used_fallback,r.converged,r.linearization is not None,r.reason)
lin=r.linearization
assert lin is not None
print('cells',lin.frozen.analysis_remap_cells,'control dyn',r.control[-3:])
# Deliberately alter fixed branch by one whole cell; recompute self-consistent content digest.
wrong=replace(lin.frozen,analysis_remap_cells=(RemapCell(lin.frozen.analysis_remap_cells[0].y+1,lin.frozen.analysis_remap_cells[0].x),lin.frozen.analysis_remap_cells[1]))
wrong_lin=v._content_address_linearization(r.control,replace(lin,frozen=wrong))
try:
 v.validate_analysis_linearization_content(r.control,wrong_lin)
 print('content_validator=ACCEPTED')
except Exception as e:
 print('content_validator=',type(e).__name__,str(e))
print('cells_match_actual',v._analysis_remap_cells_match(r.control,wrong))
