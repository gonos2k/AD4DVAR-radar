# cli_acceptance audit (GREEN/RED)

Baseline: `94c75d3323c986b6fb2963336b906acc85384e12`  
Environment: `/Users/yhlee/ADVAR/.venv/bin/python` (Python 3.12.13, Torch 2.13.0), `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1`.  
Scope: read-only inspection and bounded public-path probes; no repository source or test changes.

## Confirmed findings

### CLI research mode silently ignores an m/s pair-conflict threshold without a grid contract (P2 candidate)

Location: `src/advar/cli.py:1039-1048`, `src/advar/cli.py:622-628`; the downstream selection is `src/advar/nowcast.py:8451-8476`.

The CLI accepts `--maximum-pair-velocity-disagreement-mps` in research mode without requiring `--valid-times`, `--dx-m`, `--dy-m`, `--projection`, and `--grid-hash`. With no grid contract, `_motion_disagreement_mps()` must return NaN and `_motion_pairs_are_inconsistent()` falls back to the pixel threshold, so the supplied m/s threshold is recorded in `nowcast_config_json` but has no effect. A physical unit setting should either require the grid contract or be rejected before execution.

Small public-path reproduction (32x32 translated two-feature field, three frames with shifts 0/1/2, m/s threshold `0.001`):

* Without grid metadata: `motion_disagreement_px=0.0021719139`, `motion_disagreement_mps=NaN`, `motion_pair_conflict=False`.
* With a 1000 m grid contract and the same threshold: `motion_disagreement_mps=0.0036198564`, `motion_pair_conflict=True`.

The only difference is the grid/time contract. This is an actual `advar-nowcast` public invocation and output archive, not a mocked helper. It affects research-mode pair selection/conflict evidence and can make the archive’s declared m/s policy disagree with the criterion used. Operational mode already requires the calibrated physical setting and grid metadata, so the boundary is research mode.

### Three other physical pair settings fail after argument parsing with an uncaught `ValueError` (P3)

Location: `src/advar/cli.py:1038-1048` omits `--pair-echo-dilation-m`, `--phase-correlation-sidelobe-radius-m`, and `--minimum-growth-overlap-area-km2`; downstream contract is `src/advar/nowcast.py:7413-7418`.

Each option is accepted without grid/time metadata, then a valid `[3,4,4]` input reaches `nowcast()` and raises `ValueError("physical pair settings require a grid/time contract")`. No output is written and argparse does not emit a normal usage error. The settings are correctly rejected downstream, so this is an error-path/contract consistency defect rather than a wrong forecast. The parser’s physical preflight should include all three settings.

## Unconfirmed or boundary candidates

* `src/advar/cli.py:432-434,666` does not reject complex NumPy input. A public invocation with a `[3,4,4]` `complex64` array containing `20+7j` emits PyTorch’s warning “Casting complex values to real discards the imaginary part” and succeeds with an OBSERVED forecast based only on 20. Real/NaN/Inf handling is intentional (`prepare_input` uses finite masks), but complex dBZ has no physical meaning and should likely be rejected before casting. I classify this as an input-contract hardening candidate because the CLI help specifies shape but no dtype, and README’s `.float()` example also permits the cast; no real producer was shown to emit complex radar volumes.
* `src/advar/acceptance.py:410-431` intentionally reports `verified_at=manifest.created_at` and keeps `semantic_e2e_validated`, `sample_size_satisfied`, `eligible_for_scientific_review`, and `authorizes_deployment` false. The installed public runner was exercised with the full synthetic fixture: return code 0, digest printed matched report bytes, `artifact_index_complete=true`, all authority/scientific flags remained false. The timestamp provenance concern is a prior report-only boundary (R129-009), not a new acceptance authority bypass in this audit.
* `benchmarks/benchmark_variational_fso.py:96-103` loads the raw verification `.npy` before the RSS/compute budgets and does not cap its input size. This is a resource-hardening candidate only; forecast and linearization loaders have archive limits, and no safe large-file allocation was attempted. The benchmark’s emitted FSO is legacy/raw-tensor lineage unless a typed bundle is used, which keeps it diagnostic rather than promotion authority.

## GREEN preserved

* `tests/test_acceptance.py` and `tests/test_cli.py` passed as targeted tests: **26 tests, 22 subtests, 18 warnings, 9.28 s**.
* Installed editable package import under `python -I` resolved to `/Users/yhlee/ADVAR/src/advar`; package metadata reported `0.114.0`; installed `advar-nowcast --help` exposed the current CLI options.
* P0 CLI smoke produced an 18-frame finite archive and `load_forecast_run(...).validate_issuance()` passed. All-NaN input became `UNAVAILABLE` with zero coverage and all-Inf/finite mixed input became `PARTIAL` with finite forecast output; these are intentional finite-mask semantics.
* The bounded benchmark public smoke used the repository’s 8x8 converged P1 fixture, one in-horizon lead, and one metric. It emitted `p1-variational-fso-benchmark-v4`, `benchmark_passed=true`, finite Gauss–Newton defect `0.2321902552`, and matching forecast/linearization/FSO digests.
* The acceptance runner remains report-only and content-addressed at its declared scope: file bytes, stage contract, one product digest field, typed preflight identity, exact stage chain, canonical times, path ancestry, and non-authorizing report flags were all exercised by the existing tests and the public runner smoke.
* Grid/time metadata canonicalizes `+09:00` input times to UTC; physical grid spacing and affine matrix are validated by `RadarGridTimeContract`. QC masks remain strict boolean `[3,H,W]` inputs, and common-bias mode preflight occurs before mode materialization.

## Commands, artifacts, and limitations

Runnable probe and latest combined stdout are stored at:

* `/tmp/advar-team-audit-94c75d3/cli_acceptance_probe.py`
* `/tmp/advar-team-audit-94c75d3/cli_acceptance_probe.stdout.json`

Commands:

```text
OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -m pytest -q tests/test_acceptance.py tests/test_cli.py
OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-team-audit-94c75d3/cli_acceptance_probe.py
/Users/yhlee/ADVAR/.venv/bin/python -I -c 'import advar, advar.cli; print(advar.__file__); print(advar.cli.__file__)'
/Users/yhlee/ADVAR/.venv/bin/advar-nowcast --help
```

The benchmark smoke materializes its temporary synthetic fixture inside the probe and is bounded to one 8x8 lead/metric. No full baseline, production deployment, real radar corpus, MPS P1, CUDA, or large resource-failure experiment was run. The complex-input and raw verification-file observations are malformed-input/resource candidates, not evidence of a normal producer failure.
