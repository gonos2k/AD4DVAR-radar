from __future__ import annotations

import torch
from torch import nn

from advar.nowcast import ForecastRunContract, NowcastConfig
from advar.promotion import NeuralPriorRegimeClassifier


class Fixed(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.anchor = nn.Parameter(torch.zeros(()))

    def forward(self, value: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        del value
        return (
            self.anchor + torch.tensor([4.0, 0.0]),
            self.anchor + torch.tensor([4.0]),
        )


def main() -> None:
    frames = torch.zeros((3, 2, 2), dtype=torch.float32)
    run = ForecastRunContract.from_inputs(
        NowcastConfig(), frames, torch.ones_like(frames, dtype=torch.bool), None
    )
    classifier = NeuralPriorRegimeClassifier(
        Fixed().eval(),
        example_frames=frames,
        regime_labels=("known", "unknown"),
        range_regime_labels=("near",),
        classifier_algorithm_digest="2" * 64,
    )
    classifier.classify(frames, input_run=run)
    try:
        classifier.classify(
            frames,
            input_run=run,
            qc_valid_mask=torch.ones_like(frames, dtype=torch.bool),
            quality_weight=torch.ones_like(frames),
            observation_std_dbz=torch.full_like(frames, 2.0),
            source_available_mask=torch.ones_like(frames, dtype=torch.bool),
        )
    except ValueError as error:
        print({"direct_legacy_without_channels": "accepted", "with_channels": str(error)})
    else:
        raise AssertionError("legacy classifier unexpectedly accepted learned channels")


if __name__ == "__main__":
    main()
