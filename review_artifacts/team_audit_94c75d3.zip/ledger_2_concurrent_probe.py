"""Exercise public operational provenance append/resume concurrently."""

from __future__ import annotations

import json
import tempfile
import sys
from concurrent.futures import ThreadPoolExecutor
from dataclasses import replace
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, "/Users/yhlee/ADVAR/tests")
import test_promotion
from advar import ledger as ledger_module
from advar import promotion as promotion_module
from advar.ledger import EpisodeLedger
from advar.promotion import Ed25519PrivateKey


class ProbeLedger(EpisodeLedger):
    pass


def main() -> None:
    test_case = test_promotion.NeuralPriorPromotionTests("runTest")
    holdout = test_case.plan()
    planned = holdout.cases[0]
    input_plan = next(
        item for item in holdout.input_plans
        if item.plan_digest == planned.input_plan_digest
    )
    sampling_unit = next(
        item for item in holdout.meteorological_sampling_units
        if item.sampling_unit_digest == planned.meteorological_sampling_unit_digest
    )
    slots = tuple(
        item for item in holdout.raw_observation_slot_plans
        if item.slot_digest in sampling_unit.raw_observation_slot_digests
    )
    range_band = next(
        item for item in holdout.range_band_contracts
        if item.contract_digest == planned.range_band_contract_digest
    )
    geometry = next(
        item for item in holdout.range_geometry_contracts
        if item.contract_digest == range_band.range_geometry_contract_digest
    )
    issuance = next(
        item for item in holdout.operational_issuance_domain_plans
        if item.plan_digest == planned.operational_issuance_domain_plan_digest
    )
    processor_key = Ed25519PrivateKey.from_private_bytes(b"\x23" * 32)
    operational_plan = ledger_module.OperationalAnalysisInputProvenancePlan(
        plan_id="concurrent-operational-cycle",
        input_plan=input_plan,
        raw_observation_slot_plans=slots,
        raw_ingestor_trust_store=holdout.raw_ingestor_trust_store,
        analysis_processor_id="test-analysis-processor",
        analysis_processor_public_key_hex=processor_key.public_key().public_bytes_raw().hex(),
        analysis_processor_trust_store_digest="7" * 64,
        range_geometry_contract=geometry,
        operational_issuance_domain_plan=replace(
            issuance, case_id="concurrent-operational-cycle"
        ),
        registered_at="2026-08-07T00:00:00Z",
    )
    # Typed raw receipt/run fixture used by the repository's public operational
    # provenance test.
    _, _, _, _, _, base_run, _, receipts, _ = test_case.analysis_input_context(
        1, plan=holdout
    )
    resolution = ledger_module.OperationalRawVolumeResolutionReceipt(
        provenance_plan_digest=operational_plan.plan_digest,
        input_plan_digest=input_plan.plan_digest,
        slot_identity_bindings=tuple(
            (item.slot_plan_digest, item.raw_volume_identity.identity_digest)
            for item in receipts
        ),
        history_entries=tuple(
            ledger_module.OperationalRawResolutionHistoryEntry.issue(
                provenance_plan_digest=operational_plan.plan_digest,
                slot_digest=item.slot_plan_digest,
                resolution_identity_digest=item.raw_volume_identity.identity_digest,
                resolution_kind="resolved",
                previous_entry_digest=ledger_module.OPERATIONAL_RAW_RESOLUTION_GENESIS_DIGEST,
                transition="original",
                reason="concurrent-public-path-probe",
                issued_at=max(
                    retained.raw_volume_attestation.received_at
                    for retained in receipts
                ),
                authority_id=operational_plan.analysis_processor_id,
                authority_private_key=processor_key,
            )
            for item in receipts
        ),
        resolved_at=max(
            item.raw_volume_attestation.received_at for item in receipts
        ),
    )
    derivation = ledger_module.AnalysisInputDerivationArtifact.from_products(
        case_id=operational_plan.plan_id,
        input_plan=input_plan,
        resolved_raw_observations=receipts,
        global_resolution_receipt=resolution,
        run=base_run,
        resolved_source_coverage=None,
        background_frames_dbz=None,
        processed_at=(
            promotion_module._canonical_datetime(resolution.resolved_at)
            + timedelta(seconds=10)
        ).isoformat(),
        processor_id=operational_plan.analysis_processor_id,
        processor_private_key=processor_key,
    )
    run = replace(
        base_run,
        analysis_input_derivation_artifact_json=json.dumps(
            derivation.payload, sort_keys=True, separators=(",", ":")
        ),
        analysis_input_derivation_artifact_digest=derivation.artifact_digest,
    )
    append_kwargs = {
        "run": run,
        "resolved_raw_observations": receipts,
        "raw_resolution": resolution,
        "derivation": derivation,
        "resolved_source_coverage": None,
        "raw_ingestor_trust_store_path": "/unused/raw.json",
        "analysis_processor_trust_store_path": "/unused/deployment.json",
        "provenance_commit_signer": test_case.provenance_ledger_signer(
            (promotion_module._canonical_datetime(derivation.processed_at)
             + timedelta(seconds=1)).isoformat()
        ),
    }
    with tempfile.TemporaryDirectory() as directory:
        ledger = ProbeLedger(Path(directory))
        authority_trust = test_case.provenance_authority_trust_store(
            ledger,
            authority_id=operational_plan.analysis_processor_id,
            private_key=processor_key,
            content_digest="7" * 64,
        )
        trusted_now = promotion_module._canonical_datetime(derivation.processed_at) + timedelta(seconds=1)
        with (
            patch.object(
                ledger_module,
                "_load_promotion_deployment_authority_trust_store",
                return_value=authority_trust,
            ),
            patch.object(
                ledger_module,
                "_load_raw_ingestor_trust_store",
                return_value=holdout.raw_ingestor_trust_store,
            ),
            patch.object(ledger_module, "datetime", wraps=datetime) as clock,
        ):
            clock.now.return_value = datetime.fromisoformat("2026-08-08T00:00:00+00:00")
            ledger.append_operational_analysis_input_provenance_plan(
                operational_plan,
                analysis_processor_trust_store_path="/unused/deployment.json",
            )
            clock.now.return_value = trusted_now
            # Public append commits status=prepared before this reconciliation
            # callback. Force only the post-commit callback to fail.
            with patch.object(
                ProbeLedger,
                "reconcile_prepared_analysis_input_provenance",
                side_effect=RuntimeError("simulated postcommit crash"),
            ):
                try:
                    ledger.append_operational_analysis_input_provenance(
                        operational_plan, **append_kwargs
                    )
                except RuntimeError as error:
                    assert str(error) == "simulated postcommit crash"

            with ledger._connect() as connection:
                state_before = connection.execute(
                    "SELECT status,usable FROM analysis_input_provenance_commits "
                    "WHERE artifact_digest = ?", (derivation.artifact_digest,)
                ).fetchone()

            def resume(_: int) -> str:
                try:
                    value = ledger.reconcile_prepared_analysis_input_provenance(
                        derivation.artifact_digest,
                        raw_ingestor_trust_store_path="/unused/raw.json",
                        analysis_processor_trust_store_path="/unused/deployment.json",
                    )
                    return f"ok:{value}"
                except Exception as error:
                    return f"error:{type(error).__name__}:{error}"

            with ThreadPoolExecutor(max_workers=2) as executor:
                outcomes = tuple(executor.map(resume, (0, 1)))
            with ledger._connect() as connection:
                state_after = connection.execute(
                    "SELECT status,usable FROM analysis_input_provenance_commits "
                    "WHERE artifact_digest = ?", (derivation.artifact_digest,)
                ).fetchone()
        print(json.dumps({
            "artifact_digest": derivation.artifact_digest,
            "state_before": state_before,
            "outcomes": outcomes,
            "state_after": state_after,
        }, sort_keys=True))


if __name__ == "__main__":
    main()
