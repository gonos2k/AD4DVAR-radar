"""Bounded read-only audit probes for test_sensitivity_2."""

from fractions import Fraction

import torch

import advar.sensitivity as s


def main() -> None:
    # One source has no rival; a finite eligible interval must be retained.
    lower = torch.tensor([[[[1.0]]]], dtype=torch.float64)
    upper = torch.tensor([[[[1.0]]]], dtype=torch.float64)
    eligible = torch.ones_like(lower, dtype=torch.bool)
    one = s._strictly_dominating_source_scores(
        score_lower=lower,
        score_upper=upper,
        eligible=eligible,
    )
    assert torch.equal(one, lower)

    # Tied source intervals are intentionally uncertified: strict dominance
    # prevents backend/order dependent ownership.
    tied = s._strictly_dominating_source_scores(
        score_lower=torch.cat((lower, lower)),
        score_upper=torch.cat((upper, upper)),
        eligible=torch.ones((2, 1, 1, 1), dtype=torch.bool),
    )
    assert torch.count_nonzero(tied) == 0

    # The directed range enclosure contains the exact rational endpoints.
    projected = torch.tensor([[[[100.0]]]], dtype=torch.float64)
    lo, hi = s._ground_range_interval_km_float64(projected)
    e = Fraction.from_float(s.CURRENT_RADAR_METRIC_DOMAIN.maximum_linear_scale_error)
    exact_lo = Fraction(100) / (Fraction(1) + e)
    exact_hi = Fraction(100) / (Fraction(1) - e)
    assert Fraction.from_float(float(lo.item())) <= exact_lo
    assert Fraction.from_float(float(hi.item())) >= exact_hi
    print({"one_source": one.tolist(), "tied": tied.tolist(), "range": (float(lo), float(hi))})


if __name__ == "__main__":
    main()
