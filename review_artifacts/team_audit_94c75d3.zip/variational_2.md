# variational_2 GREEN audit

- Unit: `variational_2`
- Baseline: `94c75d3323c986b6fb2963336b906acc85384e12`
- Assigned source: `src/advar/variational.py:4901-9756` (read in ten contiguous chunks)
- Scope: solver acceptance, final frozen IRLS/Gauss–Newton polish, remap branch identity, posterior/identifiability diagnostics, amplitude gates, bounded scalar/radial transforms, input validation, and retained P1 linearization content.
- MPS P1: excluded from new findings. The existing full MPS P1 NO-GO is R01 and was not counted as a CPU regression.

## Confirmed finding

### P2/P3 boundary: self-addressed P1 artifact can retain remap cells inconsistent with its control

Locations:

- `src/advar/variational.py:8870-8887` computes the expected cells from the decoded control.
- `src/advar/variational.py:8891-8905` already has `_analysis_remap_cells_match` for that relation.
- `src/advar/variational.py:9694-9756` (`validate_analysis_linearization_content`) validates shapes, whitening, digests, and runtime, but never checks that `linearization.frozen.analysis_remap_cells` matches the decoded control.
- The public artifact path calls this validator and then replays `_analysis_trajectory` with the retained cells (`src/advar/linearization_artifact.py` loader path), so a retained branch can be used by delayed P1/FSO calculations.

Mathematical contract: remap is piecewise affine in displacement. A frozen linearization is valid only when each retained cell is the floor cell of `step * decode(control)`; otherwise the replayed Jacobian is for a different piecewise branch. The content digest authenticates the values relative to itself, but does not establish this invariant.

Reproduction (`variational_2_artifact_branch_probe.py`, output in the audit directory):

1. Use a finite CPU `float64` 3×4×4 constant field (`20 dBZ` at all three times), whose baseline displacement and growth are exactly zero.
2. Set control to `initial_control(frozen)`, whose correct cells are `(0,0),(0,0)`.
3. Replace only the retained second cell with `RemapCell(-1, 0)`, recompute the content digest, and construct a self-consistent P1 state.
4. The trajectory values are identical (`frame diff = 0.0`) because the clamped fraction still selects the zero shift, but the dynamics Jacobian differs by `199.79999999999586`.
5. `_analysis_remap_cells_match(control, wrong_frozen)` is `False`; nevertheless `validate_analysis_linearization_content(...)` accepts it, and the public `save_p1_linearization` → `load_p1_linearization` round trip prints `public_save_load=ACCEPTED loaded_match False`.

Impact boundary: this is a malformed/self-addressed artifact case, not a normal producer output or an ordinary byte-tamper (the ordinary artifact digest catches changed bytes). A producer or storage layer that rewrites both content digests can pass the current replay validator and feed a branch-inconsistent tangent into delayed FSO/adjoint code. The smallest corrective invariant is to reject retained cells unless `_analysis_remap_cells_match(control, linearization.frozen)` is true (and to keep the existing frozen-cell fraction validation semantics).

## Unconfirmed candidate

### `_validate_control` accepts NaN/Inf controls

At `src/advar/variational.py:9147-9164`, `_validate_control` checks rank, length, floating dtype, device, dtype, active indices, and prior metadata but not `torch.isfinite(control)`. The module-level `analysis_trajectory`, `observation_residual_dbz`, and `whitened_observation_residual` paths call this validator.

Probe (`variational_2_nonfinite_probe2.py`) with constant 3×4×4 CPU `float64` frames and one NaN dynamics control: `analysis_trajectory` returns `displacement_yx = [0, 0]` but `frames_linear` is nonfinite, while `solve_analysis` fails closed to its baseline with `positivity_violation`. ±Inf controls are also accepted by the helper and saturate the bounded dynamics transform. This is malformed caller input and the solver's public acceptance path is guarded by `_evaluate_control`; no normal producer failure was shown. It remains a numerical input-contract candidate because a public trajectory/residual helper can return nonfinite physical echoes instead of rejecting the control.

## GREEN preserved

- Scalar `_bounded_update` and radial `_bounded_vector_update` preserve baseline values at saturation, allow inward moves, block outward moves, remain in their configured bounds, and retain finite first/second derivatives at the origin and extreme finite controls.
- The selected CPU numerical review passed 5 tests (12 subtests) covering zero-background derivatives, large-control Jacobians, huge-background projection, and small float32 residual cost/solve. The selected variational tests passed 8 tests (3 subtests) covering radial equivariance, saturation behavior, stationarity block scaling, final polish, and remap-cell tracking.
- Solver acceptance recomputes actual objective decrease, amplitude admissibility, representability, positivity, and final robust/IRLS stationarity. Final polish refreshes remap cells on branch changes and explicitly checks its retained branch before returning.
- Pseudo-Huber cost uses a stable `hypot`/rationalized expression; fixed residual VJP/JVP paths preserve AD on CPU. MPS failures remain the pre-existing R01 unsupported full-P1 boundary.

## Commands and results

- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I -m pytest -q tests/test_numerical_review.py -k 'zero_background_velocity_derivatives or large_control_has_finite_velocity_jacobian or large_background_projection_keeps_direction or small_float32_residual_cost or small_float32_residual_solve'` → `5 passed, 9 deselected` (12 subtests).
- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I -m pytest -q tests/test_variational.py -k 'radial_velocity_control_is_rotation_equivariant or radial_velocity_control_preserves_baseline_and_local_scale or bounded_controls_allow_inward_updates_at_saturated_baselines or radial_velocity_control_keeps_large_controls_inside_speed_ball or block_stationarity_is_resolution_stable or sparse_field_gradient_cannot_hide_behind_rms or final_linearization_is_polished_to_stationarity or final_linearization_tracks_remap_branch_changes'` → `8 passed, 134 deselected` (3 subtests).
- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I -m pytest -q tests/test_variational.py -k 'linearization_artifact_restarts_identical_fso or linearization_artifact_rejects_tamper or final_linearization_tracks_remap_branch_changes'` → `1 passed, 141 deselected`.
- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I -m pytest -q tests/test_sensitivity.py -k 'p1_linearization_artifact_restarts_identical_fso or p1_linearization_artifact_rejects_tamper_and_runtime_mismatch'` → `2 passed, 91 deselected`.
- `variational_2_artifact_branch_probe.py` → forged branch accepted through public save/load with identical values but a `199.79999999999586` dynamics-Jacobian discrepancy.
- `variational_2_nonfinite_probe2.py` → NaN trajectory helper returns nonfinite frames; `solve_analysis` falls back with `positivity_violation`.

No repository source or test files were modified. The existing dirty files and parent-agent outputs were preserved. No full baseline or full variational/sensitivity suite was run.

