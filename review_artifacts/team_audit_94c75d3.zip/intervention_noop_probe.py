import sys
from pathlib import Path
import sqlite3
import tempfile
from types import SimpleNamespace
from unittest.mock import patch

sys.path.insert(0, "/Users/yhlee/ADVAR/src")
sys.path.insert(1, "/Users/yhlee/ADVAR/tests")

import torch
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from advar.intervention import (
    InterventionActionGenerator,
    OperatorActionApproval,
    ProspectiveInterventionDecision,
    RealizedInterventionReceipt,
    ReusableInterventionPolicyEvidence,
)
from advar import ledger as ledger_module
from advar.ledger import EpisodeLedger
from test_ledger import _prospective_run_and_context


class NoOpQc(torch.nn.Module):
    def forward(self, context):
        return context[1].to(torch.bool), context[2], torch.tensor(
            True, device=context.device
        )


frames = torch.zeros((3, 2, 2), dtype=torch.float64)
masks = torch.ones_like(frames, dtype=torch.bool)
before_run, before_context, plan_digest, _ = _prospective_run_and_context(
    frames, masks
)
after_run, after_context, _, _ = _prospective_run_and_context(frames, masks)
generator = InterventionActionGenerator.from_model(
    NoOpQc().eval(), before_context,
    intervention_type="realized_qc_intervention",
    action_reason="no-op audit",
)
policy = ReusableInterventionPolicyEvidence(
    policy_id="noop-policy",
    action_generator_digest=generator.generator_digest,
    context_schema_digest=before_context.context_schema_digest,
    applicability_region_digest=before_context.applicability_region_digest,
    execution_policy_digest="e" * 64,
    allowed_intervention_types=("realized_qc_intervention",),
    maximum_absolute_delta_dbz=2.0,
    maximum_changed_fraction=1.0,
    maximum_global_quality_precision_scale_l2=4.0,
    maximum_tile_quality_precision_scale_l2=4.0,
    validation_evidence_digests=("d" * 64,),
)
decision = ProspectiveInterventionDecision.from_policy(
    policy,
    action_generator=generator,
    decision_id="noop-decision",
    case_id="case-1",
    radar_id="radar-1",
    intervention_type="realized_qc_intervention",
    actual_input_context=before_context,
    actual_input_before_run=before_run,
    input_plan_digest=plan_digest,
    decision_basis_digest="d" * 64,
    decision_policy_digest="e" * 64,
    decision_trust_store_digest="f" * 64,
    decided_at="2026-08-08T00:22:00Z",
    observation_valid_time="2026-08-08T00:20:00Z",
    input_available_time="2026-08-08T00:21:00Z",
    decision_deadline="2099-08-08T00:30:00Z",
    publication_time="2099-08-08T01:00:00Z",
)
print("decision_created", decision.decision_digest)
print("action_changed_pixels", decision.action_safety_diagnostics_json)
try:
    RealizedInterventionReceipt.from_decision(
        decision,
        actual_input_before_context=before_context,
        actual_input_before_run=before_run,
        actual_input_after_context=after_context,
        actual_input_after_run=after_run,
        action_policy=policy,
        action_generator=generator,
        executor_key_id="executor-noop",
        executor_trust_store_digest="0" * 64,
        executor_private_key=Ed25519PrivateKey.generate(),
        executor_sequence_number=1,
        applied_time="2026-08-08T00:23:00Z",
        receipt_time="2026-08-08T00:23:00Z",
    )
except Exception as error:
    print("receipt_result", type(error).__name__, str(error))
else:
    print("receipt_result", "unexpectedly accepted")

operator_private = Ed25519PrivateKey.generate()
approval = OperatorActionApproval.from_decision(
    decision,
    operator_key_id="operator-noop",
    operator_role="duty-meteorologist",
    operator_trust_store_digest="1" * 64,
    operator_private_key=operator_private,
    reviewed_at=decision.decided_at,
    expires_at=decision.decision_deadline,
    operator_comment_digest="2" * 64,
)
learning_trust = SimpleNamespace(
    content_digest="f" * 64,
    approved_policy_digests=frozenset(("e" * 64, policy.policy_digest)),
)
operator_trust = ledger_module._OperatorTrustStore(
    keys={"operator-noop": operator_private.public_key()},
    roles={"operator-noop": frozenset(("duty-meteorologist",))},
    content_digest="1" * 64,
)
with tempfile.TemporaryDirectory() as directory:
    ledger = EpisodeLedger(Path(directory))
    with patch.object(
        ledger_module,
        "_load_learning_policy_trust_store",
        return_value=learning_trust,
    ), patch.object(
        ledger_module,
        "_load_operator_trust_store",
        return_value=operator_trust,
    ):
        ledger.append_prospective_intervention_decision(
            decision,
            operator_approval=approval,
            action_policy=policy,
            action_generator=generator,
            actual_input_before_context=before_context,
            actual_input_before_run=before_run,
            trust_store_path="/tmp/learning-trust.json",
            operator_trust_store_path="/tmp/operator-trust.json",
        )
    with sqlite3.connect(ledger.index_path) as connection:
        count = connection.execute(
            "SELECT COUNT(*) FROM prospective_intervention_decisions"
        ).fetchone()[0]
    print("ledger_decision_rows", count)
