import pathlib
import tempfile

import numpy as np
import torch

from advar.nowcast import (
    CURRENT_RADAR_METRIC_DOMAIN,
    CURRENT_RADAR_METRIC_DOMAIN_EVIDENCE,
    RADAR_PROJECTED_GRID_CELL_CENTER_CONVENTION,
    RADAR_PROJECTED_GRID_COORDINATE_DTYPE,
    RadarGridTimeContract,
    radar_projected_crs_semantic_digest,
    NowcastConfig,
    nowcast,
)
from advar.run_artifact import save_forecast_run, load_forecast_run
from advar.sensitivity import RadarObservationGeometryContract


TIMES = (
    "2026-08-26T00:00:00Z",
    "2026-08-26T00:10:00Z",
    "2026-08-26T00:20:00Z",
)
COMMON = dict(
    valid_times=TIMES,
    dx_m=1000.0,
    dy_m=1000.0,
    projection="EPSG:5179",
    grid_hash="1" * 64,
    grid_shape_yx=(2, 2),
    projected_crs_digest=radar_projected_crs_semantic_digest("EPSG:5179"),
    metric_domain_digest=CURRENT_RADAR_METRIC_DOMAIN.digest,
    cell_center_origin_xy_m=(1_000_000.0, 2_000_000.0),
    grid_coordinate_dtype=RADAR_PROJECTED_GRID_COORDINATE_DTYPE,
    cell_center_convention=RADAR_PROJECTED_GRID_CELL_CENTER_CONVENTION,
)


def grid(contract: str) -> RadarGridTimeContract:
    values = dict(COMMON, spatial_grid_contract=contract)
    if contract.endswith("v6"):
        values["metric_domain_evidence_digest"] = (
            CURRENT_RADAR_METRIC_DOMAIN_EVIDENCE.digest
        )
    return RadarGridTimeContract(**values)


def main() -> None:
    v5 = grid("radar-spatial-grid-identity-v5")
    v6 = grid("radar-spatial-grid-identity-v6")
    print("v5_constructed", v5.metric_domain_evidence_digest)
    try:
        RadarObservationGeometryContract.from_grid_time_contract(v5)
    except ValueError as error:
        print("v5_verification_geometry", type(error).__name__, str(error))
    geometry = RadarObservationGeometryContract.from_grid_time_contract(v6)
    print("v6_verification_geometry", geometry.contract)

    result = nowcast(
        torch.full((3, 2, 2), 20.0, dtype=torch.float64),
        config=NowcastConfig(maximum_motion_speed_mps=10.0),
        grid_time_contract=v5,
    )
    with tempfile.TemporaryDirectory() as temporary:
        path = pathlib.Path(temporary) / "v5-current.npz"
        save_forecast_run(result, path)
        with np.load(path, allow_pickle=False) as archive:
            print("saved_artifact_version", str(archive["forecast_run_artifact_version"]))
        loaded = load_forecast_run(path)
        print(
            "loaded_current_artifact_grid",
            loaded.run.grid_time_contract.spatial_grid_contract,
            loaded.run.grid_time_contract.metric_domain_evidence_digest,
        )


if __name__ == "__main__":
    main()
