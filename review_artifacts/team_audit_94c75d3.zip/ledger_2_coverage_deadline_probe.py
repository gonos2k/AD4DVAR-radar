"""Exercise the public dynamic source coverage append across its deadline."""

from __future__ import annotations

import json
import sqlite3
import sys
import tempfile
from datetime import datetime
from pathlib import Path
from unittest.mock import patch

import torch

sys.path.insert(0, "/Users/yhlee/ADVAR/tests")
import test_promotion
from advar import ledger as ledger_module
from advar import promotion as promotion_module
from advar.ledger import EpisodeLedger


class DelayedLedger(EpisodeLedger):
    def _connect(self):
        # Simulate the scheduler/SQLite delay after append's preflight clock
        # check and before the public INSERT.
        if clock is not None:
            clock.now.return_value = after_deadline
        return super()._connect()


after_deadline: datetime
clock = None


def main() -> None:
    global after_deadline
    test_case = test_promotion.NeuralPriorPromotionTests("runTest")
    plan, input_plan, registry = test_case.mosaic_issuance_context()
    nominal = torch.ones((1, 2, 2), dtype=torch.bool)
    resolved = promotion_module.ResolvedSourceCoverageArtifact.from_observations(
        plan,
        input_plan,
        registry,
        nominal_source_coverage_mask=nominal,
        source_radar_index_map=torch.tensor(
            [[0, 1], [0, 1]], dtype=torch.int64
        ),
        outage_mask=torch.zeros((2, 2), dtype=torch.bool),
        dynamic_qc_valid_mask=torch.ones((2, 2), dtype=torch.bool),
        input_bundle_digest="e" * 64,
        full_analysis_input_digest="1" * 64,
        resolved_at="2026-08-09T00:01:00Z",
        data_ingestor_id="trusted-radar-ingestor",
        data_ingestor_private_key=test_case.scheduler_key(),
    )
    domain = promotion_module.OperationalIssuanceDomainArtifact.from_masks(
        plan,
        publication_eligible_mask=nominal,
        source_coverage_mask=nominal,
        permanent_exclusion_mask=torch.zeros_like(nominal),
        resolved_source_coverage=resolved,
    )
    before_deadline = datetime.fromisoformat("2026-08-09T00:01:30+00:00")
    after_deadline = datetime.fromisoformat("2026-08-09T00:03:00+00:00")
    globals()["after_deadline"] = after_deadline
    with tempfile.TemporaryDirectory() as directory:
        ledger = DelayedLedger(Path(directory))
        with patch.object(ledger_module, "datetime", wraps=datetime) as trusted_clock:
            globals()["clock"] = trusted_clock
            trusted_clock.now.return_value = before_deadline
            digest = ledger.append_resolved_source_coverage_artifact(
                plan, input_plan, resolved, domain
            )
        with sqlite3.connect(ledger.index_path) as connection:
            row = connection.execute(
                "SELECT artifact_digest,resolved_at FROM "
                "neural_prior_resolved_source_coverage_artifacts"
            ).fetchone()
        print(json.dumps({
            "digest_returned": digest,
            "resolved_at": resolved.resolved_at,
            "preflight_now": before_deadline.isoformat(),
            "insert_now": after_deadline.isoformat(),
            "decision_deadline": input_plan.decision_deadline,
            "row": row,
        }, sort_keys=True))


if __name__ == "__main__":
    main()
