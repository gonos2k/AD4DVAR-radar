import math
import torch

from advar.nowcast import NowcastConfig, nowcast
from advar.physics import remap


def main() -> None:
    config = NowcastConfig(horizon_minutes=20)
    y, x = torch.meshgrid(
        torch.arange(16, dtype=torch.float64),
        torch.arange(16, dtype=torch.float64),
        indexing="ij",
    )
    echo0 = 1_000.0 * torch.exp(-((y - 8.0) ** 2 + (x - 8.0) ** 2) / 8.0)
    displacement = torch.tensor((0.5, -0.25), dtype=torch.float64)
    echo1 = remap(echo0, displacement)
    echo2 = remap(echo1, displacement)
    from advar.physics import echo_to_dbz

    frames = echo_to_dbz(
        torch.stack((echo0, echo1, echo2)),
        min_dbz=config.min_dbz,
        max_dbz=config.max_dbz,
    )
    result = nowcast(frames, config)
    assert result.forecast_dbz.shape == (2, 16, 16)
    assert torch.equal(torch.isfinite(result.forecast_dbz), result.valid_mask)
    assert result.metadata.tendency_pair_count == 2
    impulse = torch.zeros((4, 4), dtype=torch.float64)
    impulse[2, 2] = 1.0
    moved = remap(impulse, torch.tensor((0.0, 0.5)))
    assert math.isclose(float(moved.sum()), 1.0)

    missing = torch.full((3, 8, 8), torch.nan, dtype=torch.float64)
    background = torch.full_like(missing, 20.0)
    stale = nowcast(
        missing,
        config,
        background_frames_dbz=background,
        background_age_minutes=10.0,
    )
    assert stale.metadata.data_status.value == "STALE_BACKGROUND"
    assert stale.metadata.background_used
    print("meteorological_motion", result.metadata.tendency_pair_count)
    print("motion", result.state.displacement_yx.tolist())
    print("stale_background", stale.metadata.data_status.value, stale.metadata.background_age_minutes)
    print("finite_mask_equal", bool(torch.equal(torch.isfinite(result.forecast_dbz), result.valid_mask)))


if __name__ == "__main__":
    main()
