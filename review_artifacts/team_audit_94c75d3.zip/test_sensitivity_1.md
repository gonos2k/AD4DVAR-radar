# `test_sensitivity_1` audit

Baseline: `94c75d3323c986b6fb2963336b906acc85384e12`

## Confirmed finding: M0 drops typed verification metric weights

`compute_sensitivity_snapshot` accepts a current typed `VerificationBundle`, but it does not apply the bundle's resolved metric weight to the M0 metric domain.

The typed path resolves `verification.fso_metric_weight` into `_ResolvedVerification.metric_weight` at [src/advar/sensitivity.py:11659](/Users/yhlee/ADVAR/src/advar/sensitivity.py:11659). For current v22, `fso_metric_weight` is the quantitative echo weight and is zero for `BELOW_DETECTION_CENSORED` cells at [src/advar/sensitivity.py:8437](/Users/yhlee/ADVAR/src/advar/sensitivity.py:8437). The current verification contract also documents that below-detection censored cells remain in lineage but have point-value metric weight zero (README.md:1310–1335).

The M0 implementation then discards that resolved weight. It sets `verification_finite = verification_bundle.valid_mask` at [src/advar/sensitivity.py:12459](/Users/yhlee/ADVAR/src/advar/sensitivity.py:12459), and each lead passes only this Boolean mask to `_metric_domain_weight` at [src/advar/sensitivity.py:12610](/Users/yhlee/ADVAR/src/advar/sensitivity.py:12610). `_metric_domain_weight` combines the forecast issued/domain weight with the Boolean verification mask, but never receives `verification_bundle.metric_weight` ([src/advar/sensitivity.py:10838](/Users/yhlee/ADVAR/src/advar/sensitivity.py:10838)). Therefore a censored cell with `valid_mask=True` contributes to the point metric and to the derivative. The P1 score path does multiply `verification.metric_weight` at [src/advar/sensitivity.py:13252](/Users/yhlee/ADVAR/src/advar/sensitivity.py:13252), so this finding is specific to M0.

The runnable current-contract probe is [test_sensitivity_1_derivative_probe.py](/tmp/advar-team-audit-94c75d3/test_sensitivity_1_derivative_probe.py), with output [test_sensitivity_1_derivative_probe.out](/tmp/advar-team-audit-94c75d3/test_sensitivity_1_derivative_probe.out). It constructs a public `RadarGridTimeContract`, runs `nowcast` on a constant 20 dBZ field, and sets one verification cell to NaN before constructing the current v22 bundle through the existing test fixture helper. The resulting public bundle and snapshot report:

```text
contract radar-verification-bundle-v22
state_00 5
valid_mask_00 True
fso_metric_weight_00 0.0
snapshot_score 2.9823176871440986
expected_fso_weighted_score 0.0
forecast_sensitivity_00 0.008634694098727665
forecast_sensitivity_other 1.1102230246251558e-18
```

State code 5 is `BELOW_DETECTION_CENSORED`; the helper only supplies the current public bundle, while the failing computation is the public `compute_sensitivity_snapshot` API. In this minimal case every non-censored truth value equals the forecast. `log_echo_mse` is a masked mean ([src/advar/sensitivity.py:17203](/Users/yhlee/ADVAR/src/advar/sensitivity.py:17203)); excluding the censored cell with its declared zero point-value weight therefore gives score 0 and zero derivative. The observed score and nonzero forecast-linear derivative show that `nan_to_num(..., min_dbz)` turns the censored value into a synthetic finite target and the M0 path scores/differentiates it.

This can overstate M0 forecast scores and direct/forecast sensitivities whenever a current verification bundle contains censored, QC-excluded, low-quality, or otherwise fractional-weight cells. The relevant correction must preserve the typed bundle's resolved metric weight in the M0 metric input (at minimum for point-value `log_echo_mse`); the same frozen weight must feed the score and all derived gradients/evidence. Legacy raw tensor behavior should remain unchanged. The existing tests validate `bundle.metric_weight`/`bundle.fso_metric_weight` in isolation around [tests/test_sensitivity.py:2674](/Users/yhlee/ADVAR/tests/test_sensitivity.py:2674), but no M0 integration test binds a current bundle weight to `compute_sensitivity_snapshot`.

## Unconfirmed candidates

No additional actionable candidate survived public-path probing in this assigned range. The current affine physical FSS footprint, source replay/mask checks, and observation-error weight construction were exercised and passed targeted tests. The M0 weight omission above is independently reproducible and does not depend on corrupting a digest or bypassing production validation.

## GREEN preserved

The following targeted tests passed under the required constrained runtime:

```text
tests/test_sensitivity.py::SensitivityTests::test_current_metric_uncertainty_reaches_soft_fss_footprint
tests/test_sensitivity.py::SensitivityTests::test_physical_fss_uses_exact_anisotropic_affine_footprint
tests/test_sensitivity.py::VariationalFSOTests::test_verification_observation_error_controls_metric_weight
tests/test_sensitivity.py::VariationalFSOTests::test_confirmatory_observation_masks_and_source_identity_replay
4 passed, 18 warnings, 3 subtests passed in 5.27s
```

## Commands, results, and limitations

- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python /tmp/advar-team-audit-94c75d3/test_sensitivity_1_derivative_probe.py` — reproduced the v22 censored-cell score and derivative above.
- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -m pytest -q tests/test_sensitivity.py::SensitivityTests::test_current_metric_uncertainty_reaches_soft_fss_footprint tests/test_sensitivity.py::SensitivityTests::test_physical_fss_uses_exact_anisotropic_affine_footprint tests/test_sensitivity.py::VariationalFSOTests::test_verification_observation_error_controls_metric_weight tests/test_sensitivity.py::VariationalFSOTests::test_confirmatory_observation_masks_and_source_identity_replay` — 4 passed.
- The probe uses `_current_verification_bundle` from the assigned test module only to create a valid current v22 fixture. It does not mutate the bundle after creation or bypass its integrity checks. No repository source or test files were changed, and no full suite was run.
