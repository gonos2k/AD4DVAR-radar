# ledger_1 audit

Baseline: `94c75d3323c986b6fb2963336b906acc85384e12`

## Confirmed finding

`EpisodeLedger.append` can commit an episode that its own verifier rejects because the input snapshot context names are not checked against the current episode schema before publication.

- `_validate_m0_snapshot` at `src/advar/ledger.py:21867-21872` checks only that `context_feature_names` is nonempty and unique. It accepts a tuple such as `("wrong_0", ...)`.
- `_verify_manifest_layout` at `src/advar/ledger.py:21732-21733` later requires the manifest names to equal the current `CONTEXT_FEATURE_NAMES` schema.
- The append path at `src/advar/ledger.py:4962-5030` validates the snapshot, writes the manifest and arrays, publishes the directory, inserts the SQLite row, and commits without running the same manifest-schema check.

The runnable probe `ledger_1_context_names_probe.py` constructs a normal computed snapshot, replaces only its names using `dataclasses.replace`, and calls the public `EpisodeLedger.append` and `verify` methods. Its output is recorded in `ledger_1_context_names_probe.stdout.txt`:

```text
append_returned True
ValueError context features do not match the episode schema
```

Expected behavior is that append rejects the malformed snapshot before publication, or that the committed artifact verifies successfully. Observed behavior is a published, indexed directory followed by verifier failure. A caller can therefore receive a successful append and later fail on `load(..., verify=True)` or `verify(...)`; the unusable record remains indexed until removed. The current internal snapshot producer uses canonical names, but the `SensitivityEpisode`/`SensitivitySnapshot` boundary accepts externally constructed dataclass values, so this is a public input-contract failure rather than an unsupported backend case.

## Green behavior preserved

The reviewed ledger paths retain strong checks for NPZ safe loading, exact artifact file sets, file and SQLite checksum agreement, episode path identity, digest and shape validation, replay bundle contracts, shard digests and tensor roles, current verification provenance, trust-store file safety, and atomic temporary-directory publication plus SQLite commit/rollback cleanup. M0 numerical, evidence-mask, metric, impact, and trust-product invariants are checked in `_validate_m0_snapshot`; the gap above is specifically the context-name schema equality at the append boundary.

## Other review notes

No additional actionable finding was promoted from the reviewed paths. The possible `_connect`/mutable-path-rebinding concern requires deliberate mutation of private object state and was not treated as a normal public caller defect. Existing ledger-index/manifest identity candidates were left unconfirmed and are not repeated here without a complete public-path repro.

## Verification and scope

The probe was run with `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1` using `/Users/yhlee/ADVAR/.venv/bin/python` (Python 3.12.13/Torch 2.13 environment). No source or test files were modified. I did not run the full baseline or whole ledger test suites; the probe is the scoped regression reproduction. Read coverage is recorded in `ledger_1_coverage.json`.
