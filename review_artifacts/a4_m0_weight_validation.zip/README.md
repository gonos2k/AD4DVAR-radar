# A4 M0 metric-weight regression evidence

Base: 2398e5fd24a0027219c01d826bf41c80f1d9e894.
Run from an editable installation of this candidate checkout:

    OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 python -I -m pytest -q tests/test_m0_linearity_weights.py tests/test_a2_fso.py tests/test_sensitivity.py::SensitivityTests

The same 18 new cases were applied to a detached base checkout with only the two test files copied into it. Import resolution was asserted against that checkout by run_pytest.py. Both Python versions reject exactly the 9 nonuniform/domain-mismatch cases; 9 unit/uniform/missing controls pass. No product mutation was made in the working branch.

capture_snapshots.py ROOT OUTPUT_JSON reuses the new regression inputs and records snapshots before assertions. Candidate versus base results verify that all fields except trust_score/trust_components are identical; the non-linearity trust components are also identical. Raw tensor values are compared by SHA256 over their bytes.

Current v22 weights come from source registry quality, so the nonuniform case uses a real two-source mosaic with complementary beam blockage and registry quality 1 / 0.01. Uniform uses registry quality 0.25. QC/age knobs alone do not generate fractional v22 weights. Coverage is Boolean; domain confidence and anchored support are separate synthetic forecast evidence.

These are public M0 sensitivity calls on synthetic forecast_from_state results, not end-to-end nowcast-to-ledger or real radar skill validation. The product patch does not change transport, optimization, issuance, or verification derivation.
