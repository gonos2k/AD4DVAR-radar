import dataclasses
import hashlib
import json
import os
from pathlib import Path
import sys

root = Path(sys.argv[1]).resolve()
os.chdir(root)
sys.path[:0] = [str(root / 'src'), str(root / 'tests')]
import advar
assert Path(advar.__file__).resolve().is_relative_to(root)
import torch
import test_m0_linearity_weights as regression

original = regression.compute_sensitivity_snapshot
rows = []
def capture(*args, **kwargs):
    snapshot = original(*args, **kwargs)
    invariant = {}
    for field in dataclasses.fields(snapshot):
        value = getattr(snapshot, field.name)
        if field.name in {'trust_score', 'trust_components'}:
            continue
        if isinstance(value, torch.Tensor):
            value = hashlib.sha256(value.detach().cpu().numpy().tobytes()).hexdigest()
        else:
            value = repr(value)
        invariant[field.name] = value
    rows.append({'invariant': invariant, 'trust': snapshot.trust_components,
                 'trust_score': snapshot.trust_score})
    return snapshot
regression.compute_sensitivity_snapshot = capture
for domain, case in [('issued','nonuniform'), ('confidence_weighted','unit'),
                     ('radar_dynamics_anchored','unit'), ('issued','unit'),
                     ('issued','uniform'), ('issued','missing')]:
    for delta in [1e-3, 1e-4, 1e-5]:
        try:
            regression.test_m0_linearity_uses_score_weights_and_boolean_coverage(domain, case, delta)
        except AssertionError:
            passed = False
        else:
            passed = True
        rows[-1].update(domain=domain, case=case, delta=delta, assertions_passed=passed)
Path(sys.argv[2]).write_text(json.dumps(rows, indent=2) + '\n')
