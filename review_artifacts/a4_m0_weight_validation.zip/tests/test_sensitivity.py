from dataclasses import replace
from datetime import datetime, timedelta, timezone
from fractions import Fraction
from importlib import import_module
from pathlib import Path
from types import SimpleNamespace
import json
import math
import os
import stat
import tempfile
import sys
import unittest
from unittest.mock import patch

import numpy as np
import torch
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from advar._digest import tensor_digest  # noqa: E402
from advar._contract_registry import CONTRACT_CAPABILITIES  # noqa: E402
import advar.sensitivity as sensitivity_module  # noqa: E402
import advar.promotion as promotion_module  # noqa: E402
import advar.linearization_artifact as linearization_artifact_module  # noqa: E402
from advar.linearization_artifact import (  # noqa: E402
    load_p1_linearization,
    save_p1_linearization,
)
from advar.intervention import (  # noqa: E402
    InterventionExecutionPolicy,
    InterventionMetricGuardrail,
    RealizedObservationIntervention,
    validate_realized_observation_intervention,
)
from advar.ledger import EpisodeLedger  # noqa: E402
from advar.matrix_free import PCGResult  # noqa: E402
from advar.nowcast import (  # noqa: E402
    CURRENT_RADAR_METRIC_DOMAIN,
    CURRENT_RADAR_METRIC_DOMAIN_EVIDENCE,
    _estimate_source_tendencies,
    _forecast_linear_at_step_core,
    _forecast_run_identity_digest,
    DataStatus,
    ForecastMetadata,
    ForecastResult,
    ForecastRunContract,
    GeodeticMetricUncertaintyError,
    NowcastConfig,
    RADAR_PROJECTED_GRID_CELL_CENTER_CONVENTION,
    RADAR_PROJECTED_GRID_COORDINATE_DTYPE,
    RadarGridTimeContract,
    RadarState,
    StatePathProvenance,
    TendencySource,
    TendencyPairSelection,
    forecast_from_state,
    forecast_linear_at_step,
    forecast_linear_from_state,
    nowcast,
    radar_projected_crs_digest,
    radar_projected_crs_semantic_digest,
    state_metadata_digest,
)
from advar.physics import (  # noqa: E402
    dbz_to_echo,
    echo_to_dbz,
    freeze_remap_cell,
)
from advar.sensitivity import (  # noqa: E402
    CURRENT_VARIATIONAL_FSO_CONTRACT,
    CURRENT_VARIATIONAL_FSOI_CONTRACT,
    EXPLORATORY_VARIATIONAL_FSO_CONTRACT,
    EXPLORATORY_VARIATIONAL_FSOI_CONTRACT,
    OBSERVATION_ERROR_DERIVATION_ALGORITHM_DIGEST,
    OBSERVATION_ERROR_DERIVATION_ALGORITHM_V2_DIGEST,
    OBSERVATION_ERROR_DERIVATION_ALGORITHM_V3_DIGEST,
    OBSERVATION_ERROR_DERIVATION_ALGORITHM_V4_DIGEST,
    OBSERVATION_ERROR_DERIVATION_ALGORITHM_V5_DIGEST,
    OBSERVATION_ERROR_DERIVATION_ALGORITHM_V6_DIGEST,
    OBSERVATION_ERROR_DERIVATION_ALGORITHM_V7_DIGEST,
    OBSERVATION_ERROR_DERIVATION_ALGORITHM_V8_DIGEST,
    OBSERVATION_ERROR_DERIVATION_ALGORITHM_V10_DIGEST,
    OBSERVATION_ERROR_DERIVATION_ALGORITHM_V11_DIGEST,
    OBSERVATION_ERROR_DERIVATION_ALGORITHM_V13_DIGEST,
    OBSERVATION_ERROR_DERIVATION_ALGORITHM_V14_DIGEST,
    OBSERVATION_ERROR_DERIVATION_ALGORITHM_V15_DIGEST,
    OBSERVATION_TEMPORAL_QUALITY_DECAY_ALGORITHM_V1_DIGEST,
    OBSERVATION_TEMPORAL_ERROR_ALGORITHM_V1_DIGEST,
    OBSERVATION_DETECTION_LIMIT_ALGORITHM_V1_DIGEST,
    OBSERVATION_DETECTION_LIMIT_ALGORITHM_V3_DIGEST,
    OBSERVATION_CENSOR_STATE_ALGORITHM_V1_DIGEST,
    OBSERVATION_REPORT_KIND_ALGORITHM_V1_DIGEST,
    OBSERVATION_MASK_DERIVATION_ALGORITHM_DIGEST,
    OBSERVATION_MASK_DERIVATION_ALGORITHM_V1_DIGEST,
    OBSERVATION_MASK_DERIVATION_ALGORITHM_V2_DIGEST,
    OBSERVATION_MASK_DERIVATION_ALGORITHM_V4_DIGEST,
    OBSERVATION_MASK_DERIVATION_ALGORITHM_V6_DIGEST,
    OBSERVATION_MASK_DERIVATION_ALGORITHM_V9_DIGEST,
    OBSERVATION_MASK_DERIVATION_ALGORITHM_V10_DIGEST,
    OBSERVATION_MASK_DERIVATION_ALGORITHM_V12_DIGEST,
    OBSERVATION_MASK_DERIVATION_ALGORITHM_V13_DIGEST,
    OBSERVATION_MASK_DERIVATION_ALGORITHM_V14_DIGEST,
    OBSERVATION_SOURCE_SELECTION_ALGORITHM_V1_DIGEST,
    OBSERVATION_SOURCE_SELECTION_ALGORITHM_V3_DIGEST,
    OBSERVATION_SOURCE_SELECTION_ALGORITHM_V4_DIGEST,
    OBSERVATION_SOURCE_SELECTION_ALGORITHM_V5_DIGEST,
    OBSERVATION_SPATIAL_AGE_GATE_ALGORITHM_V1_DIGEST,
    OBSERVATION_SPATIAL_AGE_GATE_ALGORITHM_V3_DIGEST,
    OBSERVATION_SPATIAL_AGE_GATE_ALGORITHM_V4_DIGEST,
    AutomatedLearningPolicy,
    MetricTaylorThreshold,
    ObservationRemovalConfig,
    _baseline_branch_is_stable,
    _gauss_newton_curvature_diagnostics,
    _apply_output_cap,
    _metric_evidence_ratios,
    _metric_domain_weight,
    _NormalProductBudget,
    _p0_tendency_branch_signature,
    _remap_fraction_margin,
    SensitivityConfig,
    SparseRadarPerturbation,
    MosaicObservationSourceRegistry,
    ObservationRadarSource,
    RadarObservationGeometryContract,
    VerificationBundle,
    VerificationCellState,
    VerificationObservationErrorContract,
    VerificationObservationErrorPlan,
    VerificationObservationDerivationInputs,
    VerificationObservationMaskEvidence,
    VerificationObservationReportKind,
    VerificationObservationSourceIdentity,
    VariationalAdjointConfig,
    VariationalObservationPerturbation,
    compute_sensitivity_snapshot,
    compute_variational_fso,
    compute_variational_fsoi,
    compute_variational_observation_removal_impact,
    derive_verification_observation_error,
    derive_verification_observation_masks,
    compute_variational_fsoi_for_learning,
    score_candidate_perturbations,
    validate_top_k_learning_impacts,
    extract_context_features,
    forecast_metric,
    validate_variational_fso,
    validate_variational_fsoi,
    validate_variational_fsoi_issuance_impact,
    validate_variational_learning_impact,
    validate_observation_removal_impact,
    variational_fso_digest,
)
from advar.variational import (  # noqa: E402
    _analysis_trajectory,
    AnalysisConfig,
    NeuralPriorInferenceRunner,
    NeuralPriorProbabilityContract,
    NeuralPriorStateContract,
    neural_prior_state_censor_policy_digest,
    residual_vector,
    variational_nowcast,
)


def dbz_to_linear(dbz: torch.Tensor, config: NowcastConfig) -> torch.Tensor:
    return dbz_to_echo(
        dbz,
        min_dbz=config.min_dbz,
        max_dbz=config.max_dbz,
    )


def linear_to_dbz(echo: torch.Tensor, config: NowcastConfig) -> torch.Tensor:
    return echo_to_dbz(
        echo,
        min_dbz=config.min_dbz,
        max_dbz=config.max_dbz,
    )


def metadata_for(
    state: RadarState,
    *,
    pair_motion: torch.Tensor | None = None,
    pair_growth: torch.Tensor | None = None,
) -> ForecastMetadata:
    pair_motion = (
        torch.stack((state.displacement_yx, state.displacement_yx))
        if pair_motion is None
        else pair_motion
    )
    pair_growth = (
        torch.stack(
            (state.log_growth_per_step, state.log_growth_per_step)
        )
        if pair_growth is None
        else pair_growth
    )
    return ForecastMetadata(
        data_status=DataStatus.OBSERVED,
        coverage_by_frame=torch.ones(
            3,
            dtype=state.echo_linear.dtype,
            device=state.echo_linear.device,
        ),
        background_used=False,
        background_contribution_fraction=0.0,
        background_age_minutes=None,
        source_support=torch.ones_like(state.echo_linear),
        observation_source_support=torch.ones_like(state.echo_linear),
        background_source_support=torch.zeros_like(state.echo_linear),
        path_verified_source_support=torch.ones_like(state.echo_linear),
        verified_source_support=torch.ones_like(state.echo_linear),
        local_motion_verified_support=torch.ones_like(state.echo_linear),
        local_growth_verified_support=torch.ones_like(state.echo_linear),
        local_dynamics_verified_support=torch.ones_like(state.echo_linear),
        observation_verified_source_support=torch.ones_like(
            state.echo_linear
        ),
        background_verified_source_support=torch.zeros_like(
            state.echo_linear
        ),
        motion_disagreement_px=torch.linalg.vector_norm(
            pair_motion[1] - pair_motion[0]
        ),
        motion_disagreement_mps=state.echo_linear.new_full((), torch.nan),
        growth_disagreement=torch.abs(pair_growth[1] - pair_growth[0]),
        maximum_growth_saturation_excess=state.echo_linear.new_zeros(()),
        posterior_velocity_uncertainty_mps=state.echo_linear.new_full(
            (), torch.nan
        ),
        posterior_log_growth_uncertainty_per_step=(
            state.echo_linear.new_full((), torch.nan)
        ),
        p1_velocity_saturation_uncertainty_mps=(
            state.echo_linear.new_full((), torch.nan)
        ),
        p1_log_growth_saturation_uncertainty_per_step=(
            state.echo_linear.new_full((), torch.nan)
        ),
        minimum_phase_correlation_psr=state.echo_linear.new_tensor(10.0),
        tendency_pair_count=2,
        tendency_source=TendencySource.OBSERVATION,
        state_path_source=TendencySource.OBSERVATION,
        state_path_age_minutes=0.0,
        observation_path=StatePathProvenance(age_minutes=0.0),
        minimum_growth_overlap_support=float(state.echo_linear.numel()),
    )


def result_for(
    state: RadarState,
    config: NowcastConfig,
    *,
    frames: torch.Tensor | None = None,
    accepted_mask: torch.Tensor | None = None,
    background: torch.Tensor | None = None,
    pair_motion: torch.Tensor | None = None,
    pair_growth: torch.Tensor | None = None,
    grid_time_contract: RadarGridTimeContract | None = None,
) -> ForecastResult:
    if frames is None:
        latest = linear_to_dbz(state.echo_linear, config)
        frames = torch.stack((latest, latest, latest))
    if accepted_mask is None:
        accepted_mask = torch.isfinite(frames)
    metadata = metadata_for(
        state,
        pair_motion=pair_motion,
        pair_growth=pair_growth,
    )
    if grid_time_contract is not None:
        motions = (
            torch.stack((state.displacement_yx, state.displacement_yx))
            if pair_motion is None
            else pair_motion
        )
        metadata = replace(
            metadata,
            motion_disagreement_mps=torch.linalg.vector_norm(
                grid_time_contract.projected_displacement_xy(
                    motions[1] - motions[0]
                )
            )
            / (config.interval_minutes * 60.0),
            minimum_growth_overlap_area_km2=(
                metadata.minimum_growth_overlap_support
                * grid_time_contract.cell_area_m2
                / 1.0e6
            ),
        )
    return forecast_from_state(
        state,
        metadata,
        config,
        run=ForecastRunContract.from_inputs(
            config,
            frames,
            accepted_mask,
            background,
            0.0 if background is not None else None,
            grid_time_contract=grid_time_contract,
        ),
    )


class _SpatialStdPrior(torch.nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.register_buffer("anchor", torch.tensor(0.0, dtype=torch.float64))

    def forward(
        self,
        frames: torch.Tensor,
    ) -> tuple[torch.Tensor, ...]:
        mean = frames[0] + self.anchor
        std = torch.exp(0.02 * frames[0])
        valid = torch.ones_like(mean)
        state_support = (mean >= 5.0).to(mean)
        event_probability = torch.ones_like(mean)
        return (
            mean,
            std,
            valid,
            state_support,
            event_probability,
            mean,
            std,
        )


def _current_verification_bundle(
    frames_dbz: torch.Tensor,
    *,
    valid_times: tuple[str, ...],
    grid_time_contract: RadarGridTimeContract,
    radar_product_digest: str = "5" * 64,
    qc_pipeline_digest: str = "6" * 64,
    acquisition_time_offset_seconds: float = 0.0,
    radar_range_m: float = 10_000.0,
    representative_scan_elevation_deg: float = 1.0,
    attenuation_qc_score: torch.Tensor | None = None,
    source_quality_weights: tuple[float, ...] = (1.0,),
    beam_blockage_fraction_by_source: torch.Tensor | None = None,
) -> VerificationBundle:
    """Build one complete current scientific verification lineage."""

    source_private_key = Ed25519PrivateKey.from_private_bytes(b"\x39" * 32)
    source_public_key_hex = (
        source_private_key.public_key().public_bytes_raw().hex()
    )
    geometry = RadarObservationGeometryContract.from_grid_time_contract(
        grid_time_contract
    )
    grid_origin = grid_time_contract.cell_center_origin_xy_m
    assert grid_origin is not None
    registry = MosaicObservationSourceRegistry(
        radar_source_kind=(
            "single_site" if len(source_quality_weights) == 1 else "mosaic"
        ),
        ordered_sources=tuple(
            ObservationRadarSource(
                radar_site_digest=str(2 * index + 1) * 64,
                calibration_epoch_digest=str(2 * index + 2) * 64,
                quality_weight=quality,
                observation_std_dbz=2.0,
                detection_limit_dbz=-20.0,
                projected_x_m=float(grid_origin[0]) - radar_range_m,
                projected_y_m=float(grid_origin[1]),
                radar_altitude_m=100.0,
                representative_scan_elevation_deg=(
                    representative_scan_elevation_deg
                ),
                contract="observation-radar-source-v4",
            )
            for index, quality in enumerate(source_quality_weights)
        ),
        projected_crs_digest=geometry.projected_crs_digest,
        metric_domain_digest=CURRENT_RADAR_METRIC_DOMAIN.digest,
        metric_domain_evidence_digest=(
            CURRENT_RADAR_METRIC_DOMAIN_EVIDENCE.digest
        ),
        geometry_model="projected-horizontal-representative-tilt-v1",
        radar_altitude_role="provenance_only",
        contract="mosaic-observation-source-registry-v7",
    )
    plan = VerificationObservationErrorPlan(
        radar_source_kind=registry.radar_source_kind,
        source_registry_digest=registry.source_registry_digest,
        calibration_registry_digest=registry.calibration_registry_digest,
        range_elevation_validity_algorithm_digest=(
            OBSERVATION_MASK_DERIVATION_ALGORITHM_DIGEST
        ),
        beam_blockage_algorithm_digest=(
            OBSERVATION_MASK_DERIVATION_ALGORITHM_DIGEST
        ),
        attenuation_qc_digest=qc_pipeline_digest,
        censoring_rule_digest="7" * 64,
        spatial_correlation_block_algorithm_digest="8" * 64,
        quality_weight_interpretation_digest="9" * 64,
        quality_weight_algorithm_digest=(
            OBSERVATION_ERROR_DERIVATION_ALGORITHM_V15_DIGEST
        ),
        observation_std_algorithm_digest=(
            OBSERVATION_ERROR_DERIVATION_ALGORITHM_V15_DIGEST
        ),
        observation_error_model_digest="a" * 64,
        source_assignment_algorithm_digest=(
            OBSERVATION_SOURCE_SELECTION_ALGORITHM_V5_DIGEST
        ),
        minimum_detectable_echo_dbz=-20.0,
        observation_error_reference_std_dbz=2.0,
        derivation_algorithm_digest=(OBSERVATION_ERROR_DERIVATION_ALGORITHM_V15_DIGEST),
        mask_derivation_algorithm_digest=(
            OBSERVATION_MASK_DERIVATION_ALGORITHM_V14_DIGEST
        ),
        maximum_range_km=300.0,
        minimum_elevation_deg=0.0,
        maximum_elevation_deg=20.0,
        maximum_beam_blockage_fraction=0.5,
        minimum_attenuation_qc_score=0.5,
        verification_source_authority_id="fso-verification-source",
        verification_source_authority_public_key_hex=source_public_key_hex,
        maximum_acquisition_age_seconds=300.0,
        temporal_quality_decay_scale_seconds=120.0,
        temporal_quality_decay_power=2.0,
        temporal_error_growth_dbz_per_second=0.01,
        temporal_quality_decay_algorithm_digest=(
            OBSERVATION_TEMPORAL_QUALITY_DECAY_ALGORITHM_V1_DIGEST
        ),
        temporal_error_algorithm_digest=(
            OBSERVATION_TEMPORAL_ERROR_ALGORITHM_V1_DIGEST
        ),
        detection_limit_derivation_algorithm_digest=(
            OBSERVATION_DETECTION_LIMIT_ALGORITHM_V3_DIGEST
        ),
        censor_state_derivation_algorithm_digest=(
            OBSERVATION_REPORT_KIND_ALGORITHM_V1_DIGEST
        ),
        geometry_contract_digest=geometry.geometry_digest,
        acquisition_timestamp_reference="volume_end",
        spatial_metric_reference_speed_mps=20.0,
        spatial_metric_maximum_displacement_fraction_cells=1.0,
        spatial_age_gate_algorithm_digest=(
            OBSERVATION_SPATIAL_AGE_GATE_ALGORITHM_V4_DIGEST
        ),
        contract="verification-observation-error-plan-v16",
    )
    finite = torch.isfinite(frames_dbz)
    source_frames = torch.nan_to_num(frames_dbz, nan=-30.0).unsqueeze(0)
    report_kind = torch.where(
        finite,
        torch.full_like(
            frames_dbz,
            int(VerificationObservationReportKind.DETECTED_ECHO),
            dtype=torch.uint8,
        ),
        torch.full_like(
            frames_dbz,
            int(
                VerificationObservationReportKind.BELOW_DETECTION_CENSORED
            ),
            dtype=torch.uint8,
        ),
    ).unsqueeze(0)
    source_frames = source_frames.repeat(len(source_quality_weights), 1, 1, 1)
    report_kind = report_kind.repeat(len(source_quality_weights), 1, 1, 1)
    evidence = VerificationObservationMaskEvidence.issue(
        plan=plan,
        geometry=geometry,
        valid_times=valid_times,
        acquisition_valid_times_by_source=tuple(
            valid_times for _ in source_quality_weights
        ),
        grid_contract_digest=grid_time_contract.digest,
        radar_product_digest=radar_product_digest,
        native_verification_source_identity_digest="b" * 64,
        source_registry=registry,
        source_authority_id="fso-verification-source",
        source_authority_private_key=source_private_key,
        source_observed_at=valid_times[-1],
        reflectivity_dbz_by_source=source_frames,
        acquisition_time_offset_seconds_by_source=torch.full_like(
            source_frames,
            acquisition_time_offset_seconds,
        ),
        observation_report_kind_by_source=report_kind,
        source_availability_by_time=torch.ones(
            (len(source_quality_weights), len(valid_times)), dtype=torch.bool
        ),
        beam_blockage_fraction_by_source=(
            torch.zeros_like(source_frames)
            if beam_blockage_fraction_by_source is None
            else beam_blockage_fraction_by_source
        ),
        attenuation_qc_score_by_source=(
            torch.ones_like(source_frames)
            if attenuation_qc_score is None
            else attenuation_qc_score.unsqueeze(0).expand_as(source_frames)
        ),
        range_elevation_validity_domain_digest="c" * 64,
        beam_blockage_visibility_mask_digest="d" * 64,
        spatial_correlation_block_digest="e" * 64,
    )
    mask_derivation = derive_verification_observation_masks(
        plan=plan,
        raw_evidence=evidence,
        source_registry=registry,
        geometry=geometry,
    )
    derivation = derive_verification_observation_error(
        plan=plan,
        raw_verification_source=(
            VerificationObservationDerivationInputs.from_mask_derivation(
                mask_derivation
            )
        ),
        source_registry=registry,
    )
    return VerificationBundle(
        frames_dbz=mask_derivation.selected_frames_dbz,
        valid_mask=derivation.valid_mask,
        valid_times=valid_times,
        grid_contract_digest=grid_time_contract.digest,
        radar_product_digest=radar_product_digest,
        qc_pipeline_digest=qc_pipeline_digest,
        mask_policy_digest="f" * 64,
        censor_policy_digest="7" * 64,
        reflectivity_resolution_dbz=0.5,
        quantization_origin_dbz=-20.0,
        threshold_bin_convention="nearest_rounding_threshold_censor",
        floor_representation_contract_digest="0" * 64,
        quality_weight=derivation.quality_weight,
        observation_std_dbz=derivation.observation_std_dbz,
        observation_state_code=derivation.observation_state_code,
        source_radar_index_map=derivation.source_radar_index_map,
        detection_limit_dbz=mask_derivation.selected_detection_limit_dbz,
        acquisition_time_offset_seconds=(
            mask_derivation.selected_acquisition_time_offset_seconds
        ),
        acquisition_age_seconds=(
            mask_derivation.selected_acquisition_age_seconds
        ),
        spatial_metric_valid_mask=mask_derivation.spatial_metric_valid_mask,
        observation_error_contract=derivation.observation_error_contract,
        observation_error_derivation=derivation,
        contract="radar-verification-bundle-v22",
    )


class SensitivityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.nowcast_config = NowcastConfig()
        cls.sensitivity_config = SensitivityConfig(
            metric_names=("log_echo_mse",),
            full_map_lead_minutes=(10,),
            tile_size=6,
        )
        cls.height, cls.width = 13, 17
        y, x = torch.meshgrid(
            torch.arange(cls.height, dtype=torch.float64),
            torch.arange(cls.width, dtype=torch.float64),
            indexing="ij",
        )
        latest = 18.0 + 26.0 * torch.exp(
            -((y - 6.0) ** 2 + (x - 8.0) ** 2) / 20.0
        )
        cls.frames = torch.stack((latest - 2.0, latest - 1.0, latest))
        cls.frames[2, 0, 0] = float("nan")
        cls.frames[2, 0, 1] = cls.nowcast_config.min_dbz
        cls.frames[2, 0, 2] = cls.nowcast_config.max_dbz
        cls.qc_mask = torch.ones_like(cls.frames, dtype=torch.bool)
        cls.qc_mask[2, 0, 3] = False

        cls.state = RadarState(
            echo_linear=dbz_to_linear(cls.frames[2], cls.nowcast_config),
            displacement_yx=torch.tensor([0.35, -0.25], dtype=torch.float64),
            log_growth_per_step=torch.tensor(0.015, dtype=torch.float64),
        )
        clean_frames = torch.nan_to_num(
            cls.frames,
            nan=cls.nowcast_config.min_dbz,
            posinf=cls.nowcast_config.max_dbz,
            neginf=cls.nowcast_config.min_dbz,
        ).clamp(
            cls.nowcast_config.min_dbz,
            cls.nowcast_config.max_dbz,
        )
        cls.background = (
            clean_frames - 0.3 * torch.cos(x / 4.0)[None]
        ).clamp(
            cls.nowcast_config.min_dbz,
            cls.nowcast_config.max_dbz,
        )
        cls.result = result_for(
            cls.state,
            cls.nowcast_config,
            frames=cls.frames,
            accepted_mask=cls.qc_mask & torch.isfinite(cls.frames),
            background=cls.background,
            pair_motion=torch.tensor(
                [[0.32, -0.20], [0.37, -0.28]],
                dtype=torch.float64,
            ),
            pair_growth=torch.tensor(
                [0.01, 0.02],
                dtype=torch.float64,
            ),
        )
        cls.verification = (
            cls.result.forecast_dbz + 0.4 * torch.sin(y / 3.0)[None]
        )
        common = {
            "sensitivity_config": cls.sensitivity_config,
            "observation_std_dbz": 2.0,
        }
        cls.snapshot = compute_sensitivity_snapshot(
            cls.frames[2],
            cls.result,
            cls.verification,
            latest_background_dbz=cls.background[2],
            **common,
        )
        result_without_background = result_for(
            cls.state,
            cls.nowcast_config,
            frames=cls.frames,
            accepted_mask=cls.qc_mask & torch.isfinite(cls.frames),
            pair_motion=torch.tensor(
                [[0.32, -0.20], [0.37, -0.28]],
                dtype=torch.float64,
            ),
            pair_growth=torch.tensor(
                [0.01, 0.02],
                dtype=torch.float64,
            ),
        )
        cls.snapshot_without_background = compute_sensitivity_snapshot(
            cls.frames[2],
            result_without_background,
            cls.verification,
            **common,
        )

    def test_forecast_linear_core_matches_step_and_dbz_paths(self) -> None:
        config = NowcastConfig(horizon_minutes=30)
        y, x = torch.meshgrid(
            torch.arange(12, dtype=torch.float64),
            torch.arange(14, dtype=torch.float64),
            indexing="ij",
        )
        latest_dbz = 15.0 + 15.0 * torch.exp(
            -((y - 5.0) ** 2 + (x - 7.0) ** 2) / 18.0
        )
        state = RadarState(
            echo_linear=dbz_to_linear(latest_dbz, config),
            displacement_yx=torch.tensor([0.2, -0.15], dtype=torch.float64),
            log_growth_per_step=torch.zeros((), dtype=torch.float64),
        )

        linear = forecast_linear_from_state(state, config)
        by_step = torch.stack(
            [
                forecast_linear_at_step(state, step, config)
                for step in range(1, config.forecast_steps + 1)
            ]
        )

        torch.testing.assert_close(linear, by_step)
        frames = torch.stack((latest_dbz, latest_dbz, latest_dbz))
        result = result_for(state, config, frames=frames)
        expected_dbz = linear_to_dbz(linear, config)
        self.assertTrue(
            torch.equal(
                torch.isfinite(result.forecast_dbz),
                result.valid_mask,
            )
        )
        torch.testing.assert_close(
            result.forecast_dbz[result.valid_mask],
            expected_dbz[result.valid_mask],
        )
        torch.testing.assert_close(
            dbz_to_linear(result.forecast_dbz, config)[result.valid_mask],
            linear[result.valid_mask],
        )

    def test_metric_domain_policies_freeze_distinct_weights(self) -> None:
        finite = torch.ones(
            (self.height, self.width),
            dtype=torch.bool,
        )
        finite[0, 0] = False
        issued = _metric_domain_weight(
            self.result,
            finite,
            0,
            "issued",
        )
        anchored = _metric_domain_weight(
            self.result,
            finite,
            0,
            "radar_dynamics_anchored",
        )
        confidence = _metric_domain_weight(
            self.result,
            finite,
            0,
            "confidence_weighted",
        )
        torch.testing.assert_close(
            issued,
            (finite & self.result.valid_mask[0]).to(issued),
        )
        torch.testing.assert_close(
            anchored,
            (
                finite
                & self.result.radar_dynamics_anchored_valid_mask[0]
            ).to(anchored),
        )
        torch.testing.assert_close(
            confidence,
            torch.where(
                finite & self.result.valid_mask[0],
                self.result.forecast_confidence[0],
                torch.zeros_like(confidence),
            ),
        )
        self.assertTrue(bool(torch.all(anchored <= issued)))
        self.assertTrue(bool(torch.all(confidence <= issued)))

        forecast = torch.tensor([[1.0, 4.0]], dtype=torch.float64)
        truth = torch.tensor([[1.0, 1.0]], dtype=torch.float64)
        weight = torch.tensor([[1.0, 0.0]], dtype=torch.float64)
        weighted_score = forecast_metric(
            "log_echo_mse",
            forecast,
            truth,
            weight,
            self.nowcast_config,
            replace(
                self.sensitivity_config,
                metric_domain="confidence_weighted",
            ),
        )
        torch.testing.assert_close(
            weighted_score,
            torch.zeros_like(weighted_score),
        )

    def test_confidence_weighted_fss_downweights_low_confidence_windows(
        self,
    ) -> None:
        forecast = dbz_to_linear(
            torch.tensor([[40.0, 40.0]], dtype=torch.float64),
            self.nowcast_config,
        )
        truth = dbz_to_linear(
            torch.tensor([[40.0, 0.0]], dtype=torch.float64),
            self.nowcast_config,
        )
        config = replace(
            self.sensitivity_config,
            metric_domain="confidence_weighted",
            soft_fss_window=1,
        )
        equal_weight = forecast_metric(
            "soft_fss_error_35",
            forecast,
            truth,
            torch.ones_like(forecast),
            self.nowcast_config,
            config,
        )
        low_bad_region_weight = forecast_metric(
            "soft_fss_error_35",
            forecast,
            truth,
            torch.tensor([[1.0, 1.0e-6]], dtype=torch.float64),
            self.nowcast_config,
            config,
        )

        self.assertLess(low_bad_region_weight, 1.0e-4 * equal_weight)

    def test_snapshot_shapes_and_m0_scope(self) -> None:
        snapshot = self.snapshot
        tile_rows = math.ceil(self.height / self.sensitivity_config.tile_size)
        tile_columns = math.ceil(
            self.width / self.sensitivity_config.tile_size
        )

        self.assertEqual(snapshot.lead_minutes, tuple(range(10, 181, 10)))
        self.assertIsNone(snapshot.grid_time_contract_digest)
        self.assertEqual(snapshot.full_map_lead_minutes, (10,))
        self.assertEqual(
            snapshot.context_features.shape,
            (len(snapshot.context_feature_names),),
        )
        self.assertIn("motion_pair_conflict", snapshot.context_feature_names)
        self.assertIn("growth_pair_conflict", snapshot.context_feature_names)
        self.assertIn("log_integrated_echo", snapshot.context_feature_names)
        self.assertNotIn("log_echo_mass", snapshot.context_feature_names)
        context = dict(
            zip(snapshot.context_feature_names, snapshot.context_features)
        )
        for component in ("motion", "growth"):
            selection_values = tuple(
                float(
                    context[
                        f"{component}_pair_selection_{selection.value.lower()}"
                    ]
                )
                for selection in TendencyPairSelection
            )
            self.assertEqual(sum(selection_values), 1.0)
            self.assertEqual(
                context[f"{component}_pair_selection_blended"],
                1.0,
            )
        self.assertEqual(context["phase_correlation_psr_available"], 1.0)
        torch.testing.assert_close(
            context["log1p_minimum_phase_correlation_psr"],
            torch.log1p(self.result.metadata.minimum_phase_correlation_psr),
        )
        self.assertEqual(context["projected_velocity_available"], 0.0)
        for name in (
            "projected_velocity_x_mps",
            "projected_velocity_y_mps",
            "projected_speed_mps",
        ):
            self.assertEqual(context[name], 0.0)
        self.assertEqual(context["motion_disagreement_mps_available"], 0.0)
        self.assertEqual(context["motion_disagreement_mps"], 0.0)
        self.assertEqual(context["area_weighted_echo_available"], 0.0)
        self.assertEqual(
            context["log1p_linear_reflectivity_integral_km2"], 0.0
        )
        self.assertEqual(context["grid_spacing_available"], 0.0)
        self.assertEqual(context["grid_column_spacing_m"], 0.0)
        self.assertEqual(context["grid_row_spacing_m"], 0.0)
        self.assertEqual(snapshot.analysis_control.shape, (3,))
        self.assertEqual(snapshot.forecast_scores.shape, (18, 1))
        self.assertEqual(snapshot.metric_available.shape, (18, 1))
        self.assertEqual(snapshot.control_sensitivity.shape, (18, 1, 3))
        self.assertEqual(
            snapshot.forecast_sensitivity.shape,
            (1, 1, self.height, self.width),
        )
        self.assertEqual(
            snapshot.forecast_cap_active_mask.shape,
            (1, self.height, self.width),
        )
        self.assertEqual(
            snapshot.forecast_confidence.shape,
            (18, self.height, self.width),
        )
        self.assertEqual(snapshot.path_evidence_by_metric.shape, (18, 1))
        self.assertEqual(
            snapshot.observation_source_fraction_by_metric.shape,
            (18, 1),
        )
        self.assertEqual(
            snapshot.observation_verified_evidence_by_metric.shape,
            (18, 1),
        )
        self.assertEqual(
            snapshot.background_verified_evidence_by_metric.shape,
            (18, 1),
        )
        self.assertEqual(
            snapshot.direct.maps.shape,
            (1, 1, self.height, self.width),
        )
        self.assertEqual(
            snapshot.direct.norm.shape,
            (18, 1),
        )
        self.assertEqual(
            snapshot.direct.tile_norm.shape,
            (18, 1, tile_rows, tile_columns),
        )
        self.assertIsNotNone(snapshot.direct.impact)
        self.assertEqual(
            snapshot.direct.impact.shape,
            (18, 1),
        )
        self.assertEqual(snapshot.latest_sensitivity_mask.shape, (13, 17))
        self.assertEqual(
            snapshot.observation_innovation_mask.shape,
            (13, 17),
        )
        self.assertTrue(snapshot.whitened_tile_norm_available)
        self.assertEqual(
            snapshot.nowcast_config_digest,
            self.nowcast_config.digest,
        )
        self.assertEqual(
            snapshot.sensitivity_config_digest,
            self.sensitivity_config.digest,
        )
        self.assertEqual(
            snapshot.forecast_run_digest,
            self.result.forecast_run_digest,
        )

    def test_sensitivity_uses_the_forecast_run_config(self) -> None:
        config = NowcastConfig(
            horizon_minutes=20,
            growth_decay_minutes=120.0,
            max_dbz=60.0,
            min_publish_support=0.7,
        )
        frames = torch.full((3, 5, 6), 20.0, dtype=torch.float64)
        result = nowcast(frames, config)
        verification = result.forecast_dbz.clone()

        snapshot = compute_sensitivity_snapshot(
            frames[-1],
            result,
            verification,
            sensitivity_config=SensitivityConfig(
                metric_names=("log_echo_mse",),
                full_map_lead_minutes=(10,),
            ),
        )

        self.assertEqual(snapshot.nowcast_config_digest, config.digest)
        torch.testing.assert_close(
            snapshot.forecast_scores,
            torch.zeros_like(snapshot.forecast_scores),
        )

    def test_sensitivity_rejects_mismatched_run_inputs(self) -> None:
        different_frame = self.frames[-1].clone()
        different_frame[6, 8] += 0.1
        with self.assertRaisesRegex(ValueError, "latest frame disagrees"):
            compute_sensitivity_snapshot(
                different_frame,
                self.result,
                self.verification,
                sensitivity_config=self.sensitivity_config,
            )

        different_background = self.background[-1].clone()
        different_background[6, 8] += 0.1
        with self.assertRaisesRegex(ValueError, "background disagrees"):
            compute_sensitivity_snapshot(
                self.frames[-1],
                self.result,
                self.verification,
                sensitivity_config=self.sensitivity_config,
                latest_background_dbz=different_background,
            )

    def test_sensitivity_rejects_a_changed_acceptance_mask(self) -> None:
        changed_mask = self.result.run.latest_observation_mask
        changed_mask[0, 3] = True
        changed_run = replace(
            self.result.run,
            _latest_observation_mask=changed_mask,
        )

        with self.assertRaisesRegex(
            ValueError,
            "observation mask disagrees",
        ):
            compute_sensitivity_snapshot(
                self.frames[-1],
                replace(self.result, run=changed_run),
                self.verification,
                sensitivity_config=self.sensitivity_config,
                latest_background_dbz=self.background[-1],
            )

    def test_returned_acceptance_mask_is_an_independent_copy(self) -> None:
        changed_mask = self.result.run.latest_observation_mask
        changed_mask[:] = True

        snapshot = compute_sensitivity_snapshot(
            self.frames[-1],
            self.result,
            self.verification,
            sensitivity_config=self.sensitivity_config,
            latest_background_dbz=self.background[-1],
        )

        self.assertFalse(bool(snapshot.latest_sensitivity_mask[0, 3]))

    def test_sensitivity_rejects_a_forecast_that_does_not_close(self) -> None:
        changed = self.result.forecast_dbz.clone()
        changed[0, 6, 8] += 0.1
        with self.assertRaisesRegex(
            ValueError,
            "disagrees with the issued forecast",
        ):
            compute_sensitivity_snapshot(
                self.frames[-1],
                replace(self.result, forecast_dbz=changed),
                self.verification,
                sensitivity_config=self.sensitivity_config,
            )

    def test_sensitivity_rejects_a_shrunken_issued_domain(self) -> None:
        changed = self.result.forecast_dbz.clone()
        changed[0, 6, 8] = float("nan")

        with self.assertRaisesRegex(
            ValueError,
            "disagrees with the issued forecast",
        ):
            compute_sensitivity_snapshot(
                self.frames[-1],
                replace(self.result, forecast_dbz=changed),
                self.verification,
                sensitivity_config=self.sensitivity_config,
            )

    def test_control_gradient_matches_centered_finite_difference(self) -> None:
        truth = dbz_to_linear(self.verification[0], self.nowcast_config)
        valid = torch.isfinite(self.verification[0])

        def score(control: torch.Tensor) -> torch.Tensor:
            candidate_state = RadarState(
                echo_linear=self.state.echo_linear,
                displacement_yx=control[:2],
                log_growth_per_step=control[2],
            )
            return forecast_metric(
                "log_echo_mse",
                forecast_linear_at_step(
                    candidate_state,
                    1,
                    self.nowcast_config,
                ),
                truth,
                valid,
                self.nowcast_config,
                self.sensitivity_config,
            )

        control = self.snapshot.analysis_control
        epsilon = 1.0e-5
        finite_difference = []
        for index in range(3):
            delta = torch.zeros_like(control)
            delta[index] = epsilon
            finite_difference.append(
                (score(control + delta) - score(control - delta))
                / (2.0 * epsilon)
            )

        torch.testing.assert_close(
            self.snapshot.control_sensitivity[0, 0],
            torch.stack(finite_difference),
            atol=1.0e-6,
            rtol=1.0e-5,
        )

    def test_latest_direct_dbz_gradient_obeys_frozen_active_set(self) -> None:
        mask = self.snapshot.latest_sensitivity_mask
        gradient = self.snapshot.direct.maps[0, 0]

        self.assertTrue(bool(torch.all(torch.isfinite(gradient))))
        self.assertFalse(bool(mask[0, 0]))  # non-finite
        self.assertFalse(bool(mask[0, 1]))  # dBZ floor
        self.assertFalse(bool(mask[0, 2]))  # dBZ cap
        self.assertFalse(bool(mask[0, 3]))  # rejected by QC
        self.assertTrue(bool(mask[1, 1]))
        self.assertTrue(
            torch.equal(
                gradient[~mask],
                torch.zeros_like(gradient[~mask]),
            )
        )
        self.assertGreater(
            int(torch.count_nonzero(gradient[mask])),
            0,
        )

        row, column = 6, 8
        epsilon = 1.0e-4
        clean_latest = torch.nan_to_num(
            self.frames[2],
            nan=self.nowcast_config.min_dbz,
        )

        def score(latest_dbz: torch.Tensor) -> torch.Tensor:
            candidate_echo = dbz_to_linear(
                latest_dbz,
                self.nowcast_config,
            )
            candidate_state = RadarState(
                echo_linear=torch.where(
                    mask,
                    candidate_echo,
                    self.state.echo_linear,
                ),
                displacement_yx=self.state.displacement_yx,
                log_growth_per_step=self.state.log_growth_per_step,
            )
            return forecast_metric(
                "log_echo_mse",
                forecast_linear_at_step(
                    candidate_state,
                    1,
                    self.nowcast_config,
                ),
                dbz_to_linear(
                    self.verification[0],
                    self.nowcast_config,
                ),
                torch.isfinite(self.verification[0]),
                self.nowcast_config,
                self.sensitivity_config,
            )

        perturbation = torch.zeros_like(clean_latest)
        perturbation[row, column] = epsilon
        finite_difference = (
            score(clean_latest + perturbation)
            - score(clean_latest - perturbation)
        ) / (2.0 * epsilon)
        torch.testing.assert_close(
            gradient[row, column],
            finite_difference,
            atol=1.0e-8,
            rtol=1.0e-5,
        )

    def test_soft_fss_is_zero_for_identity_and_symmetric_for_a_miss(
        self,
    ) -> None:
        config = SensitivityConfig(
            metric_names=("soft_fss_error_35",),
            full_map_lead_minutes=(10,),
            soft_fss_window=5,
        )
        truth_dbz = torch.full((15, 15), 10.0, dtype=torch.float64)
        truth_dbz[5:10, 5:10] = 45.0
        miss_dbz = torch.full_like(truth_dbz, 10.0)
        miss_dbz[1:5, 1:5] = 45.0
        truth = dbz_to_linear(truth_dbz, self.nowcast_config)
        miss = dbz_to_linear(miss_dbz, self.nowcast_config)
        valid = torch.ones_like(truth, dtype=torch.bool)

        identical_score = forecast_metric(
            "soft_fss_error_35",
            truth,
            truth,
            valid,
            self.nowcast_config,
            config,
        )
        miss_score = forecast_metric(
            "soft_fss_error_35",
            miss,
            truth,
            valid,
            self.nowcast_config,
            config,
        )
        reverse_score = forecast_metric(
            "soft_fss_error_35",
            truth,
            miss,
            valid,
            self.nowcast_config,
            config,
        )

        torch.testing.assert_close(
            identical_score,
            torch.zeros_like(identical_score),
        )
        self.assertTrue(bool(torch.isfinite(miss_score)))
        self.assertGreater(float(miss_score), 0.0)
        self.assertLessEqual(float(miss_score), 1.0)
        torch.testing.assert_close(miss_score, reverse_score)

    def test_odd_grid_tile_impacts_close_to_total(self) -> None:
        self.assertNotEqual(
            self.height % self.sensitivity_config.tile_size,
            0,
        )
        self.assertNotEqual(
            self.width % self.sensitivity_config.tile_size,
            0,
        )
        tile_sum = self.snapshot.direct.tile_impact.sum(
            dim=(-1, -2)
        )

        self.assertTrue(bool(torch.all(torch.isfinite(tile_sum))))
        torch.testing.assert_close(
            tile_sum,
            self.snapshot.direct.impact,
            atol=1.0e-12,
            rtol=1.0e-12,
        )

    def test_missing_background_marks_impacts_unavailable(self) -> None:
        snapshot = self.snapshot_without_background

        self.assertFalse(snapshot.impact_available)
        self.assertFalse(snapshot.reward_available)
        self.assertIsNone(snapshot.observation_innovation_dbz)
        self.assertIsNone(snapshot.observation_innovation_mask)
        self.assertIsNone(snapshot.direct.impact)
        self.assertIsNone(snapshot.direct.tile_impact)
        self.assertIsNone(snapshot.direct.reward)

    def test_unlineaged_baseline_scores_are_rejected(self) -> None:
        baseline_scores = torch.ones_like(self.snapshot.forecast_scores)

        with self.assertRaisesRegex(
            ValueError,
            "verified lineage contract",
        ):
            compute_sensitivity_snapshot(
                self.frames[2],
                self.result,
                self.verification,
                sensitivity_config=self.sensitivity_config,
                latest_background_dbz=self.background[2],
                observation_std_dbz=2.0,
                baseline_scores=baseline_scores,
            )

    def test_sensitivity_scores_the_issued_capped_forecast(self) -> None:
        config = self.nowcast_config
        frames = torch.full(
            (3, 8, 9),
            config.max_dbz - 0.5,
            dtype=torch.float64,
        )
        state = RadarState(
            echo_linear=dbz_to_linear(frames[2], config),
            displacement_yx=torch.zeros(2, dtype=torch.float64),
            log_growth_per_step=torch.tensor(
                config.max_log_growth_per_step,
                dtype=torch.float64,
            ),
        )
        result = result_for(state, config, frames=frames)
        verification = torch.full(
            (config.forecast_steps, 8, 9),
            config.max_dbz,
            dtype=torch.float64,
        )
        snapshot = compute_sensitivity_snapshot(
            frames[2],
            result,
            verification,
            sensitivity_config=SensitivityConfig(
                metric_names=("log_echo_mse",),
                full_map_lead_minutes=(10,),
            ),
        )

        torch.testing.assert_close(
            snapshot.forecast_scores,
            torch.zeros_like(snapshot.forecast_scores),
        )
        torch.testing.assert_close(
            snapshot.control_sensitivity,
            torch.zeros_like(snapshot.control_sensitivity),
        )
        self.assertFalse(bool(torch.any(snapshot.forecast_cap_active_mask)))

    def test_missing_verification_is_not_recorded_as_zero_error(self) -> None:
        verification = torch.full_like(self.verification, float("nan"))
        snapshot = compute_sensitivity_snapshot(
            self.frames[2],
            self.result,
            verification,
            sensitivity_config=self.sensitivity_config,
            latest_background_dbz=self.background[2],
        )

        self.assertFalse(bool(torch.any(snapshot.metric_available)))
        self.assertTrue(bool(torch.all(torch.isnan(snapshot.forecast_scores))))
        self.assertTrue(
            bool(torch.all(torch.isnan(snapshot.control_sensitivity)))
        )
        self.assertFalse(snapshot.impact_available)

    def test_scores_and_gradients_use_only_the_issued_domain(self) -> None:
        issued = torch.zeros_like(self.result.forecast_dbz, dtype=torch.bool)
        issued[:, 3:10, 4:13] = True
        issued &= self.result.valid_mask
        issued_dbz = torch.where(
            issued,
            self.result.forecast_dbz,
            torch.full_like(self.result.forecast_dbz, float("nan")),
        )
        forecast_digest = tensor_digest(issued_dbz)
        valid_mask_digest = tensor_digest(issued)
        result = replace(
            self.result,
            forecast_dbz=issued_dbz,
            valid_mask=issued,
            forecast_dbz_digest=forecast_digest,
            valid_mask_digest=valid_mask_digest,
            forecast_run_digest=_forecast_run_identity_digest(
                self.result.run,
                self.result.state_metadata_digest,
                forecast_digest,
                valid_mask_digest,
            ),
        )
        snapshot = compute_sensitivity_snapshot(
            self.frames[2],
            result,
            self.verification,
            sensitivity_config=self.sensitivity_config,
            latest_background_dbz=self.background[2],
        )
        truth = dbz_to_linear(self.verification[0], self.nowcast_config)
        expected = forecast_metric(
            "log_echo_mse",
            forecast_linear_at_step(
                self.result.state,
                1,
                self.nowcast_config,
            ),
            truth,
            issued[0],
            self.nowcast_config,
            self.sensitivity_config,
        )

        torch.testing.assert_close(snapshot.forecast_scores[0, 0], expected)
        self.assertTrue(
            torch.equal(
                snapshot.forecast_sensitivity[0, 0][~issued[0]],
                torch.zeros_like(
                    snapshot.forecast_sensitivity[0, 0][~issued[0]]
                ),
            )
        )
        with self.assertRaisesRegex(ValueError, "valid mask disagrees"):
            compute_sensitivity_snapshot(
                self.frames[2],
                replace(self.result, valid_mask=issued),
                self.verification,
                sensitivity_config=self.sensitivity_config,
            )

    def test_unissued_forecast_has_no_sensitivity(self) -> None:
        metadata = replace(
            self.result.metadata,
            data_status=DataStatus.UNAVAILABLE,
        )
        metadata_digest = state_metadata_digest(
            self.result.state,
            metadata,
        )
        valid_mask = torch.zeros_like(self.result.valid_mask)
        forecast_dbz = torch.full_like(self.result.forecast_dbz, torch.nan)
        forecast_digest = tensor_digest(forecast_dbz)
        valid_mask_digest = tensor_digest(valid_mask)
        result = replace(
            self.result,
            forecast_dbz=forecast_dbz,
            valid_mask=valid_mask,
            metadata=metadata,
            state_metadata_digest=metadata_digest,
            forecast_dbz_digest=forecast_digest,
            valid_mask_digest=valid_mask_digest,
            forecast_run_digest=_forecast_run_identity_digest(
                self.result.run,
                metadata_digest,
                forecast_digest,
                valid_mask_digest,
            ),
        )

        with self.assertRaisesRegex(ValueError, "unissued forecast"):
            compute_sensitivity_snapshot(
                self.frames[2],
                result,
                self.verification,
                sensitivity_config=self.sensitivity_config,
                latest_background_dbz=self.background[2],
            )

    def test_background_only_state_has_no_direct_sensitivity(self) -> None:
        frames = torch.full_like(self.frames, float("nan"))
        background = torch.full_like(self.frames, 20.0)
        result = nowcast(
            frames,
            self.nowcast_config,
            background_frames_dbz=background,
            background_age_minutes=10.0,
        )

        with self.assertRaisesRegex(ValueError, "valid latest observation"):
            compute_sensitivity_snapshot(
                frames[2],
                result,
                self.verification,
                sensitivity_config=self.sensitivity_config,
                latest_background_dbz=background[2],
            )

    def test_context_separates_observed_weather_from_missing_area(self) -> None:
        frames = torch.full((3, 4, 5), float("nan"), dtype=torch.float64)
        frames[2, 1, 2] = 40.0
        metadata = replace(
            self.result.metadata,
            coverage_by_frame=torch.tensor(
                [0.0, 0.0, 0.05],
                dtype=torch.float64,
            ),
            tendency_pair_count=1,
            tendency_source=TendencySource.BACKGROUND,
            background_contribution_fraction=0.25,
            source_support=torch.full((4, 5), 0.5, dtype=torch.float64),
        )
        state = replace(
            self.state,
            echo_linear=torch.zeros((4, 5), dtype=torch.float64),
        )
        features = extract_context_features(
            frames[2],
            state,
            metadata,
            self.nowcast_config,
            latest_observation_mask=torch.isfinite(frames[2]),
        )
        values = dict(zip(self.snapshot.context_feature_names, features))

        torch.testing.assert_close(values["latest_mean_dbz"], features.new_tensor(40.0))
        for name, expected in (
            ("echo_fraction_5dbz", 1.0),
            ("latest_observation_coverage", 0.05),
            ("current_state_support_fraction", 0.5),
            ("tendency_source_background", 1.0),
        ):
            torch.testing.assert_close(
                values[name],
                features.new_tensor(expected),
            )

    def test_context_preserves_independent_pair_conflicts(self) -> None:
        metadata = replace(
            self.result.metadata,
            motion_pair_conflict=True,
            growth_pair_conflict=False,
        )
        features = extract_context_features(
            self.frames[2],
            self.state,
            metadata,
            self.nowcast_config,
            latest_observation_mask=(
                self.qc_mask[2] & torch.isfinite(self.frames[2])
            ),
        )
        values = dict(zip(self.snapshot.context_feature_names, features))

        self.assertEqual(float(values["motion_pair_conflict"]), 1.0)
        self.assertEqual(float(values["growth_pair_conflict"]), 0.0)

    def test_context_records_reconstruction_and_growth_evidence(self) -> None:
        metadata = replace(
            self.result.metadata,
            state_path_source=TendencySource.OBSERVATION,
            state_path_mode=TendencyPairSelection.RECENT,
            state_path_pair_count=1,
            state_path_minimum_psr=12.0,
            state_path_conflict=True,
            state_path_extrapolated=False,
            state_path_age_minutes=10.0,
            minimum_growth_overlap_support=5.0,
            minimum_growth_overlap_area_km2=2.0,
            observation_path=StatePathProvenance(
                mode=TendencyPairSelection.RECENT,
                pair_count=1,
                minimum_psr=13.0,
                conflict=False,
                extrapolated=False,
                age_minutes=10.0,
            ),
            background_path=StatePathProvenance(
                mode=TendencyPairSelection.LONG,
                pair_count=1,
                minimum_psr=7.0,
                conflict=True,
                extrapolated=True,
                age_minutes=20.0,
            ),
        )
        features = extract_context_features(
            self.frames[2],
            self.state,
            metadata,
            self.nowcast_config,
            latest_observation_mask=(
                self.qc_mask[2] & torch.isfinite(self.frames[2])
            ),
        )
        values = dict(zip(self.snapshot.context_feature_names, features))

        expected = {
            "state_path_pair_count": 1.0,
            "state_path_source_observation": 1.0,
            "state_path_source_background": 0.0,
            "state_path_conflict": 1.0,
            "state_path_extrapolated": 0.0,
            "state_path_age_available": 1.0,
            "state_path_age_minutes": 10.0,
            "state_path_psr_available": 1.0,
            "log1p_state_path_minimum_psr": math.log1p(12.0),
            "growth_overlap_support_available": 1.0,
            "log1p_minimum_growth_overlap_support": math.log1p(5.0),
            "growth_overlap_area_available": 1.0,
            "log1p_minimum_growth_overlap_area_km2": math.log1p(2.0),
            "state_path_mode_recent": 1.0,
            "observation_path_pair_count": 1.0,
            "observation_path_conflict": 0.0,
            "observation_path_extrapolated": 0.0,
            "observation_path_age_available": 1.0,
            "observation_path_age_minutes": 10.0,
            "observation_path_psr_available": 1.0,
            "log1p_observation_path_minimum_psr": math.log1p(13.0),
            "background_path_pair_count": 1.0,
            "background_path_conflict": 1.0,
            "background_path_extrapolated": 1.0,
            "background_path_age_available": 1.0,
            "background_path_age_minutes": 20.0,
            "background_path_psr_available": 1.0,
            "log1p_background_path_minimum_psr": math.log1p(7.0),
        }
        for name, value in expected.items():
            with self.subTest(name=name):
                torch.testing.assert_close(
                    values[name],
                    features.new_tensor(value),
                )

    def test_context_distinguishes_missing_psr_from_numeric_zero(self) -> None:
        metadata = replace(
            self.result.metadata,
            tendency_pair_count=0,
            motion_pair_count=0,
            growth_pair_count=0,
            motion_pair_selection=TendencyPairSelection.NONE,
            growth_pair_selection=TendencyPairSelection.NONE,
            minimum_phase_correlation_psr=torch.tensor(float("nan")),
        )
        features = extract_context_features(
            self.frames[2],
            self.state,
            metadata,
            self.nowcast_config,
            latest_observation_mask=(
                self.qc_mask[2] & torch.isfinite(self.frames[2])
            ),
        )
        values = dict(zip(self.snapshot.context_feature_names, features))

        self.assertEqual(float(values["phase_correlation_psr_available"]), 0.0)
        self.assertEqual(
            float(values["log1p_minimum_phase_correlation_psr"]),
            0.0,
        )

    def test_context_uses_projected_velocity_from_grid_contract(self) -> None:
        contract = RadarGridTimeContract(
            valid_times=(
                "2026-08-02T00:00:00Z",
                "2026-08-02T00:10:00Z",
                "2026-08-02T00:20:00Z",
            ),
            dx_m=1000.0,
            dy_m=1000.0,
            projection="EPSG:5179",
            grid_hash="1" * 64,
            pixel_to_projected_matrix_m=(
                (800.0, -600.0),
                (600.0, 800.0),
            ),
        )
        result = result_for(
            self.state,
            self.nowcast_config,
            frames=self.frames,
            accepted_mask=self.qc_mask & torch.isfinite(self.frames),
            pair_motion=torch.stack(
                (
                    torch.zeros_like(self.state.displacement_yx),
                    self.state.displacement_yx,
                )
            ),
            grid_time_contract=contract,
        )
        snapshot = compute_sensitivity_snapshot(
            self.frames[2],
            result,
            self.verification,
            sensitivity_config=self.sensitivity_config,
        )
        context = dict(
            zip(snapshot.context_feature_names, snapshot.context_features)
        )
        self.assertEqual(snapshot.grid_time_contract_digest, contract.digest)
        expected = self.state.displacement_yx.new_tensor(
            (-410.0 / 600.0, 130.0 / 600.0)
        )

        self.assertEqual(context["projected_velocity_available"], 1.0)
        torch.testing.assert_close(
            context["projected_velocity_x_mps"],
            expected[0],
        )
        torch.testing.assert_close(
            context["projected_velocity_y_mps"],
            expected[1],
        )
        torch.testing.assert_close(
            context["projected_speed_mps"],
            torch.linalg.vector_norm(expected),
        )
        self.assertEqual(
            context["motion_disagreement_mps_available"], 1.0
        )
        torch.testing.assert_close(
            context["motion_disagreement_mps"],
            torch.linalg.vector_norm(expected),
        )
        self.assertEqual(context["area_weighted_echo_available"], 1.0)
        torch.testing.assert_close(
            context["log1p_linear_reflectivity_integral_km2"],
            context["log_integrated_echo"],
        )
        self.assertEqual(context["grid_spacing_available"], 1.0)
        self.assertEqual(context["grid_column_spacing_m"], contract.dx_m)
        self.assertEqual(context["grid_row_spacing_m"], contract.dy_m)

        issue_time = datetime(2026, 8, 2, 0, 20, tzinfo=timezone.utc)
        verification = VerificationBundle(
            frames_dbz=self.verification,
            valid_mask=torch.isfinite(self.verification),
            valid_times=tuple(
                (issue_time + timedelta(minutes=lead))
                .isoformat()
                .replace("+00:00", "Z")
                for lead in range(10, 181, 10)
            ),
            grid_contract_digest=contract.digest,
            radar_product_digest="2" * 64,
            qc_pipeline_digest="3" * 64,
        )
        lineage_snapshot = compute_sensitivity_snapshot(
            self.frames[2],
            result,
            verification,
            sensitivity_config=replace(
                self.sensitivity_config,
                require_verification_lineage=True,
            ),
        )
        self.assertTrue(lineage_snapshot.verification_lineage_complete)
        self.assertEqual(
            lineage_snapshot.verification_bundle_digest,
            verification.content_digest,
        )
        self.assertEqual(
            lineage_snapshot.verification_valid_times,
            verification.valid_times,
        )

        with self.assertRaisesRegex(ValueError, "VerificationBundle"):
            compute_sensitivity_snapshot(
                self.frames[2],
                result,
                self.verification,
                sensitivity_config=replace(
                    self.sensitivity_config,
                    require_verification_lineage=True,
                ),
            )

    def test_area_weighted_echo_is_resolution_invariant(self) -> None:
        physical_integrals = []
        pixel_integrals = []
        for size, spacing_m in ((2, 1000.0), (4, 500.0)):
            latest = torch.full(
                (size, size), 20.0, dtype=torch.float64
            )
            state = RadarState(
                echo_linear=dbz_to_linear(latest, self.nowcast_config),
                displacement_yx=torch.zeros(2, dtype=torch.float64),
                log_growth_per_step=torch.zeros((), dtype=torch.float64),
            )
            contract = RadarGridTimeContract(
                valid_times=(
                    "2026-08-02T00:00:00Z",
                    "2026-08-02T00:10:00Z",
                    "2026-08-02T00:20:00Z",
                ),
                dx_m=spacing_m,
                dy_m=spacing_m,
                projection="EPSG:5179",
                grid_hash=str(size) * 64,
            )
            features = extract_context_features(
                latest,
                state,
                metadata_for(state),
                self.nowcast_config,
                latest_observation_mask=torch.ones_like(
                    latest, dtype=torch.bool
                ),
                grid_time_contract=contract,
            )
            context = dict(zip(self.snapshot.context_feature_names, features))
            physical_integrals.append(
                context["log1p_linear_reflectivity_integral_km2"]
            )
            pixel_integrals.append(context["log_integrated_echo"])

        torch.testing.assert_close(
            physical_integrals[0], physical_integrals[1]
        )
        self.assertNotEqual(pixel_integrals[0], pixel_integrals[1])

    def test_pair_conflict_reduces_trust_without_changing_other_components(
        self,
    ) -> None:
        penalty = 0.4
        sensitivity_config = replace(
            self.sensitivity_config,
            pair_conflict_trust_penalty=penalty,
        )
        conflict_metadata = replace(
            self.result.metadata,
            motion_pair_count=0,
            motion_pair_selection=TendencyPairSelection.PERSISTENCE,
            motion_pair_conflict=True,
        )
        conflict_result = forecast_from_state(
            self.state,
            conflict_metadata,
            self.nowcast_config,
            run=self.result.run,
        )
        baseline = compute_sensitivity_snapshot(
            self.frames[2],
            self.result,
            self.verification,
            sensitivity_config=sensitivity_config,
            latest_background_dbz=self.background[2],
        )
        conflict = compute_sensitivity_snapshot(
            self.frames[2],
            conflict_result,
            self.verification,
            sensitivity_config=sensitivity_config,
            latest_background_dbz=self.background[2],
        )

        self.assertEqual(baseline.trust_components["pair_consistency"], 1.0)
        self.assertEqual(
            conflict.trust_components["pair_consistency"],
            penalty,
        )
        for name in (
            "linearity",
            "verification",
            "metric_support",
        ):
            self.assertAlmostEqual(
                conflict.trust_components[name],
                baseline.trust_components[name],
            )
        self.assertLess(
            conflict.trust_components["observation_verified_evidence"],
            baseline.trust_components["observation_verified_evidence"],
        )
        self.assertLess(
            conflict.trust_score,
            baseline.trust_score * penalty,
        )

    def test_unverified_path_support_reduces_trust(self) -> None:
        verified = self.result.metadata.verified_source_support.clone()
        verified[:, verified.shape[1] // 2 :] = 0.0
        metadata = replace(
            self.result.metadata,
            verified_source_support=verified,
            local_motion_verified_support=verified,
            local_growth_verified_support=verified,
            local_dynamics_verified_support=verified,
            observation_verified_source_support=verified,
        )
        unverified_result = forecast_from_state(
            self.state,
            metadata,
            self.nowcast_config,
            run=self.result.run,
        )

        baseline = compute_sensitivity_snapshot(
            self.frames[2],
            self.result,
            self.verification,
            sensitivity_config=self.sensitivity_config,
            latest_background_dbz=self.background[2],
        )
        unverified = compute_sensitivity_snapshot(
            self.frames[2],
            unverified_result,
            self.verification,
            sensitivity_config=self.sensitivity_config,
            latest_background_dbz=self.background[2],
        )

        baseline_available = (
            baseline.metric_available
            & torch.isfinite(baseline.path_evidence_by_metric)
            & torch.isfinite(
                baseline.observation_verified_evidence_by_metric
            )
        )
        unverified_available = (
            unverified.metric_available
            & torch.isfinite(unverified.path_evidence_by_metric)
            & torch.isfinite(
                unverified.observation_verified_evidence_by_metric
            )
        )
        baseline_observation_verified_evidence = float(
            baseline.observation_verified_evidence_by_metric[
                baseline_available
            ].mean()
        )
        unverified_observation_verified_evidence = float(
            unverified.observation_verified_evidence_by_metric[
                unverified_available
            ].mean()
        )
        self.assertAlmostEqual(
            baseline.trust_components["observation_verified_evidence"],
            baseline_observation_verified_evidence,
        )
        self.assertAlmostEqual(
            unverified.trust_components["observation_verified_evidence"],
            unverified_observation_verified_evidence,
        )
        self.assertLess(
            unverified_observation_verified_evidence,
            baseline_observation_verified_evidence,
        )
        for name in (
            "linearity",
            "verification",
            "metric_support",
            "pair_consistency",
        ):
            self.assertAlmostEqual(
                unverified.trust_components[name],
                baseline.trust_components[name],
            )
        self.assertAlmostEqual(
            unverified.trust_score,
            baseline.trust_score
            * unverified_observation_verified_evidence
            / baseline_observation_verified_evidence,
        )

    def test_joint_evidence_rejects_spatially_disjoint_marginals(
        self,
    ) -> None:
        weight = torch.ones((2, 2), dtype=torch.float64)
        observation_source = torch.tensor(
            [[1.0, 1.0], [0.0, 0.0]],
            dtype=torch.float64,
        )
        background_verified = 1.0 - observation_source
        evidence = _metric_evidence_ratios(
            weight,
            torch.ones_like(weight),
            background_verified,
            observation_source,
            torch.zeros_like(weight),
            background_verified,
            self.sensitivity_config.epsilon,
        )

        self.assertIsNotNone(evidence)
        assert evidence is not None
        path, observation_source_fraction, observation_verified, background = (
            evidence
        )
        self.assertEqual(float(path), 0.5)
        self.assertEqual(float(observation_source_fraction), 0.5)
        self.assertEqual(float(observation_verified), 0.0)
        self.assertEqual(float(background), 0.5)

    def test_m0_uses_the_issued_forecast_confidence(self) -> None:
        snapshot = compute_sensitivity_snapshot(
            self.frames[2],
            self.result,
            self.verification,
            sensitivity_config=self.sensitivity_config,
            latest_background_dbz=self.background[2],
        )
        torch.testing.assert_close(
            snapshot.forecast_confidence,
            self.result.forecast_confidence,
        )

    def test_nonfinite_background_does_not_create_fake_innovation(self) -> None:
        background = torch.full_like(self.frames, float("nan"))
        result = result_for(
            self.state,
            self.nowcast_config,
            frames=self.frames,
            accepted_mask=self.qc_mask & torch.isfinite(self.frames),
            background=background,
        )
        snapshot = compute_sensitivity_snapshot(
            self.frames[2],
            result,
            self.verification,
            sensitivity_config=self.sensitivity_config,
            latest_background_dbz=background[2],
        )

        self.assertFalse(snapshot.impact_available)
        self.assertIsNone(snapshot.observation_innovation_mask)
        self.assertIsNone(snapshot.observation_innovation_dbz)
        self.assertIsNone(snapshot.direct.impact)

    def test_soft_fss_handles_a_grid_smaller_than_its_window(self) -> None:
        config = SensitivityConfig(
            metric_names=("soft_fss_error_35",),
            full_map_lead_minutes=(10,),
            soft_fss_window=9,
        )
        truth_dbz = torch.full((5, 5), 10.0, dtype=torch.float64)
        truth_dbz[2, 2] = 45.0
        miss_dbz = torch.full_like(truth_dbz, 10.0)
        miss_dbz[0, 0] = 45.0
        valid = torch.ones_like(truth_dbz, dtype=torch.bool)
        score = forecast_metric(
            "soft_fss_error_35",
            dbz_to_linear(miss_dbz, self.nowcast_config),
            dbz_to_linear(truth_dbz, self.nowcast_config),
            valid,
            self.nowcast_config,
            config,
        )

        self.assertTrue(bool(torch.isfinite(score)))
        self.assertGreater(float(score), 0.0)

    def test_empty_centroid_and_invalid_configs_are_explicit(self) -> None:
        empty = torch.zeros((5, 5), dtype=torch.float64)
        valid = torch.ones_like(empty, dtype=torch.bool)
        score = forecast_metric(
            "centroid_error",
            empty,
            empty,
            valid,
            self.nowcast_config,
            self.sensitivity_config,
        )
        self.assertTrue(bool(torch.isnan(score)))

        invalid_configs = (
            {"metric_domain": "unknown"},
            {"tile_size": 2.5},
            {"tile_size_m": 0.0},
            {"soft_fss_window": 4.5},
            {"soft_fss_window_m": 0.0},
            {"soft_fss_temperature_dbz": float("nan")},
            {"active_margin_dbz": float("nan")},
            {"linearity_delta": (0.1, 0.2)},
            {"pair_conflict_trust_penalty": 0.0},
            {"pair_conflict_trust_penalty": 1.1},
            {"pair_conflict_trust_penalty": float("nan")},
            {"require_verification_lineage": 1},
            {"required_verification_radar_product_digest": "1" * 64},
            {
                "required_verification_radar_product_digest": "1" * 64,
                "required_verification_qc_pipeline_digest": "2" * 64,
            },
            {
                "require_verification_lineage": True,
                "required_verification_radar_product_digest": "bad",
                "required_verification_qc_pipeline_digest": "2" * 64,
            },
        )
        for values in invalid_configs:
            with self.subTest(values=values):
                with self.assertRaises((TypeError, ValueError)):
                    SensitivityConfig(**values)

    def test_physical_metric_settings_resolve_from_the_grid(self) -> None:
        grid = RadarGridTimeContract(
            valid_times=(
                "2026-08-05T00:00:00Z",
                "2026-08-05T00:10:00Z",
                "2026-08-05T00:20:00Z",
            ),
            dx_m=1000.0,
            dy_m=1000.0,
            projection="EPSG:5179",
            grid_hash="4" * 64,
            spatial_grid_contract="radar-spatial-grid-identity-v6",
            grid_shape_yx=(self.height, self.width),
            projected_crs_digest=radar_projected_crs_semantic_digest(
                "EPSG:5179"
            ),
            metric_domain_digest=CURRENT_RADAR_METRIC_DOMAIN.digest,
            metric_domain_evidence_digest=(
                CURRENT_RADAR_METRIC_DOMAIN_EVIDENCE.digest
            ),
            cell_center_origin_xy_m=(1_000_000.0, 2_000_000.0),
            grid_coordinate_dtype=RADAR_PROJECTED_GRID_COORDINATE_DTYPE,
            cell_center_convention=(
                RADAR_PROJECTED_GRID_CELL_CENTER_CONVENTION
            ),
        )
        with self.assertRaisesRegex(
            ValueError,
            "projected-grid identity|does not bind current",
        ):
            RadarObservationGeometryContract.from_grid_time_contract(
                replace(grid, metric_domain_evidence_digest=None)
            )
        forecast = torch.zeros((5, 5), dtype=torch.float64)
        truth = torch.zeros_like(forecast)
        forecast[2, 1] = 10.0
        truth[2, 3] = 10.0
        valid = torch.ones_like(forecast, dtype=torch.bool)
        centroid = forecast_metric(
            "centroid_error_m2",
            forecast,
            truth,
            valid,
            self.nowcast_config,
            SensitivityConfig(metric_names=("centroid_error_m2",)),
            grid,
        )
        self.assertAlmostEqual(float(centroid), 4_000_000.0)

        physical = forecast_metric(
            "soft_fss_error_35",
            forecast,
            truth,
            valid,
            self.nowcast_config,
            SensitivityConfig(
                metric_names=("soft_fss_error_35",),
                soft_fss_window_m=5_000.0,
            ),
            grid,
        )
        pixels = forecast_metric(
            "soft_fss_error_35",
            forecast,
            truth,
            valid,
            self.nowcast_config,
            SensitivityConfig(
                metric_names=("soft_fss_error_35",),
                soft_fss_window=5,
            ),
        )
        self.assertTrue(torch.isfinite(physical))
        self.assertGreater(abs(float(physical - pixels)), 1.0e-9)

    def test_current_metric_uncertainty_reaches_soft_fss_footprint(self) -> None:
        grid = RadarGridTimeContract(
            valid_times=(
                "2026-08-05T00:00:00Z",
                "2026-08-05T00:10:00Z",
                "2026-08-05T00:20:00Z",
            ),
            dx_m=1000.0,
            dy_m=1000.0,
            projection="EPSG:5179",
            grid_hash="8" * 64,
            spatial_grid_contract="radar-spatial-grid-identity-v6",
            grid_shape_yx=(3, 3),
            projected_crs_digest=radar_projected_crs_semantic_digest(
                "EPSG:5179"
            ),
            metric_domain_digest=CURRENT_RADAR_METRIC_DOMAIN.digest,
            metric_domain_evidence_digest=(
                CURRENT_RADAR_METRIC_DOMAIN_EVIDENCE.digest
            ),
            cell_center_origin_xy_m=(1_000_000.0, 2_000_000.0),
            grid_coordinate_dtype=RADAR_PROJECTED_GRID_COORDINATE_DTYPE,
            cell_center_convention=(
                RADAR_PROJECTED_GRID_CELL_CENTER_CONVENTION
            ),
        )
        impulse = torch.zeros((3, 3), dtype=torch.float64)
        impulse[1, 1] = 1.0

        with self.assertRaisesRegex(
            GeodeticMetricUncertaintyError,
            "uncertain grid annulus",
        ):
            sensitivity_module._affine_footprint_average(
                impulse,
                grid,
                1000.0,
            )

    def test_physical_fss_uses_exact_anisotropic_affine_footprint(self) -> None:
        grid = RadarGridTimeContract(
            valid_times=(
                "2026-08-05T00:00:00Z",
                "2026-08-05T00:10:00Z",
                "2026-08-05T00:20:00Z",
            ),
            dx_m=250.0,
            dy_m=2_000.0,
            projection="EPSG:5179",
            grid_hash="5" * 64,
        )
        impulse = torch.zeros((9, 41), dtype=torch.float64)
        impulse[4, 20] = 1.0
        local = sensitivity_module._affine_footprint_average(
            impulse,
            grid,
            4_500.0,
        )

        self.assertGreater(float(local[4, 38]), 0.0)
        self.assertGreater(float(local[6, 20]), 0.0)
        self.assertEqual(float(local[7, 20]), 0.0)
        self.assertEqual(
            sensitivity_module._metric_tile_shape(
                SensitivityConfig(tile_size_m=9_000.0),
                grid,
            ),
            (5, 36),
        )

    def test_candidate_ranking_is_dimensionless_and_benefit_directed(self) -> None:
        available = torch.ones((1, 2), dtype=torch.bool)
        scales = torch.tensor((0.1, 100.0), dtype=torch.float64)
        weights = torch.ones((1, 2), dtype=torch.float64)
        equal_normalized = torch.tensor(
            ((-0.1, -100.0),),
            dtype=torch.float64,
        )
        harmful = -equal_normalized

        score = sensitivity_module._candidate_ranking_score(
            equal_normalized,
            available,
            scales,
            weights,
            "expected_error_reduction",
        )
        harmful_score = sensitivity_module._candidate_ranking_score(
            harmful,
            available,
            scales,
            weights,
            "expected_error_reduction",
        )

        self.assertAlmostEqual(score, math.sqrt(2.0))
        self.assertEqual(harmful_score, 0.0)


class VariationalFSOTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        coordinates = torch.arange(8, dtype=torch.float64)
        y, x = torch.meshgrid(coordinates, coordinates, indexing="ij")
        cls.frames = torch.stack(
            tuple(
                -10.0
                + 40.0
                * torch.exp(
                    -(
                        (y - center).square()
                        + (x - center).square()
                    )
                    / 4.0
                )
                for center in (3.0, 3.5, 4.0)
            )
        )
        cls.nowcast_config = NowcastConfig(horizon_minutes=10)
        cls.analysis_config = AnalysisConfig(
            censored_background_policy="detection_limit",
            maximum_outer_iterations=12,
            maximum_pcg_iterations=100,
            pcg_relative_tolerance=1.0e-8,
        )
        cls.forecast, cls.analysis = variational_nowcast(
            cls.frames,
            nowcast_config=cls.nowcast_config,
            analysis_config=cls.analysis_config,
        )
        if (
            not cls.analysis.converged
            or cls.analysis.degraded
            or cls.analysis.linearization is None
        ):
            raise RuntimeError("variational FSO fixture did not converge")
        cls.verification = torch.where(
            torch.isfinite(cls.forecast.forecast_dbz),
            cls.forecast.forecast_dbz - 0.5,
            cls.forecast.forecast_dbz,
        )
        cls.sensitivity_config = SensitivityConfig(
            metric_names=("log_echo_mse",),
            full_map_lead_minutes=(10,),
            tile_size=4,
        )
        cls.fso = compute_variational_fso(
            cls.forecast,
            cls.analysis,
            cls.verification,
            sensitivity_config=cls.sensitivity_config,
        )

    def test_physical_fsoi_includes_spatial_prior_uncertainty_path(self) -> None:
        input_run = ForecastRunContract.from_inputs(
            self.nowcast_config,
            self.frames,
            torch.isfinite(self.frames),
            None,
        )
        runner = NeuralPriorInferenceRunner(
            _SpatialStdPrior().eval(),
            lambda value: value,
            example_frames=self.frames,
            state_contract=NeuralPriorStateContract(
                state_product_digest="a" * 64,
                state_qc_pipeline_digest="9" * 64,
                state_mask_policy_digest="3" * 64,
                state_censor_policy_digest=neural_prior_state_censor_policy_digest(
                    detection_limit_dbz=5.0,
                    censor_temperature_dbz=1.0,
                    censored_background_policy=(
                        self.analysis_config.censored_background_policy
                    ),
                    minimum_dbz=-10.0,
                    maximum_dbz=70.0,
                ),
                support_threshold_dbz=5.0,
                minimum_state_dbz=-10.0,
                maximum_state_dbz=70.0,
                minimum_state_std_dbz=0.1,
                maximum_state_std_dbz=20.0,
                valid_decision_probability=0.6,
                support_decision_probability=0.7,
            ),
            probability_contract=NeuralPriorProbabilityContract(
                support_threshold_dbz=5.0,
                support_product_digest="a" * 64,
                qc_pipeline_digest="9" * 64,
                reflectivity_resolution_dbz=0.5,
                quantization_origin_dbz=-10.0,
            ),
            model_contract_digest="4" * 64,
            feature_schema_digest="5" * 64,
            training_manifest_digest="6" * 64,
            dependency="radar_dependent",
        )
        application = runner.infer(
            self.frames,
            input_run=input_run,
            role="candidate",
        )
        forecast, analysis = variational_nowcast(
            self.frames,
            nowcast_config=self.nowcast_config,
            analysis_config=replace(
                self.analysis_config,
                maximum_outer_iterations=20,
            ),
            neural_prior=application,
        )
        linearization = analysis.linearization
        self.assertTrue(analysis.converged)
        assert linearization is not None
        delta = torch.zeros_like(self.frames)
        delta[0, 3, 3] = 0.01
        perturbation = VariationalObservationPerturbation.from_radar_dbz_delta(
            delta,
            linearization,
            neural_prior_runner=runner,
            neural_prior_application=application,
        )
        verification = torch.where(
            torch.isfinite(forecast.forecast_dbz),
            forecast.forecast_dbz - 0.5,
            forecast.forecast_dbz,
        )
        fsoi = compute_variational_fsoi(
            forecast,
            analysis,
            verification,
            perturbation,
            sensitivity_config=self.sensitivity_config,
            adjoint_config=VariationalAdjointConfig(
                maximum_gauss_newton_relative_curvature_defect=1.0e9,
            ),
            neural_prior_runner=runner,
            neural_prior_application=application,
        )
        total_from_map = torch.sum(
            fsoi.fso.observation.frozen_structure_input_dbz.maps[0, 0]
            * delta
        )
        total_from_components = torch.sum(fsoi.observation.total.sum_by_time)
        torch.testing.assert_close(total_from_components, total_from_map)
        self.assertAlmostEqual(
            fsoi.fso.active_set_margins.neural_prior_support_probability,
            0.3,
        )
        self.assertAlmostEqual(
            fsoi.fso.active_set_margins.neural_prior_valid_probability,
            0.4,
        )
        self.assertNotEqual(
            float(torch.sum(fsoi.observation.initial_background_dbz.sum_by_time)),
            0.0,
        )

    def test_variational_fso_covers_all_observation_times(self) -> None:
        fso = self.fso
        self.assertEqual(fso.contract, EXPLORATORY_VARIATIONAL_FSO_CONTRACT)
        self.assertGreaterEqual(
            fso.neural_prior_adjoint_direction_maximum_defect,
            0.0,
        )
        self.assertEqual(
            fso.sensitivity_scope,
            "residual_plus_input_dependent_initial_state_and_baseline_with_frozen_selection",
        )
        self.assertFalse(fso.baseline_dynamics_frozen)
        self.assertTrue(fso.baseline_pair_selection_frozen)
        self.assertEqual(fso.baseline_dynamics_branch_status, "unknown")
        self.assertIsNone(
            fso.observation.trusted_frozen_structure_input_dbz
        )
        self.assertEqual(
            fso.verification_contract,
            "legacy-verification-tensor-v1",
        )
        self.assertFalse(fso.verification_lineage_complete)
        self.assertIsNone(fso.verification_valid_times)
        self.assertEqual(fso.metric_names, ("log_echo_mse",))
        self.assertEqual(fso.metric_domain, "issued")
        self.assertNotEqual(fso.metric_domain_digest, "")
        self.assertEqual(fso.lead_minutes, (10,))
        self.assertEqual(fso.full_map_lead_minutes, (10,))
        self.assertEqual(
            fso.linearization_contract,
            "p1-final-frozen-irls-gn-v15",
        )
        self.assertEqual(
            fso.forecast_run_digest,
            self.forecast.forecast_run_digest,
        )
        linearization = self.analysis.linearization
        assert linearization is not None
        self.assertEqual(
            linearization.forecast_run_digest,
            self.forecast.forecast_run_digest,
        )
        self.assertEqual(fso.linearization_digest, linearization.linearization_digest)
        self.assertEqual(
            fso.algorithm_bundle_digest,
            linearization.algorithm_bundle_digest,
        )
        self.assertEqual(
            fso.numerical_runtime_digest,
            linearization.numerical_runtime_digest,
        )
        self.assertEqual(
            fso.feasibility_margins.reachability_support,
            linearization.feasibility_margins.reachability_support,
        )
        self.assertEqual(
            fso.feasibility_margins.unresolved_amplitude_fraction,
            linearization.feasibility_margins.unresolved_amplitude_fraction,
        )
        self.assertEqual(
            fso.feasibility_margins.motion_saturation_fraction,
            linearization.feasibility_margins.motion_saturation_fraction,
        )
        self.assertEqual(
            fso.feasibility_margins.growth_saturation_per_step,
            linearization.feasibility_margins.growth_saturation_per_step,
        )
        self.assertEqual(
            fso.variational_fso_digest,
            variational_fso_digest(fso),
        )
        validate_variational_fso(fso)
        self.assertLessEqual(
            linearization.relative_stationarity,
            self.analysis_config
            .final_linearization_relative_stationarity_tolerance,
        )
        self.assertEqual(
            self.analysis.linearization_relative_stationarity,
            linearization.relative_stationarity,
        )
        self.assertEqual(
            self.analysis.linearization_polish_iterations,
            linearization.polish_iterations,
        )
        self.assertEqual(
            fso.analysis_input_digest,
            self.forecast.run.analysis_input_digest,
        )
        self.assertEqual(fso.forecast_scores.shape, (1, 1))
        self.assertEqual(fso.metric_available.shape, (1, 1))
        self.assertEqual(fso.forecast_cap_active_mask.shape, (1, 8, 8))
        self.assertEqual(
            fso.observation.detected_dbz.maps.shape,
            (1, 1, 3, 8, 8),
        )
        self.assertEqual(
            fso.observation.detected_dbz.norm_by_time.shape,
            (1, 1, 3),
        )
        self.assertEqual(
            fso.observation.initial_background_dbz.maps.shape,
            (1, 1, 3, 8, 8),
        )
        self.assertEqual(
            fso.observation.baseline_dynamics_dbz.maps.shape,
            (1, 1, 3, 8, 8),
        )
        torch.testing.assert_close(
            fso.observation.frozen_structure_input_dbz.maps,
            fso.observation.detected_dbz.maps
            + fso.observation.initial_background_dbz.maps
            + fso.observation.baseline_dynamics_dbz.maps,
        )
        self.assertEqual(
            int(
                torch.count_nonzero(
                    fso.observation.initial_background_dbz.maps[
                        ..., 1:, :, :
                    ]
                )
            ),
            0,
        )
        self.assertGreater(fso.total_normal_products, 0)
        self.assertEqual(
            fso.total_normal_products,
            int(fso.adjoint_normal_products.sum())
            + fso.gauss_newton_diagnostics.normal_products,
        )
        self.assertGreater(fso.materialized_output_bytes, 0)
        self.assertGreaterEqual(
            float(fso.adjoint_true_residual_norm[0, 0]),
            0.0,
        )
        self.assertEqual(fso.adjoint_config_digest, VariationalAdjointConfig().digest)
        self.assertFalse(bool(fso.adjoint_warm_started[0, 0]))
        self.assertEqual(
            fso.gauss_newton_diagnostics.relative_curvature_defect.shape,
            (VariationalAdjointConfig().gauss_newton_probe_count,),
        )
        self.assertEqual(
            fso.gauss_newton_diagnostics.exact_hessian_products,
            VariationalAdjointConfig().gauss_newton_probe_count,
        )
        self.assertTrue(
            bool(
                torch.all(
                    torch.isfinite(
                        fso.gauss_newton_diagnostics
                        .relative_curvature_defect
                    )
                )
            )
        )

    def test_verification_bundle_binds_time_grid_qc_and_content(self) -> None:
        grid = RadarGridTimeContract(
            valid_times=(
                "2026-08-05T00:00:00Z",
                "2026-08-05T00:10:00Z",
                "2026-08-05T00:20:00Z",
            ),
            dx_m=1000.0,
            dy_m=1000.0,
            projection="EPSG:5179",
            grid_hash="4" * 64,
            spatial_grid_contract="radar-spatial-grid-identity-v6",
            grid_shape_yx=tuple(self.frames.shape[-2:]),
            projected_crs_digest=radar_projected_crs_semantic_digest(
                "EPSG:5179"
            ),
            metric_domain_digest=CURRENT_RADAR_METRIC_DOMAIN.digest,
            metric_domain_evidence_digest=(
                CURRENT_RADAR_METRIC_DOMAIN_EVIDENCE.digest
            ),
            cell_center_origin_xy_m=(1_000_000.0, 2_000_000.0),
            grid_coordinate_dtype=RADAR_PROJECTED_GRID_COORDINATE_DTYPE,
            cell_center_convention=(
                RADAR_PROJECTED_GRID_CELL_CENTER_CONVENTION
            ),
        )
        forecast, analysis = variational_nowcast(
            self.frames,
            nowcast_config=self.nowcast_config,
            analysis_config=self.analysis_config,
            grid_time_contract=grid,
        )
        self.assertTrue(analysis.converged)
        self.assertFalse(analysis.degraded)
        verification_frames = torch.where(
            torch.isfinite(forecast.forecast_dbz),
            forecast.forecast_dbz - 0.5,
            forecast.forecast_dbz,
        )
        legacy_bundle = VerificationBundle(
            frames_dbz=verification_frames,
            valid_mask=torch.isfinite(verification_frames),
            valid_times=("2026-08-05T00:30:00Z",),
            grid_contract_digest=grid.digest,
            radar_product_digest="5" * 64,
            qc_pipeline_digest="6" * 64,
        )
        bundle = _current_verification_bundle(
            verification_frames,
            valid_times=("2026-08-05T00:30:00Z",),
            grid_time_contract=grid,
        )
        strict_config = replace(
            self.sensitivity_config,
            require_verification_lineage=True,
        )
        fso = compute_variational_fso(
            forecast,
            analysis,
            bundle,
            sensitivity_config=strict_config,
        )
        self.assertTrue(fso.verification_lineage_complete)
        self.assertEqual(fso.contract, CURRENT_VARIATIONAL_FSO_CONTRACT)
        self.assertEqual(
            fso.verification_contract,
            "radar-verification-bundle-v22",
        )
        self.assertEqual(fso.verification_bundle_digest, bundle.content_digest)
        self.assertEqual(fso.verification_valid_times, bundle.valid_times)
        self.assertEqual(fso.verification_grid_contract_digest, grid.digest)
        validate_variational_fso(fso)

        approved_config = replace(
            strict_config,
            required_verification_radar_product_digest="5" * 64,
            required_verification_qc_pipeline_digest="6" * 64,
        )
        compute_variational_fso(
            forecast,
            analysis,
            bundle,
            sensitivity_config=approved_config,
        )
        with self.assertRaisesRegex(ValueError, "not approved"):
            compute_variational_fso(
                forecast,
                analysis,
                bundle,
                sensitivity_config=replace(
                    approved_config,
                    required_verification_qc_pipeline_digest="8" * 64,
                ),
            )

        with self.assertRaisesRegex(ValueError, "VerificationBundle"):
            compute_variational_fso(
                forecast,
                analysis,
                verification_frames,
                sensitivity_config=strict_config,
            )
        with self.assertRaisesRegex(ValueError, "audit-only"):
            compute_variational_fso(
                forecast,
                analysis,
                legacy_bundle,
                sensitivity_config=strict_config,
            )
        wrong_time = _current_verification_bundle(
            verification_frames,
            valid_times=("2026-08-05T00:40:00Z",),
            grid_time_contract=grid,
        )
        with self.assertRaisesRegex(ValueError, "valid times"):
            compute_variational_fso(
                forecast,
                analysis,
                wrong_time,
                sensitivity_config=strict_config,
            )
        wrong_grid = _current_verification_bundle(
            verification_frames,
            valid_times=bundle.valid_times,
            grid_time_contract=replace(
                grid,
                cell_center_origin_xy_m=(1_000_500.0, 2_000_000.0),
            ),
        )
        with self.assertRaisesRegex(ValueError, "grid contracts"):
            compute_variational_fso(
                forecast,
                analysis,
                wrong_grid,
                sensitivity_config=strict_config,
            )
        altered_grids = {
            "reversed-y": replace(
                grid,
                pixel_to_projected_matrix_m=(
                    (1000.0, 0.0),
                    (0.0, 1000.0),
                ),
            ),
            "rotated": replace(
                grid,
                pixel_to_projected_matrix_m=(
                    (0.0, -1000.0),
                    (1000.0, 0.0),
                ),
            ),
            "reversed-x": replace(
                grid,
                pixel_to_projected_matrix_m=(
                    (-1000.0, 0.0),
                    (0.0, -1000.0),
                ),
            ),
            "anisotropic": replace(
                grid,
                dy_m=2000.0,
                pixel_to_projected_matrix_m=(
                    (1000.0, 0.0),
                    (0.0, -2000.0),
                ),
            ),
        }
        for label, altered_grid in altered_grids.items():
            with self.subTest(label=label):
                altered_bundle = _current_verification_bundle(
                    verification_frames,
                    valid_times=bundle.valid_times,
                    grid_time_contract=altered_grid,
                )
                with self.assertRaisesRegex(ValueError, "grid contracts"):
                    compute_variational_fso(
                        forecast,
                        analysis,
                        altered_bundle,
                        sensitivity_config=strict_config,
                    )

        with self.assertRaisesRegex(ValueError, "projected-metre CRS"):
            replace(grid, projection="EPSG:3857")

        valid_index = tuple(
            int(value)
            for value in torch.nonzero(bundle.valid_mask, as_tuple=False)[0]
        )
        bundle.frames_dbz[valid_index] += 1.0
        with self.assertRaisesRegex(ValueError, "content digest"):
            bundle.validate_integrity()

    def test_verification_observation_error_controls_metric_weight(self) -> None:
        frames = torch.tensor([[[12.0, 8.0], [2.0, -10.0]]])
        valid = torch.tensor([[[True, True], [True, False]]])
        quality = torch.tensor([[[1.0, 0.5], [0.0, 0.0]]])
        error_std = torch.tensor([[[2.0, 4.0], [2.0, 0.0]]])
        observation_state = torch.tensor(
            [[[
                int(VerificationCellState.OBSERVED_ECHO),
                int(VerificationCellState.OBSERVED_ECHO),
            ], [
                int(VerificationCellState.OBSERVED_ECHO),
                int(VerificationCellState.QC_INVALID),
            ]]],
            dtype=torch.uint8,
        )
        plan = VerificationObservationErrorPlan(
            radar_source_kind="single_site",
            source_registry_digest="0" * 64,
            calibration_registry_digest="1" * 64,
            range_elevation_validity_algorithm_digest=(
                OBSERVATION_ERROR_DERIVATION_ALGORITHM_DIGEST
            ),
            beam_blockage_algorithm_digest=(
                OBSERVATION_ERROR_DERIVATION_ALGORITHM_DIGEST
            ),
            attenuation_qc_digest="5" * 64,
            censoring_rule_digest="6" * 64,
            spatial_correlation_block_algorithm_digest="7" * 64,
            quality_weight_interpretation_digest="8" * 64,
            quality_weight_algorithm_digest=(
                OBSERVATION_ERROR_DERIVATION_ALGORITHM_DIGEST
            ),
            observation_std_algorithm_digest=(
                OBSERVATION_ERROR_DERIVATION_ALGORITHM_DIGEST
            ),
            observation_error_model_digest="9" * 64,
            source_assignment_algorithm_digest=(
                OBSERVATION_ERROR_DERIVATION_ALGORITHM_DIGEST
            ),
            minimum_detectable_echo_dbz=-10.0,
            observation_error_reference_std_dbz=2.0,
        )
        error = VerificationObservationErrorContract.from_tensors(
            plan=plan,
            frames_dbz=frames,
            valid_mask=valid,
            quality_weight=quality,
            observation_std_dbz=error_std,
            observation_state_code=observation_state,
            source_radar_index_map=None,
            source_calibration_epochs=(("1" * 64, "2" * 64),),
            range_elevation_validity_domain_digest="3" * 64,
            beam_blockage_visibility_mask_digest="4" * 64,
            spatial_correlation_block_digest="7" * 64,
        )
        self.assertEqual(error.observation_error_plan_digest, plan.plan_digest)
        with self.assertRaisesRegex(ValueError, "observation-error plan"):
            error.validate_against_plan(
                replace(plan, observation_error_reference_std_dbz=4.0)
            )
        with self.assertRaisesRegex(ValueError, "observation-error plan"):
            error.validate_against_plan(
                replace(plan, spatial_correlation_role="inferential")  # type: ignore[arg-type]
            )
        bundle = VerificationBundle(
            frames_dbz=frames,
            valid_mask=valid,
            valid_times=("2026-08-05T00:30:00Z",),
            grid_contract_digest="a" * 64,
            radar_product_digest="b" * 64,
            qc_pipeline_digest="5" * 64,
            mask_policy_digest="c" * 64,
            censor_policy_digest="6" * 64,
            reflectivity_resolution_dbz=0.5,
            quantization_origin_dbz=-10.0,
            threshold_bin_convention="nearest_rounding_threshold_censor",
            floor_representation_contract_digest="d" * 64,
            quality_weight=quality,
            observation_std_dbz=error_std,
            observation_state_code=observation_state,
            observation_error_contract=error,
            contract="radar-verification-bundle-v6",
        )
        self.assertTrue(
            torch.equal(
                bundle.metric_weight,
                torch.tensor([[[1.0, 0.125], [0.0, 0.0]]]),
            )
        )
        bundle.quality_weight[0, 0, 0] = 0.0
        with self.assertRaisesRegex(ValueError, "content digest"):
            bundle.validate_integrity()

    def test_verification_cell_state_preserves_censoring_without_point_score(
        self,
    ) -> None:
        plan = VerificationObservationErrorPlan(
            radar_source_kind="single_site",
            source_registry_digest="0" * 64,
            calibration_registry_digest="1" * 64,
            range_elevation_validity_algorithm_digest="2" * 64,
            beam_blockage_algorithm_digest="3" * 64,
            attenuation_qc_digest="5" * 64,
            censoring_rule_digest="6" * 64,
            spatial_correlation_block_algorithm_digest="7" * 64,
            quality_weight_interpretation_digest="8" * 64,
            quality_weight_algorithm_digest="a" * 64,
            observation_std_algorithm_digest="b" * 64,
            observation_error_model_digest="9" * 64,
            source_assignment_algorithm_digest="c" * 64,
            minimum_detectable_echo_dbz=-10.0,
            observation_error_reference_std_dbz=2.0,
        )
        frames = torch.tensor([[[-10.0, 12.0]]])
        valid = torch.ones_like(frames, dtype=torch.bool)
        quality = torch.ones_like(frames)
        error_std = torch.full_like(frames, 2.0)
        state = torch.tensor(
            [[[
                int(VerificationCellState.BELOW_DETECTION_CENSORED),
                int(VerificationCellState.OBSERVED_ECHO),
            ]]],
            dtype=torch.uint8,
        )
        error = VerificationObservationErrorContract.from_tensors(
            plan=plan,
            frames_dbz=frames,
            valid_mask=valid,
            quality_weight=quality,
            observation_std_dbz=error_std,
            observation_state_code=state,
            source_radar_index_map=None,
            source_calibration_epochs=(("1" * 64, "2" * 64),),
            range_elevation_validity_domain_digest="3" * 64,
            beam_blockage_visibility_mask_digest="4" * 64,
            spatial_correlation_block_digest="7" * 64,
        )
        bundle = VerificationBundle(
            frames_dbz=frames,
            valid_mask=valid,
            valid_times=("2026-08-05T00:30:00Z",),
            grid_contract_digest="a" * 64,
            radar_product_digest="b" * 64,
            qc_pipeline_digest="5" * 64,
            mask_policy_digest="c" * 64,
            censor_policy_digest="6" * 64,
            reflectivity_resolution_dbz=0.5,
            quantization_origin_dbz=-10.0,
            threshold_bin_convention="nearest_rounding_threshold_censor",
            floor_representation_contract_digest="d" * 64,
            quality_weight=quality,
            observation_std_dbz=error_std,
            observation_state_code=state,
            observation_error_contract=error,
            contract="radar-verification-bundle-v6",
        )
        self.assertTrue(
            torch.equal(bundle.metric_weight, torch.tensor([[[0.0, 1.0]]]))
        )
        with self.assertRaisesRegex(ValueError, "state semantics"):
            VerificationObservationErrorContract.from_tensors(
                plan=plan,
                frames_dbz=frames,
                valid_mask=valid,
                quality_weight=quality,
                observation_std_dbz=error_std,
                observation_state_code=torch.tensor(
                    [[[
                        int(VerificationCellState.SOURCE_MISSING),
                        int(VerificationCellState.OBSERVED_ECHO),
                    ]]],
                    dtype=torch.uint8,
                ),
                source_radar_index_map=None,
                source_calibration_epochs=(("1" * 64, "2" * 64),),
                range_elevation_validity_domain_digest="3" * 64,
                beam_blockage_visibility_mask_digest="4" * 64,
                spatial_correlation_block_digest="7" * 64,
            )

    def test_mosaic_cell_state_is_bound_to_source_assignment(self) -> None:
        plan = VerificationObservationErrorPlan(
            radar_source_kind="mosaic",
            source_registry_digest="0" * 64,
            calibration_registry_digest="1" * 64,
            range_elevation_validity_algorithm_digest="2" * 64,
            beam_blockage_algorithm_digest="3" * 64,
            attenuation_qc_digest="5" * 64,
            censoring_rule_digest="6" * 64,
            spatial_correlation_block_algorithm_digest="7" * 64,
            quality_weight_interpretation_digest="8" * 64,
            quality_weight_algorithm_digest="a" * 64,
            observation_std_algorithm_digest="b" * 64,
            observation_error_model_digest="9" * 64,
            source_assignment_algorithm_digest="c" * 64,
            minimum_detectable_echo_dbz=-10.0,
            observation_error_reference_std_dbz=2.0,
        )
        frames = torch.tensor([[[12.0, -10.0]]])
        valid = torch.tensor([[[True, False]]])
        quality = torch.tensor([[[1.0, 0.0]]])
        error_std = torch.tensor([[[2.0, 0.0]]])
        state = torch.tensor(
            [[[
                int(VerificationCellState.OBSERVED_ECHO),
                int(VerificationCellState.MOSAIC_SOURCE_UNASSIGNED),
            ]]],
            dtype=torch.uint8,
        )
        source_map = torch.tensor([[[0, -1]]], dtype=torch.int64)
        error = VerificationObservationErrorContract.from_tensors(
            plan=plan,
            frames_dbz=frames,
            valid_mask=valid,
            quality_weight=quality,
            observation_std_dbz=error_std,
            observation_state_code=state,
            source_radar_index_map=source_map,
            source_calibration_epochs=(
                ("1" * 64, "2" * 64),
                ("3" * 64, "4" * 64),
            ),
            range_elevation_validity_domain_digest="3" * 64,
            beam_blockage_visibility_mask_digest="4" * 64,
            spatial_correlation_block_digest="7" * 64,
        )
        self.assertEqual(
            error.source_radar_index_map_digest,
            tensor_digest(source_map),
        )
        with self.assertRaisesRegex(ValueError, "state semantics"):
            VerificationObservationErrorContract.from_tensors(
                plan=plan,
                frames_dbz=frames,
                valid_mask=valid,
                quality_weight=quality,
                observation_std_dbz=error_std,
                observation_state_code=state,
                source_radar_index_map=torch.tensor(
                    [[[0, 1]]], dtype=torch.int64
                ),
                source_calibration_epochs=(
                    ("1" * 64, "2" * 64),
                    ("3" * 64, "4" * 64),
                ),
                range_elevation_validity_domain_digest="3" * 64,
                beam_blockage_visibility_mask_digest="4" * 64,
                spatial_correlation_block_digest="7" * 64,
            )

    def test_mosaic_observation_registry_bounds_and_binds_source_indices(
        self,
    ) -> None:
        source_a = ObservationRadarSource(
            radar_site_digest="1" * 64,
            calibration_epoch_digest="2" * 64,
            quality_weight=1.0,
            observation_std_dbz=2.0,
        )
        source_b = ObservationRadarSource(
            radar_site_digest="3" * 64,
            calibration_epoch_digest="4" * 64,
            quality_weight=0.75,
            observation_std_dbz=3.0,
        )
        registry = MosaicObservationSourceRegistry(
            radar_source_kind="mosaic",
            ordered_sources=(source_a, source_b),
        )
        plan = VerificationObservationErrorPlan(
            radar_source_kind="mosaic",
            source_registry_digest=registry.source_registry_digest,
            calibration_registry_digest=registry.calibration_registry_digest,
            range_elevation_validity_algorithm_digest=(
                OBSERVATION_ERROR_DERIVATION_ALGORITHM_DIGEST
            ),
            beam_blockage_algorithm_digest=(
                OBSERVATION_ERROR_DERIVATION_ALGORITHM_DIGEST
            ),
            attenuation_qc_digest="5" * 64,
            censoring_rule_digest="6" * 64,
            spatial_correlation_block_algorithm_digest="7" * 64,
            quality_weight_interpretation_digest="8" * 64,
            quality_weight_algorithm_digest=(
                OBSERVATION_ERROR_DERIVATION_ALGORITHM_DIGEST
            ),
            observation_std_algorithm_digest=(
                OBSERVATION_ERROR_DERIVATION_ALGORITHM_DIGEST
            ),
            observation_error_model_digest="9" * 64,
            source_assignment_algorithm_digest=(
                OBSERVATION_ERROR_DERIVATION_ALGORITHM_DIGEST
            ),
            minimum_detectable_echo_dbz=-10.0,
            observation_error_reference_std_dbz=2.0,
        )
        registry.validate_against_plan(plan)
        registry.validate_source_map(
            torch.tensor([[[0, 1, -1]]], dtype=torch.int64),
            expected_shape=torch.Size((1, 1, 3)),
            expected_device=torch.device("cpu"),
        )
        for invalid_index in (2, 999):
            with self.subTest(invalid_index=invalid_index):
                with self.assertRaisesRegex(ValueError, "outside its registry"):
                    registry.validate_source_map(
                        torch.tensor([[[invalid_index]]], dtype=torch.int64),
                        expected_shape=torch.Size((1, 1, 1)),
                        expected_device=torch.device("cpu"),
                    )
        reordered = MosaicObservationSourceRegistry(
            radar_source_kind="mosaic",
            ordered_sources=(source_b, source_a),
        )
        with self.assertRaisesRegex(
            ValueError,
            "disagrees with its plan|disagrees with its preregistered registry",
        ):
            reordered.validate_against_plan(plan)
        wrong_calibration = MosaicObservationSourceRegistry(
            radar_source_kind="mosaic",
            ordered_sources=(
                replace(
                    source_a,
                    calibration_epoch_digest=source_b.calibration_epoch_digest,
                ),
                replace(
                    source_b,
                    calibration_epoch_digest=source_a.calibration_epoch_digest,
                ),
            ),
        )
        with self.assertRaisesRegex(
            ValueError,
            "disagrees with its plan|disagrees with its preregistered registry",
        ):
            wrong_calibration.validate_against_plan(plan)

    def test_observation_error_derivation_replays_exact_registry_tensors(
        self,
    ) -> None:
        registry = MosaicObservationSourceRegistry(
            radar_source_kind="mosaic",
            ordered_sources=(
                ObservationRadarSource(
                    radar_site_digest="1" * 64,
                    calibration_epoch_digest="2" * 64,
                    quality_weight=1.0,
                    observation_std_dbz=2.0,
                ),
                ObservationRadarSource(
                    radar_site_digest="3" * 64,
                    calibration_epoch_digest="4" * 64,
                    quality_weight=0.5,
                    observation_std_dbz=4.0,
                    detection_limit_dbz=-5.0,
                    detection_limit_range_quadratic_dbz_per_km2=0.0001,
                ),
            ),
        )
        plan = VerificationObservationErrorPlan(
            radar_source_kind="mosaic",
            source_registry_digest=registry.source_registry_digest,
            calibration_registry_digest=registry.calibration_registry_digest,
            range_elevation_validity_algorithm_digest=(
                OBSERVATION_ERROR_DERIVATION_ALGORITHM_DIGEST
            ),
            beam_blockage_algorithm_digest=(
                OBSERVATION_ERROR_DERIVATION_ALGORITHM_DIGEST
            ),
            attenuation_qc_digest="5" * 64,
            censoring_rule_digest="6" * 64,
            spatial_correlation_block_algorithm_digest="7" * 64,
            quality_weight_interpretation_digest="8" * 64,
            quality_weight_algorithm_digest=(
                OBSERVATION_ERROR_DERIVATION_ALGORITHM_DIGEST
            ),
            observation_std_algorithm_digest=(
                OBSERVATION_ERROR_DERIVATION_ALGORITHM_DIGEST
            ),
            observation_error_model_digest="9" * 64,
            source_assignment_algorithm_digest=(
                OBSERVATION_ERROR_DERIVATION_ALGORITHM_DIGEST
            ),
            minimum_detectable_echo_dbz=-10.0,
            observation_error_reference_std_dbz=2.0,
            derivation_algorithm_digest=(
                OBSERVATION_ERROR_DERIVATION_ALGORITHM_DIGEST
            ),
            contract="verification-observation-error-plan-v2",
        )
        frames = torch.tensor([[[12.0, -12.0, 0.0]]])
        source_map = torch.tensor([[[0, 1, -1]]], dtype=torch.int64)
        raw_inputs = VerificationObservationDerivationInputs(
            frames_dbz=frames,
            source_present_mask=torch.ones_like(frames, dtype=torch.bool),
            range_elevation_valid_mask=torch.ones_like(
                frames,
                dtype=torch.bool,
            ),
            beam_blocked_mask=torch.zeros_like(frames, dtype=torch.bool),
            acquisition_time_valid_mask=torch.ones_like(
                frames,
                dtype=torch.bool,
            ),
            attenuation_qc_valid_mask=torch.ones_like(
                frames,
                dtype=torch.bool,
            ),
            confirmed_clear_mask=torch.zeros_like(frames, dtype=torch.bool),
            below_detection_censored_mask=torch.zeros_like(
                frames,
                dtype=torch.bool,
            ),
            source_radar_index_map=source_map,
            upstream_verification_artifact_digest="d" * 64,
            range_elevation_validity_domain_digest="3" * 64,
            beam_blockage_visibility_mask_digest="4" * 64,
            spatial_correlation_block_digest="7" * 64,
        )
        derivation = derive_verification_observation_error(
            plan=plan,
            raw_verification_source=raw_inputs,
            source_registry=registry,
        )
        derivation.validate_replay()
        repeated = derive_verification_observation_error(
            plan=plan,
            raw_verification_source=raw_inputs,
            source_registry=registry,
        )
        self.assertEqual(repeated.artifact_digest, derivation.artifact_digest)
        self.assertEqual(
            repeated.raw_inputs.raw_verification_identity_digest,
            derivation.raw_inputs.raw_verification_identity_digest,
        )
        with self.assertRaisesRegex(ValueError, "derivation is unsupported"):
            replace(plan, quality_weight_algorithm_digest="f" * 64)
        self.assertTrue(
            torch.equal(
                derivation.valid_mask,
                torch.tensor([[[True, True, False]]]),
            )
        )
        self.assertTrue(
            torch.equal(
                derivation.quality_weight,
                torch.tensor([[[1.0, 0.5, 0.0]]]),
            )
        )
        self.assertTrue(
            torch.equal(
                derivation.observation_std_dbz,
                torch.tensor([[[2.0, 4.0, 0.0]]]),
            )
        )
        contract = derivation.observation_error_contract
        self.assertEqual(contract.scientific_evidence_mode, "deterministic_replay")
        bundle = VerificationBundle(
            frames_dbz=frames,
            valid_mask=derivation.valid_mask,
            valid_times=("2026-08-05T00:30:00Z",),
            grid_contract_digest="a" * 64,
            radar_product_digest="b" * 64,
            qc_pipeline_digest="5" * 64,
            mask_policy_digest="c" * 64,
            censor_policy_digest="6" * 64,
            reflectivity_resolution_dbz=0.5,
            quantization_origin_dbz=-10.0,
            threshold_bin_convention="nearest_rounding_threshold_censor",
            floor_representation_contract_digest="e" * 64,
            quality_weight=derivation.quality_weight,
            observation_std_dbz=derivation.observation_std_dbz,
            observation_state_code=derivation.observation_state_code,
            source_radar_index_map=derivation.source_radar_index_map,
            observation_error_contract=contract,
            observation_error_derivation=derivation,
            contract="radar-verification-bundle-v7",
        )
        bundle.validate_integrity()
        exploratory = VerificationObservationErrorContract.from_tensors(
            plan=plan,
            frames_dbz=frames,
            valid_mask=derivation.valid_mask,
            quality_weight=derivation.quality_weight,
            observation_std_dbz=derivation.observation_std_dbz,
            observation_state_code=derivation.observation_state_code,
            source_radar_index_map=derivation.source_radar_index_map,
            source_calibration_epochs=registry.source_calibration_epochs,
            range_elevation_validity_domain_digest="3" * 64,
            beam_blockage_visibility_mask_digest="4" * 64,
            spatial_correlation_block_digest="7" * 64,
        )
        self.assertEqual(exploratory.scientific_evidence_mode, "exploratory_only")
        with self.assertRaisesRegex(ValueError, "disagrees with observation-error replay"):
            replace(bundle, observation_error_contract=exploratory)
        for tensor_name in (
            "_quality_weight",
            "_observation_std_dbz",
            "_observation_state_code",
        ):
            attacked = derive_verification_observation_error(
                plan=plan,
                raw_verification_source=raw_inputs,
                source_registry=registry,
            )
            tensor = getattr(attacked, tensor_name)
            tensor.data[0, 0, 0] = 0
            with self.subTest(tensor_name=tensor_name):
                with self.assertRaisesRegex(ValueError, "replay mismatch"):
                    attacked.validate_replay()
        attacked_plan = replace(plan)
        attacked_plan_derivation = derive_verification_observation_error(
            plan=attacked_plan,
            raw_verification_source=raw_inputs,
            source_registry=registry,
        )
        object.__setattr__(
            attacked_plan,
            "minimum_detectable_echo_dbz",
            -20.0,
        )
        with self.assertRaisesRegex(ValueError, "plan digest mismatch"):
            attacked_plan_derivation.validate_replay()
        attacked_registry = MosaicObservationSourceRegistry(
            radar_source_kind="mosaic",
            ordered_sources=tuple(
                replace(source) for source in registry.ordered_sources
            ),
        )
        attacked_registry_derivation = derive_verification_observation_error(
            plan=plan,
            raw_verification_source=raw_inputs,
            source_registry=attacked_registry,
        )
        object.__setattr__(
            attacked_registry.ordered_sources[0],
            "quality_weight",
            0.25,
        )
        with self.assertRaisesRegex(ValueError, "source digest mismatch"):
            attacked_registry_derivation.validate_replay()
        attacked_source = derive_verification_observation_error(
            plan=plan,
            raw_verification_source=raw_inputs,
            source_registry=registry,
        )
        assert attacked_source.raw_inputs.source_radar_index_map is not None
        attacked_source.raw_inputs.source_radar_index_map.data[0, 0, 0] = 999
        with self.assertRaisesRegex(ValueError, "input mismatch"):
            attacked_source.validate_replay()

    def test_current_geometry_binds_grid_identity_and_derived_spacing(
        self,
    ) -> None:
        grid_x_m = torch.tensor(
            [[0.0, 1000.0, 2000.0], [0.0, 1000.0, 2000.0]]
        )
        grid_y_m = torch.tensor(
            [[0.0, 0.0, 0.0], [1000.0, 1000.0, 1000.0]]
        )
        geometry = RadarObservationGeometryContract(
            grid_contract_digest="1" * 64,
            projected_crs_digest="2" * 64,
            grid_x_m=grid_x_m,
            grid_y_m=grid_y_m,
            grid_spacing_m=1000.0,
            contract="radar-observation-geometry-v2",
        )
        changed_grid_identity = RadarObservationGeometryContract(
            grid_contract_digest="3" * 64,
            projected_crs_digest="2" * 64,
            grid_x_m=grid_x_m,
            grid_y_m=grid_y_m,
            grid_spacing_m=1000.0,
            contract="radar-observation-geometry-v2",
        )
        self.assertNotEqual(
            geometry.geometry_digest,
            changed_grid_identity.geometry_digest,
        )
        self.assertEqual(geometry.grid_spacing_m, 1000.0)
        self.assertEqual(
            geometry.payload["grid_contract_digest"],
            "1" * 64,
        )

        with self.assertRaisesRegex(ValueError, "spacing disagrees"):
            RadarObservationGeometryContract(
                grid_contract_digest="1" * 64,
                projected_crs_digest="2" * 64,
                grid_x_m=grid_x_m,
                grid_y_m=grid_y_m,
                grid_spacing_m=10_000.0,
                contract="radar-observation-geometry-v2",
            )

    def test_scientific_geometry_is_generated_from_one_float64_affine(
        self,
    ) -> None:
        cosine = math.cos(math.radians(30.0))
        sine = math.sin(math.radians(30.0))
        grid = RadarGridTimeContract(
            valid_times=(
                "2026-08-05T00:00:00Z",
                "2026-08-05T00:10:00Z",
                "2026-08-05T00:20:00Z",
            ),
            dx_m=1000.0,
            dy_m=1000.0,
            projection="EPSG:5179",
            grid_hash="1" * 64,
            pixel_to_projected_matrix_m=(
                (1000.0 * cosine, -1000.0 * sine),
                (1000.0 * sine, 1000.0 * cosine),
            ),
            spatial_grid_contract="radar-spatial-grid-identity-v6",
            grid_shape_yx=(100, 100),
            projected_crs_digest=radar_projected_crs_semantic_digest(
                "EPSG:5179"
            ),
            metric_domain_digest=CURRENT_RADAR_METRIC_DOMAIN.digest,
            metric_domain_evidence_digest=(
                CURRENT_RADAR_METRIC_DOMAIN_EVIDENCE.digest
            ),
            cell_center_origin_xy_m=(1_000_000.0, 2_000_000.0),
            grid_coordinate_dtype=RADAR_PROJECTED_GRID_COORDINATE_DTYPE,
            cell_center_convention=(
                RADAR_PROJECTED_GRID_CELL_CENTER_CONVENTION
            ),
        )
        geometry = RadarObservationGeometryContract.from_grid_time_contract(
            grid
        )
        self.assertEqual(geometry.grid_x_m.dtype, torch.float64)
        self.assertEqual(geometry.grid_y_m.dtype, torch.float64)
        self.assertEqual(
            geometry.projected_grid_identity.digest,
            grid.spatial_grid_digest,
        )

        with self.assertRaisesRegex(ValueError, "affine geometry"):
            replace(
                geometry,
                grid_x_m=geometry.grid_x_m.to(torch.float32),
                grid_y_m=geometry.grid_y_m.to(torch.float32),
            )
        with self.assertRaisesRegex(ValueError, "projected grid"):
            replace(
                geometry,
                grid_y_m=torch.flip(geometry.grid_y_m, dims=(0,)),
            )
        shifted_grid = replace(
            grid,
            cell_center_origin_xy_m=(1_000_500.0, 2_000_000.0),
        )
        with self.assertRaisesRegex(ValueError, "projected grid"):
            replace(
                geometry,
                projected_grid_identity=shifted_grid.spatial_grid_identity,
            )
        with self.assertRaisesRegex(ValueError, "projected-grid identity"):
            replace(grid, projected_crs_digest="2" * 64)

        reversed_y_grid = replace(
            grid,
            pixel_to_projected_matrix_m=(
                grid.pixel_to_projected_matrix_m[0],
                (
                    grid.pixel_to_projected_matrix_m[1][0],
                    -grid.pixel_to_projected_matrix_m[1][1],
                ),
            ),
        )
        self.assertNotEqual(
            reversed_y_grid.spatial_grid_digest,
            grid.spatial_grid_digest,
        )

        axis_grid = replace(
            grid,
            pixel_to_projected_matrix_m=((1000.0, 0.0), (0.0, -1000.0)),
            grid_shape_yx=(2, 1),
            cell_center_origin_xy_m=(1_000_000.0, 2_000_000.0),
        )
        axis_geometry = RadarObservationGeometryContract.from_grid_time_contract(
            axis_grid
        )
        off_axis_source = ObservationRadarSource(
            radar_site_digest="4" * 64,
            calibration_epoch_digest="5" * 64,
            quality_weight=1.0,
            observation_std_dbz=2.0,
            projected_x_m=1_000_000.0,
            projected_y_m=2_001_000.0,
            radar_altitude_m=100.0,
            representative_scan_elevation_deg=1.0,
            contract="observation-radar-source-v4",
        )
        axis_registry = MosaicObservationSourceRegistry(
            radar_source_kind="single_site",
            ordered_sources=(off_axis_source,),
            projected_crs_digest=axis_geometry.projected_crs_digest,
            metric_domain_digest=CURRENT_RADAR_METRIC_DOMAIN.digest,
            metric_domain_evidence_digest=(
                CURRENT_RADAR_METRIC_DOMAIN_EVIDENCE.digest
            ),
            geometry_model="projected-horizontal-representative-tilt-v1",
            radar_altitude_role="provenance_only",
            contract="mosaic-observation-source-registry-v7",
        )
        range_km, _ = sensitivity_module._registered_observation_geometry_fields(
            source_registry=axis_registry,
            geometry=axis_geometry,
            time_count=1,
        )
        torch.testing.assert_close(
            range_km[0, 0, :, 0],
            torch.tensor([1.0, 2.0], dtype=torch.float64),
        )

        legacy_x_m = torch.tensor(
            [[0.0, 1000.0, 2000.0], [0.0, 1000.0, 2000.0]]
        )
        legacy_y_m = torch.tensor(
            [[0.0, 0.0, 0.0], [1000.0, 1000.0, 1000.0]]
        )
        nonuniform_x_m = legacy_x_m.clone()
        nonuniform_x_m[:, 1:] = nonuniform_x_m[:, [2, 1]]
        with self.assertRaisesRegex(ValueError, "uniformly rectilinear"):
            RadarObservationGeometryContract(
                grid_contract_digest="1" * 64,
                projected_crs_digest="2" * 64,
                grid_x_m=nonuniform_x_m,
                grid_y_m=legacy_y_m,
                grid_spacing_m=1000.0,
                contract="radar-observation-geometry-v2",
            )

    def test_sheared_grid_uses_minimum_singular_spatial_age_gate(
        self,
    ) -> None:
        common = {
            "valid_times": (
                "2026-08-05T00:00:00Z",
                "2026-08-05T00:10:00Z",
                "2026-08-05T00:20:00Z",
            ),
            "dx_m": 1000.0,
            "dy_m": 1000.0,
            "projection": "EPSG:5179",
            "grid_shape_yx": (2, 2),
            "projected_crs_digest": radar_projected_crs_semantic_digest(
                "EPSG:5179"
            ),
            "metric_domain_digest": CURRENT_RADAR_METRIC_DOMAIN.digest,
            "metric_domain_evidence_digest": (
                CURRENT_RADAR_METRIC_DOMAIN_EVIDENCE.digest
            ),
            "cell_center_origin_xy_m": (1_000_000.0, 2_000_000.0),
            "grid_coordinate_dtype": RADAR_PROJECTED_GRID_COORDINATE_DTYPE,
            "cell_center_convention": (
                RADAR_PROJECTED_GRID_CELL_CENTER_CONVENTION
            ),
            "spatial_grid_contract": "radar-spatial-grid-identity-v6",
        }
        orthogonal = RadarGridTimeContract(
            **common,
            grid_hash="1" * 64,
        )
        sheared = RadarGridTimeContract(
            **common,
            grid_hash="2" * 64,
            pixel_to_projected_matrix_m=(
                (1000.0, 800.0),
                (0.0, 600.0),
            ),
        )
        verification_frames = torch.full(
            (1, 2, 2),
            10.0,
            dtype=torch.float64,
        )
        valid_times = ("2026-08-05T00:30:00Z",)

        orthogonal_bundle = _current_verification_bundle(
            verification_frames,
            valid_times=valid_times,
            grid_time_contract=orthogonal,
            acquisition_time_offset_seconds=-30.0,
        )
        sheared_bundle = _current_verification_bundle(
            verification_frames,
            valid_times=valid_times,
            grid_time_contract=sheared,
            acquisition_time_offset_seconds=-30.0,
        )

        self.assertEqual(
            orthogonal.spatial_grid_identity.minimum_l2_cell_displacement_m,
            1000.0,
        )
        self.assertAlmostEqual(
            sheared.spatial_grid_identity.minimum_l2_cell_displacement_m,
            447.2135954999579,
        )
        self.assertTrue(
            bool(torch.all(orthogonal_bundle.spatial_metric_valid_mask))
        )
        self.assertFalse(
            bool(torch.any(sheared_bundle.spatial_metric_valid_mask))
        )
        with self.assertRaisesRegex(ValueError, "orthogonal grid axes"):
            sensitivity_module._metric_tile_shape(
                SensitivityConfig(tile_size_m=16_000.0),
                sheared,
            )
        with self.assertRaisesRegex(ValueError, "orthogonal grid axes"):
            sensitivity_module._perturbation_tile_size(
                VariationalAdjointConfig(
                    perturbation_tile_size_m=16_000.0,
                ),
                sheared,
            )
        self.assertEqual(
            sensitivity_module._metric_tile_shape(
                SensitivityConfig(tile_size=4),
                sheared,
            ),
            (4, 4),
        )

    def test_current_source_registry_rejects_radar_outside_metric_domain(
        self,
    ) -> None:
        source = ObservationRadarSource(
            radar_site_digest="1" * 64,
            calibration_epoch_digest="2" * 64,
            quality_weight=1.0,
            observation_std_dbz=2.0,
            projected_x_m=0.0,
            projected_y_m=0.0,
            radar_altitude_m=100.0,
            representative_scan_elevation_deg=1.0,
            contract="observation-radar-source-v4",
        )
        with self.assertRaisesRegex(ValueError, "outside the metric domain"):
            MosaicObservationSourceRegistry(
                radar_source_kind="single_site",
                ordered_sources=(source,),
                projected_crs_digest=radar_projected_crs_semantic_digest(
                    "EPSG:5179"
                ),
                metric_domain_digest=CURRENT_RADAR_METRIC_DOMAIN.digest,
                metric_domain_evidence_digest=(
                    CURRENT_RADAR_METRIC_DOMAIN_EVIDENCE.digest
                ),
                geometry_model=(
                    "projected-horizontal-representative-tilt-v1"
                ),
                radar_altitude_role="provenance_only",
                contract="mosaic-observation-source-registry-v7",
            )

    def test_current_verification_rejects_half_precision_spatial_fields(
        self,
    ) -> None:
        grid = RadarGridTimeContract(
            valid_times=(
                "2026-08-05T00:00:00Z",
                "2026-08-05T00:10:00Z",
                "2026-08-05T00:20:00Z",
            ),
            dx_m=1000.0,
            dy_m=1000.0,
            projection="EPSG:5179",
            grid_hash="3" * 64,
            spatial_grid_contract="radar-spatial-grid-identity-v6",
            grid_shape_yx=(2, 2),
            projected_crs_digest=radar_projected_crs_semantic_digest(
                "EPSG:5179"
            ),
            metric_domain_digest=CURRENT_RADAR_METRIC_DOMAIN.digest,
            metric_domain_evidence_digest=(
                CURRENT_RADAR_METRIC_DOMAIN_EVIDENCE.digest
            ),
            cell_center_origin_xy_m=(1_000_000.0, 2_000_000.0),
            grid_coordinate_dtype=RADAR_PROJECTED_GRID_COORDINATE_DTYPE,
            cell_center_convention=(
                RADAR_PROJECTED_GRID_CELL_CENTER_CONVENTION
            ),
        )
        for dtype in (torch.float16, torch.bfloat16):
            with self.subTest(dtype=dtype):
                with self.assertRaisesRegex(ValueError, "float32 or float64"):
                    _current_verification_bundle(
                        torch.full((1, 2, 2), 10.0, dtype=dtype),
                        valid_times=("2026-08-05T00:30:00Z",),
                        grid_time_contract=grid,
                    )

    def test_current_geometry_binds_registry_crs_and_model_scope(self) -> None:
        source = ObservationRadarSource(
            radar_site_digest="1" * 64,
            calibration_epoch_digest="2" * 64,
            quality_weight=1.0,
            observation_std_dbz=2.0,
            projected_x_m=0.0,
            projected_y_m=0.0,
            radar_altitude_m=100.0,
            representative_scan_elevation_deg=1.0,
            contract="observation-radar-source-v4",
        )
        registry = MosaicObservationSourceRegistry(
            radar_source_kind="single_site",
            ordered_sources=(source,),
            projected_crs_digest="3" * 64,
            geometry_model="projected-horizontal-representative-tilt-v1",
            radar_altitude_role="provenance_only",
            contract="mosaic-observation-source-registry-v5",
        )
        other_crs_registry = MosaicObservationSourceRegistry(
            radar_source_kind="single_site",
            ordered_sources=(source,),
            projected_crs_digest="4" * 64,
            geometry_model="projected-horizontal-representative-tilt-v1",
            radar_altitude_role="provenance_only",
            contract="mosaic-observation-source-registry-v5",
        )
        self.assertNotEqual(
            registry.source_registry_digest,
            other_crs_registry.source_registry_digest,
        )
        self.assertEqual(
            registry.payload["geometry_model"],
            "projected-horizontal-representative-tilt-v1",
        )
        self.assertEqual(registry.payload["radar_altitude_role"], "provenance_only")

        grid_x_m = torch.tensor([[0.0, 1000.0]])
        grid_y_m = torch.zeros_like(grid_x_m)
        mismatched_geometry = RadarObservationGeometryContract(
            grid_contract_digest="5" * 64,
            projected_crs_digest="4" * 64,
            grid_x_m=grid_x_m,
            grid_y_m=grid_y_m,
            grid_spacing_m=1000.0,
            contract="radar-observation-geometry-v2",
        )
        with self.assertRaisesRegex(ValueError, "registered radar geometry"):
            sensitivity_module._registered_observation_geometry_fields(
                source_registry=registry,
                geometry=mismatched_geometry,
                time_count=1,
            )

        legacy_geometry = RadarObservationGeometryContract(
            grid_contract_digest="5" * 64,
            projected_crs_digest="3" * 64,
            grid_x_m=grid_x_m,
            grid_y_m=grid_y_m,
            grid_spacing_m=1000.0,
            contract="radar-observation-geometry-v1",
        )
        with self.assertRaisesRegex(ValueError, "registered radar geometry"):
            sensitivity_module._registered_observation_geometry_fields(
                source_registry=registry,
                geometry=legacy_geometry,
                time_count=1,
            )

    def test_historical_v9_observation_error_digest_is_immutable(self) -> None:
        contract = VerificationObservationErrorContract(
            radar_source_kind="mosaic",
            source_calibration_epochs=(
                ("1" * 64, "2" * 64),
                ("3" * 64, "4" * 64),
            ),
            range_elevation_validity_domain_digest="d" * 64,
            beam_blockage_visibility_mask_digest="e" * 64,
            attenuation_qc_digest="5" * 64,
            censoring_rule_digest="6" * 64,
            spatial_correlation_block_digest="7" * 64,
            quality_weight_interpretation_digest="8" * 64,
            observation_error_model_digest="9" * 64,
            minimum_detectable_echo_dbz=-10.0,
            observation_error_reference_std_dbz=2.0,
            valid_mask_digest=(
                "44fe7e6465fe6797c1478e0d7453f1faa46537eb896c83845f8d87bd294f2f11"
            ),
            quality_weight_digest=(
                "789a7c03c9130f57f355478eec90b7be688396e7059bba8f435a9d7f8da3e491"
            ),
            observation_std_dbz_digest=(
                "96257727179fef028b28601c7515462baaf6bc615f7f2ba928d82af7e00be3e6"
            ),
            observation_state_code_digest=(
                "e91b632f035fc65097bfca0431161d35ba402fc2eb7971f8f84056709afcb424"
            ),
            observation_error_plan_digest=(
                "33c7833db8f5eee25d12c23b79ccfcf598b82797e395116ae3d75d0ff82cdf63"
            ),
            detection_limit_dbz_digest="f" * 64,
            acquisition_time_offset_seconds_digest="0" * 64,
            acquisition_age_seconds_digest="1" * 64,
            spatial_metric_valid_mask_digest="2" * 64,
            source_registry_digest=(
                "bf53c8b30b987e8ac297ffdb2037f76d8bcec071229cbe28a963d24062963065"
            ),
            calibration_registry_digest=(
                "2bb59fcba93250a9c3f8f1f02b3ec6878e0a2d3127b6cb19c00fcc5e86e32dac"
            ),
            observation_error_derivation_digest=(
                "f5944c055fd3608e0c0784dfcb32a155030e2ebcc5bc925bc6f8e7cd4e0e0d7a"
            ),
            observation_mask_derivation_digest="6" * 64,
            verification_source_identity_digest="7" * 64,
            source_acquisition_time_identity_digest="8" * 64,
            source_radar_index_map_digest=(
                "6aa51e80434f577352948efffab201f2a26c2b9e58316b5aad76a679a50e7b93"
            ),
            missing_data_taxonomy=(
                "observed_clear",
                "observed_echo",
                "source_missing",
                "qc_invalid",
                "beam_blocked",
                "below_detection_censored",
                "mosaic_source_unassigned",
                "stale_acquisition",
            ),
            contract="verification-observation-error-contract-v9",
        )
        for excluded in (
            "observation_mask_derivation_digest",
            "verification_source_identity_digest",
            "source_acquisition_time_identity_digest",
            "detection_limit_dbz_digest",
            "acquisition_time_offset_seconds_digest",
            "acquisition_age_seconds_digest",
            "spatial_metric_valid_mask_digest",
        ):
            self.assertNotIn(excluded, contract.payload)
        self.assertEqual(
            contract.contract_digest,
            "f949f768b5fb9f5b63d157d45df8ab64fde23e9a26314b2ae47b955a6ae69db9",
        )

    def test_verification_bundle_capabilities_have_one_current_generation(
        self,
    ) -> None:
        self.assertEqual(
            OBSERVATION_MASK_DERIVATION_ALGORITHM_V10_DIGEST,
            "1cee7232295cab3a0a59451917310f88237a92fef4f11007e0c7179ddfd8ef7f",
        )
        self.assertEqual(
            OBSERVATION_ERROR_DERIVATION_ALGORITHM_V11_DIGEST,
            "53714c0c8a27cb035181236e3893980788b0f458bc6d4603af04fce9cc44292b",
        )
        self.assertEqual(
            CURRENT_VARIATIONAL_FSO_CONTRACT,
            "p1-variational-fso-v28",
        )
        self.assertEqual(
            CURRENT_VARIATIONAL_FSOI_CONTRACT,
            "p1-linearized-observation-impact-v24",
        )
        self.assertEqual(
            sensitivity_module._SUPPORTED_VERIFICATION_BUNDLE_CONTRACTS,
            frozenset(
                f"radar-verification-bundle-v{generation}"
                for generation in range(1, 23)
            ),
        )
        self.assertEqual(
            sensitivity_module
            ._OBSERVATION_ERROR_VERIFICATION_BUNDLE_CONTRACTS,
            frozenset(
                f"radar-verification-bundle-v{generation}"
                for generation in range(6, 23)
            ),
        )
        self.assertEqual(
            sensitivity_module._FSO_VERIFICATION_CONTRACTS[
                CURRENT_VARIATIONAL_FSO_CONTRACT
            ],
            "radar-verification-bundle-v22",
        )
        self.assertEqual(
            sensitivity_module._FSOI_FSO_CONTRACTS[
                CURRENT_VARIATIONAL_FSOI_CONTRACT
            ],
            CURRENT_VARIATIONAL_FSO_CONTRACT,
        )
        expected_predecessors = {
            "radar_spatial_grid_identity": "radar-spatial-grid-identity-v5",
            "mosaic_observation_source_registry": (
                "mosaic-observation-source-registry-v6"
            ),
            "radar_observation_geometry": "radar-observation-geometry-v6",
            "verification_observation_error_plan": (
                "verification-observation-error-plan-v15"
            ),
            "verification_bundle": "radar-verification-bundle-v21",
            "variational_fso": "p1-variational-fso-v27",
            "variational_fsoi": "p1-linearized-observation-impact-v23",
        }
        for family, predecessor in expected_predecessors.items():
            with self.subTest(family=family):
                capabilities = CONTRACT_CAPABILITIES[family]
                self.assertEqual(capabilities.predecessor, predecessor)
                self.assertIn(predecessor, capabilities.audit_readable)
                self.assertNotIn(predecessor, capabilities.issuable)
                self.assertNotIn(predecessor, capabilities.scientific_eligible)
        self.assertNotIn(
            "p1-variational-fso-v26",
            sensitivity_module._FSO_VERIFICATION_CONTRACTS,
        )
        self.assertNotIn(
            "p1-linearized-observation-impact-v22",
            sensitivity_module._FSOI_FSO_CONTRACTS,
        )

    def test_confirmatory_observation_masks_and_source_identity_replay(
        self,
    ) -> None:
        source_private_key = Ed25519PrivateKey.from_private_bytes(b"\x27" * 32)
        source_public_key_hex = (
            source_private_key.public_key().public_bytes_raw().hex()
        )
        sources = (
            ObservationRadarSource(
                radar_site_digest="1" * 64,
                calibration_epoch_digest="2" * 64,
                quality_weight=1.0,
                observation_std_dbz=2.0,
                detection_limit_dbz=-10.0,
                projected_x_m=1_000_000.0,
                projected_y_m=2_000_000.0,
                radar_altitude_m=100.0,
                representative_scan_elevation_deg=1.0,
                contract="observation-radar-source-v4",
            ),
            ObservationRadarSource(
                radar_site_digest="3" * 64,
                calibration_epoch_digest="4" * 64,
                quality_weight=0.5,
                observation_std_dbz=4.0,
                detection_limit_dbz=-5.0,
                detection_limit_range_quadratic_dbz_per_km2=0.0001,
                projected_x_m=1_004_000.0,
                projected_y_m=2_000_000.0,
                radar_altitude_m=120.0,
                representative_scan_elevation_deg=2.0,
                contract="observation-radar-source-v4",
            ),
        )
        spatial_grid = RadarGridTimeContract(
            valid_times=(
                "2026-08-05T00:10:00Z",
                "2026-08-05T00:20:00Z",
                "2026-08-05T00:30:00Z",
            ),
            dx_m=1000.0,
            dy_m=1000.0,
            projection="EPSG:5179",
            grid_hash="a" * 64,
            spatial_grid_contract="radar-spatial-grid-identity-v6",
            grid_shape_yx=(1, 5),
            projected_crs_digest=radar_projected_crs_semantic_digest(
                "EPSG:5179"
            ),
            metric_domain_digest=CURRENT_RADAR_METRIC_DOMAIN.digest,
            metric_domain_evidence_digest=(
                CURRENT_RADAR_METRIC_DOMAIN_EVIDENCE.digest
            ),
            cell_center_origin_xy_m=(1_000_000.0, 2_000_000.0),
            grid_coordinate_dtype=RADAR_PROJECTED_GRID_COORDINATE_DTYPE,
            cell_center_convention=(
                RADAR_PROJECTED_GRID_CELL_CENTER_CONVENTION
            ),
        )
        geometry = RadarObservationGeometryContract.from_grid_time_contract(
            spatial_grid
        )
        registry = MosaicObservationSourceRegistry(
            radar_source_kind="mosaic",
            ordered_sources=sources,
            projected_crs_digest=geometry.projected_crs_digest,
            metric_domain_digest=CURRENT_RADAR_METRIC_DOMAIN.digest,
            metric_domain_evidence_digest=(
                CURRENT_RADAR_METRIC_DOMAIN_EVIDENCE.digest
            ),
            geometry_model="projected-horizontal-representative-tilt-v1",
            radar_altitude_role="provenance_only",
            contract="mosaic-observation-source-registry-v7",
        )
        assert geometry.projected_grid_identity is not None
        legacy_geometry = replace(
            geometry,
            projected_grid_identity=replace(
                geometry.projected_grid_identity,
                metric_domain_evidence_digest=None,
                contract="radar-spatial-grid-identity-v5",
            ),
            contract="radar-observation-geometry-v6",
        )
        with self.assertRaisesRegex(
            ValueError,
            "registered radar geometry is invalid",
        ):
            sensitivity_module._registered_observation_geometry_fields(
                source_registry=registry,
                geometry=legacy_geometry,
                time_count=1,
            )
        with self.assertRaisesRegex(ValueError, "does not bind"):
            sensitivity_module._validate_current_metric_domain_observation_geometry(
                source_registry=registry,
                geometry=legacy_geometry,
            )
        plan = VerificationObservationErrorPlan(
            radar_source_kind="mosaic",
            source_registry_digest=registry.source_registry_digest,
            calibration_registry_digest=registry.calibration_registry_digest,
            range_elevation_validity_algorithm_digest=(
                OBSERVATION_MASK_DERIVATION_ALGORITHM_DIGEST
            ),
            beam_blockage_algorithm_digest=(
                OBSERVATION_MASK_DERIVATION_ALGORITHM_DIGEST
            ),
            attenuation_qc_digest="5" * 64,
            censoring_rule_digest="6" * 64,
            spatial_correlation_block_algorithm_digest="7" * 64,
            quality_weight_interpretation_digest="8" * 64,
            quality_weight_algorithm_digest=(
                OBSERVATION_ERROR_DERIVATION_ALGORITHM_V15_DIGEST
            ),
            observation_std_algorithm_digest=(
                OBSERVATION_ERROR_DERIVATION_ALGORITHM_V15_DIGEST
            ),
            observation_error_model_digest="9" * 64,
            source_assignment_algorithm_digest=(
                OBSERVATION_SOURCE_SELECTION_ALGORITHM_V5_DIGEST
            ),
            minimum_detectable_echo_dbz=-10.0,
            observation_error_reference_std_dbz=2.0,
            derivation_algorithm_digest=(
                OBSERVATION_ERROR_DERIVATION_ALGORITHM_V15_DIGEST
            ),
            mask_derivation_algorithm_digest=(
                OBSERVATION_MASK_DERIVATION_ALGORITHM_V14_DIGEST
            ),
            maximum_range_km=300.0,
            minimum_elevation_deg=0.0,
            maximum_elevation_deg=20.0,
            maximum_beam_blockage_fraction=0.5,
            minimum_attenuation_qc_score=0.5,
            verification_source_authority_id="verification-source-a",
            verification_source_authority_public_key_hex=source_public_key_hex,
            maximum_acquisition_age_seconds=300.0,
            temporal_quality_decay_scale_seconds=120.0,
            temporal_quality_decay_power=2.0,
            temporal_error_growth_dbz_per_second=0.01,
            temporal_quality_decay_algorithm_digest=(
                OBSERVATION_TEMPORAL_QUALITY_DECAY_ALGORITHM_V1_DIGEST
            ),
            temporal_error_algorithm_digest=(
                OBSERVATION_TEMPORAL_ERROR_ALGORITHM_V1_DIGEST
            ),
            detection_limit_derivation_algorithm_digest=(
                OBSERVATION_DETECTION_LIMIT_ALGORITHM_V3_DIGEST
            ),
            censor_state_derivation_algorithm_digest=(
                OBSERVATION_REPORT_KIND_ALGORITHM_V1_DIGEST
            ),
            geometry_contract_digest=geometry.geometry_digest,
            acquisition_timestamp_reference="volume_end",
            spatial_metric_reference_speed_mps=20.0,
            spatial_metric_maximum_displacement_fraction_cells=1.0,
            spatial_age_gate_algorithm_digest=(
                OBSERVATION_SPATIAL_AGE_GATE_ALGORITHM_V4_DIGEST
            ),
            contract="verification-observation-error-plan-v16",
        )
        common_evidence = {
            "plan": plan,
            "geometry": geometry,
            "valid_times": ("2026-08-05T00:30:00Z",),
            "acquisition_valid_times_by_source": (
                ("2026-08-05T00:30:00Z",),
                ("2026-08-05T00:30:00Z",),
            ),
            "grid_contract_digest": spatial_grid.digest,
            "radar_product_digest": "b" * 64,
            "native_verification_source_identity_digest": "c" * 64,
            "source_registry": registry,
            "source_authority_id": "verification-source-a",
            "source_authority_private_key": source_private_key,
            "source_observed_at": "2026-08-05T00:30:00Z",
            "reflectivity_dbz_by_source": torch.tensor(
                [
                    [[[12.0, -12.0, -11.0, 50.0, 60.0]]],
                    [[[22.0, -22.0, 10.0, 5.0, 6.0]]],
                ]
            ),
            "observation_report_kind_by_source": torch.tensor(
                [
                    [[[
                        int(VerificationObservationReportKind.DETECTED_ECHO),
                        int(VerificationObservationReportKind.CONFIRMED_CLEAR),
                        int(VerificationObservationReportKind.BELOW_DETECTION_CENSORED),
                        int(VerificationObservationReportKind.DETECTED_ECHO),
                        int(VerificationObservationReportKind.DETECTED_ECHO),
                    ]]],
                    [[[
                        int(VerificationObservationReportKind.DETECTED_ECHO),
                        int(VerificationObservationReportKind.BELOW_DETECTION_CENSORED),
                        int(VerificationObservationReportKind.DETECTED_ECHO),
                        int(VerificationObservationReportKind.DETECTED_ECHO),
                        int(VerificationObservationReportKind.DETECTED_ECHO),
                    ]]],
                ],
                dtype=torch.uint8,
            ),
            "acquisition_time_offset_seconds_by_source": torch.tensor(
                [
                    [[[0.0, 0.0, 0.0, 0.0, 0.0]]],
                    [[[-60.0, -60.0, -60.0, -60.0, -60.0]]],
                ]
            ),
            "source_availability_by_time": torch.ones((2, 1), dtype=torch.bool),
            "beam_blockage_fraction_by_source": torch.tensor(
                [
                    [[[0.0, 0.0, 0.0, 1.0, 1.0]]],
                    [[[1.0, 1.0, 1.0, 0.0, 0.0]]],
                ]
            ),
            "attenuation_qc_score_by_source": torch.ones((2, 1, 1, 5)),
            "range_elevation_validity_domain_digest": "d" * 64,
            "beam_blockage_visibility_mask_digest": "e" * 64,
            "spatial_correlation_block_digest": "7" * 64,
        }
        evidence = VerificationObservationMaskEvidence.issue(**common_evidence)
        self.assertEqual(
            torch.argmax(evidence.source_assignment_scores, dim=0).tolist(),
            [[[0, 0, 0, 1, 1]]],
        )
        mask_derivation = derive_verification_observation_masks(
            plan=plan,
            raw_evidence=evidence,
            source_registry=registry,
            geometry=geometry,
        )
        self.assertEqual(
            mask_derivation.source_radar_index_map.tolist(),
            [[[0, 0, 0, 1, 1]]],
        )
        self.assertEqual(
            mask_derivation.spatial_metric_valid_mask.tolist(),
            [[[True, True, True, False, False]]],
        )
        derivation = derive_verification_observation_error(
            plan=plan,
            raw_verification_source=(
                VerificationObservationDerivationInputs.from_mask_derivation(
                    mask_derivation
                )
            ),
            source_registry=registry,
        )
        self.assertEqual(
            derivation.observation_state_code.tolist(),
            [[[
                int(VerificationCellState.OBSERVED_ECHO),
                int(VerificationCellState.OBSERVED_CLEAR),
                int(VerificationCellState.BELOW_DETECTION_CENSORED),
                int(VerificationCellState.OBSERVED_ECHO),
                int(VerificationCellState.OBSERVED_ECHO),
            ]]],
        )
        self.assertEqual(
            derivation.observation_error_contract.contract,
            "verification-observation-error-contract-v18",
        )
        bundle = VerificationBundle(
            frames_dbz=mask_derivation.selected_frames_dbz,
            valid_mask=derivation.valid_mask,
            valid_times=("2026-08-05T00:30:00Z",),
            grid_contract_digest=spatial_grid.digest,
            radar_product_digest="b" * 64,
            qc_pipeline_digest="5" * 64,
            mask_policy_digest="f" * 64,
            censor_policy_digest="6" * 64,
            reflectivity_resolution_dbz=0.5,
            quantization_origin_dbz=-10.0,
            threshold_bin_convention="nearest_rounding_threshold_censor",
            floor_representation_contract_digest="0" * 64,
            quality_weight=derivation.quality_weight,
            observation_std_dbz=derivation.observation_std_dbz,
            observation_state_code=derivation.observation_state_code,
            source_radar_index_map=derivation.source_radar_index_map,
            detection_limit_dbz=mask_derivation.selected_detection_limit_dbz,
            acquisition_time_offset_seconds=(
                mask_derivation.selected_acquisition_time_offset_seconds
            ),
            acquisition_age_seconds=(
                mask_derivation.selected_acquisition_age_seconds
            ),
            spatial_metric_valid_mask=(
                mask_derivation.spatial_metric_valid_mask
            ),
            observation_error_contract=derivation.observation_error_contract,
            observation_error_derivation=derivation,
            contract="radar-verification-bundle-v22",
        )
        bundle.validate_integrity()
        self.assertEqual(
            int(torch.count_nonzero(bundle.fso_metric_weight)),
            1,
        )
        self.assertGreater(float(bundle.metric_weight[0, 0, 1]), 0.0)
        self.assertEqual(
            float(bundle.intensity_metric_weight[0, 0, 1]),
            0.0,
        )
        self.assertEqual(
            float(bundle.intensity_metric_weight[0, 0, 2]),
            0.0,
        )

        equality_frames = common_evidence["reflectivity_dbz_by_source"].clone()
        equality_frames[0, 0, 0, 0] = -10.0
        for report_kind in VerificationObservationReportKind:
            equality_kinds = common_evidence[
                "observation_report_kind_by_source"
            ].clone()
            equality_kinds[0, 0, 0, 0] = int(report_kind)
            with self.subTest(threshold_equality=report_kind):
                call = lambda: VerificationObservationMaskEvidence.issue(
                    **(
                        common_evidence
                        | {
                            "reflectivity_dbz_by_source": equality_frames,
                            "observation_report_kind_by_source": equality_kinds,
                        }
                    )
                )
                equality_evidence = call()
                self.assertTrue(
                    bool(
                        equality_evidence.detection_classification_uncertain_by_source[
                            0, 0, 0, 0
                        ]
                    )
                )
                self.assertEqual(
                    float(equality_evidence.source_assignment_scores[0, 0, 0, 0]),
                    0.0,
                )

        fallback_evidence = VerificationObservationMaskEvidence.issue(
            **(
                common_evidence
                | {
                    "acquisition_valid_times_by_source": (
                        ("2026-08-05T00:20:00Z",),
                        ("2026-08-05T00:30:00Z",),
                    ),
                    "acquisition_time_offset_seconds_by_source": torch.zeros(
                        (2, 1, 1, 5)
                    ),
                    "beam_blockage_fraction_by_source": torch.zeros((2, 1, 1, 5)),
                }
            )
        )
        fallback_mask = derive_verification_observation_masks(
            plan=plan,
            raw_evidence=fallback_evidence,
            source_registry=registry,
            geometry=geometry,
        )
        self.assertEqual(
            fallback_mask.source_radar_index_map.tolist(),
            [[[1, 1, 1, 1, 1]]],
        )

        with self.assertRaisesRegex(ValueError, "raw mask evidence"):
            replace(
                evidence,
                source_assignment_scores=torch.flip(
                    evidence.source_assignment_scores,
                    dims=(0,),
                ),
            )
        forged_geometry = RadarObservationGeometryContract(
            grid_contract_digest="a" * 64,
            projected_crs_digest="0" * 64,
            grid_x_m=geometry.grid_x_m + 1000.0,
            grid_y_m=geometry.grid_y_m,
            grid_spacing_m=1000.0,
            contract="radar-observation-geometry-v2",
        )
        with self.assertRaisesRegex(
            ValueError,
            "generation is not current|geometry/source selection",
        ):
            evidence.validate_against_plan_registry_and_geometry(
                plan=plan,
                source_registry=registry,
                geometry=forged_geometry,
            )
        reordered_registry = MosaicObservationSourceRegistry(
            radar_source_kind="mosaic",
            ordered_sources=tuple(reversed(sources)),
            projected_crs_digest=geometry.projected_crs_digest,
            metric_domain_digest=CURRENT_RADAR_METRIC_DOMAIN.digest,
            metric_domain_evidence_digest=(
                CURRENT_RADAR_METRIC_DOMAIN_EVIDENCE.digest
            ),
            geometry_model="projected-horizontal-representative-tilt-v1",
            radar_altitude_role="provenance_only",
            contract="mosaic-observation-source-registry-v7",
        )
        with self.assertRaisesRegex(
            ValueError,
            "disagrees with its plan|disagrees with its preregistered registry",
        ):
            derive_verification_observation_masks(
                plan=plan,
                raw_evidence=evidence,
                source_registry=reordered_registry,
                geometry=geometry,
            )
        attacked_mask = derive_verification_observation_masks(
            plan=plan,
            raw_evidence=evidence,
            source_registry=registry,
            geometry=geometry,
        )
        attacked_mask._spatial_metric_valid_mask.data[0, 0, 0] = False
        with self.assertRaisesRegex(ValueError, "mask replay mismatch"):
            attacked_mask.validate_replay()

    def test_ground_range_bounds_control_verification_selection_and_age(
        self,
    ) -> None:
        grid = RadarGridTimeContract(
            valid_times=(
                "2026-08-05T00:10:00Z",
                "2026-08-05T00:20:00Z",
                "2026-08-05T00:30:00Z",
            ),
            dx_m=1005.0,
            dy_m=1005.0,
            projection="EPSG:5179",
            grid_hash="d" * 64,
            spatial_grid_contract="radar-spatial-grid-identity-v6",
            grid_shape_yx=(1, 2),
            projected_crs_digest=radar_projected_crs_semantic_digest(
                "EPSG:5179"
            ),
            metric_domain_digest=CURRENT_RADAR_METRIC_DOMAIN.digest,
            metric_domain_evidence_digest=(
                CURRENT_RADAR_METRIC_DOMAIN_EVIDENCE.digest
            ),
            cell_center_origin_xy_m=(1_000_000.0, 2_000_000.0),
            grid_coordinate_dtype=RADAR_PROJECTED_GRID_COORDINATE_DTYPE,
            cell_center_convention=(
                RADAR_PROJECTED_GRID_CELL_CENTER_CONVENTION
            ),
        )
        bundle = _current_verification_bundle(
            torch.tensor([[[20.0, 20.0]]], dtype=torch.float64),
            valid_times=("2026-08-05T00:30:00Z",),
            grid_time_contract=grid,
            acquisition_time_offset_seconds=-50.0,
        )
        self.assertFalse(bool(torch.any(bundle.spatial_metric_valid_mask)))

        derivation = bundle.observation_error_derivation
        assert derivation is not None
        plan = derivation.plan
        single_shape = (1, 1, 1, 1)
        strict_range_scores = (
            sensitivity_module._product_owned_source_assignment_scores(
                plan=replace(plan, maximum_range_km=100.0),
                valid_times=("2026-08-05T00:30:00Z",),
                acquisition_valid_times_by_source=(
                    ("2026-08-05T00:30:00Z",),
                ),
                acquisition_time_offset_seconds_by_source=torch.zeros(
                    single_shape,
                    dtype=torch.float64,
                ),
                source_availability_by_time=torch.ones(
                    (1, 1), dtype=torch.bool
                ),
                range_km_by_source=torch.full(
                    single_shape,
                    100.0,
                    dtype=torch.float64,
                ),
                elevation_deg_by_source=torch.ones(
                    single_shape,
                    dtype=torch.float64,
                ),
                beam_blockage_fraction_by_source=torch.zeros(
                    single_shape,
                    dtype=torch.float64,
                ),
                attenuation_qc_score_by_source=torch.ones(
                    single_shape,
                    dtype=torch.float64,
                ),
            )
        )
        self.assertEqual(float(strict_range_scores.item()), 0.0)

        two_source_shape = (2, 1, 1, 1)
        overlapping_scores = (
            sensitivity_module._product_owned_source_assignment_scores(
                plan=replace(plan, radar_source_kind="mosaic"),
                valid_times=("2026-08-05T00:30:00Z",),
                acquisition_valid_times_by_source=(
                    ("2026-08-05T00:30:00Z",),
                    ("2026-08-05T00:30:00Z",),
                ),
                acquisition_time_offset_seconds_by_source=torch.zeros(
                    two_source_shape,
                    dtype=torch.float64,
                ),
                source_availability_by_time=torch.ones(
                    (2, 1), dtype=torch.bool
                ),
                range_km_by_source=torch.full(
                    two_source_shape,
                    10.0,
                    dtype=torch.float64,
                ),
                elevation_deg_by_source=torch.ones(
                    two_source_shape,
                    dtype=torch.float64,
                ),
                beam_blockage_fraction_by_source=torch.zeros(
                    two_source_shape,
                    dtype=torch.float64,
                ),
                attenuation_qc_score_by_source=torch.ones(
                    two_source_shape,
                    dtype=torch.float64,
                ),
            )
        )
        self.assertTrue(bool(torch.all(overlapping_scores == 0.0)))

        source = replace(
            derivation.source_registry.ordered_sources[0],
            detection_limit_dbz=-10.0,
            detection_limit_range_quadratic_dbz_per_km2=0.001,
        )
        registry = replace(
            derivation.source_registry,
            ordered_sources=(source,),
        )
        projected_range = torch.full(
            single_shape,
            100.0,
            dtype=torch.float64,
        )
        conservative_limit = sensitivity_module._registered_detection_limit_field(
            source_registry=registry,
            range_km_by_source=projected_range,
            elevation_deg_by_source=torch.ones_like(projected_range),
            conservative_ground_range=True,
        )
        nominal_limit = sensitivity_module._registered_detection_limit_field(
            source_registry=registry,
            range_km_by_source=projected_range,
            elevation_deg_by_source=torch.ones_like(projected_range),
        )
        self.assertGreater(
            float(conservative_limit.item()),
            float(nominal_limit.item()),
        )
        limit_interval = sensitivity_module._registered_detection_limit_interval(
            source_registry=registry,
            range_km_by_source=projected_range,
            elevation_deg_by_source=torch.ones_like(projected_range),
        )
        lower_limit = float(limit_interval.lower_dbz.item())
        upper_limit = float(limit_interval.upper_dbz.item())
        self.assertAlmostEqual(lower_limit, -0.118927, places=5)
        self.assertAlmostEqual(upper_limit, 0.121087, places=5)
        self.assertLess(lower_limit, 0.0)
        self.assertGreater(upper_limit, 0.0)
        self.assertFalse(0.0 > upper_limit)
        self.assertFalse(0.0 < lower_limit)
        self.assertFalse(0.0 <= lower_limit)

        counter_source = replace(
            derivation.source_registry.ordered_sources[0],
            detection_limit_dbz=-30.928499221801758,
            detection_limit_range_quadratic_dbz_per_km2=(
                2.4236200601990276e-7
            ),
            detection_limit_elevation_excess_dbz_per_degree=(
                6.632991790771484
            ),
            detection_limit_reference_elevation_deg=5.87116003036499,
        )
        counter_registry = replace(
            derivation.source_registry,
            ordered_sources=(counter_source,),
        )
        counter_range = torch.tensor(
            [[[[224.26649475097656]]]],
            dtype=torch.float32,
        )
        counter_elevation = torch.tensor(
            [[[[9.581335067749023]]]],
            dtype=torch.float32,
        )
        counter_interval = (
            sensitivity_module._registered_detection_limit_interval(
                source_registry=counter_registry,
                range_km_by_source=counter_range,
                elevation_deg_by_source=counter_elevation,
            )
        )
        projected = Fraction.from_float(float(counter_range.item()))
        scale_error = Fraction.from_float(
            CURRENT_RADAR_METRIC_DOMAIN.maximum_linear_scale_error
        )
        ground_lower = projected / (Fraction(1) + scale_error)
        ground_upper = projected / (Fraction(1) - scale_error)
        base = Fraction.from_float(counter_source.detection_limit_dbz)
        range_coefficient = Fraction.from_float(
            counter_source.detection_limit_range_quadratic_dbz_per_km2
        )
        elevation_coefficient = Fraction.from_float(
            counter_source.detection_limit_elevation_excess_dbz_per_degree
        )
        elevation_excess = max(
            Fraction(0),
            Fraction.from_float(float(counter_elevation.item()))
            - Fraction.from_float(
                counter_source.detection_limit_reference_elevation_deg
            ),
        )
        exact_lower = (
            base
            + range_coefficient * ground_lower * ground_lower
            + elevation_coefficient * elevation_excess
        )
        exact_upper = (
            base
            + range_coefficient * ground_upper * ground_upper
            + elevation_coefficient * elevation_excess
        )
        self.assertLessEqual(
            Fraction.from_float(float(counter_interval.lower_dbz.item())),
            exact_lower,
        )
        self.assertGreaterEqual(
            Fraction.from_float(float(counter_interval.upper_dbz.item())),
            exact_upper,
        )
        next_above_upper = torch.nextafter(
            counter_interval.upper_dbz,
            torch.full_like(counter_interval.upper_dbz, torch.inf),
        )
        self.assertGreater(
            Fraction.from_float(float(next_above_upper.item())),
            exact_upper,
        )

        adversarial_scores = (
            sensitivity_module._product_owned_source_assignment_scores(
                plan=replace(
                    plan,
                    radar_source_kind="mosaic",
                    maximum_range_km=400.0,
                    maximum_beam_blockage_fraction=0.9,
                    minimum_attenuation_qc_score=0.1,
                ),
                valid_times=("2026-08-05T00:30:00Z",),
                acquisition_valid_times_by_source=(
                    ("2026-08-05T00:30:00Z",),
                    ("2026-08-05T00:30:00Z",),
                ),
                acquisition_time_offset_seconds_by_source=torch.zeros(
                    two_source_shape,
                    dtype=torch.float32,
                ),
                source_availability_by_time=torch.ones(
                    (2, 1), dtype=torch.bool
                ),
                range_km_by_source=torch.tensor(
                    [[[[212.0695037841797]]], [[[299.5369873046875]]]],
                    dtype=torch.float32,
                ),
                elevation_deg_by_source=torch.full(
                    two_source_shape,
                    0.5
                    * (
                        float(plan.minimum_elevation_deg)
                        + float(plan.maximum_elevation_deg)
                    ),
                    dtype=torch.float32,
                ),
                beam_blockage_fraction_by_source=torch.tensor(
                    [[[[0.4808613061904907]]], [[[0.47117313742637634]]]],
                    dtype=torch.float32,
                ),
                attenuation_qc_score_by_source=torch.tensor(
                    [[[[0.25443780422210693]]], [[[0.24606764316558838]]]],
                    dtype=torch.float32,
                ),
            )
        )
        self.assertTrue(bool(torch.all(adversarial_scores == 0.0)))

        mask_derivation = derivation.raw_inputs.mask_derivation
        assert mask_derivation is not None
        maximum_spatial_age = (
            sensitivity_module._spatial_metric_maximum_age_seconds(
                plan=plan,
                geometry=mask_derivation.geometry,
            )
        )
        exact_spacing_lower = Fraction.from_float(
            mask_derivation.geometry.grid_spacing_m
        ) / (Fraction(1) + scale_error)
        exact_maximum_age = (
            Fraction.from_float(
                float(plan.spatial_metric_maximum_displacement_fraction_cells)
            )
            * exact_spacing_lower
            / Fraction.from_float(float(plan.spatial_metric_reference_speed_mps))
        )
        self.assertLessEqual(
            Fraction.from_float(maximum_spatial_age),
            exact_maximum_age,
        )

    def test_fp32_reflectivity_does_not_downcast_observation_geometry(
        self,
    ) -> None:
        grid = RadarGridTimeContract(
            valid_times=(
                "2026-08-26T00:00:00Z",
                "2026-08-26T00:10:00Z",
                "2026-08-26T00:20:00Z",
            ),
            dx_m=1000.0,
            dy_m=1000.0,
            projection="EPSG:5179",
            grid_hash="1" * 64,
            spatial_grid_contract="radar-spatial-grid-identity-v6",
            grid_shape_yx=(1, 2),
            projected_crs_digest=radar_projected_crs_semantic_digest(
                "EPSG:5179"
            ),
            metric_domain_digest=CURRENT_RADAR_METRIC_DOMAIN.digest,
            metric_domain_evidence_digest=(
                CURRENT_RADAR_METRIC_DOMAIN_EVIDENCE.digest
            ),
            cell_center_origin_xy_m=(1_000_000.0, 2_000_000.0),
            grid_coordinate_dtype=RADAR_PROJECTED_GRID_COORDINATE_DTYPE,
            cell_center_convention=(
                RADAR_PROJECTED_GRID_CELL_CENTER_CONVENTION
            ),
        )
        bundle = _current_verification_bundle(
            torch.tensor([[[20.0, 20.0]]], dtype=torch.float32),
            valid_times=("2026-08-26T00:20:00Z",),
            grid_time_contract=grid,
            radar_range_m=100_000.003,
            representative_scan_elevation_deg=20.0000005,
        )
        derivation = bundle.observation_error_derivation
        assert derivation is not None
        mask_derivation = derivation.raw_inputs.mask_derivation
        assert mask_derivation is not None
        evidence = mask_derivation.raw_evidence
        self.assertIs(evidence.reflectivity_dbz_by_source.dtype, torch.float32)
        for value in (
            evidence.range_km_by_source,
            evidence.elevation_deg_by_source,
            evidence.source_assignment_scores,
            evidence.projected_range_lower_km_by_source,
            evidence.projected_range_upper_km_by_source,
            evidence.ground_range_lower_km_by_source,
            evidence.ground_range_upper_km_by_source,
        ):
            assert value is not None
            self.assertIs(value.dtype, torch.float64)
        self.assertNotEqual(float(evidence.range_km_by_source[0, 0, 0, 0]), 100.0)
        self.assertEqual(
            float(evidence.elevation_deg_by_source[0, 0, 0, 0]),
            20.0000005,
        )
        ground_upper = evidence.ground_range_upper_km_by_source
        assert ground_upper is not None
        authoritative_upper = (
            Fraction.from_float(100_000.003)
            / 1000
            / (
                Fraction(1)
                - Fraction.from_float(
                    CURRENT_RADAR_METRIC_DOMAIN.maximum_linear_scale_error
                )
            )
        )
        self.assertGreaterEqual(
            Fraction.from_float(float(ground_upper[0, 0, 0, 0])),
            authoritative_upper,
        )

    def test_top2_source_dominance_matches_quadratic_oracle(self) -> None:
        generator = torch.Generator().manual_seed(146)
        lower = torch.rand((7, 2, 3, 4), generator=generator, dtype=torch.float64)
        width = torch.rand(lower.shape, generator=generator, dtype=torch.float64)
        upper = lower + width
        eligible = torch.rand(
            lower.shape,
            generator=generator,
            dtype=torch.float64,
        ) > 0.2
        lower = torch.where(eligible, lower, torch.zeros_like(lower))
        upper = torch.where(eligible, upper, torch.zeros_like(upper))
        upper[0, 0, 0, 0] = 2.0
        upper[1, 0, 0, 0] = 2.0
        lower[0, 0, 0, 0] = 1.5
        lower[1, 0, 0, 0] = 1.5

        expected_rows = []
        for index in range(lower.shape[0]):
            competitor = torch.cat(
                (upper[:index], upper[index + 1 :]),
                dim=0,
            ).amax(dim=0)
            expected_rows.append(
                torch.where(
                    eligible[index] & (lower[index] > competitor),
                    lower[index],
                    torch.zeros_like(lower[index]),
                )
            )
        expected = torch.stack(expected_rows)
        actual = sensitivity_module._strictly_dominating_source_scores(
            score_lower=lower,
            score_upper=upper,
            eligible=eligible,
        )
        self.assertTrue(torch.equal(actual, expected))
        self.assertEqual(float(actual[0, 0, 0, 0]), 0.0)
        self.assertEqual(float(actual[1, 0, 0, 0]), 0.0)
        invalid = lower.clone()
        invalid[0, 0, 0, 0] = float("nan")
        with self.assertRaisesRegex(ValueError, "score intervals"):
            sensitivity_module._strictly_dominating_source_scores(
                score_lower=invalid,
                score_upper=upper,
                eligible=eligible,
            )

    def test_source_selection_never_treats_pow_exp_as_authoritative(
        self,
    ) -> None:
        grid = RadarGridTimeContract(
            valid_times=(
                "2026-08-26T00:00:00Z",
                "2026-08-26T00:10:00Z",
                "2026-08-26T00:20:00Z",
            ),
            dx_m=1000.0,
            dy_m=1000.0,
            projection="EPSG:5179",
            grid_hash="1" * 64,
            spatial_grid_contract="radar-spatial-grid-identity-v6",
            grid_shape_yx=(1, 2),
            projected_crs_digest=radar_projected_crs_semantic_digest("EPSG:5179"),
            metric_domain_digest=CURRENT_RADAR_METRIC_DOMAIN.digest,
            metric_domain_evidence_digest=(CURRENT_RADAR_METRIC_DOMAIN_EVIDENCE.digest),
            cell_center_origin_xy_m=(1_000_000.0, 2_000_000.0),
            grid_coordinate_dtype=RADAR_PROJECTED_GRID_COORDINATE_DTYPE,
            cell_center_convention=(RADAR_PROJECTED_GRID_CELL_CENTER_CONVENTION),
        )
        bundle = _current_verification_bundle(
            torch.tensor([[[20.0, 20.0]]]),
            valid_times=("2026-08-26T00:20:00Z",),
            grid_time_contract=grid,
            acquisition_time_offset_seconds=-60.0,
        )
        derivation = bundle.observation_error_derivation
        assert derivation is not None
        mask_derivation = derivation.raw_inputs.mask_derivation
        assert mask_derivation is not None
        evidence = mask_derivation.raw_evidence
        lower = evidence.ground_range_lower_km_by_source
        upper = evidence.ground_range_upper_km_by_source
        certain = evidence.detection_classification_uncertain_by_source
        assert lower is not None and upper is not None and certain is not None

        with (
            patch.object(torch, "pow", side_effect=AssertionError("pow called")),
            patch.object(torch, "exp", side_effect=AssertionError("exp called")),
        ):
            replayed = sensitivity_module._product_owned_source_assignment_scores(
                plan=derivation.plan,
                valid_times=evidence.source_identity.valid_times,
                acquisition_valid_times_by_source=(
                    evidence.source_identity.acquisition_valid_times_by_source
                ),
                acquisition_time_offset_seconds_by_source=(
                    evidence.acquisition_time_offset_seconds_by_source
                ),
                source_availability_by_time=evidence.source_availability_by_time,
                range_km_by_source=evidence.range_km_by_source,
                elevation_deg_by_source=evidence.elevation_deg_by_source,
                beam_blockage_fraction_by_source=(
                    evidence.beam_blockage_fraction_by_source
                ),
                attenuation_qc_score_by_source=(
                    evidence.attenuation_qc_score_by_source
                ),
                detection_classification_certain_by_source=~certain,
                ground_range_lower_km_by_source=lower,
                ground_range_upper_km_by_source=upper,
            )
        self.assertTrue(torch.equal(replayed, evidence.source_assignment_scores))

    def test_temporal_transcendental_overlap_leaves_source_unassigned(
        self,
    ) -> None:
        grid = RadarGridTimeContract(
            valid_times=(
                "2026-08-05T00:10:00Z",
                "2026-08-05T00:20:00Z",
                "2026-08-05T00:30:00Z",
            ),
            dx_m=1000.0,
            dy_m=1000.0,
            projection="EPSG:5179",
            grid_hash="1" * 64,
            spatial_grid_contract="radar-spatial-grid-identity-v6",
            grid_shape_yx=(1, 2),
            projected_crs_digest=radar_projected_crs_semantic_digest("EPSG:5179"),
            metric_domain_digest=CURRENT_RADAR_METRIC_DOMAIN.digest,
            metric_domain_evidence_digest=(CURRENT_RADAR_METRIC_DOMAIN_EVIDENCE.digest),
            cell_center_origin_xy_m=(1_000_000.0, 2_000_000.0),
            grid_coordinate_dtype=RADAR_PROJECTED_GRID_COORDINATE_DTYPE,
            cell_center_convention=(RADAR_PROJECTED_GRID_CELL_CENTER_CONVENTION),
        )
        plan = _current_verification_bundle(
            torch.tensor([[[20.0, 20.0]]]),
            valid_times=("2026-08-05T00:30:00Z",),
            grid_time_contract=grid,
        ).observation_error_derivation
        assert plan is not None
        shape = (2, 1, 1, 1)
        ones = torch.ones(shape, dtype=torch.float64)
        scores = sensitivity_module._product_owned_source_assignment_scores(
            plan=plan.plan,
            valid_times=("2026-08-05T00:30:00Z",),
            acquisition_valid_times_by_source=(
                ("2026-08-05T00:30:00Z",),
                ("2026-08-05T00:29:00Z",),
            ),
            acquisition_time_offset_seconds_by_source=torch.zeros(shape),
            source_availability_by_time=torch.ones((2, 1), dtype=torch.bool),
            range_km_by_source=ones * 10.0,
            elevation_deg_by_source=ones,
            beam_blockage_fraction_by_source=torch.zeros(shape),
            attenuation_qc_score_by_source=ones,
            detection_classification_certain_by_source=torch.ones(
                shape, dtype=torch.bool
            ),
            ground_range_lower_km_by_source=ones * 9.9,
            ground_range_upper_km_by_source=ones * 10.1,
        )
        self.assertEqual(int(torch.count_nonzero(scores)), 0)

    @unittest.skipUnless(
        getattr(torch.backends, "mps", None) is not None
        and torch.backends.mps.is_available(),
        "MPS backend is unavailable",
    )
    def test_current_source_selection_declares_cpu_binary64_boundary(
        self,
    ) -> None:
        grid = RadarGridTimeContract(
            valid_times=(
                "2026-08-05T00:10:00Z",
                "2026-08-05T00:20:00Z",
                "2026-08-05T00:30:00Z",
            ),
            dx_m=1000.0,
            dy_m=1000.0,
            projection="EPSG:5179",
            grid_hash="2" * 64,
            spatial_grid_contract="radar-spatial-grid-identity-v6",
            grid_shape_yx=(1, 2),
            projected_crs_digest=radar_projected_crs_semantic_digest("EPSG:5179"),
            metric_domain_digest=CURRENT_RADAR_METRIC_DOMAIN.digest,
            metric_domain_evidence_digest=(CURRENT_RADAR_METRIC_DOMAIN_EVIDENCE.digest),
            cell_center_origin_xy_m=(1_000_000.0, 2_000_000.0),
            grid_coordinate_dtype=RADAR_PROJECTED_GRID_COORDINATE_DTYPE,
            cell_center_convention=(RADAR_PROJECTED_GRID_CELL_CENTER_CONVENTION),
        )
        derivation = _current_verification_bundle(
            torch.tensor([[[20.0, 20.0]]]),
            valid_times=("2026-08-05T00:30:00Z",),
            grid_time_contract=grid,
        ).observation_error_derivation
        assert derivation is not None
        shape = (1, 1, 1, 1)
        with self.assertRaisesRegex(RuntimeError, "CPU binary64"):
            sensitivity_module._product_owned_source_assignment_scores(
                plan=derivation.plan,
                valid_times=("2026-08-05T00:30:00Z",),
                acquisition_valid_times_by_source=(("2026-08-05T00:30:00Z",),),
                acquisition_time_offset_seconds_by_source=torch.zeros(
                    shape, device="mps"
                ),
                source_availability_by_time=torch.ones(
                    (1, 1), dtype=torch.bool, device="mps"
                ),
                range_km_by_source=torch.ones(shape, device="mps"),
                elevation_deg_by_source=torch.ones(shape, device="mps"),
                beam_blockage_fraction_by_source=torch.zeros(
                    shape, device="mps"
                ),
                attenuation_qc_score_by_source=torch.ones(shape, device="mps"),
            )

    @unittest.skipUnless(
        getattr(torch.backends, "mps", None) is not None
        and torch.backends.mps.is_available(),
        "MPS backend is unavailable",
    )
    def test_current_v6_mps_physical_psr_fss_and_centroid_paths(
        self,
    ) -> None:
        nowcast_module = import_module("advar.nowcast")
        grid = RadarGridTimeContract(
            valid_times=(
                "2026-08-05T00:10:00Z",
                "2026-08-05T00:20:00Z",
                "2026-08-05T00:30:00Z",
            ),
            dx_m=1000.0,
            dy_m=1000.0,
            projection="EPSG:5179",
            grid_hash="4" * 64,
            spatial_grid_contract="radar-spatial-grid-identity-v6",
            grid_shape_yx=(4, 4),
            projected_crs_digest=radar_projected_crs_semantic_digest(
                "EPSG:5179"
            ),
            metric_domain_digest=CURRENT_RADAR_METRIC_DOMAIN.digest,
            metric_domain_evidence_digest=(
                CURRENT_RADAR_METRIC_DOMAIN_EVIDENCE.digest
            ),
            cell_center_origin_xy_m=(1_000_000.0, 2_000_000.0),
            grid_coordinate_dtype=RADAR_PROJECTED_GRID_COORDINATE_DTYPE,
            cell_center_convention=(
                RADAR_PROJECTED_GRID_CELL_CENTER_CONVENTION
            ),
        )
        correlation = torch.arange(
            16, dtype=torch.float32, device="mps"
        ).reshape(4, 4)
        correlation[0, 0] = 30.0
        psr = nowcast_module._peak_to_sidelobe_ratio(
            correlation,
            0,
            0,
            NowcastConfig(phase_correlation_sidelobe_radius_m=1_500.0),
            grid,
        )
        self.assertEqual(psr.device.type, "mps")
        self.assertTrue(bool(torch.isfinite(psr)))

        forecast = torch.arange(
            1, 17, dtype=torch.float32, device="mps"
        ).reshape(4, 4).requires_grad_()
        truth = torch.roll(forecast.detach(), shifts=1, dims=1)
        valid = torch.ones((4, 4), dtype=torch.bool, device="mps")
        metric_config = SensitivityConfig(
            metric_names=("soft_fss_error_35", "centroid_error_m2"),
            soft_fss_window_m=3_000.0,
        )
        fss = forecast_metric(
            "soft_fss_error_35",
            forecast,
            truth,
            valid,
            NowcastConfig(),
            metric_config,
            grid,
        )
        centroid = forecast_metric(
            "centroid_error_m2",
            forecast,
            truth,
            valid,
            NowcastConfig(),
            metric_config,
            grid,
        )
        self.assertEqual(fss.device.type, "mps")
        self.assertEqual(centroid.device.type, "mps")
        (fss + centroid).backward()
        self.assertIsNotNone(forecast.grad)

    def test_v2_observation_derivation_inputs_are_audit_only(self) -> None:
        frames = torch.ones((1, 2, 2))
        with self.assertRaisesRegex(ValueError, "audit-only"):
            VerificationObservationDerivationInputs(
                frames_dbz=frames,
                source_present_mask=torch.ones_like(frames, dtype=torch.bool),
                range_elevation_valid_mask=torch.ones_like(
                    frames, dtype=torch.bool
                ),
                beam_blocked_mask=torch.zeros_like(frames, dtype=torch.bool),
                acquisition_time_valid_mask=torch.ones_like(
                    frames, dtype=torch.bool
                ),
                attenuation_qc_valid_mask=torch.ones_like(
                    frames, dtype=torch.bool
                ),
                confirmed_clear_mask=torch.zeros_like(
                    frames, dtype=torch.bool
                ),
                below_detection_censored_mask=torch.zeros_like(
                    frames, dtype=torch.bool
                ),
                source_radar_index_map=torch.zeros_like(
                    frames, dtype=torch.int64
                ),
                upstream_verification_artifact_digest="1" * 64,
                range_elevation_validity_domain_digest="2" * 64,
                beam_blockage_visibility_mask_digest="3" * 64,
                spatial_correlation_block_digest="4" * 64,
                contract="verification-observation-derivation-inputs-v2",
            )

    def test_observation_error_gaussian_diagnostic_is_proper_and_report_only(
        self,
    ) -> None:
        plan = VerificationObservationErrorPlan(
            radar_source_kind="single_site",
            source_registry_digest="0" * 64,
            calibration_registry_digest="1" * 64,
            range_elevation_validity_algorithm_digest="2" * 64,
            beam_blockage_algorithm_digest="3" * 64,
            attenuation_qc_digest="5" * 64,
            censoring_rule_digest="6" * 64,
            spatial_correlation_block_algorithm_digest="7" * 64,
            quality_weight_interpretation_digest="8" * 64,
            quality_weight_algorithm_digest="a" * 64,
            observation_std_algorithm_digest="b" * 64,
            observation_error_model_digest="9" * 64,
            source_assignment_algorithm_digest="c" * 64,
            minimum_detectable_echo_dbz=-10.0,
            observation_error_reference_std_dbz=2.0,
        )
        frames = torch.tensor([[[12.0, -12.0, -10.0]]])
        valid = torch.ones_like(frames, dtype=torch.bool)
        quality = torch.ones_like(frames)
        observation_std = torch.full_like(frames, 2.0)
        state = torch.tensor(
            [[[
                int(VerificationCellState.OBSERVED_ECHO),
                int(VerificationCellState.OBSERVED_CLEAR),
                int(VerificationCellState.BELOW_DETECTION_CENSORED),
            ]]],
            dtype=torch.uint8,
        )
        error = VerificationObservationErrorContract.from_tensors(
            plan=plan,
            frames_dbz=frames,
            valid_mask=valid,
            quality_weight=quality,
            observation_std_dbz=observation_std,
            observation_state_code=state,
            source_radar_index_map=None,
            source_calibration_epochs=(("1" * 64, "2" * 64),),
            range_elevation_validity_domain_digest="3" * 64,
            beam_blockage_visibility_mask_digest="4" * 64,
            spatial_correlation_block_digest="7" * 64,
        )
        verification = VerificationBundle(
            frames_dbz=frames,
            valid_mask=valid,
            valid_times=("2026-08-05T00:30:00Z",),
            grid_contract_digest="a" * 64,
            radar_product_digest="b" * 64,
            qc_pipeline_digest="5" * 64,
            mask_policy_digest="c" * 64,
            censor_policy_digest="6" * 64,
            reflectivity_resolution_dbz=0.5,
            quantization_origin_dbz=-10.0,
            threshold_bin_convention="nearest_rounding_threshold_censor",
            floor_representation_contract_digest="d" * 64,
            quality_weight=quality,
            observation_std_dbz=observation_std,
            observation_state_code=state,
            observation_error_contract=error,
            contract="radar-verification-bundle-v6",
        )
        forecast_std = torch.ones_like(frames)
        calibrated = promotion_module.compute_observation_error_gaussian_diagnostic(
            torch.tensor([[[12.0, -12.0, -15.0]]]),
            forecast_std,
            verification,
        )
        misspecified = (
            promotion_module.compute_observation_error_gaussian_diagnostic(
                torch.tensor([[[0.0, 40.0, 5.0]]]),
                forecast_std,
                verification,
            )
        )
        self.assertTrue(calibrated.diagnostic_only)
        self.assertEqual(calibrated.point_sample_count, 1)
        self.assertEqual(calibrated.censored_sample_count, 1)
        clear_value_changed = (
            promotion_module.compute_observation_error_gaussian_diagnostic(
                torch.tensor([[[12.0, 60.0, -15.0]]]),
                forecast_std,
                verification,
            )
        )
        self.assertEqual(
            calibrated.combined_gaussian_nll,
            clear_value_changed.combined_gaussian_nll,
        )
        self.assertLess(
            calibrated.combined_gaussian_nll,
            misspecified.combined_gaussian_nll,
        )
        assert calibrated.point_gaussian_nll is not None
        assert misspecified.point_gaussian_nll is not None
        assert calibrated.censored_gaussian_nll is not None
        assert misspecified.censored_gaussian_nll is not None
        self.assertLess(
            calibrated.point_gaussian_nll,
            misspecified.point_gaussian_nll,
        )
        self.assertLess(
            calibrated.censored_gaussian_nll,
            misspecified.censored_gaussian_nll,
        )

    def test_correlated_observation_fso_matches_perturb_and_resolve(
        self,
    ) -> None:
        analysis_config = replace(
            self.analysis_config,
            maximum_outer_iterations=12,
            observation_common_bias_std_dbz=0.2,
        )
        x_fraction = torch.linspace(
            0.0,
            1.0,
            self.frames.shape[-1],
            dtype=self.frames.dtype,
        ).expand(self.frames.shape[-2], -1)
        mode_weights = torch.stack(
            (torch.sqrt(1.0 - x_fraction), torch.sqrt(x_fraction))
        )
        forecast, analysis = variational_nowcast(
            self.frames,
            nowcast_config=self.nowcast_config,
            analysis_config=analysis_config,
            observation_common_bias_mode_weights=mode_weights,
        )
        self.assertTrue(analysis.converged, analysis.reason)
        self.assertFalse(analysis.degraded, analysis.reason)
        verification = torch.where(
            torch.isfinite(forecast.forecast_dbz),
            forecast.forecast_dbz - 0.5,
            forecast.forecast_dbz,
        )
        fso = compute_variational_fso(
            forecast,
            analysis,
            verification,
            sensitivity_config=self.sensitivity_config,
        )
        validate_variational_fso(fso)
        self.assertGreater(fso.whitener_operations_per_apply, 0)
        self.assertGreater(fso.observed_whitener_apply_count, 0)
        linearization = analysis.linearization
        assert linearization is not None
        original_mode_weights = (
            linearization.observations.common_bias_mode_weights
        )
        assert original_mode_weights is not None
        expected_operations = (
            2 * self.frames.shape[0] * original_mode_weights.numel()
        )
        self.assertEqual(
            fso.whitener_operations_per_apply,
            expected_operations,
        )
        with self.assertRaisesRegex(ValueError, "total operation budget"):
            compute_variational_fso(
                forecast,
                analysis,
                verification,
                sensitivity_config=self.sensitivity_config,
                adjoint_config=VariationalAdjointConfig(
                    maximum_whitener_total_operations=expected_operations,
                ),
            )
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "overlapping-linearization.npz"
            save_p1_linearization(analysis, path)
            restarted = load_p1_linearization(path)
            assert restarted.linearization is not None
            restarted_mode_weights = (
                restarted.linearization.observations.common_bias_mode_weights
            )
            assert restarted_mode_weights is not None
            torch.testing.assert_close(
                restarted_mode_weights,
                original_mode_weights,
            )
        observations = linearization.observations
        frozen = linearization.frozen
        truth = dbz_to_echo(
            verification[0],
            min_dbz=self.nowcast_config.min_dbz,
            max_dbz=self.nowcast_config.max_dbz,
        )
        valid = torch.isfinite(verification[0]) & forecast.valid_mask[0]
        lead_cell = freeze_remap_cell(analysis.state.displacement_yx)
        cap_active = fso.forecast_cap_active_mask[0]

        def score(candidate_control: torch.Tensor) -> torch.Tensor:
            trajectory = _analysis_trajectory(candidate_control, frozen)
            state = RadarState(
                echo_linear=trajectory.frames_linear[-1],
                displacement_yx=trajectory.displacement_yx,
                log_growth_per_step=trajectory.log_growth_per_step,
            )
            latent = _forecast_linear_at_step_core(
                state,
                1,
                self.nowcast_config,
                lead_cell,
            )
            return forecast_metric(
                "log_echo_mse",
                _apply_output_cap(
                    latent,
                    cap_active,
                    self.nowcast_config,
                ),
                truth,
                valid,
                self.nowcast_config,
                self.sensitivity_config,
            )

        def solve_perturbed(changed_dbz: torch.Tensor) -> torch.Tensor:
            changed_observations = replace(observations, dbz=changed_dbz)
            candidate = torch.nn.Parameter(analysis.control.clone())
            optimizer = torch.optim.LBFGS(
                (candidate,),
                lr=0.25,
                max_iter=100,
                tolerance_grad=1.0e-12,
                tolerance_change=1.0e-14,
                line_search_fn="strong_wolfe",
            )

            def closure() -> torch.Tensor:
                optimizer.zero_grad()
                residual = residual_vector(
                    candidate,
                    changed_observations,
                    frozen,
                )
                objective = 0.5 * torch.dot(residual, residual)
                objective.backward()
                return objective

            optimizer.step(closure)
            return candidate.detach()

        sensitivity = fso.observation.detected_dbz.maps[0, 0]
        flat_index = int(torch.argmax(sensitivity.abs()))
        index = torch.unravel_index(
            torch.tensor(flat_index),
            observations.dbz.shape,
        )
        self.assertTrue(bool(observations.detected_mask[index]))
        delta = 1.0e-3
        perturbation = torch.zeros_like(observations.dbz)
        perturbation[index] = delta
        plus = solve_perturbed(observations.dbz + perturbation)
        minus = solve_perturbed(observations.dbz - perturbation)
        finite_difference = (score(plus) - score(minus)) / (2.0 * delta)
        torch.testing.assert_close(
            finite_difference,
            sensitivity[index],
            rtol=2.0e-1,
            atol=1.0e-8,
        )

    def test_adjoint_config_validation_and_active_set_margin(self) -> None:
        invalid = (
            {"lead_minutes": ()},
            {"lead_minutes": (20, 10)},
            {"lead_minutes": (10, 10)},
            {"pcg_relative_tolerance": 0.0},
            {"maximum_pcg_iterations": 0},
            {"maximum_normal_products": 0},
            {"maximum_materialized_output_bytes": 0},
            {"preconditioner": "unknown"},
            {"minimum_remap_fraction_margin": -1.0},
            {"minimum_reachability_margin": -1.0},
            {"minimum_unresolved_amplitude_fraction_margin": -1.0},
            {"minimum_amplitude_confidence_margin": -1.0},
            {"minimum_motion_saturation_margin_fraction": -1.0},
            {"minimum_motion_speed_saturation_margin_mps": -1.0},
            {"minimum_growth_saturation_margin_per_step": -1.0},
            {"gauss_newton_probe_count": 0},
            {"gauss_newton_probe_seed": -1},
            {"maximum_gauss_newton_relative_curvature_defect": -1.0},
            {"maximum_detected_delta_dbz": 0.0},
            {"maximum_censor_delta_dbz": 0.0},
            {"maximum_observation_weight_delta": 0.0},
            {"maximum_background_delta_dbz": 0.0},
            {"maximum_perturbed_pixel_count": 0},
            {"maximum_perturbed_fraction": 0.0},
            {"maximum_perturbed_fraction": 1.1},
            {"maximum_perturbed_area_km2": 0.0},
            {"maximum_whitened_perturbation_l2": 0.0},
            {"perturbation_tile_size": 0},
            {"perturbation_tile_size_m": 0.0},
            {"maximum_per_tile_whitened_norm": 0.0},
            {"maximum_observation_weight_l2": 0.0},
            {"minimum_observation_multiplier": 0.0},
        )
        for values in invalid:
            with self.subTest(values=values):
                with self.assertRaises((TypeError, ValueError)):
                    VariationalAdjointConfig(**values)

        metric_policy = SensitivityConfig.for_automated_learning(
            radar_product_digest="1" * 64,
            qc_pipeline_digest="2" * 64,
        )
        self.assertEqual(
            metric_policy.metric_domain,
            "radar_dynamics_anchored",
        )
        self.assertTrue(metric_policy.require_verification_lineage)
        self.assertEqual(
            metric_policy.required_verification_radar_product_digest,
            "1" * 64,
        )
        self.assertEqual(
            metric_policy.required_verification_qc_pipeline_digest,
            "2" * 64,
        )
        adjoint_policy = VariationalAdjointConfig.for_automated_learning()
        self.assertTrue(adjoint_policy.require_active_set_margin)
        self.assertTrue(adjoint_policy.require_feasibility_margin)
        self.assertTrue(adjoint_policy.require_gauss_newton_reliability)
        self.assertTrue(
            adjoint_policy.require_baseline_dynamics_branch_validity
        )
        linearization = self.analysis.linearization
        assert linearization is not None
        learning_policy = AutomatedLearningPolicy(
            sensitivity_config=metric_policy,
            adjoint_config=adjoint_policy,
            algorithm_bundle_digest=linearization.algorithm_bundle_digest,
            numerical_runtime_digest=linearization.numerical_runtime_digest,
        )
        self.assertNotEqual(learning_policy.digest, "")
        for values in (
            {"maximum_candidate_count": 0},
            {"maximum_learning_candidates_to_validate": 0},
            {"maximum_total_robust_resolves": 0},
            {
                "maximum_candidate_count": 1,
                "maximum_learning_candidates_to_validate": 2,
            },
            {
                "maximum_learning_candidates_to_validate": 2,
                "maximum_total_robust_resolves": 2,
            },
        ):
            with self.subTest(values=values):
                with self.assertRaises(ValueError):
                    replace(learning_policy, **values)
        with self.assertRaisesRegex(ValueError, "ranking metric weight"):
            replace(
                learning_policy,
                metric_taylor_thresholds=tuple(
                    replace(threshold, ranking_weight=0.0)
                    for threshold in learning_policy.metric_taylor_thresholds
                ),
            )
        with self.assertRaisesRegex(ValueError, "verification lineage"):
            AutomatedLearningPolicy(
                sensitivity_config=SensitivityConfig(),
                adjoint_config=adjoint_policy,
                algorithm_bundle_digest=linearization.algorithm_bundle_digest,
                numerical_runtime_digest=(
                    linearization.numerical_runtime_digest
                ),
            )
        with self.assertRaisesRegex(ValueError, "local-validity gate"):
            AutomatedLearningPolicy(
                sensitivity_config=metric_policy,
                adjoint_config=VariationalAdjointConfig(),
                algorithm_bundle_digest=linearization.algorithm_bundle_digest,
                numerical_runtime_digest=(
                    linearization.numerical_runtime_digest
                ),
            )

        displacement = torch.tensor((0.25, 0.40), dtype=torch.float64)
        self.assertAlmostEqual(
            _remap_fraction_margin(
                displacement,
                freeze_remap_cell(displacement),
            ),
            0.25,
        )
        near_boundary = torch.tensor(
            (0.99999, 0.25),
            dtype=torch.float64,
        )
        self.assertLess(
            _remap_fraction_margin(
                near_boundary,
                freeze_remap_cell(near_boundary),
            ),
            2.0e-5,
        )

        self.assertFalse(self.fso.active_set_margins.low_local_validity)
        with self.assertRaisesRegex(ValueError, "active-set margin"):
            compute_variational_fso(
                self.forecast,
                self.analysis,
                self.verification,
                sensitivity_config=self.sensitivity_config,
                adjoint_config=VariationalAdjointConfig(
                    minimum_remap_fraction_margin=(
                        self.fso.active_set_margins.analysis_remap_fraction
                        + 1.0
                    ),
                    require_active_set_margin=True,
                ),
            )
        feasibility = self.fso.feasibility_margins
        with self.assertRaisesRegex(ValueError, "feasibility margin"):
            compute_variational_fso(
                self.forecast,
                self.analysis,
                self.verification,
                sensitivity_config=self.sensitivity_config,
                adjoint_config=VariationalAdjointConfig(
                    minimum_reachability_margin=(
                        feasibility.reachability_support + 1.0
                    ),
                    require_feasibility_margin=True,
                ),
            )
        self.assertTrue(self.fso.gauss_newton_diagnostics.reliable)
        with self.assertRaisesRegex(ValueError, "curvature approximation"):
            compute_variational_fso(
                self.forecast,
                self.analysis,
                self.verification,
                sensitivity_config=self.sensitivity_config,
                adjoint_config=VariationalAdjointConfig(
                    maximum_gauss_newton_relative_curvature_defect=1.0e-3,
                    require_gauss_newton_reliability=True,
                ),
            )
        with self.assertRaisesRegex(ValueError, "branch margins"):
            compute_variational_fso(
                self.forecast,
                self.analysis,
                self.verification,
                sensitivity_config=self.sensitivity_config,
                adjoint_config=VariationalAdjointConfig(
                    require_baseline_dynamics_branch_validity=True,
                ),
            )

    def test_feasibility_margins_are_content_addressed(self) -> None:
        linearization = self.analysis.linearization
        assert linearization is not None
        changed_linearization = replace(
            linearization,
            feasibility_margins=replace(
                linearization.feasibility_margins,
                reachability_support=(
                    linearization.feasibility_margins.reachability_support
                    + 0.01
                ),
            ),
        )
        with self.assertRaisesRegex(ValueError, "content digest"):
            compute_variational_fso(
                self.forecast,
                replace(self.analysis, linearization=changed_linearization),
                self.verification,
                sensitivity_config=self.sensitivity_config,
            )

        changed_fso = replace(
            self.fso,
            feasibility_margins=replace(
                self.fso.feasibility_margins,
                growth_saturation_per_step=(
                    self.fso.feasibility_margins
                    .growth_saturation_per_step
                    + 0.01
                ),
            ),
        )
        with self.assertRaisesRegex(ValueError, "result digest"):
            validate_variational_fso(changed_fso)

    def test_variational_fso_binds_metric_domain_policy(self) -> None:
        confidence = compute_variational_fso(
            self.forecast,
            self.analysis,
            self.verification,
            sensitivity_config=replace(
                self.sensitivity_config,
                metric_domain="confidence_weighted",
            ),
        )
        anchored = compute_variational_fso(
            self.forecast,
            self.analysis,
            self.verification,
            sensitivity_config=replace(
                self.sensitivity_config,
                metric_domain="radar_dynamics_anchored",
            ),
        )
        self.assertEqual(confidence.metric_domain, "confidence_weighted")
        self.assertEqual(
            anchored.metric_domain,
            "radar_dynamics_anchored",
        )
        self.assertNotEqual(
            confidence.metric_domain_digest,
            self.fso.metric_domain_digest,
        )
        self.assertNotEqual(
            anchored.metric_domain_digest,
            self.fso.metric_domain_digest,
        )
        self.assertLessEqual(
            float(confidence.metric_domain_weight_sum[0]),
            float(self.fso.metric_domain_weight_sum[0]),
        )
        self.assertLessEqual(
            float(anchored.metric_domain_weight_sum[0]),
            float(self.fso.metric_domain_weight_sum[0]),
        )

    def test_gauss_newton_curvature_defect_has_analytic_reference(self) -> None:
        control = torch.ones(1, dtype=torch.float64)

        def residual(value: torch.Tensor) -> torch.Tensor:
            return torch.cat((value, value.square()))

        def gauss_newton_product(value: torch.Tensor) -> torch.Tensor:
            return 5.0 * value

        config = VariationalAdjointConfig(
            gauss_newton_probe_count=1,
            maximum_gauss_newton_relative_curvature_defect=0.5,
        )
        diagnostics = _gauss_newton_curvature_diagnostics(
            control,
            residual,
            gauss_newton_product,
            _NormalProductBudget(maximum=2),
            config,
        )
        torch.testing.assert_close(
            diagnostics.relative_curvature_defect,
            torch.tensor((0.4,), dtype=torch.float64),
        )
        self.assertTrue(diagnostics.reliable)

        with self.assertRaisesRegex(ValueError, "curvature approximation"):
            _gauss_newton_curvature_diagnostics(
                control,
                residual,
                gauss_newton_product,
                _NormalProductBudget(maximum=2),
                replace(
                    config,
                    maximum_gauss_newton_relative_curvature_defect=0.3,
                    require_gauss_newton_reliability=True,
                ),
            )

    def test_selected_leads_warm_start_and_resource_budgets(self) -> None:
        nowcast_config = NowcastConfig(horizon_minutes=20)
        forecast, analysis = variational_nowcast(
            self.frames,
            nowcast_config=nowcast_config,
            analysis_config=self.analysis_config,
        )
        self.assertTrue(analysis.converged)
        self.assertFalse(analysis.degraded)
        verification = torch.where(
            torch.isfinite(forecast.forecast_dbz),
            forecast.forecast_dbz - 0.5,
            forecast.forecast_dbz,
        )
        all_maps = SensitivityConfig(
            metric_names=("log_echo_mse",),
            full_map_lead_minutes=(10, 20),
            tile_size=4,
        )
        selected_maps = replace(all_maps, full_map_lead_minutes=(20,))
        cold = compute_variational_fso(
            forecast,
            analysis,
            verification,
            sensitivity_config=all_maps,
            adjoint_config=VariationalAdjointConfig(
                warm_start_by_metric=False,
            ),
        )
        warm = compute_variational_fso(
            forecast,
            analysis,
            verification,
            sensitivity_config=all_maps,
            adjoint_config=VariationalAdjointConfig(),
        )
        selected = compute_variational_fso(
            forecast,
            analysis,
            verification,
            sensitivity_config=selected_maps,
            adjoint_config=VariationalAdjointConfig(
                lead_minutes=(20,),
                warm_start_by_metric=False,
            ),
        )
        unpreconditioned = compute_variational_fso(
            forecast,
            analysis,
            verification,
            sensitivity_config=selected_maps,
            adjoint_config=VariationalAdjointConfig(
                lead_minutes=(20,),
                warm_start_by_metric=False,
                preconditioner="none",
            ),
        )

        self.assertEqual(selected.lead_minutes, (20,))
        self.assertEqual(selected.forecast_scores.shape, (1, 1))
        torch.testing.assert_close(
            selected.forecast_scores[0],
            cold.forecast_scores[1],
        )
        torch.testing.assert_close(
            selected.observation.detected_dbz.maps[0],
            cold.observation.detected_dbz.maps[1],
            rtol=1.0e-6,
            atol=1.0e-10,
        )
        torch.testing.assert_close(
            selected.observation.detected_dbz.maps,
            unpreconditioned.observation.detected_dbz.maps,
            rtol=1.0e-6,
            atol=1.0e-10,
        )
        self.assertFalse(bool(warm.adjoint_warm_started[0, 0]))
        self.assertTrue(bool(warm.adjoint_warm_started[1, 0]))
        torch.testing.assert_close(
            warm.observation.detected_dbz.maps,
            cold.observation.detected_dbz.maps,
            rtol=5.0e-4,
            atol=1.0e-9,
        )

        with self.assertRaisesRegex(ValueError, "byte budget"):
            compute_variational_fso(
                forecast,
                analysis,
                verification,
                sensitivity_config=selected_maps,
                adjoint_config=VariationalAdjointConfig(
                    lead_minutes=(20,),
                    maximum_materialized_output_bytes=1,
                ),
            )
        with self.assertRaisesRegex(ValueError, "normal-product budget"):
            compute_variational_fso(
                forecast,
                analysis,
                verification,
                sensitivity_config=selected_maps,
                adjoint_config=VariationalAdjointConfig(
                    lead_minutes=(20,),
                    maximum_normal_products=1,
                ),
            )

    def test_scalar_observation_sensitivity_sign_is_independent(self) -> None:
        sigma = 2.0
        truth = -1.5
        observation = torch.tensor(3.0, dtype=torch.float64)

        def analyzed(value: torch.Tensor) -> torch.Tensor:
            return value / (1.0 + sigma**2)

        def metric(value: torch.Tensor) -> torch.Tensor:
            return 0.5 * (analyzed(value) - truth).square()

        expected = (float(analyzed(observation)) - truth) / (1.0 + sigma**2)
        delta = 1.0e-5
        finite_difference = (
            metric(observation + delta) - metric(observation - delta)
        ) / (2.0 * delta)
        self.assertGreater(expected, 0.0)
        torch.testing.assert_close(
            finite_difference,
            torch.tensor(expected, dtype=torch.float64),
            rtol=1.0e-10,
            atol=1.0e-12,
        )

    def test_variational_fso_binds_verification_and_output_contents(
        self,
    ) -> None:
        fso = self.fso
        linearization = self.analysis.linearization
        assert linearization is not None
        changed_verification = self.verification.clone()
        finite_index = tuple(
            int(value)
            for value in torch.nonzero(
                torch.isfinite(changed_verification),
                as_tuple=False,
            )[0]
        )
        changed_verification[finite_index] += 0.25
        changed = compute_variational_fso(
            self.forecast,
            self.analysis,
            changed_verification,
            sensitivity_config=self.sensitivity_config,
        )
        self.assertNotEqual(
            self.fso.verification_bundle_digest,
            changed.verification_bundle_digest,
        )
        self.assertNotEqual(
            self.fso.variational_fso_digest,
            changed.variational_fso_digest,
        )

        changed_scores = self.fso.forecast_scores.clone()
        changed_scores[0, 0] += 1.0
        tampered = replace(self.fso, forecast_scores=changed_scores)
        with self.assertRaisesRegex(ValueError, "result digest mismatch"):
            validate_variational_fso(tampered)
        self.assertEqual(
            fso.observation.detected_dbz.tile_norm_by_time.shape,
            (1, 1, 3, 2, 2),
        )
        self.assertTrue(bool(fso.metric_available[0, 0]))
        self.assertGreater(int(fso.adjoint_iterations[0, 0]), 0)
        self.assertLess(float(fso.adjoint_relative_residual[0, 0]), 1.0e-8)
        self.assertTrue(
            bool(
                torch.all(
                    fso.observation.detected_dbz.norm_by_time[0, 0] > 0.0
                )
            )
        )
        censored = ~linearization.observations.detected_mask
        torch.testing.assert_close(
            fso.observation.detected_dbz.maps[0, 0][censored],
            torch.zeros_like(
                fso.observation.detected_dbz.maps[0, 0][censored]
            ),
        )
        self.assertGreater(
            float(fso.observation.censor_threshold_dbz.maps.abs().max()),
            0.0,
        )
        self.assertGreater(
            float(fso.observation.observation_weight.maps.abs().max()),
            0.0,
        )
        torch.testing.assert_close(
            fso.observation.censor_threshold_dbz.maps[0, 0][
                linearization.observations.detected_mask
            ],
            torch.zeros_like(
                fso.observation.censor_threshold_dbz.maps[0, 0][
                    linearization.observations.detected_mask
                ]
            ),
        )

    def test_p1_linearization_artifact_restarts_identical_fso(self) -> None:
        linearization = self.analysis.linearization
        assert linearization is not None
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "p1-linearization.npz"
            save_p1_linearization(self.analysis, path)
            loaded = load_p1_linearization(path)
            restarted = compute_variational_fso(
                self.forecast,
                loaded,
                self.verification,
                sensitivity_config=self.sensitivity_config,
            )

        self.assertEqual(
            loaded.linearization.linearization_digest,
            linearization.linearization_digest,
        )
        self.assertEqual(
            restarted.variational_fso_digest,
            self.fso.variational_fso_digest,
        )
        torch.testing.assert_close(
            loaded.linearization.frozen.input_frames_dbz,
            linearization.frozen.input_frames_dbz,
            rtol=0.0,
            atol=0.0,
            equal_nan=True,
        )
        self.assertIsNone(
            loaded.linearization.frozen.background_frames_dbz
        )
        self.assertIsNone(linearization.frozen.background_frames_dbz)
        torch.testing.assert_close(
            restarted.observation.detected_dbz.maps,
            self.fso.observation.detected_dbz.maps,
            rtol=0.0,
            atol=0.0,
        )

    def test_observation_removal_rebuilds_the_full_analysis(self) -> None:
        linearization = self.analysis.linearization
        assert linearization is not None
        mask = torch.zeros_like(linearization.observations.valid_mask)
        index = torch.nonzero(
            linearization.observations.valid_mask,
            as_tuple=False,
        )[0]
        mask[tuple(int(value) for value in index)] = True

        impact = compute_variational_observation_removal_impact(
            self.forecast,
            self.analysis,
            self.verification,
            mask,
            sensitivity_config=self.sensitivity_config,
            removal_config=ObservationRemovalConfig(
                maximum_removed_fraction=1.0,
                maximum_removed_area_km2=None,
            ),
        )
        validate_observation_removal_impact(impact)

        self.assertEqual(impact.removed_observation_count, 1)
        self.assertNotEqual(
            impact.removed_forecast_digest,
            impact.nominal_forecast_digest,
        )
        self.assertNotEqual(
            impact.removed_linearization_digest,
            linearization.linearization_digest,
        )
        torch.testing.assert_close(
            impact.metric_change[impact.metric_available],
            (impact.removed_scores - impact.nominal_scores)[
                impact.metric_available
            ],
            rtol=0.0,
            atol=0.0,
        )
        self.assertEqual(
            len(impact.observation_removal_impact_digest),
            64,
        )

    def test_observation_removal_rejects_unaccepted_input(self) -> None:
        qc_mask = torch.ones_like(self.frames, dtype=torch.bool)
        qc_mask[0, 0, 0] = False
        forecast, analysis = variational_nowcast(
            self.frames,
            nowcast_config=self.nowcast_config,
            analysis_config=self.analysis_config,
            qc_mask=qc_mask,
        )
        linearization = analysis.linearization
        assert linearization is not None
        mask = torch.zeros_like(linearization.observations.valid_mask)
        mask[0, 0, 0] = True
        with self.assertRaisesRegex(ValueError, "accepted observations"):
            compute_variational_observation_removal_impact(
                forecast,
                analysis,
                forecast.forecast_dbz,
                mask,
                removal_config=ObservationRemovalConfig(
                    maximum_removed_area_km2=None,
                ),
            )

    def test_p1_linearization_artifact_syncs_file_and_directory(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "p1-linearization.npz"
            with patch(
                "advar.linearization_artifact.os.fsync",
                wraps=os.fsync,
            ) as fsync:
                save_p1_linearization(self.analysis, path)

        self.assertEqual(fsync.call_count, 2)

    def test_legacy_v13_linearization_migrates_without_prior_state(self) -> None:
        def remove_new_frozen_fields(value: object) -> None:
            if isinstance(value, dict):
                if value.get("type") == "FrozenOuterState":
                    retained = value.get("fields")
                    assert isinstance(retained, dict)
                    for name in (
                        "neural_prior_raw_background_dbz",
                        "neural_prior_execution_contract_digest",
                        "neural_prior_role",
                    ):
                        retained.pop(name, None)
                for child in value.values():
                    remove_new_frozen_fields(child)
            elif isinstance(value, list):
                for child in value:
                    remove_new_frozen_fields(child)

        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "p1-linearization.npz"
            save_p1_linearization(self.analysis, path)
            with np.load(path, allow_pickle=False) as archive:
                values = {
                    name: np.array(archive[name], copy=True)
                    for name in archive.files
                }
            payload = json.loads(str(values["payload_json"].item()))
            payload["version"] = "p1-linearization-v13"
            remove_new_frozen_fields(payload["state"])
            payload_json = json.dumps(
                payload,
                sort_keys=True,
                separators=(",", ":"),
                allow_nan=False,
            )
            tensors = {
                name: value
                for name, value in values.items()
                if name.startswith("tensor_")
            }
            values["artifact_version"] = np.asarray("p1-linearization-v13")
            values["payload_json"] = np.asarray(payload_json)
            values["artifact_digest"] = np.asarray(
                linearization_artifact_module._artifact_digest(
                    "p1-linearization-v13",
                    payload_json,
                    tensors,
                )
            )
            with path.open("wb") as stream:
                np.savez(stream, **values)

            restarted = load_p1_linearization(path)

        self.assertEqual(
            restarted.linearization.contract,
            "p1-final-frozen-irls-gn-v15",
        )

    def test_p1_linearization_artifact_rejects_tamper_and_runtime_mismatch(
        self,
    ) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "p1-linearization.npz"
            save_p1_linearization(self.analysis, path)
            with patch(
                "advar.linearization_artifact.algorithm_bundle_digest",
                return_value="0" * 64,
            ):
                with self.assertRaisesRegex(
                    ValueError,
                    "algorithm bundle mismatch",
                ):
                    load_p1_linearization(path)
            with patch(
                "advar.linearization_artifact.numerical_runtime_identity_digest",
                return_value="0" * 64,
            ):
                with self.assertRaisesRegex(
                    ValueError,
                    "numerical runtime mismatch",
                ):
                    load_p1_linearization(path)

            with np.load(path, allow_pickle=False) as archive:
                arrays = {
                    name: np.array(archive[name], copy=True)
                    for name in archive.files
                }
            tensor_name = next(
                name
                for name, value in arrays.items()
                if name.startswith("tensor_") and value.dtype.kind == "f"
            )
            arrays[tensor_name].reshape(-1)[0] += 1.0
            with path.open("wb") as stream:
                np.savez(stream, **arrays)
            with self.assertRaisesRegex(
                ValueError,
                "artifact digest mismatch",
            ):
                load_p1_linearization(path)

    def test_variational_fso_matches_dense_and_finite_difference(self) -> None:
        linearization = self.analysis.linearization
        assert linearization is not None
        observations = linearization.observations
        frozen = linearization.frozen
        control = self.analysis.control
        config = self.nowcast_config
        sensitivity_config = self.sensitivity_config

        residual_fn = lambda value: residual_vector(
            value,
            observations,
            frozen,
        )
        jacobian = torch.func.jacrev(residual_fn)(control)
        normal_matrix = jacobian.mT @ jacobian
        truth = dbz_to_echo(
            self.verification[0],
            min_dbz=config.min_dbz,
            max_dbz=config.max_dbz,
        )
        valid = torch.isfinite(self.verification[0]) & self.forecast.valid_mask[0]
        lead_cell = freeze_remap_cell(self.analysis.state.displacement_yx)
        cap_active = self.fso.forecast_cap_active_mask[0]

        def score(candidate_control: torch.Tensor) -> torch.Tensor:
            trajectory = _analysis_trajectory(candidate_control, frozen)
            state = RadarState(
                echo_linear=trajectory.frames_linear[-1],
                displacement_yx=trajectory.displacement_yx,
                log_growth_per_step=trajectory.log_growth_per_step,
            )
            latent = _forecast_linear_at_step_core(
                state,
                1,
                config,
                lead_cell,
            )
            return forecast_metric(
                "log_echo_mse",
                _apply_output_cap(latent, cap_active, config),
                truth,
                valid,
                config,
                sensitivity_config,
            )

        metric_rhs = torch.func.grad(score)(control)
        dense_adjoint = torch.linalg.solve(normal_matrix, metric_rhs)
        observation_count = observations.dbz.numel()
        observation_scale = torch.where(
            observations.detected_mask,
            torch.sqrt(observations.quality_weight)
            * frozen.irls_sqrt_weight
            / observations.std_dbz,
            torch.zeros_like(observations.dbz),
        )
        dense_sensitivity = observation_scale * (
            jacobian[:observation_count] @ dense_adjoint
        ).reshape_as(observations.dbz)
        torch.testing.assert_close(
            self.fso.observation.detected_dbz.maps[0, 0],
            dense_sensitivity,
            rtol=1.0e-5,
            atol=2.0e-10,
        )
        prediction_response = (
            jacobian[:observation_count] @ dense_adjoint
        ).reshape_as(observations.dbz)
        base_scale = (
            torch.sqrt(observations.quality_weight)
            * frozen.irls_sqrt_weight
            / observations.std_dbz
        )
        analyzed_dbz = echo_to_dbz(
            _analysis_trajectory(control, frozen).frames_linear,
            min_dbz=config.min_dbz,
        )
        censor_response = torch.sigmoid(
            (
                analyzed_dbz
                - frozen.analysis_config.detection_limit_dbz
            )
            / frozen.analysis_config.censor_temperature_dbz
        )
        censor_error = (
            frozen.analysis_config.censor_temperature_dbz
            * torch.nn.functional.softplus(
                (
                    analyzed_dbz
                    - frozen.analysis_config.detection_limit_dbz
                )
                / frozen.analysis_config.censor_temperature_dbz
            )
        )
        censor_scale = torch.where(
            observations.censored_mask,
            base_scale
            * (
                censor_response
                + (
                    censor_error
                    / frozen.analysis_config.censor_temperature_dbz
                )
                * (1.0 - censor_response)
            ),
            torch.zeros_like(observations.dbz),
        )
        dense_censor_sensitivity = censor_scale * prediction_response
        torch.testing.assert_close(
            self.fso.observation.censor_threshold_dbz.maps[0, 0],
            dense_censor_sensitivity,
            rtol=1.0e-5,
            atol=2.0e-10,
        )
        weighted_residual = residual_fn(control)[:observation_count].reshape_as(
            observations.dbz
        )
        dense_weight_sensitivity = -weighted_residual * prediction_response
        torch.testing.assert_close(
            self.fso.observation.observation_weight.maps[0, 0],
            dense_weight_sensitivity,
            rtol=1.0e-5,
            atol=2.0e-10,
        )

        def score_from_background(
            candidate_background: torch.Tensor,
        ) -> torch.Tensor:
            candidate_frozen = replace(
                frozen,
                initial_background_dbz=candidate_background,
            )
            trajectory = _analysis_trajectory(control, candidate_frozen)
            state = RadarState(
                echo_linear=trajectory.frames_linear[-1],
                displacement_yx=trajectory.displacement_yx,
                log_growth_per_step=trajectory.log_growth_per_step,
            )
            latent = _forecast_linear_at_step_core(
                state,
                1,
                config,
                lead_cell,
            )
            return forecast_metric(
                "log_echo_mse",
                _apply_output_cap(latent, cap_active, config),
                truth,
                valid,
                config,
                sensitivity_config,
            )

        def stationarity_from_background(
            candidate_background: torch.Tensor,
        ) -> torch.Tensor:
            def objective(candidate_control: torch.Tensor) -> torch.Tensor:
                residual = residual_vector(
                    candidate_control,
                    observations,
                    replace(
                        frozen,
                        initial_background_dbz=candidate_background,
                    ),
                )
                return 0.5 * torch.dot(residual, residual)

            return torch.func.grad(objective)(control)

        background_mixed_gradient = torch.func.jacrev(
            stationarity_from_background
        )(frozen.initial_background_dbz)
        direct_background = torch.func.grad(score_from_background)(
            frozen.initial_background_dbz
        )
        dense_background = direct_background - torch.einsum(
            "chw,c->hw",
            background_mixed_gradient,
            dense_adjoint,
        )
        expected_background = torch.zeros_like(observations.dbz)
        expected_background[0] = torch.where(
            observations.valid_mask[0] & frozen.observed_mask[0],
            dense_background,
            torch.zeros_like(dense_background),
        )
        torch.testing.assert_close(
            self.fso.observation.initial_background_dbz.maps[0, 0],
            expected_background,
            rtol=1.0e-5,
            atol=2.0e-10,
        )

        def dynamics_from_observation(
            candidate_dbz: torch.Tensor,
        ) -> torch.Tensor:
            candidate_linear = dbz_to_echo(
                candidate_dbz,
                min_dbz=config.min_dbz,
                max_dbz=config.max_dbz,
            )
            estimate = _estimate_source_tendencies(
                candidate_dbz,
                frozen.observed_mask,
                candidate_linear,
                config,
                frozen.grid_time_contract,
            )
            return torch.cat(
                (
                    estimate.displacement_yx,
                    estimate.log_growth_per_step.reshape(1),
                )
            )

        nominal_dynamics = torch.cat(
            (
                frozen.baseline_state.displacement_yx,
                frozen.baseline_state.log_growth_per_step.reshape(1),
            )
        )

        def frozen_from_dynamics(candidate: torch.Tensor):
            return replace(
                frozen,
                baseline_state=RadarState(
                    echo_linear=frozen.baseline_state.echo_linear,
                    displacement_yx=candidate[:2],
                    log_growth_per_step=candidate[2],
                ),
            )

        def score_from_dynamics(candidate: torch.Tensor) -> torch.Tensor:
            candidate_frozen = frozen_from_dynamics(candidate)
            trajectory = _analysis_trajectory(control, candidate_frozen)
            state = RadarState(
                echo_linear=trajectory.frames_linear[-1],
                displacement_yx=trajectory.displacement_yx,
                log_growth_per_step=trajectory.log_growth_per_step,
            )
            latent = _forecast_linear_at_step_core(
                state,
                1,
                config,
                lead_cell,
            )
            return forecast_metric(
                "log_echo_mse",
                _apply_output_cap(latent, cap_active, config),
                truth,
                valid,
                config,
                sensitivity_config,
            )

        dynamics_jacobian = torch.func.jacrev(
            dynamics_from_observation
        )(observations.dbz)
        def stationarity_from_dynamics(
            candidate: torch.Tensor,
        ) -> torch.Tensor:
            def objective(candidate_control: torch.Tensor) -> torch.Tensor:
                residual = residual_vector(
                    candidate_control,
                    observations,
                    frozen_from_dynamics(candidate),
                )
                return 0.5 * torch.dot(residual, residual)

            return torch.func.grad(objective)(control)

        dynamics_mixed_gradient = torch.func.jacrev(
            stationarity_from_dynamics
        )(nominal_dynamics)
        dynamics_metric_gradient = torch.func.grad(score_from_dynamics)(
            nominal_dynamics
        )
        dynamics_parameter_sensitivity = dynamics_metric_gradient - (
            dynamics_mixed_gradient.mT @ dense_adjoint
        )
        expected_dynamics = torch.einsum(
            "dthw,d->thw",
            dynamics_jacobian,
            dynamics_parameter_sensitivity,
        )
        expected_dynamics = torch.where(
            observations.valid_mask & frozen.observed_mask,
            expected_dynamics,
            torch.zeros_like(expected_dynamics),
        )
        torch.testing.assert_close(
            self.fso.observation.baseline_dynamics_dbz.maps[0, 0],
            expected_dynamics,
            rtol=1.0e-5,
            atol=2.0e-10,
        )
        torch.testing.assert_close(
            self.fso.observation.frozen_structure_input_dbz.maps[0, 0],
            dense_sensitivity + expected_background + expected_dynamics,
            rtol=1.0e-5,
            atol=2.0e-10,
        )

        time_index, row, column = 2, 4, 4
        observation_direction = torch.zeros_like(observations.dbz)
        observation_direction[time_index, row, column] = 1.0
        control_direction = torch.linalg.solve(
            normal_matrix,
            jacobian[:observation_count].mT
            @ (observation_scale * observation_direction).reshape(-1),
        )
        delta = 1.0e-3
        finite_difference = (
            score(control + delta * control_direction)
            - score(control - delta * control_direction)
        ) / (2.0 * delta)
        torch.testing.assert_close(
            finite_difference,
            self.fso.observation.detected_dbz.maps[
                0,
                0,
                time_index,
                row,
                column,
            ],
            rtol=1.0e-5,
            atol=1.0e-10,
        )

    def test_variational_fso_matches_observation_perturb_and_resolve(
        self,
    ) -> None:
        coordinates = torch.arange(8, dtype=torch.float64)
        y, x = torch.meshgrid(coordinates, coordinates, indexing="ij")
        moving_frames = torch.stack(
            tuple(
                -10.0
                + 35.0
                * torch.exp(
                    -(
                        (y - (3.0 + 0.18 * index)).square()
                        + (x - (3.1 + 0.21 * index)).square()
                    )
                    / 3.0
                )
                + 8.0
                * torch.exp(
                    -(
                        (y - (5.2 + 0.18 * index)).square()
                        + (x - (5.7 + 0.21 * index)).square()
                    )
                    / 0.8
                )
                for index in range(3)
            )
        )
        forecast, analysis = variational_nowcast(
            moving_frames,
            nowcast_config=self.nowcast_config,
            analysis_config=replace(
                self.analysis_config,
                maximum_outer_iterations=12,
            ),
        )
        self.assertTrue(analysis.converged, analysis.reason)
        self.assertFalse(analysis.degraded, analysis.reason)
        verification = torch.where(
            torch.isfinite(forecast.forecast_dbz),
            forecast.forecast_dbz - 0.5,
            forecast.forecast_dbz,
        )
        fso = compute_variational_fso(
            forecast,
            analysis,
            verification,
            sensitivity_config=self.sensitivity_config,
        )
        self.assertFalse(fso.active_set_margins.low_local_validity)

        linearization = analysis.linearization
        assert linearization is not None
        observations = linearization.observations
        frozen = linearization.frozen
        config = self.nowcast_config
        truth = dbz_to_echo(
            verification[0],
            min_dbz=config.min_dbz,
            max_dbz=config.max_dbz,
        )
        valid = torch.isfinite(verification[0]) & forecast.valid_mask[0]
        lead_cell = freeze_remap_cell(analysis.state.displacement_yx)
        cap_active = fso.forecast_cap_active_mask[0]

        def score(
            candidate_control: torch.Tensor,
            candidate_frozen=frozen,
        ) -> torch.Tensor:
            trajectory = _analysis_trajectory(
                candidate_control,
                candidate_frozen,
            )
            state = RadarState(
                echo_linear=trajectory.frames_linear[-1],
                displacement_yx=trajectory.displacement_yx,
                log_growth_per_step=trajectory.log_growth_per_step,
            )
            latent = _forecast_linear_at_step_core(
                state,
                1,
                config,
                lead_cell,
            )
            return forecast_metric(
                "log_echo_mse",
                _apply_output_cap(latent, cap_active, config),
                truth,
                valid,
                config,
                self.sensitivity_config,
            )

        def stationarity_at_control(
            candidate_observations,
            candidate_frozen,
        ) -> torch.Tensor:
            def objective(candidate_control: torch.Tensor) -> torch.Tensor:
                residual = residual_vector(
                    candidate_control,
                    candidate_observations,
                    candidate_frozen,
                )
                return 0.5 * torch.dot(residual, residual)

            return torch.func.grad(objective)(analysis.control)

        nominal_residual_function = lambda candidate_control: residual_vector(
            candidate_control,
            observations,
            frozen,
        )
        nominal_jacobian = torch.func.jacrev(
            nominal_residual_function
        )(analysis.control)
        nominal_normal = nominal_jacobian.mT @ nominal_jacobian
        nominal_stationarity = stationarity_at_control(observations, frozen)

        def frozen_gn_response(candidate_observations, candidate_frozen):
            stationarity_change = (
                stationarity_at_control(
                    candidate_observations,
                    candidate_frozen,
                )
                - nominal_stationarity
            )
            return analysis.control - torch.linalg.solve(
                nominal_normal,
                stationarity_change,
            )

        time_index, row, column = 2, 4, 4
        delta = 1.0e-3
        perturbation = torch.zeros_like(observations.dbz)
        perturbation[time_index, row, column] = delta
        plus = frozen_gn_response(
            replace(observations, dbz=observations.dbz + perturbation),
            frozen,
        )
        minus = frozen_gn_response(
            replace(observations, dbz=observations.dbz - perturbation),
            frozen,
        )
        finite_difference = (score(plus) - score(minus)) / (2.0 * delta)

        torch.testing.assert_close(
            finite_difference,
            fso.observation.detected_dbz.maps[
                0,
                0,
                time_index,
                row,
                column,
            ],
            rtol=5.0e-3,
            atol=1.0e-8,
        )

        first_frame_detected = torch.nonzero(
            observations.detected_mask[0],
            as_tuple=False,
        )
        total_magnitude = torch.abs(
            fso.observation.frozen_structure_input_dbz.maps[
                0,
                0,
                0,
            ]
        )
        detected_magnitude = total_magnitude[
            first_frame_detected[:, 0],
            first_frame_detected[:, 1],
        ]
        first_frame_detected = first_frame_detected[
            int(torch.argmax(detected_magnitude))
        ]
        first_row, first_column = (
            int(first_frame_detected[0]),
            int(first_frame_detected[1]),
        )
        input_delta = 1.0e-2
        input_perturbation = torch.zeros_like(observations.dbz)
        input_perturbation[0, first_row, first_column] = input_delta
        background_perturbation = torch.zeros_like(
            frozen.initial_background_dbz
        )
        background_perturbation[first_row, first_column] = input_delta
        plus_observations = replace(
            observations,
            dbz=observations.dbz + input_perturbation,
        )
        minus_observations = replace(
            observations,
            dbz=observations.dbz - input_perturbation,
        )

        def frozen_for_input(
            candidate_observations,
            candidate_background: torch.Tensor,
        ):
            candidate_linear = dbz_to_echo(
                candidate_observations.dbz,
                min_dbz=config.min_dbz,
                max_dbz=config.max_dbz,
            )
            estimate = _estimate_source_tendencies(
                candidate_observations.dbz,
                frozen.observed_mask,
                candidate_linear,
                config,
                frozen.grid_time_contract,
            )
            return replace(
                frozen,
                initial_background_dbz=candidate_background,
                baseline_state=RadarState(
                    echo_linear=frozen.baseline_state.echo_linear,
                    displacement_yx=estimate.displacement_yx,
                    log_growth_per_step=estimate.log_growth_per_step,
                ),
            )

        plus_frozen = frozen_for_input(
            plus_observations,
            frozen.initial_background_dbz + background_perturbation,
        )
        minus_frozen = frozen_for_input(
            minus_observations,
            frozen.initial_background_dbz - background_perturbation,
        )

        plus = frozen_gn_response(plus_observations, plus_frozen)
        minus = frozen_gn_response(minus_observations, minus_frozen)
        frozen_structure_difference = (
            score(plus, plus_frozen) - score(minus, minus_frozen)
        ) / (2.0 * input_delta)
        torch.testing.assert_close(
            frozen_structure_difference,
            fso.observation.frozen_structure_input_dbz.maps[
                0,
                0,
                0,
                first_row,
                first_column,
            ],
            # Re-solve the retained frozen-GN stationarity equation from an
            # actual input perturbation, including both baseline pathways.
            rtol=2.0e-2,
            atol=1.0e-8,
        )

    def test_censored_and_weight_sensitivity_match_perturb_and_resolve(
        self,
    ) -> None:
        linearization = self.analysis.linearization
        assert linearization is not None
        observations = linearization.observations
        frozen = linearization.frozen
        control = self.analysis.control
        config = self.nowcast_config
        observation_count = observations.dbz.numel()
        base_scale = (
            torch.sqrt(observations.quality_weight)
            * frozen.irls_sqrt_weight
            / observations.std_dbz
        )
        truth = dbz_to_echo(
            self.verification[0],
            min_dbz=config.min_dbz,
            max_dbz=config.max_dbz,
        )
        valid = torch.isfinite(self.verification[0]) & self.forecast.valid_mask[0]
        lead_cell = freeze_remap_cell(self.analysis.state.displacement_yx)
        cap_active = self.fso.forecast_cap_active_mask[0]

        def score(candidate_control: torch.Tensor) -> torch.Tensor:
            trajectory = _analysis_trajectory(candidate_control, frozen)
            state = RadarState(
                echo_linear=trajectory.frames_linear[-1],
                displacement_yx=trajectory.displacement_yx,
                log_growth_per_step=trajectory.log_growth_per_step,
            )
            latent = _forecast_linear_at_step_core(
                state,
                1,
                config,
                lead_cell,
            )
            return forecast_metric(
                "log_echo_mse",
                _apply_output_cap(latent, cap_active, config),
                truth,
                valid,
                config,
                self.sensitivity_config,
            )

        def solve(
            residual_function,
            delta: float,
        ) -> torch.Tensor:
            candidate = torch.nn.Parameter(control.clone())
            optimizer = torch.optim.LBFGS(
                (candidate,),
                lr=0.25,
                max_iter=150,
                tolerance_grad=1.0e-12,
                tolerance_change=1.0e-14,
                line_search_fn="strong_wolfe",
            )

            def closure() -> torch.Tensor:
                optimizer.zero_grad()
                residual = residual_function(candidate, delta)
                objective = 0.5 * torch.dot(residual, residual)
                objective.backward()
                return objective

            optimizer.step(closure)
            return candidate.detach()

        censor_flat_index = int(
            torch.argmax(
                self.fso.observation.censor_threshold_dbz.maps[0, 0].abs()
            )
        )
        censor_index = torch.unravel_index(
            torch.tensor(censor_flat_index),
            observations.dbz.shape,
        )
        censor_mask = torch.zeros_like(observations.dbz, dtype=torch.bool)
        censor_mask[censor_index] = True

        def censor_residual(
            candidate_control: torch.Tensor,
            delta: float,
        ) -> torch.Tensor:
            base = residual_vector(candidate_control, observations, frozen)
            trajectory = _analysis_trajectory(candidate_control, frozen)
            prediction = echo_to_dbz(
                trajectory.frames_linear,
                min_dbz=config.min_dbz,
            )
            censor_error = (
                frozen.analysis_config.censor_temperature_dbz
                * torch.nn.functional.softplus(
                    (
                        prediction
                        - frozen.analysis_config.detection_limit_dbz
                        - delta * censor_mask
                    )
                    / frozen.analysis_config.censor_temperature_dbz
                )
            )
            observation_block = torch.where(
                censor_mask,
                base_scale * censor_error,
                base[:observation_count].reshape_as(observations.dbz),
            )
            return torch.cat(
                (observation_block.reshape(-1), base[observation_count:])
            )

        weight_flat_index = int(
            torch.argmax(
                self.fso.observation.observation_weight.maps[0, 0].abs()
            )
        )
        weight_index = torch.unravel_index(
            torch.tensor(weight_flat_index),
            observations.dbz.shape,
        )
        weight_mask = torch.zeros_like(observations.dbz)
        weight_mask[weight_index] = 1.0

        def weight_residual(
            candidate_control: torch.Tensor,
            delta: float,
        ) -> torch.Tensor:
            base = residual_vector(candidate_control, observations, frozen)
            observation_block = base[:observation_count].reshape_as(
                observations.dbz
            ) * torch.sqrt(1.0 + delta * weight_mask)
            return torch.cat(
                (observation_block.reshape(-1), base[observation_count:])
            )

        delta = 1.0e-3
        censor_difference = (
            score(solve(censor_residual, delta))
            - score(solve(censor_residual, -delta))
        ) / (2.0 * delta)
        weight_difference = (
            score(solve(weight_residual, delta))
            - score(solve(weight_residual, -delta))
        ) / (2.0 * delta)
        torch.testing.assert_close(
            censor_difference,
            self.fso.observation.censor_threshold_dbz.maps[0, 0][
                censor_index
            ],
            # The production inverse is Gauss--Newton while this independent
            # re-solve uses the exact nonlinear least-squares curvature.
            rtol=1.2e-1,
            atol=1.0e-8,
        )
        torch.testing.assert_close(
            weight_difference,
            self.fso.observation.observation_weight.maps[0, 0][weight_index],
            rtol=2.5e-1,
            atol=1.0e-8,
        )

    def test_variational_fsoi_requires_and_applies_explicit_perturbation(
        self,
    ) -> None:
        linearization = self.analysis.linearization
        assert linearization is not None
        observations = linearization.observations
        detected = torch.zeros_like(observations.dbz)
        censor_threshold = torch.zeros_like(observations.dbz)
        observation_weight = torch.zeros_like(observations.dbz)
        initial_background = torch.zeros_like(observations.dbz)
        baseline_dynamics = torch.zeros_like(observations.dbz)
        detected_index = tuple(
            int(value)
            for value in torch.nonzero(
                observations.detected_mask,
                as_tuple=False,
            )[0]
        )
        censored_index = tuple(
            int(value)
            for value in torch.nonzero(
                observations.censored_mask,
                as_tuple=False,
            )[0]
        )
        detected[detected_index] = 0.25
        censor_threshold[censored_index] = -0.5
        observation_weight[censored_index] = -0.1
        first_frame_index = (
            0,
            *tuple(
                int(value)
                for value in torch.nonzero(
                    observations.valid_mask[0],
                    as_tuple=False,
                )[0]
            ),
        )
        initial_background[first_frame_index] = 0.125
        baseline_dynamics[detected_index] = -0.125
        perturbation = VariationalObservationPerturbation(
            detected_dbz=detected,
            censor_threshold_dbz=censor_threshold,
            observation_weight=observation_weight,
            initial_background_dbz=initial_background,
            baseline_dynamics_dbz=baseline_dynamics,
        )

        fsoi = compute_variational_fsoi(
            self.forecast,
            self.analysis,
            self.verification,
            perturbation,
            sensitivity_config=self.sensitivity_config,
        )

        self.assertEqual(
            fsoi.contract,
            EXPLORATORY_VARIATIONAL_FSOI_CONTRACT,
        )
        self.assertEqual(
            fsoi.perturbation_contract,
            "p1-observation-perturbation-v7",
        )
        self.assertEqual(fsoi.perturbation_digest, perturbation.digest)
        self.assertEqual(
            fsoi.perturbation_diagnostics.perturbed_pixel_count,
            2,
        )
        self.assertGreater(fsoi.perturbation_diagnostics.whitened_l2, 0.0)
        torch.testing.assert_close(
            fsoi.fso.observation.detected_dbz.maps,
            self.fso.observation.detected_dbz.maps,
        )
        expected_components = (
            self.fso.observation.detected_dbz.maps[0, 0] * detected,
            self.fso.observation.censor_threshold_dbz.maps[0, 0]
            * censor_threshold,
            self.fso.observation.observation_weight.maps[0, 0]
            * observation_weight,
            self.fso.observation.initial_background_dbz.maps[0, 0]
            * initial_background,
            self.fso.observation.baseline_dynamics_dbz.maps[0, 0]
            * baseline_dynamics,
        )
        actual_components = (
            fsoi.observation.detected_dbz.maps[0, 0],
            fsoi.observation.censor_threshold_dbz.maps[0, 0],
            fsoi.observation.observation_weight.maps[0, 0],
            fsoi.observation.initial_background_dbz.maps[0, 0],
            fsoi.observation.baseline_dynamics_dbz.maps[0, 0],
        )
        for actual, expected in zip(
            actual_components,
            expected_components,
            strict=True,
        ):
            torch.testing.assert_close(actual, expected)
        expected_total = sum(
            expected_components,
            torch.zeros_like(expected_components[0]),
        )
        torch.testing.assert_close(
            fsoi.observation.total.maps[0, 0],
            expected_total,
        )
        torch.testing.assert_close(
            fsoi.observation.total.sum_by_time[0, 0],
            expected_total.reshape(3, -1).sum(dim=1),
        )
        torch.testing.assert_close(
            fsoi.observation.total.tile_sum_by_time,
            fsoi.observation.detected_dbz.tile_sum_by_time
            + fsoi.observation.censor_threshold_dbz.tile_sum_by_time
            + fsoi.observation.observation_weight.tile_sum_by_time
            + fsoi.observation.initial_background_dbz.tile_sum_by_time
            + fsoi.observation.baseline_dynamics_dbz.tile_sum_by_time,
        )
        self.assertIn(
            fsoi.baseline_dynamics_branch_status,
            ("unknown", "invalid"),
        )
        self.assertEqual(
            fsoi.observation.trusted_total is not None,
            fsoi.baseline_dynamics_branch_status == "certified",
        )
        validate_variational_fsoi(fsoi)
        self.assertNotEqual(fsoi.variational_fsoi_digest, "")

        changed = replace(
            perturbation,
            detected_dbz=2.0 * perturbation.detected_dbz,
        )
        self.assertNotEqual(perturbation.digest, changed.digest)

    def test_variational_fsoi_rejects_invalid_perturbation_contracts(
        self,
    ) -> None:
        linearization = self.analysis.linearization
        assert linearization is not None
        observations = linearization.observations
        zeros = torch.zeros_like(observations.dbz)
        invalid_detected = zeros.clone()
        censored_index = tuple(
            int(value)
            for value in torch.nonzero(
                observations.censored_mask,
                as_tuple=False,
            )[0]
        )
        invalid_detected[censored_index] = 1.0
        invalid = VariationalObservationPerturbation(
            detected_dbz=invalid_detected,
            censor_threshold_dbz=zeros,
            observation_weight=zeros,
        )
        with self.assertRaisesRegex(ValueError, "outside its active mask"):
            compute_variational_fsoi(
                self.forecast,
                self.analysis,
                self.verification,
                invalid,
                sensitivity_config=self.sensitivity_config,
            )

        invalid_weight = zeros.clone()
        invalid_weight[censored_index] = -1.0
        invalid = replace(
            invalid,
            detected_dbz=zeros,
            observation_weight=invalid_weight,
        )
        with self.assertRaisesRegex(ValueError, "local first-order limit"):
            compute_variational_fsoi(
                self.forecast,
                self.analysis,
                self.verification,
                invalid,
                sensitivity_config=self.sensitivity_config,
            )

        detected_index = tuple(
            int(value)
            for value in torch.nonzero(
                observations.detected_mask,
                as_tuple=False,
            )[0]
        )
        large_detected = zeros.clone()
        large_detected[detected_index] = 0.51
        invalid = replace(
            invalid,
            detected_dbz=large_detected,
            observation_weight=zeros,
        )
        with self.assertRaisesRegex(ValueError, "local first-order limit"):
            compute_variational_fsoi(
                self.forecast,
                self.analysis,
                self.verification,
                invalid,
                sensitivity_config=self.sensitivity_config,
            )

        invalid_background = zeros.clone()
        later_valid_index = tuple(
            int(value)
            for value in torch.nonzero(
                observations.valid_mask[1],
                as_tuple=False,
            )[0]
        )
        invalid_background[(1, *later_valid_index)] = 1.0
        with self.assertRaisesRegex(
            ValueError,
            "accepted first-frame observations",
        ):
            compute_variational_fsoi(
                self.forecast,
                self.analysis,
                self.verification,
                replace(
                    invalid,
                    detected_dbz=zeros,
                    observation_weight=zeros,
                    initial_background_dbz=invalid_background,
                ),
                sensitivity_config=self.sensitivity_config,
            )
        with self.assertRaisesRegex(
            ValueError,
            "baseline_dynamics_dbz perturbation shape mismatch",
        ):
            compute_variational_fsoi(
                self.forecast,
                self.analysis,
                self.verification,
                replace(
                    invalid,
                    detected_dbz=zeros,
                    observation_weight=zeros,
                    initial_background_dbz=None,
                    baseline_dynamics_dbz=zeros[:, :-1],
                ),
                sensitivity_config=self.sensitivity_config,
            )

    def test_variational_fsoi_enforces_global_trust_radius(self) -> None:
        linearization = self.analysis.linearization
        assert linearization is not None
        observations = linearization.observations
        zeros = torch.zeros_like(observations.dbz)
        dense = torch.where(
            observations.detected_mask,
            torch.full_like(zeros, 0.1),
            zeros,
        )
        perturbation = VariationalObservationPerturbation(
            detected_dbz=dense,
            censor_threshold_dbz=zeros,
            observation_weight=zeros,
        )
        with self.assertRaisesRegex(ValueError, "area fraction"):
            compute_variational_fsoi(
                self.forecast,
                self.analysis,
                self.verification,
                perturbation,
                sensitivity_config=self.sensitivity_config,
                adjoint_config=VariationalAdjointConfig(
                    maximum_perturbed_fraction=0.01,
                ),
            )

        sparse = torch.zeros_like(zeros)
        index = tuple(
            int(value)
            for value in torch.nonzero(
                observations.detected_mask,
                as_tuple=False,
            )[0]
        )
        sparse[index] = 0.25
        perturbation = replace(perturbation, detected_dbz=sparse)
        with self.assertRaisesRegex(ValueError, "whitened trust radius"):
            compute_variational_fsoi(
                self.forecast,
                self.analysis,
                self.verification,
                perturbation,
                sensitivity_config=self.sensitivity_config,
                adjoint_config=VariationalAdjointConfig(
                    maximum_whitened_perturbation_l2=0.01,
                ),
            )
        with self.assertRaisesRegex(ValueError, "requires a grid contract"):
            compute_variational_fsoi(
                self.forecast,
                self.analysis,
                self.verification,
                perturbation,
                sensitivity_config=self.sensitivity_config,
                adjoint_config=VariationalAdjointConfig(
                    maximum_perturbed_area_km2=1.0,
                ),
            )

    def test_variational_fsoi_rejects_directional_classification_change(
        self,
    ) -> None:
        linearization = self.analysis.linearization
        assert linearization is not None
        observations = linearization.observations
        zeros = torch.zeros_like(observations.dbz)
        censored_values = torch.where(
            observations.censored_mask,
            observations.dbz,
            observations.dbz.new_full((), -math.inf),
        )
        flat_index = int(torch.argmax(censored_values))
        index = torch.unravel_index(
            torch.tensor(flat_index),
            observations.dbz.shape,
        )
        threshold_delta = zeros.clone()
        threshold_delta[index] = -0.5
        perturbation = VariationalObservationPerturbation(
            detected_dbz=zeros,
            censor_threshold_dbz=threshold_delta,
            observation_weight=zeros,
        )
        with self.assertRaisesRegex(ValueError, "detected/censored branch"):
            compute_variational_fsoi(
                self.forecast,
                self.analysis,
                self.verification,
                perturbation,
                sensitivity_config=self.sensitivity_config,
            )

    def test_baseline_branch_signature_covers_pair_and_peak_identity(
        self,
    ) -> None:
        linearization = self.analysis.linearization
        assert linearization is not None
        signature = _p0_tendency_branch_signature(
            linearization.observations.dbz,
            linearization.frozen,
        )

        self.assertEqual(signature.pair_spans, ((0, 1), (1, 2), (0, 2)))
        self.assertEqual(len(signature.pair_available_by_span), 3)
        self.assertEqual(len(signature.growth_evidence_available_by_span), 3)
        self.assertEqual(len(signature.integer_peak_yx_by_pair), 3)
        self.assertEqual(len(signature.peak_is_search_interior_by_pair), 3)
        self.assertIsInstance(signature.motion_pair_spans, tuple)
        self.assertIsInstance(signature.growth_pair_spans, tuple)
        self.assertEqual(len(signature.motion_remap_cells), 2)

    def test_baseline_branch_validation_checks_half_perturbation(self) -> None:
        linearization = self.analysis.linearization
        assert linearization is not None
        unchanged = _p0_tendency_branch_signature(
            linearization.observations.dbz,
            linearization.frozen,
        )
        changed = replace(
            unchanged,
            motion_conflict=not unchanged.motion_conflict,
        )
        with patch(
            "advar.sensitivity._p0_tendency_branch_signature",
            side_effect=(unchanged, changed),
        ) as signature:
            delta = torch.where(
                linearization.observations.detected_mask,
                torch.full_like(linearization.observations.dbz, 0.1),
                torch.zeros_like(linearization.observations.dbz),
            )
            stable = _baseline_branch_is_stable(
                linearization.observations,
                linearization.frozen,
                delta,
            )

        self.assertFalse(stable)
        self.assertEqual(signature.call_count, 2)

    def test_physical_radar_perturbation_factory_connects_input_paths(
        self,
    ) -> None:
        linearization = self.analysis.linearization
        assert linearization is not None
        observations = linearization.observations
        delta = torch.zeros_like(observations.dbz)
        index = tuple(
            int(value)
            for value in torch.nonzero(
                observations.detected_mask[0],
                as_tuple=False,
            )[0]
        )
        full_index = (0, *index)
        delta[full_index] = 0.1
        perturbation = VariationalObservationPerturbation.from_radar_dbz_delta(
            delta,
            linearization,
        )
        self.assertEqual(
            perturbation.perturbation_semantics,
            "physical_radar_value",
        )
        self.assertEqual(float(perturbation.detected_dbz[full_index]), 0.1)
        assert perturbation.initial_background_dbz is not None
        self.assertEqual(
            float(perturbation.initial_background_dbz[full_index]),
            0.1,
        )
        fsoi = compute_variational_fsoi(
            self.forecast,
            self.analysis,
            self.verification,
            perturbation,
            sensitivity_config=self.sensitivity_config,
        )
        self.assertEqual(
            fsoi.perturbation_diagnostics.perturbed_pixel_count,
            1,
        )
        self.assertEqual(
            fsoi.baseline_dynamics_branch_status,
            "unknown",
        )
        self.assertIsNotNone(
            fsoi.perturbation_diagnostics
            .baseline_dynamics_branch_signature_digest
        )
        self.assertIsNone(
            fsoi.observation.baseline_branch_trusted_total
        )
        crossing = torch.zeros_like(observations.dbz)
        crossing[full_index] = (
            linearization.frozen.nowcast_config.max_dbz
            - observations.dbz[full_index]
            + 0.1
        )
        with self.assertRaisesRegex(ValueError, "crosses input clamp"):
            VariationalObservationPerturbation.from_radar_dbz_delta(
                crossing,
                linearization,
            )

    def test_learning_policy_is_external_and_requires_physical_input(
        self,
    ) -> None:
        linearization = self.analysis.linearization
        assert linearization is not None
        observations = linearization.observations
        zeros = torch.zeros_like(observations.dbz)
        policy = AutomatedLearningPolicy(
            sensitivity_config=SensitivityConfig.for_automated_learning(
                radar_product_digest="1" * 64,
                qc_pipeline_digest="2" * 64,
            ),
            adjoint_config=(
                VariationalAdjointConfig.for_automated_learning()
            ),
            algorithm_bundle_digest=linearization.algorithm_bundle_digest,
            numerical_runtime_digest=linearization.numerical_runtime_digest,
        )
        for invalid_ratio in (0.0, 1.0, float("nan"), True):
            with self.subTest(linearity_relative_error=invalid_ratio):
                with self.assertRaisesRegex(ValueError, "must be in"):
                    replace(
                        policy,
                        maximum_linearity_relative_error=invalid_ratio,
                    )
        for invalid_value in (-1.0, float("nan"), True):
            with self.subTest(linearity_absolute_error=invalid_value):
                with self.assertRaisesRegex(ValueError, "nonnegative"):
                    replace(
                        policy,
                        metric_taylor_thresholds=(
                            MetricTaylorThreshold(
                                "log_echo_mse",
                                invalid_value,
                                1.0e-6,
                            ),
                        ),
                    )
        for invalid_value in (0.0, float("nan"), True):
            with self.subTest(material_impact_threshold=invalid_value):
                with self.assertRaisesRegex(ValueError, "positive"):
                    replace(
                        policy,
                        metric_taylor_thresholds=(
                            MetricTaylorThreshold(
                                "log_echo_mse",
                                1.0e-6,
                                invalid_value,
                            ),
                        ),
                    )
        available = torch.ones((1, 1), dtype=torch.bool)
        prediction = torch.tensor(((1.0e-3,),), dtype=torch.float64)
        self.assertTrue(
            sensitivity_module._taylor_step_is_valid(
                prediction,
                prediction,
                available,
                policy,
            )
        )
        self.assertFalse(
            sensitivity_module._taylor_step_is_valid(
                0.5 * prediction,
                0.2 * prediction,
                available,
                policy,
            )
        )
        self.assertFalse(
            sensitivity_module._material_impact_signs_are_consistent(
                ((prediction, -prediction),),
                available,
                ("log_echo_mse",),
                policy,
            )
        )
        self.assertEqual(
            policy.threshold_for("centroid_error_m2").maximum_absolute_error,
            1.0,
        )
        self.assertEqual(
            sensitivity_module._material_impact_summary(
                ((torch.zeros_like(prediction), torch.zeros_like(prediction)),),
                available,
                ("log_echo_mse",),
                policy,
            ),
            (0, 0.0, 0.0),
        )
        physical_delta = zeros.clone()
        index = tuple(
            int(value)
            for value in torch.nonzero(
                observations.detected_mask,
                as_tuple=False,
            )[0]
        )
        physical_delta[index] = 0.1
        physical = VariationalObservationPerturbation.from_radar_dbz_delta(
            physical_delta,
            linearization,
        )
        with self.assertRaisesRegex(TypeError, "approved_policy_digests"):
            compute_variational_fsoi_for_learning(
                self.forecast,
                self.analysis,
                self.verification,
                physical,
                policy=policy,
                policy_trust_store_path="/etc/advar/learning-policies.json",
                approved_policy_digests=frozenset((policy.digest,)),  # pyright: ignore[reportCallIssue]
            )
        with patch.object(
            sensitivity_module,
            "_load_learning_policy_trust_store",
            return_value=sensitivity_module._LearningPolicyTrustStore(
                approved_policy_digests=frozenset(),
                content_digest="7" * 64,
            ),
        ):
            rejected = compute_variational_fsoi_for_learning(
                self.forecast,
                self.analysis,
                self.verification,
                physical,
                policy=policy,
                policy_trust_store_path="/etc/advar/learning-policies.json",
            )
        self.assertFalse(rejected.eligibility.eligible)
        self.assertEqual(
            rejected.eligibility.reasons,
            ("unapproved_learning_policy",),
        )

        augmented = VariationalObservationPerturbation(
            detected_dbz=zeros,
            censor_threshold_dbz=zeros,
            observation_weight=zeros,
        )
        with patch.object(
            sensitivity_module,
            "_load_learning_policy_trust_store",
            return_value=sensitivity_module._LearningPolicyTrustStore(
                approved_policy_digests=frozenset((policy.digest,)),
                content_digest="7" * 64,
            ),
        ):
            rejected = compute_variational_fsoi_for_learning(
                self.forecast,
                self.analysis,
                self.verification,
                augmented,
                policy=policy,
                policy_trust_store_path="/etc/advar/learning-policies.json",
            )
        self.assertFalse(rejected.eligibility.eligible)
        self.assertEqual(
            rejected.eligibility.reasons,
            ("physical_radar_perturbation_required",),
        )

        wrong_algorithm = replace(
            policy,
            algorithm_bundle_digest="3" * 64,
        )
        with patch.object(
            sensitivity_module,
            "_load_learning_policy_trust_store",
            return_value=sensitivity_module._LearningPolicyTrustStore(
                approved_policy_digests=frozenset((wrong_algorithm.digest,)),
                content_digest="7" * 64,
            ),
        ):
            rejected = compute_variational_fsoi_for_learning(
                self.forecast,
                self.analysis,
                self.verification,
                physical,
                policy=wrong_algorithm,
                policy_trust_store_path="/etc/advar/learning-policies.json",
            )
        self.assertEqual(
            rejected.eligibility.reasons,
            ("algorithm_bundle_not_approved",),
        )

    @patch(
        "advar.sensitivity._baseline_dynamics_branch_certification",
        return_value=("certified", "8" * 64),
    )
    def test_approved_learning_policy_with_supplied_branch_certificate(
        self, _branch_certificate,
    ) -> None:
        # Exercise downstream approval/linearity contracts with an explicit
        # certificate fixture; finite P0 samples cannot supply that proof.
        grid = RadarGridTimeContract(
            valid_times=(
                "2026-08-05T00:00:00Z",
                "2026-08-05T00:10:00Z",
                "2026-08-05T00:20:00Z",
            ),
            dx_m=1000.0,
            dy_m=1000.0,
            projection="EPSG:5179",
            grid_hash="4" * 64,
            spatial_grid_contract="radar-spatial-grid-identity-v6",
            grid_shape_yx=tuple(self.frames.shape[-2:]),
            projected_crs_digest=radar_projected_crs_semantic_digest(
                "EPSG:5179"
            ),
            metric_domain_digest=CURRENT_RADAR_METRIC_DOMAIN.digest,
            metric_domain_evidence_digest=(
                CURRENT_RADAR_METRIC_DOMAIN_EVIDENCE.digest
            ),
            cell_center_origin_xy_m=(1_000_000.0, 2_000_000.0),
            grid_coordinate_dtype=RADAR_PROJECTED_GRID_COORDINATE_DTYPE,
            cell_center_convention=(
                RADAR_PROJECTED_GRID_CELL_CENTER_CONVENTION
            ),
        )
        forecast, analysis = variational_nowcast(
            self.frames,
            nowcast_config=self.nowcast_config,
            analysis_config=self.analysis_config,
            grid_time_contract=grid,
        )
        linearization = analysis.linearization
        assert linearization is not None
        verification_frames = torch.where(
            torch.isfinite(forecast.forecast_dbz),
            forecast.forecast_dbz - 0.5,
            forecast.forecast_dbz,
        )
        verification = _current_verification_bundle(
            verification_frames,
            valid_times=("2026-08-05T00:30:00Z",),
            grid_time_contract=grid,
        )
        policy = AutomatedLearningPolicy(
            sensitivity_config=replace(
                SensitivityConfig.for_automated_learning(
                    radar_product_digest="5" * 64,
                    qc_pipeline_digest="6" * 64,
                ),
                metric_names=("log_echo_mse",),
                full_map_lead_minutes=(10,),
                tile_size=4,
            ),
            adjoint_config=(
                replace(
                    VariationalAdjointConfig.for_automated_learning(),
                    lead_minutes=(10,),
                )
            ),
            algorithm_bundle_digest=linearization.algorithm_bundle_digest,
            numerical_runtime_digest=linearization.numerical_runtime_digest,
            ranking_objective="absolute_influence",
            metric_taylor_thresholds=(
                MetricTaylorThreshold(
                    "log_echo_mse",
                    1.0e-6,
                    1.0e-8,
                ),
            ),
        )
        delta = torch.zeros_like(linearization.observations.dbz)
        index = tuple(
            int(value)
            for value in torch.nonzero(
                linearization.observations.detected_mask,
                as_tuple=False,
            )[0]
        )
        nonlinear_delta = torch.zeros_like(linearization.observations.dbz)
        nonlinear_delta[index] = 0.01
        with patch.object(
            sensitivity_module,
            "_load_learning_policy_trust_store",
            return_value=sensitivity_module._LearningPolicyTrustStore(
                approved_policy_digests=frozenset((policy.digest,)),
                content_digest="7" * 64,
            ),
        ):
            nonlinear = compute_variational_fsoi_for_learning(
                forecast,
                analysis,
                verification,
                VariationalObservationPerturbation.from_radar_dbz_delta(
                    nonlinear_delta,
                    linearization,
                ),
                policy=policy,
                policy_trust_store_path=(
                    "/etc/advar/learning-policies.json"
                ),
            )
        self.assertFalse(nonlinear.eligibility.eligible)
        self.assertEqual(
            nonlinear.eligibility.reasons,
            ("first_order_validation_failed",),
        )
        assert nonlinear.first_order_validation is not None
        self.assertFalse(nonlinear.first_order_validation.first_order_valid)

        delta[index] = 5.0e-6
        perturbation = VariationalObservationPerturbation.from_radar_dbz_delta(
            delta,
            linearization,
        )
        resolved_change = (
            nonlinear.first_order_validation
            .full_step_resolved_metric_change
        )
        certified_validation = replace(
            nonlinear.first_order_validation,
            full_step_prediction=resolved_change,
            full_step_absolute_error=torch.zeros_like(resolved_change),
            half_step_prediction=0.5 * resolved_change,
            half_step_resolved_metric_change=0.5 * resolved_change,
            half_step_absolute_error=torch.zeros_like(resolved_change),
            full_step_valid=True,
            half_step_valid=True,
            sign_consistent_for_material_impacts=True,
            material_metric_count=1,
            maximum_material_impact=float(torch.amax(torch.abs(resolved_change))),
            aggregate_material_impact_norm=float(
                torch.linalg.vector_norm(resolved_change)
            ),
            first_order_valid=True,
        )

        def certified_for_fsoi(*args, **_kwargs):
            resolved_fsoi = args[3]
            return replace(
                certified_validation,
                source_fsoi_digest=resolved_fsoi.variational_fsoi_digest,
                nominal_forecast_digest=args[0].forecast_run_digest,
                nominal_input_bundle_digest=args[0].run.input_bundle_digest,
            )

        with (
            patch.object(
                sensitivity_module,
                "_load_learning_policy_trust_store",
                return_value=sensitivity_module._LearningPolicyTrustStore(
                    approved_policy_digests=frozenset((policy.digest,)),
                    content_digest="7" * 64,
                ),
            ),
            patch.object(
                sensitivity_module,
                "_validate_first_order_learning_impact",
                side_effect=certified_for_fsoi,
            ),
        ):
            learning = compute_variational_fsoi_for_learning(
                forecast,
                analysis,
                verification,
                perturbation,
                policy=policy,
                policy_trust_store_path=(
                    "/etc/advar/learning-policies.json"
                ),
            )

        self.assertTrue(
            learning.eligibility.eligible,
            (
                learning.eligibility.reasons,
                learning.first_order_validation,
            ),
        )
        self.assertEqual(learning.eligibility.reasons, ())
        assert learning.fsoi is not None
        assert learning.first_order_validation is not None
        self.assertEqual(
            learning.fsoi.contract,
            CURRENT_VARIATIONAL_FSOI_CONTRACT,
        )
        self.assertEqual(
            learning.fsoi.fso.contract,
            CURRENT_VARIATIONAL_FSO_CONTRACT,
        )
        self.assertTrue(learning.first_order_validation.first_order_valid)
        self.assertTrue(
            learning.first_order_validation
            .full_step_resolved_analysis_converged
        )
        self.assertTrue(
            learning.first_order_validation
            .half_step_resolved_analysis_converged
        )
        self.assertTrue(learning.first_order_validation.full_step_valid)
        self.assertTrue(learning.first_order_validation.half_step_valid)
        self.assertTrue(
            learning.first_order_validation
            .sign_consistent_for_material_impacts
        )
        self.assertEqual(
            learning.first_order_validation.metric_domain_contract,
            "frozen_metric_domain",
        )
        self.assertTrue(learning.first_order_validation.active_branch_valid)
        self.assertEqual(
            learning.fsoi.baseline_dynamics_branch_status,
            "certified",
        )
        self.assertEqual(
            learning.fsoi.perturbation_diagnostics.perturbed_area_km2,
            1.0,
        )
        self.assertEqual(learning.fsoi.fso.tile_size, 16)
        self.assertIsNotNone(learning.frozen_domain_learning_impact)
        assert learning.approval_evidence is not None
        self.assertEqual(
            learning.approval_evidence.trust_store_digest,
            "7" * 64,
        )
        validate_variational_learning_impact(
            learning,
            expected_trust_store_digest="7" * 64,
        )
        ranking_fso = compute_variational_fso(
            forecast,
            analysis,
            verification,
            sensitivity_config=policy.sensitivity_config,
            adjoint_config=policy.ranking_adjoint_config,
        )
        ranking = score_candidate_perturbations(
            ranking_fso,
            analysis,
            (("current-v11-candidate", perturbation),),
            policy=policy,
        )
        self.assertEqual(
            ranking.fso.contract,
            CURRENT_VARIATIONAL_FSO_CONTRACT,
        )
        issuance_validation = validate_variational_fsoi_issuance_impact(
            forecast,
            analysis,
            verification,
            learning.fsoi,
            policy=policy,
        )
        execution_policy = InterventionExecutionPolicy(
                metric_guardrails=tuple(
                    InterventionMetricGuardrail(
                        name,
                        scale=1.0,
                        maximum_predicted_harm=1.0e20,
                        maximum_resolved_harm=1.0e20,
                    )
                    for name in learning.fsoi.fso.metric_names
                ),
                allowed_intervention_types=("realized_sensor_correction",),
            )
        with patch(
            "advar.intervention._load_learning_policy_trust_store",
            return_value=sensitivity_module._LearningPolicyTrustStore(
                approved_policy_digests=frozenset((execution_policy.digest,)),
                content_digest="9" * 64,
            ),
        ):
            realized = RealizedObservationIntervention.from_learning_result(
                learning,
                analysis,
                intervention_id="radar-correction-20260808-001",
                intervention_type="realized_sensor_correction",
                action_digest="8" * 64,
                applied_time=forecast.run.grid_time_contract.valid_times[-1],
                actual_input_before=linearization.frozen.input_frames_dbz,
                actual_input_after=(
                    linearization.frozen.input_frames_dbz + delta
                ),
                nominal_forecast=forecast,
                case_id="learning-case",
                radar_id="learning-radar",
                resolved_issuance_validation=issuance_validation,
                execution_policy=execution_policy,
                execution_policy_trust_store_path=(
                    "/etc/advar/intervention-policies.json"
                ),
            )
        harmful_issuance = replace(
            issuance_validation,
            full_step_resolved_metric_change=torch.ones_like(
                issuance_validation.full_step_resolved_metric_change
            ),
            frozen_domain_state_effect=torch.zeros_like(
                issuance_validation.full_step_resolved_metric_change
            ),
            issuance_policy_effect=torch.ones_like(
                issuance_validation.full_step_resolved_metric_change
            ),
            end_to_end_issuance_effect=torch.ones_like(
                issuance_validation.full_step_resolved_metric_change
            ),
            first_order_valid=True,
            full_step_resolved_analysis_converged=True,
            half_step_resolved_analysis_converged=True,
            active_branch_valid=True,
        )
        harmful_policy = replace(
            execution_policy,
            approval_class="automation",
            metric_guardrails=tuple(
                replace(item, maximum_resolved_harm=0.01)
                for item in execution_policy.metric_guardrails
            ),
        )
        with patch(
            "advar.intervention._load_learning_policy_trust_store",
            return_value=sensitivity_module._LearningPolicyTrustStore(
                approved_policy_digests=frozenset((harmful_policy.digest,)),
                content_digest="9" * 64,
            ),
        ), self.assertRaisesRegex(ValueError, "resolved intervention harm"):
            RealizedObservationIntervention.from_learning_result(
                learning,
                analysis,
                intervention_id="resolved-harm",
                intervention_type="realized_sensor_correction",
                action_digest="8" * 64,
                applied_time=forecast.run.grid_time_contract.valid_times[-1],
                actual_input_before=linearization.frozen.input_frames_dbz,
                actual_input_after=linearization.frozen.input_frames_dbz + delta,
                nominal_forecast=forecast,
                case_id="learning-case",
                radar_id="learning-radar",
                resolved_issuance_validation=harmful_issuance,
                execution_policy=harmful_policy,
                execution_policy_trust_store_path=(
                    "/etc/advar/intervention-policies.json"
                ),
            )
        validate_realized_observation_intervention(realized)
        self.assertEqual(
            realized.applied_time,
            forecast.run.grid_time_contract.valid_times[-1],
        )
        self.assertEqual(
            realized.learning_result_digest,
            learning.learning_result_digest,
        )
        self.assertEqual(
            issuance_validation.metric_domain_contract,
            "resolved_issuance_domain",
        )
        self.assertIsNotNone(
            issuance_validation.full_step_forecast_digest
        )
        self.assertIsNotNone(issuance_validation.frozen_domain_state_effect)
        self.assertIsNotNone(issuance_validation.issuance_policy_effect)
        self.assertIsNotNone(issuance_validation.end_to_end_issuance_effect)
        assert issuance_validation.frozen_domain_state_effect is not None
        assert issuance_validation.issuance_policy_effect is not None
        assert issuance_validation.end_to_end_issuance_effect is not None
        torch.testing.assert_close(
            issuance_validation.frozen_domain_state_effect
            + issuance_validation.issuance_policy_effect,
            issuance_validation.end_to_end_issuance_effect,
            rtol=0.0,
            atol=0.0,
            equal_nan=True,
        )
        for value in (
            issuance_validation.coverage_before,
            issuance_validation.coverage_after,
            issuance_validation.newly_issued_fraction,
            issuance_validation.withdrawn_fraction,
        ):
            self.assertIsNotNone(value)
        assert issuance_validation.coverage_before is not None
        unrelated_issuance = replace(
            issuance_validation,
            source_fsoi_digest="f" * 64,
        )
        with patch(
            "advar.intervention._load_learning_policy_trust_store",
            return_value=sensitivity_module._LearningPolicyTrustStore(
                approved_policy_digests=frozenset((execution_policy.digest,)),
                content_digest="9" * 64,
            ),
        ), self.assertRaisesRegex(ValueError, "lineage mismatch"):
            RealizedObservationIntervention.from_learning_result(
                learning,
                analysis,
                intervention_id="unrelated-validation",
                intervention_type="realized_sensor_correction",
                action_digest="8" * 64,
                applied_time=forecast.run.grid_time_contract.valid_times[-1],
                actual_input_before=linearization.frozen.input_frames_dbz,
                actual_input_after=(
                    linearization.frozen.input_frames_dbz + delta
                ),
                nominal_forecast=forecast,
                case_id="learning-case",
                radar_id="learning-radar",
                resolved_issuance_validation=unrelated_issuance,
                execution_policy=execution_policy,
                execution_policy_trust_store_path=(
                    "/etc/advar/intervention-policies.json"
                ),
            )
        unsafe_issuance = replace(
            issuance_validation,
            coverage_after=0.5 * issuance_validation.coverage_before,
            first_order_valid=True,
            full_step_resolved_analysis_converged=True,
            half_step_resolved_analysis_converged=True,
            active_branch_valid=True,
        )
        automation_policy = replace(
            execution_policy,
            approval_class="automation",
            minimum_coverage_retention=0.9,
        )
        with patch(
            "advar.intervention._load_learning_policy_trust_store",
            return_value=sensitivity_module._LearningPolicyTrustStore(
                approved_policy_digests=frozenset((automation_policy.digest,)),
                content_digest="9" * 64,
            ),
        ), self.assertRaisesRegex(ValueError, "excessive coverage"):
            RealizedObservationIntervention.from_learning_result(
                learning,
                analysis,
                intervention_id="unsafe-automation",
                intervention_type="realized_sensor_correction",
                action_digest="8" * 64,
                applied_time=forecast.run.grid_time_contract.valid_times[-1],
                actual_input_before=linearization.frozen.input_frames_dbz,
                actual_input_after=(
                    linearization.frozen.input_frames_dbz + delta
                ),
                nominal_forecast=forecast,
                case_id="learning-case",
                radar_id="learning-radar",
                resolved_issuance_validation=unsafe_issuance,
                execution_policy=automation_policy,
                execution_policy_trust_store_path=(
                    "/etc/advar/intervention-policies.json"
                ),
            )
        weaker_delta = 0.5 * delta
        candidates = (
            ("stronger", perturbation),
            (
                "weaker",
                VariationalObservationPerturbation.from_radar_dbz_delta(
                    weaker_delta,
                    linearization,
                ),
            ),
        )
        ranking_fso = compute_variational_fso(
            forecast,
            analysis,
            verification,
            sensitivity_config=policy.sensitivity_config,
            adjoint_config=policy.ranking_adjoint_config,
        )
        ranking = score_candidate_perturbations(
            ranking_fso,
            analysis,
            candidates,
            policy=policy,
        )
        self.assertEqual(
            tuple(score.candidate_id for score in ranking.scores),
            ("stronger", "weaker"),
        )
        self.assertIsInstance(
            ranking.scores[0].perturbation,
            SparseRadarPerturbation,
        )
        invalid_delta = 1_000_000.0 * delta
        screened = score_candidate_perturbations(
            ranking_fso,
            analysis,
            (
                (
                    "invalid-high-score",
                    SparseRadarPerturbation.from_dense(invalid_delta),
                ),
                ("valid", perturbation),
            ),
            policy=policy,
        )
        self.assertEqual(
            tuple(score.candidate_id for score in screened.scores),
            ("valid",),
        )
        self.assertFalse(screened.prechecks[0].admissible)
        stream_policy = replace(
            policy,
            maximum_learning_candidates_to_validate=2,
            maximum_total_robust_resolves=4,
        )
        streamed = score_candidate_perturbations(
            ranking_fso,
            analysis,
            (
                (
                    f"candidate-{index:02d}",
                    SparseRadarPerturbation.from_dense(
                        delta * ((index + 1) / 10.0)
                    ),
                )
                for index in range(10)
            ),
            policy=stream_policy,
        )
        self.assertEqual(streamed.candidate_count, 10)
        self.assertEqual(len(streamed.scores), 2)
        with self.assertRaisesRegex(ValueError, "ranking policy mismatch"):
            validate_top_k_learning_impacts(
                forecast,
                analysis,
                verification,
                ranking,
                policy=replace(
                    policy,
                    maximum_learning_candidates_to_validate=1,
                    maximum_total_robust_resolves=2,
                ),
                policy_trust_store_path=(
                    "/etc/advar/learning-policies.json"
                ),
                maximum_candidates_to_validate=2,
            )
        with (
            patch.object(
                sensitivity_module,
                "_load_learning_policy_trust_store",
                return_value=sensitivity_module._LearningPolicyTrustStore(
                    approved_policy_digests=frozenset((policy.digest,)),
                    content_digest="7" * 64,
                ),
            ),
            patch.object(
                sensitivity_module,
                "_learning_impact_from_fsoi",
                return_value=sensitivity_module._rejected_learning_impact(
                    policy,
                    "test_validation_stub",
                ),
            ) as validate_mock,
            patch.object(
                sensitivity_module,
                "pcg",
                side_effect=AssertionError("adjoint must not be recomputed"),
            ),
        ):
            top = validate_top_k_learning_impacts(
                forecast,
                analysis,
                verification,
                ranking,
                policy=policy,
                policy_trust_store_path=(
                    "/etc/advar/learning-policies.json"
                ),
                maximum_candidates_to_validate=1,
            )
        self.assertEqual(len(top), 1)
        self.assertEqual(validate_mock.call_count, 1)
        validated_fsoi = validate_mock.call_args.args[3]
        torch.testing.assert_close(
            validated_fsoi.observation.total.sum_by_time.sum(dim=-1),
            ranking.scores[0].predicted_metric_change,
        )
        with (
            patch.object(
                sensitivity_module,
                "_load_learning_policy_trust_store",
                return_value=sensitivity_module._LearningPolicyTrustStore(
                    approved_policy_digests=frozenset((policy.digest,)),
                    content_digest="7" * 64,
                ),
            ),
            patch.object(
                sensitivity_module,
                "_validate_first_order_learning_impact",
                side_effect=certified_for_fsoi,
            ),
        ):
            approved_ranked = validate_top_k_learning_impacts(
                forecast,
                analysis,
                verification,
                ranking,
                policy=policy,
                policy_trust_store_path=(
                    "/etc/advar/learning-policies.json"
                ),
                maximum_candidates_to_validate=1,
            )
        self.assertEqual(approved_ranked[0].candidate_id, "stronger")
        ranked_evidence = approved_ranked[0].result.approval_evidence
        assert ranked_evidence is not None
        self.assertEqual(ranked_evidence.selection_mode, "ranked_top_k")
        self.assertEqual(ranked_evidence.candidate_rank, 1)
        self.assertEqual(
            ranked_evidence.ranking_digest,
            ranking.ranking_digest,
        )
        with tempfile.TemporaryDirectory() as temporary:
            ranked_ledger = EpisodeLedger(temporary)
            ranked_digest = ranked_ledger.append_variational_learning_approval(
                approved_ranked[0].result
            )
            stored_ranked = ranked_ledger.load_variational_learning_approval(
                ranked_digest
            )
        self.assertEqual(stored_ranked, ranked_evidence)
        ranking.scores[0].predicted_metric_change.add_(1.0)
        with self.assertRaisesRegex(ValueError, "ranking digest"):
            validate_top_k_learning_impacts(
                forecast,
                analysis,
                verification,
                ranking,
                policy=policy,
                policy_trust_store_path=(
                    "/etc/advar/learning-policies.json"
                ),
                maximum_candidates_to_validate=1,
            )
        with tempfile.TemporaryDirectory() as temporary:
            ledger = EpisodeLedger(temporary)
            stored_digest = ledger.append_variational_learning_approval(
                learning
            )
            stored = ledger.load_variational_learning_approval(stored_digest)
        self.assertEqual(stored, learning.approval_evidence)
        no_material = replace(
            certified_validation,
            material_metric_count=0,
            maximum_material_impact=0.0,
            aggregate_material_impact_norm=0.0,
            first_order_valid=False,
        )

        def no_material_for_fsoi(*args, **kwargs):
            bound = certified_for_fsoi(*args, **kwargs)
            return replace(
                no_material,
                source_fsoi_digest=bound.source_fsoi_digest,
                nominal_forecast_digest=bound.nominal_forecast_digest,
                nominal_input_bundle_digest=bound.nominal_input_bundle_digest,
            )
        with (
            patch.object(
                sensitivity_module,
                "_load_learning_policy_trust_store",
                return_value=sensitivity_module._LearningPolicyTrustStore(
                    approved_policy_digests=frozenset((policy.digest,)),
                    content_digest="7" * 64,
                ),
            ),
            patch.object(
                sensitivity_module,
                "_validate_first_order_learning_impact",
                side_effect=no_material_for_fsoi,
            ),
        ):
            rejected = compute_variational_fsoi_for_learning(
                forecast,
                analysis,
                verification,
                perturbation,
                policy=policy,
                policy_trust_store_path=(
                    "/etc/advar/learning-policies.json"
                ),
            )
        self.assertEqual(
            rejected.eligibility.reasons,
            ("no_material_learning_signal",),
        )
        learning.first_order_validation.full_step_absolute_error.add_(1.0)
        with self.assertRaisesRegex(ValueError, "validation digest"):
            validate_variational_learning_impact(learning)

    def test_learning_policy_trust_store_requires_root_ownership(self) -> None:
        digest = "a" * 64
        document = {
            "contract": "advar-learning-policy-trust-store-v1",
            "approved_policy_digests": [digest],
        }
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "learning-policies.json"
            path.write_text(json.dumps(document), encoding="utf-8")
            real_fstat = os.fstat

            with patch.object(
                sensitivity_module.os,
                "fstat",
                side_effect=lambda descriptor: SimpleNamespace(
                    st_mode=stat.S_IFREG | 0o644,
                    st_uid=1000,
                    st_size=real_fstat(descriptor).st_size,
                ),
            ):
                with self.assertRaisesRegex(ValueError, "root-owned"):
                    sensitivity_module._load_learning_policy_trust_store(
                        path
                    )
            with patch.object(
                sensitivity_module.os,
                "fstat",
                side_effect=lambda descriptor: SimpleNamespace(
                    st_mode=stat.S_IFREG | 0o644,
                    st_uid=0,
                    st_size=real_fstat(descriptor).st_size,
                ),
            ):
                store = (
                    sensitivity_module
                    ._load_learning_policy_trust_store(path)
                )
                self.assertEqual(
                    store.approved_policy_digests,
                    frozenset((digest,)),
                )
                self.assertEqual(len(store.content_digest), 64)

    def test_censored_perturbations_use_event_specific_factories(self) -> None:
        linearization = self.analysis.linearization
        assert linearization is not None
        observations = linearization.observations
        delta = torch.zeros_like(observations.dbz)
        index = tuple(
            int(value)
            for value in torch.nonzero(
                observations.censored_mask,
                as_tuple=False,
            )[0]
        )
        delta[index] = 0.1

        with self.assertRaisesRegex(ValueError, "detected observations"):
            VariationalObservationPerturbation.from_radar_dbz_delta(
                delta,
                linearization,
            )

        threshold = (
            VariationalObservationPerturbation.from_censor_threshold_delta(
                delta,
                linearization,
            )
        )
        weight = (
            VariationalObservationPerturbation.from_censored_event_weight_delta(
                delta,
                linearization,
            )
        )
        self.assertEqual(float(threshold.censor_threshold_dbz[index]), 0.1)
        self.assertEqual(float(weight.observation_weight[index]), 0.1)
        self.assertEqual(float(threshold.detected_dbz[index]), 0.0)
        self.assertEqual(float(weight.detected_dbz[index]), 0.0)

    def test_variational_fso_fails_closed(self) -> None:
        p0_forecast = nowcast(self.frames, self.nowcast_config)
        with self.assertRaisesRegex(ValueError, "accepted P1"):
            compute_variational_fso(
                p0_forecast,
                self.analysis,
                self.verification,
                sensitivity_config=self.sensitivity_config,
            )

        with self.assertRaisesRegex(ValueError, "converged P1"):
            compute_variational_fso(
                self.forecast,
                replace(self.analysis, degraded=True),
                self.verification,
                sensitivity_config=self.sensitivity_config,
            )

        linearization = self.analysis.linearization
        assert linearization is not None
        changed_std = linearization.observations.std_dbz.clone()
        changed_std[0, 0, 0] += 0.1
        changed_observations = replace(
            linearization.observations,
            std_dbz=changed_std,
        )
        changed_analysis = replace(
            self.analysis,
            linearization=replace(
                linearization,
                observations=changed_observations,
            ),
        )
        with self.assertRaisesRegex(ValueError, "content digest mismatch"):
            compute_variational_fso(
                self.forecast,
                changed_analysis,
                self.verification,
                sensitivity_config=self.sensitivity_config,
            )

        changed_run_analysis = replace(
            self.analysis,
            linearization=replace(
                linearization,
                forecast_run_digest="0" * 64,
            ),
        )
        with self.assertRaisesRegex(ValueError, "content digest mismatch"):
            compute_variational_fso(
                self.forecast,
                changed_run_analysis,
                self.verification,
                sensitivity_config=self.sensitivity_config,
            )

        changed_stationarity_analysis = replace(
            self.analysis,
            linearization=replace(
                linearization,
                gradient_norm=linearization.gradient_norm + 1.0,
            ),
        )
        with self.assertRaisesRegex(ValueError, "content digest mismatch"):
            compute_variational_fso(
                self.forecast,
                changed_stationarity_analysis,
                self.verification,
                sensitivity_config=self.sensitivity_config,
            )

        changed_analysis_diagnostics = replace(
            self.analysis,
            linearization_gradient_norm=(
                self.analysis.linearization_gradient_norm or 0.0
            )
            + 1.0,
        )
        with self.assertRaisesRegex(ValueError, "diagnostics mismatch"):
            compute_variational_fso(
                self.forecast,
                changed_analysis_diagnostics,
                self.verification,
                sensitivity_config=self.sensitivity_config,
            )

        failed_pcg = PCGResult(
            solution=torch.zeros_like(self.analysis.control),
            converged=False,
            iterations=1,
            relative_residual=1.0,
        )
        with patch("advar.sensitivity.pcg", return_value=failed_pcg):
            with self.assertRaisesRegex(ValueError, "did not converge"):
                compute_variational_fso(
                    self.forecast,
                    self.analysis,
                    self.verification,
                    sensitivity_config=self.sensitivity_config,
                )

        unpolished_forecast, unpolished_analysis = variational_nowcast(
            self.frames,
            nowcast_config=self.nowcast_config,
            analysis_config=replace(
                self.analysis_config,
                maximum_final_linearization_polish_iterations=0,
            ),
        )
        self.assertFalse(unpolished_analysis.final_linearization_stationary)
        self.assertFalse(unpolished_analysis.fso_eligible)
        self.assertTrue(unpolished_analysis.degraded)
        self.assertIsNone(unpolished_analysis.linearization)
        self.assertGreater(
            unpolished_analysis.linearization_relative_stationarity or 0.0,
            self.analysis_config
            .final_linearization_relative_stationarity_tolerance,
        )
        with self.assertRaisesRegex(ValueError, "converged P1 analysis"):
            compute_variational_fso(
                unpolished_forecast,
                unpolished_analysis,
                self.verification,
                sensitivity_config=self.sensitivity_config,
            )


if __name__ == "__main__":
    unittest.main()
