#!/usr/bin/env python3
"""Build a small, provenance-oriented Phase 1 evidence bundle.

The default destination is scratch staging under /tmp.  This script only
copies captured facts into JSON and a zip; it does not run tests, infer a full
suite/CI result, or turn an absent learning artifact into a pass.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import platform
from pathlib import Path
import re
import sys
import zipfile
import xml.etree.ElementTree as ET


REPOSITORY = Path("/Users/yhlee/ADVAR")
SCRATCH = Path("/tmp/advar-phase1-completion")
REPORT_NAME = "phase1_theoretical_validation.json"


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    digest.update(path.read_bytes())
    return digest.hexdigest()


def _file_record(path: Path, root: Path) -> dict[str, object]:
    return {
        "path": str(path.relative_to(root)),
        "sha256": _sha256(path),
        "bytes": path.stat().st_size,
    }


def _read_json(path: Path) -> dict[str, object]:
    return json.loads(path.read_text(encoding="utf-8"))


def _core_evidence(root: Path, scratch: Path) -> dict[str, object]:
    log_path = scratch / "core.log"
    xml_path = scratch / "core.xml"
    collection_error_path = scratch / "core_collection_error.log"
    log_text = log_path.read_text(encoding="utf-8")
    match = re.search(
        r"(?P<tests>\d+) passed, (?P<warnings>\d+) warnings, "
        r"(?P<subtests>\d+) subtests passed in (?P<seconds>[\d.]+)s",
        log_text,
    )
    if match is None:
        summary: dict[str, object] = {
            "status": "not_parsed",
            "raw_tail": log_text[-500:],
        }
    else:
        summary = {
            "status": "captured_passed",
            "tests_passed": int(match["tests"]),
            "warnings": int(match["warnings"]),
            "subtests_passed": int(match["subtests"]),
            "elapsed_seconds": float(match["seconds"]),
        }
    root_xml = ET.parse(xml_path).getroot()
    suites = []
    for suite in root_xml.findall(".//testsuite"):
        suites.append(
            {
                "name": suite.get("name"),
                "tests_attribute": int(suite.get("tests", "0")),
                "errors": int(suite.get("errors", "0")),
                "failures": int(suite.get("failures", "0")),
                "skipped": int(suite.get("skipped", "0")),
                "testcase_elements": len(suite.findall("testcase")),
                "timestamp": suite.get("timestamp"),
                "hostname": suite.get("hostname"),
            }
        )
    collection_error = collection_error_path.read_text(encoding="utf-8").strip()
    command = (
        "OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 .venv/bin/python -I -m pytest -q "
        "tests/test_matrix_free.py tests/test_pcg.py tests/test_numerical_review.py "
        "tests/test_shift_zero.py tests/test_m0_linearity_weights.py "
        "tests/test_prior_spatial_cotangent.py tests/test_a5_uncertainty_oracles.py "
        "tests/test_a5_loss_stats.py "
        "tests/test_promotion.py::NeuralPriorPromotionTests::"
        "test_event_weighted_estimand_is_invariant_to_case_replication "
        "tests/test_promotion.py::NeuralPriorPromotionTests::"
        "test_same_physical_storm_across_days_and_radars_is_one_cluster "
        "--junitxml=/tmp/advar-phase1-completion/core.xml"
    )
    return {
        "command": command,
        "command_status": "captured_from_reproduction_record",
        "captured_log": str(log_path),
        "captured_xml": str(xml_path),
        "summary": summary,
        "xml": {"suites": suites},
        "collection_error": {
            "present": bool(collection_error),
            "path": str(collection_error_path),
            "text": collection_error or None,
            "status": (
                "corrected_selector_collection_attempt"
                if collection_error
                else "empty"
            ),
            "product_test_failure": False,
            "interpretation": (
                "The initial collection used a nonexistent PromotionTests "
                "class; the corrected NeuralPriorPromotionTests selectors "
                "are included in the successful command."
                if collection_error
                else "No collection error was recorded."
            ),
        },
        "interpretation": (
            "Scoped core evidence only; this is not a full-repository or CI result."
        ),
    }


def _focused_evidence(log_path: Path, xml_path: Path) -> dict[str, object]:
    if not log_path.is_file() or not xml_path.is_file():
        return {
            "status": "not_supplied",
            "log": str(log_path),
            "xml": str(xml_path),
        }
    log_text = log_path.read_text(encoding="utf-8")
    match = re.search(
        r"(?P<tests>\d+) passed(?:, (?P<failed>\d+) failed)?"
        r"(?:, (?P<skipped>\d+) skipped)?(?:, (?P<warnings>\d+) warnings?)?"
        r"(?:, (?P<subtests>\d+) subtests passed)? in (?P<seconds>[\d.]+)s",
        log_text,
    )
    summary = {
        "status": "captured_result" if match else "not_parsed",
        "raw_tail": log_text[-500:] if match is None else None,
    }
    if match is not None:
        summary.update(
            {
                "tests_passed": int(match["tests"]),
                "failed": int(match["failed"] or 0),
                "skipped": int(match["skipped"] or 0),
                "warnings": int(match["warnings"] or 0),
                "subtests_passed": int(match["subtests"] or 0),
                "elapsed_seconds": float(match["seconds"]),
            }
        )
    xml_root = ET.parse(xml_path).getroot()
    suites = xml_root.findall(".//testsuite")
    xml_suite_tests = sum(int(suite.get("tests", "0")) for suite in suites)
    xml_suite_failures = sum(int(suite.get("failures", "0")) for suite in suites)
    xml_suite_errors = sum(int(suite.get("errors", "0")) for suite in suites)
    return {
        "command": (
            "OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 .venv/bin/python -I -m pytest -q "
            "tests/test_phase1_theoretical_demonstration.py "
            "tests/test_phase1_learning_demonstration.py "
            "--junitxml=/tmp/advar-phase1-completion/final_focused.xml"
        ),
        "status": "captured_result",
        "log": str(log_path),
        "xml": str(xml_path),
        "summary": summary,
        "xml_tests_attribute": xml_suite_tests,
        "xml_failures": xml_suite_failures,
        "xml_errors": xml_suite_errors,
    }


def _runtime() -> dict[str, object]:
    try:
        torch_version = importlib.metadata.version("torch")
    except importlib.metadata.PackageNotFoundError:
        torch_version = None
    return {
        "executable": sys.executable,
        "python_version": sys.version,
        "python_implementation": platform.python_implementation(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "torch_distribution_version": torch_version,
    }


def _optional_artifact(path: Path | None) -> dict[str, object]:
    if path is None:
        return {"status": "not_supplied", "path": None}
    if not path.is_file():
        return {
            "status": "missing",
            "path": str(path),
            "sha256": None,
        }
    return {
        "status": "captured_input_not_interpreted",
        "path": str(path),
        "sha256": _sha256(path),
        "bytes": path.stat().st_size,
    }


def _hash_records(
    paths: tuple[tuple[Path, bool], ...],
    root: Path,
) -> list[dict[str, object]]:
    records = []
    for path, required in paths:
        present = path.is_file()
        if required and not present:
            raise FileNotFoundError(f"missing required hash input: {path}")
        records.append(
            {
                "path": str(path.relative_to(root)),
                "present": present,
                "sha256": _sha256(path) if present else None,
                "bytes": path.stat().st_size if present else None,
                "required": required,
            }
        )
    return records


def _build_payload(
    root: Path,
    scratch: Path,
    *,
    learning_report: Path | None,
    final_ci: Path | None,
    final_log: Path,
    final_xml: Path,
) -> dict[str, object]:
    oracle_path = scratch / "oracles/phase1_theoretical_demonstration.json"
    oracle = _read_json(oracle_path)
    tracked_inputs = (
        (root / "AGENTS.md", True),
        (root / "src/advar/physics.py", True),
        (root / "src/advar/nowcast.py", True),
        (root / "src/advar/sensitivity.py", True),
        (root / "src/advar/variational.py", True),
        (root / "README.md", True),
        (root / "PHASE1_COMPLETION_CHECKLIST.md", True),
        (root / "SIXTH_CODE_REVIEW_CHECKLIST.md", True),
        (root / "tests/test_phase1_theoretical_demonstration.py", True),
        (root / "tests/test_phase1_learning_demonstration.py", False),
    )
    learning_review = scratch / "learning_contract_review.md"
    learning_probe = scratch / "learn_probe.py"
    trust_store = scratch / "learning-policies.json"
    learning_summary = (
        _read_json(learning_report)
        if learning_report is not None and learning_report.is_file()
        else None
    )
    learning_status = (
        "captured_report"
        if learning_summary is not None
        else "reported_only_not_independently_revalidated"
    )
    return {
        "contract": "phase1-theoretical-validation-bundle-v1",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "scope": {
            "status": "theoretical_synthetic_only",
            "real_data": "excluded",
            "universal_p0_p1_skill": "not_claimed",
        },
        "runtime": _runtime(),
        "builder": {
            "path": str(Path(__file__).resolve()),
            "sha256": _sha256(Path(__file__).resolve()),
        },
        "code_and_test_hashes": _hash_records(tracked_inputs, root),
        "captured_commands_and_results": oracle.get("commands", []),
        "synthetic_oracle": oracle,
        "scoped_core_evidence": _core_evidence(root, scratch),
        "final_focused_evidence": _focused_evidence(final_log, final_xml),
        "learning_evidence": {
            "status": learning_status,
            "review_file": str(learning_review),
            "probe_script": str(learning_probe),
            "review_file_present": learning_review.is_file(),
            "probe_script_present": learning_probe.is_file(),
            "summary_file": str(learning_report) if learning_report else None,
            "summary": learning_summary,
            "result_status": (
                "captured_report_status_requires_review"
                if learning_summary is not None
                else "not_marked_passed_by_this_bundle"
            ),
            "external_trust_boundary_fixture": {
                "kind": "policy trust-store loader",
                "path": str(trust_store),
                "present": trust_store.is_file(),
                "status": "declared_boundary_only",
                "interpretation": (
                    "No learning eligibility or fixture pass is inferred from "
                    "the review text or an absent trust-store file."
                ),
            },
        },
        "full_suite": {
            "status": "not_claimed",
            "reason": "No full-repository baseline result is an input to this bundle.",
        },
        "ci": {
            "status": "pending",
            "reason": "PR CI remains pending and is not represented as passed.",
        },
        "optional_future_inputs": {
            "learning_report": _optional_artifact(learning_report),
            "final_ci": _optional_artifact(final_ci),
            "final_log": _optional_artifact(final_log),
            "final_xml": _optional_artifact(final_xml),
            "interpretation": (
                "Optional inputs are hash-recorded only; a reviewer must "
                "interpret their result and update status explicitly."
            ),
        },
        "existing_evidence_selectors": oracle.get(
            "related_existing_selectors", []
        ),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repository", type=Path, default=REPOSITORY)
    parser.add_argument("--scratch", type=Path, default=SCRATCH)
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=SCRATCH / "staging/review_artifacts",
    )
    parser.add_argument("--learning-report", type=Path)
    parser.add_argument("--final-ci", type=Path)
    parser.add_argument(
        "--final-log",
        type=Path,
        default=SCRATCH / "final_focused.log",
    )
    parser.add_argument(
        "--final-xml",
        type=Path,
        default=SCRATCH / "final_focused.xml",
    )
    parser.set_defaults(
        learning_report=SCRATCH / "learning_completion_summary.json"
    )
    args = parser.parse_args()
    payload = _build_payload(
        args.repository,
        args.scratch,
        learning_report=args.learning_report,
        final_ci=args.final_ci,
        final_log=args.final_log,
        final_xml=args.final_xml,
    )
    args.output_dir.mkdir(parents=True, exist_ok=True)
    json_path = args.output_dir / REPORT_NAME
    json_path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True)
        + "\n",
        encoding="utf-8",
    )
    zip_path = args.output_dir / REPORT_NAME.replace(".json", ".zip")
    archive_inputs = (
        (
            args.repository / "tests/test_phase1_theoretical_demonstration.py",
            "tests/test_phase1_theoretical_demonstration.py",
        ),
        (
            args.repository / "tests/test_phase1_learning_demonstration.py",
            "tests/test_phase1_learning_demonstration.py",
        ),
        (args.scratch / "core.log", "evidence/core.log"),
        (args.scratch / "core.xml", "evidence/core.xml"),
        (
            args.scratch / "core_collection_error.log",
            "evidence/core_collection_error.log",
        ),
        (args.final_log, "evidence/final_focused.log"),
        (args.final_xml, "evidence/final_focused.xml"),
        (
            args.scratch / "oracles/phase1_theoretical_demonstration.json",
            "evidence/oracles/phase1_theoretical_demonstration.json",
        ),
        (args.learning_report, "evidence/learning_completion_summary.json"),
        (
            args.scratch / "learning_contract_review.md",
            "evidence/learning_contract_review.md",
        ),
        (args.scratch / "learn_probe.py", "evidence/learn_probe.py"),
        (Path(__file__).resolve(), "builder/build_evidence.py"),
    )
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        archive.write(json_path, arcname=REPORT_NAME)
        for path, arcname in archive_inputs:
            if path is not None and path.is_file() and path != json_path:
                archive.write(path, arcname=arcname)
    print(json_path)
    print(zip_path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
