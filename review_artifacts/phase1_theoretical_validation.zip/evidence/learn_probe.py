import sys
from dataclasses import replace
from torch import nn
import torch

sys.path.insert(0, "/Users/yhlee/ADVAR/tests")
sys.path.insert(1, "/Users/yhlee/ADVAR/src")
import test_sensitivity as s
from advar.variational import (
    AnalysisConfig,
    NeuralPriorInferenceRunner,
    variational_nowcast,
)
from advar.nowcast import (
    ForecastRunContract,
    NowcastConfig,
    RadarGridTimeContract,
    RADAR_PROJECTED_GRID_CELL_CENTER_CONVENTION,
    RADAR_PROJECTED_GRID_COORDINATE_DTYPE,
    radar_projected_crs_semantic_digest,
)
from advar.sensitivity import (
    AutomatedLearningPolicy,
    CURRENT_RADAR_METRIC_DOMAIN,
    CURRENT_RADAR_METRIC_DOMAIN_EVIDENCE,
    MetricTaylorThreshold,
    SensitivityConfig,
    VariationalAdjointConfig,
    VariationalObservationPerturbation,
    compute_variational_fsoi_for_learning,
)


class ConstantPrior(nn.Module):
    def __init__(self, value: float) -> None:
        super().__init__()
        self.value = nn.Parameter(torch.tensor(value, dtype=torch.float64))

    def forward(self, features: torch.Tensor) -> torch.Tensor:
        return features * 0.0 + self.value


class RadarDependentPrior(nn.Module):
    def __init__(self, offset: float = 0.0) -> None:
        super().__init__()
        self.register_buffer("anchor", torch.tensor(offset, dtype=torch.float64))

    def forward(self, features: torch.Tensor) -> tuple[torch.Tensor, ...]:
        mean = features + self.anchor
        std = torch.exp(0.002 * features)
        valid = torch.ones_like(mean)
        support = (mean >= 5.0).to(mean)
        probability = torch.ones_like(mean)
        return (mean, std, valid, support, probability, mean, std)


def build():
    coordinates = torch.arange(16, dtype=torch.float64)
    y, x = torch.meshgrid(coordinates, coordinates, indexing="ij")
    frames = torch.stack(
        tuple(
            20.0
            + 5.0
            * torch.exp(-((y - center) ** 2 + (x - center) ** 2) / 8.0)
            for center in (6.0, 6.5, 7.0)
        )
    )
    background = frames.clone()
    frames[2, 2:5, 2:5] = frames[0, 2:5, 2:5] + 1.0
    observation_mask = torch.ones_like(frames, dtype=torch.bool)
    observation_mask[1] = False
    observation_mask[1, 2:14, 2:14] = True
    observation_mask[2] = False
    observation_mask[2, 2:14, 2:14] = True
    nowcast_config = NowcastConfig(horizon_minutes=10)
    analysis_config = AnalysisConfig(
        censored_background_policy="floor",
        maximum_outer_iterations=100,
        maximum_pcg_iterations=200,
        pcg_relative_tolerance=1.0e-8,
        initial_increment_scale_dbz=1.0,
        field_smoothness_weight=0.0,
        maximum_final_linearization_polish_iterations=4,
        pseudo_huber_delta=1.0e6,
        echo_transform_scale_dbz=10.0,
    )
    prior = NeuralPriorInferenceRunner(
        RadarDependentPrior(1.0).eval(),
        lambda features: features[0],
        example_frames=frames,
        state_contract=s.NeuralPriorStateContract(
            state_product_digest="a" * 64,
            state_qc_pipeline_digest="9" * 64,
            state_mask_policy_digest="3" * 64,
            state_censor_policy_digest=s.neural_prior_state_censor_policy_digest(
                detection_limit_dbz=5.0,
                censor_temperature_dbz=1.0,
                censored_background_policy="floor",
                minimum_dbz=-10.0,
                maximum_dbz=70.0,
            ),
            support_threshold_dbz=5.0,
            minimum_state_dbz=-10.0,
            maximum_state_dbz=70.0,
            minimum_state_std_dbz=0.1,
            maximum_state_std_dbz=20.0,
        ),
        probability_contract=s.NeuralPriorProbabilityContract(
            support_threshold_dbz=5.0,
            support_product_digest="a" * 64,
            qc_pipeline_digest="9" * 64,
            reflectivity_resolution_dbz=0.5,
            quantization_origin_dbz=-10.0,
        ),
        model_contract_digest="4" * 64,
        feature_schema_digest="5" * 64,
        training_manifest_digest="6" * 64,
        dependency="radar_dependent",
    )
    observation_times = (
        "2026-08-05T00:00:00Z",
        "2026-08-05T00:10:00Z",
        "2026-08-05T00:20:00Z",
    )
    background_times = observation_times
    grid = RadarGridTimeContract(
        valid_times=observation_times,
        background_valid_times=background_times,
        dx_m=1000.0,
        dy_m=1000.0,
        projection="EPSG:5179",
        grid_hash="4" * 64,
        spatial_grid_contract="radar-spatial-grid-identity-v6",
        grid_shape_yx=tuple(frames.shape[-2:]),
        projected_crs_digest=radar_projected_crs_semantic_digest("EPSG:5179"),
        metric_domain_digest=CURRENT_RADAR_METRIC_DOMAIN.digest,
        metric_domain_evidence_digest=CURRENT_RADAR_METRIC_DOMAIN_EVIDENCE.digest,
        cell_center_origin_xy_m=(1_000_000.0, 2_000_000.0),
        grid_coordinate_dtype=RADAR_PROJECTED_GRID_COORDINATE_DTYPE,
        cell_center_convention=RADAR_PROJECTED_GRID_CELL_CENTER_CONVENTION,
    )
    input_run = ForecastRunContract.from_inputs(
        nowcast_config,
        frames,
        observation_mask,
        background,
        0.0,
        grid_time_contract=grid,
    )
    application = prior.infer(frames, input_run=input_run, role="candidate")
    forecast, analysis = variational_nowcast(
        frames,
        nowcast_config=nowcast_config,
        analysis_config=analysis_config,
        qc_mask=observation_mask,
        background_frames_dbz=background,
        background_age_minutes=0.0,
        grid_time_contract=grid,
        neural_prior=application,
    )
    verification = s._current_verification_bundle(
        torch.where(
            torch.isfinite(forecast.forecast_dbz),
            forecast.forecast_dbz - 0.5,
            forecast.forecast_dbz,
        ),
        valid_times=("2026-08-05T00:30:00Z",),
        grid_time_contract=grid,
    )
    linearization = analysis.linearization
    if linearization is None:
        raise RuntimeError(
            f"analysis failed: converged={analysis.converged} "
            f"fallback={analysis.used_fallback} reason={analysis.reason}"
        )
    sensitivity_config = replace(
        SensitivityConfig.for_automated_learning(
            radar_product_digest="5" * 64,
            qc_pipeline_digest="6" * 64,
        ),
        metric_names=("log_echo_mse",),
        full_map_lead_minutes=(10,),
        tile_size=4,
        tile_size_m=4000.0,
        metric_domain="radar_dynamics_anchored",
    )
    adjoint_config = replace(
        VariationalAdjointConfig.for_automated_learning(),
        lead_minutes=(10,),
        maximum_perturbed_area_km2=256.0,
        perturbation_tile_size_m=4000.0,
    )
    policy = AutomatedLearningPolicy(
        sensitivity_config=sensitivity_config,
        adjoint_config=adjoint_config,
        algorithm_bundle_digest=linearization.algorithm_bundle_digest,
        numerical_runtime_digest=linearization.numerical_runtime_digest,
        metric_taylor_thresholds=(
            MetricTaylorThreshold("log_echo_mse", 1.0e-6, 1.0e-8),
        ),
    )
    index = torch.nonzero(linearization.observations.detected_mask[0], as_tuple=False)[0]
    location = (0, int(index[0]), int(index[1]))
    return {
        "frames": frames,
        "background": background,
        "observation_mask": observation_mask,
        "nowcast_config": nowcast_config,
        "analysis_config": analysis_config,
        "prior": prior,
        "grid": grid,
        "application": application,
        "forecast": forecast,
        "analysis": analysis,
        "verification": verification,
        "linearization": linearization,
        "policy": policy,
        "location": location,
    }


if __name__ == "__main__":
    values = build()
    for delta_value in (1.0e-4, 1.0e-3, 1.0e-2, 1.0e-1):
        delta = torch.zeros_like(values["frames"])
        delta[values["location"]] = delta_value
        perturbation = VariationalObservationPerturbation.from_radar_dbz_delta(
            delta,
            values["linearization"],
            neural_prior_runner=values["prior"],
            neural_prior_application=values["application"],
        )
        try:
            result = compute_variational_fsoi_for_learning(
                values["forecast"],
                values["analysis"],
                values["verification"],
                perturbation,
                policy=values["policy"],
                policy_trust_store_path="/tmp/advar-phase1-completion/learning-policies.json",
                neural_prior_runner=values["prior"],
                neural_prior_application=values["application"],
            )
            print(delta_value, result.eligibility.eligible, result.eligibility.reasons)
            if result.first_order_validation is not None:
                validation = result.first_order_validation
                print(validation)
        except Exception as error:
            print(delta_value, type(error).__name__, error)
