# Phase 1 learning contract review

## Reachability

`VariationalObservationPerturbation.from_radar_dbz_delta` accepts a nonzero physical dBZ delta only on retained detected observations, and canonicalizes channels to detected dBZ plus the accepted first-frame background path and (only when `baseline_metadata.tendency_source == OBSERVATION`) the continuous P0 dynamics path. It rejects input-clamp or detected/censored classification crossings and enforces local, pixel/fraction/area, whitened and tile budgets.

`AutomatedLearningPolicy` requires every local-validity gate and an explicit full-map lead tuple. The approved path is: root-trusted policy digest -> lineage-compatible accepted P1 analysis/linearization -> current verification bundle -> FSO -> physical FSOI -> two real `solve_analysis` calls at scales 1 and 0.5 -> finite/converged unchanged-branch results, Taylor tolerances, sign consistency, and at least one material metric. Eligible evidence must retain both resolved analysis/forecast digests and nominal input/full-analysis lineage.

## P0 branch result

`_baseline_dynamics_branch_certification` is fundamentally fail-closed for any nonzero radar delta when the retained P0 tendency source is `OBSERVATION`: it samples 0.5 and 1.0, then returns `unknown` even when both signatures match because those samples do not prove no discrete FFT peak/pair transition over the interval. The automated config requires `certified`, so an ordinary finite observation-derived tendency cannot reach learning eligibility without a branch certificate (a mock would conceal this).

The viable physical fixture must make retained P0 tendency source `BACKGROUND` (or `NONE` with no P0 tendency path), while retaining enough accepted latest observations for P1. Use finite radar frames with the first two observation masks rejected/unavailable and a spatially varying, fully available three-frame background whose pair phase-correlation/growth evidence is interior and above thresholds. Set `RadarGridTimeContract.background_valid_times` when a grid is used. A constant background is unsafe: phase-correlation can be non-interior and produce `NONE`.

## Prior choice and preservation

An exogenous neural prior is stable across full/half re-solves and therefore avoids a prior-input branch transition, but physical radar dBZ has no derivative through valid prior cells; the P1 prior contribution is zero except identity fallback cells. A radar-dependent prior gives a genuinely nonzero P1-prior/JVP path, but requires a retained runner/application and sufficient valid/support probability margins. The runner must reproduce the retained prior and the full/half re-solves must preserve its valid mask; exogenous output must be exactly unchanged (`torch.equal`) after changed radar input. Either prior mode still needs unchanged analysis remap cells, output-cap masks, classification, convergence and publication/metric support.

The physical delta should be a small nonzero latest or first-frame detected cell, away from dBZ floor/cap and detection threshold. A latest-frame delta exercises residual/P1 observation only; a first-frame delta exercises the prior channel for a radar-dependent prior (or fallback identity for an exogenous prior), while `BACKGROUND` P0 keeps baseline-dynamics perturbation identically zero. Make the verification bundle current, complete, grid-consistent and valid for every configured lead. The real full/half changes must be large enough to exceed materiality yet small enough for both Taylor errors and unchanged active branches.

## Existing test warning

The existing approved-learning test explicitly patches both `_baseline_dynamics_branch_certification` and `_validate_first_order_learning_impact`; it demonstrates downstream evidence wiring only. It cannot serve as an unmocked Phase 1 oracle. The nearby physical factory test correctly observes `unknown` for the standard observation-tendency fixture.

## Reproduced viable recipe

The existing `/tmp/advar-phase1-completion/learn_probe.py` structure reaches the entire path unmocked when its `RadarDependentPrior` offset is `0.0`, `0.1`, `1.0`, or `2.0` (offset `5.0` makes the P1 solve degrade). With offset `1.0`, the probe converged with `TendencySource.BACKGROUND` and `validity_contract="probabilistic"`; a first-frame detected-cell delta reached `compute_variational_fsoi_for_learning` under the default GN defect limit `0.25`. For delta magnitudes `1e-4`, `1e-3`, `1e-2`, and `1e-1`, the real full/half checks returned `eligible=True`, with both Taylor checks and sign consistency true and one material metric. Full-step absolute errors were approximately `5.7e-9`, `5.7e-9`, `7.6e-9`, and `2.0e-7` respectively. The only in-memory substitution used in this probe was the trust-store loader, which is the separately permitted external trust-store boundary; no branch certificate or Taylor-validation result was injected.
