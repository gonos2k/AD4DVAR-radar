# PR158 preflight CI review

Verdict: preserve `_validate_explicit_metric_cell_event_counts` and the
corresponding issuance guard. The policy constructors reject duplicate required
cell keys, the normal `compute_neural_prior_promotion` path initializes and
updates one count row per policy key, and `cell_feasible` is an `all()` over the
rows supplied. A sparse explicit map therefore omits an independent metric or
issuance gate; it can make `all()` vacuously true and claim feasibility without
evidence for the omitted weather×range×metric×lead cell. The complete-map
fixture is the correct CI fix. With the current two metric and two issuance
cells, supplying all four rows and testing available 5 versus required 10
preserves the sparse-cell rejection and checks the boundary at 10. The targeted
test passed under Python 3.12.13 (`1 passed, 2 subtests`).

The row minimum field deserves a separate contract hardening decision. In the
normal producer it is policy-derived: metric rows use
`max(item.minimum_physical_events,
policy.minimum_deployment_metric_cell_events,
policy.minimum_continuous_metric_cell_events)` and issuance rows use
`item.minimum_physical_events`. The explicit validators currently require only
positive integers, so a direct caller can provide a complete map whose
`required` values are lower than those floors. If available events exceed the
global preflight requirement but a cell is below its policy floor, that map can
still report `cell_feasible=True`; this is a real weakness of the unrestricted
module API, although no normal production caller reaches it because
`compute_neural_prior_promotion` supplies the derived values. A follow-up could
reject metric required values below the metric floor and issuance values below
`item.minimum_physical_events` (retain larger caller values if intentionally
supported). It need not expand the PR158 test-only CI fix.

`PromotionSampleSizePreflight.__post_init__` and acceptance artifact loading
cannot enforce exact policy keys because they receive no policy; synthetic
report-only acceptance fixtures can therefore construct empty maps. The
canonical production producer emits complete maps, so this is a boundary
limitation rather than a regression in the PR158 fixture fix.
