"""Run final regressions with the base commit's caller restored in memory."""
import ast
from pathlib import Path
import subprocess
import sys

import pytest
import advar.sensitivity as sensitivity

root = Path('/Users/yhlee/ADVAR')
source = subprocess.check_output(
    ['git', 'show', '1d0ce7d6b2a50238d0188b8bdcc968084907be2b:src/advar/sensitivity.py'],
    cwd=root, text=True,
)
body = [
    node for node in ast.parse(source).body
    if isinstance(node, ast.FunctionDef) and node.name == '_compute_variational_products'
]
assert len(body) == 1
exec(compile(ast.Module(body=body, type_ignores=[]), '<1d0ce7d former caller>', 'exec'), sensitivity.__dict__)
sys.exit(pytest.main(['-q', str(root / 'tests/test_prior_spatial_cotangent.py'), '--tb=short', '--show-capture=no']))
