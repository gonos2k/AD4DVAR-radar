# A6 independent review: prior spatial cotangent

## Scope and state

- Repository: `/Users/yhlee/ADVAR`
- Branch inspected: `agent/prior-spatial-cotangent`
- Commit inspected: `1d0ce7d6b2a50238d0188b8bdcc968084907be2b`
- Review was read-only for repository source, tests, and environments. The
  worktree already contained unrelated untracked files; none were changed.
- The review file is the only requested artifact written by this review.

## Chain traced

`src/advar/sensitivity.py:15327-16210` contains
`_compute_variational_products`. For every selected lead and metric it obtains
the observation adjoint, then calls
`_frozen_initial_background_observation_sensitivity` with
`return_field_sensitivity=True` at `:15855-15872`.

`src/advar/sensitivity.py:16379-16473` confirms the return dimensions and
meaning:

- `field_sensitivity = direct + implicit` is a spatial `[H,W]` cotangent with
  respect to the consumed P1 initial background field.
- `first_frame` applies the accepted-first-frame mask and remains `[H,W]`.
- `observation_sensitivity` concatenates `first_frame.unsqueeze(0)` with two
  zero frames and is `[3,H,W]`.
- With `return_field_sensitivity=True`, the helper returns
  `(observation_sensitivity, field_sensitivity)`, i.e. `([3,H,W], [H,W])`.

At `sensitivity.py:15873-15885`, the caller correctly builds the observation
derived fallback as a `[3,H,W]` tensor and writes only its first time frame.
For a radar-dependent prior, the cotangent passed to the prior VJP must be the
whole spatial field masked by `prior_valid`:

```text
prior_cotangent[y,x] = field_sensitivity[y,x] where prior_valid[y,x]
```

The current code at `sensitivity.py:15890-15894` instead uses
`background_field_sensitivity[0]`. Since `background_field_sensitivity` is
`[H,W]`, this selects one spatial row `[W]`; `torch.where` silently broadcasts
that row over all `H` rows. It is a shape-valid but spatially incorrect VJP.

The P1 state construction in `src/advar/variational.py:4168-4348` confirms the
partition. `prepare_analysis` first forms an observation/background initial
field, then replaces valid prior cells with `prior_background`; invalid prior
cells retain the observation-derived value. It stores the final prior validity
mask as `[H,W]` in `FrozenOuterState.neural_prior_valid_mask`. Thus the whole
field mask in the VJP is aligned with the actual consumed prior state.

## Neural-prior VJP semantics

`src/advar/variational.py:1881-1890` defines the derivative output as
`(mean, log_std)`, each `[H,W]`. `:2633-2673` maps an input tangent to the
canonical learned channel and `:2690-2720` pulls back `[H,W]` mean and
log-standard-deviation cotangents. For a legacy model it returns the
`[3,H,W]` frame gradient; for the current five-channel learned input it strips
the feature-channel dimension with `result[0]`, yielding the same `[3,H,W]`
frame gradient. That `result[0]` is a deliberate canonical-input-channel
selection and is unrelated to the spatial-row bug.

`src/advar/variational.py:2722-2776` validates the same mean/log-std cotangent
pair against a JVP. The log-standard-deviation path from
`sensitivity.py:16476-16510` is already a whole `[H,W]` field and is masked by
`prior_valid`; it does not need a spatial `[0]`.

The complete caller composition is therefore:

```text
G = d(metric)/d(initial_background) under the frozen GN implicit solve
fallback[0] = G on accepted first-frame cells not using the prior
prior_cotangent = prior_valid * G on prior cells
prior_input_sensitivity = fallback + prior_VJP(prior_cotangent, log_std_cotangent)
```

For an exogenous prior, the caller intentionally keeps only `fallback`; the
prior has no observation derivative. For no prior, it keeps the helper's
`[3,H,W]` observation sensitivity. These branches are dimensionally and
semantically consistent.

## Other relevant uses of `[0]`

No other spatial-row use of `field_sensitivity` was found. The following uses
are intentional and should remain unchanged:

- `sensitivity.py:15878-15884`: `background_sensitivity[0]` and `fallback[0]`
  select the first observation time in `[3,H,W]` tensors.
- `sensitivity.py:16446-16457`: helper masks the accepted first observation
  frame.
- `sensitivity.py:16818-16837`: physical perturbation initial-background
  activity is first-frame-only.
- `sensitivity.py:14858-14875` and `:17292-17297`: first-frame perturbation
  extraction is intentional.
- `variational.py:2662-2665`: learned model input channel zero is the canonical
  dBZ channel.
- `variational.py:2718-2720`: learned model input channel zero is stripped
  after the VJP to return frame-space gradients.

The precomputed path at `sensitivity.py:14442-14531` is also already
dimensionally correct: it multiplies the retained initial-background FSO map by
`_initial_background_perturbation`, which for physical radar input was built by
`_physical_radar_channels` at `:9318-9379` using the prior JVP and first-frame
fallback. The discovered bug is in the direct `_compute_variational_products`
composition, especially its physical FSOI frozen-structure impact at
`:16001-16023`.

## Runtime probe

Command run with the repository's fixed environment:

```text
./.venv/bin/python -m unittest \
  tests.test_sensitivity.VariationalFSOTests.test_physical_fsoi_includes_spatial_prior_uncertainty_path
```

Result: one test passed in 6.295 seconds.

I also ran an ephemeral CPU probe that wrapped the helper and
`NeuralPriorInferenceRunner.vjp_components` around the same compact public
radar-dependent P1 FSOI case. It observed:

- helper field shape `(8, 8)` and VJP cotangent shape `(8, 8)`;
- prior-valid row counts `[0, 0, 3, 3, 3, 0, 0, 0]`;
- captured VJP cotangent exactly equaled
  `where(prior_valid, field[0], 0)`;
- it differed from `where(prior_valid, field, 0)` by a maximum absolute value
  of approximately `6.67e-4`.

This demonstrates that the bad indexing is active, silently broadcasts, and
loses or misroutes spatial prior gradient information. The existing public
test passes because it checks aggregate consistency and a nonzero prior path,
without checking the spatial prior cotangent at a non-first-row cell.

## Regression oracle recommendation

The strongest bounded public regression is a partial prior/fallback case with
one lead and one metric:

1. Use a radar-dependent identity-mean prior with constant uncertainty, and a
   validity/support mask that activates prior cells in rows below row zero while
   retaining at least one accepted observation-derived fallback cell.
2. Inject or otherwise construct a deterministic helper field cotangent
   `G:[H,W]` with distinct spatial values and an exactly zero first row. If the
   test wraps the private helper only to supply this analytic field, label that
   explicitly as a controlled public-caller oracle; it isolates routing while
   the real runner VJP remains exercised.
3. Assert the captured prior VJP input is
   `where(prior_valid, G, 0)`, and that the public FSOI
   `initial_background_dbz` impact at a prior cell equals `G[cell] * delta[cell]`.
   Assert a fallback cell equals the observation-derived `G[cell] * delta[cell]`
   as well. The total impact should equal the sum of the five component impacts.
4. If practical, materialize FSOI from the retained FSO and compare its
   initial-background component with the direct public FSOI. This checks that
   the precomputed route, whose prior JVP is already explicit, remains aligned.

Do not use a full nonlinear re-analysis finite difference as the primary oracle:
the public contract deliberately uses the frozen Gauss--Newton normal operator,
so exact nonlinear curvature would conflate this routing defect with the
documented GN approximation. A direct whole-composition chain-rule oracle over
the helper field, prior VJP, fallback, and component aggregation is stable and
bounded.

## Final working-tree diff and regression review

After the original-state probe, the shared working tree changed as follows:

- `src/advar/sensitivity.py` removes exactly the two spatial-row selections
  from the radar-dependent prior cotangent, adds the `[3,H,W]` versus `[H,W]`
  comment at the caller, and documents the field-gradient return in the helper.
- No other source use of `background_field_sensitivity` changed. `git diff
  --check` is clean for the tracked source diff.
- `tests/test_prior_spatial_cotangent.py` adds two public P1 regressions. The
  identity prior/fallback test uses a real partial radar-dependent prior and
  checks the FSO map, FSOI initial-background impact, total component sum, and
  standalone FSO composition at distinct prior and fallback cells. The
  controlled quadratic test keeps the real public caller and runner VJP, while
  replacing only the helper subproblem with an analytically solved
  `J(c,B)=||c-B||²/2`, `E=.25<G,B>+.75<G,c>` oracle. It exercises three spatial
  fields: nonuniform `G`, zero-first-row `G`, and a row-flipped `G`; all include
  a non-first-row prior cell and a fallback cell.
- Targeted validation in the fixed working tree passed with
  `./.venv/bin/python -m pytest -q tests/test_prior_spatial_cotangent.py`: `2
  passed`, `3 subtests passed` (8.36 seconds; only existing Torch deprecation
  warnings).
- The broader root-run result reported for the frozen change was 93 tests and
  99 subtests passed with type checks clean.

The probe script itself was run inline and was not preserved as a separate
file; the numerical observations are recorded above.

## Verdict

Replacing exactly the two occurrences of
`background_field_sensitivity[0]` in the radar-dependent prior cotangent with
`background_field_sensitivity` is mathematically and dimensionally correct.
Adding comments naming `[3,H,W]` observation sensitivities versus `[H,W]`
initial-background/prior cotangents is useful. No other `[0]` in the traced
caller/helper/VJP chain should change. The remaining risk is limited to test
coverage of direct public FSOI spatial routing; the helper, fallback, exogenous
branch, learned-input channel handling, and precomputed-FSOI multiplication
have coherent semantics from inspection.
