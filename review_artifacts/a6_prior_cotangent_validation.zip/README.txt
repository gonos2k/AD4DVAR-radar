Apply fix.patch to base1d0ce7d and copy tests/test_prior_spatial_cotangent.py.
Use existing environment; run OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 .venv/bin/python -I -m pytest -q tests/test_prior_spatial_cotangent.py tests/test_a5_derivatives.py tests/test_m0_linearity_weights.py tests/test_numerical_review.py tests/test_sensitivity.py::VariationalFSOTests --tb=short
The former-caller script deliberately restores the old function in memory and should fail; adjust its repository root when reproducing elsewhere.
Original before.txt predates the final standalone-FSO assertion; former-caller.txt runs the exact final test file.
