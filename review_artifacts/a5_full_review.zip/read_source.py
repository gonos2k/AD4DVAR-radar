import hashlib,json,sys
from pathlib import Path
agent,name,start,end=sys.argv[1:]
start,end=int(start),int(end)
assert 1<=start<=end and end-start<350
root=Path('/Users/yhlee/ADVAR');p=(root/name).resolve();assert p.is_relative_to(root)
manifest=json.loads(Path('/tmp/advar-a5-review/manifest.json').read_text())
expected=next((r for r in manifest['files'] if r['file']==name),None)
b=p.read_bytes();digest=hashlib.sha256(b).hexdigest()
if expected:assert digest==expected['sha256']
lines=b.decode().splitlines();end=min(end,len(lines));assert start<=end
out=Path('/tmp/advar-a5-review/probes')/agent;out.mkdir(exist_ok=True)
with (out/'reads.jsonl').open('a') as f:f.write(json.dumps({'file':name,'start':start,'end':end,'sha256':digest})+'\n')
for i in range(start,end+1):print(f'{i}: {lines[i-1]}')
