import torch, math
from advar.nowcast import NowcastConfig, nowcast, prepare_input, _estimate_available_pair
from advar.physics import dbz_to_echo
from advar.physics import echo_to_dbz

def pattern(shift, amp):
 h=w=64
 yy,xx=torch.meshgrid(torch.arange(h,dtype=torch.float64),torch.arange(w,dtype=torch.float64),indexing='ij')
 p=torch.zeros(h,w,dtype=torch.float64)
 # unique non symmetric multi blobs
 for y,x,s,a in [(24,16,3,1),(37,19,4,0.7),(18,27,2,0.8),(42,30,2.5,0.9),(29,34,3,0.6),(49,23,2,0.5)]:
  p += a*torch.exp(-((yy-y)**2+(xx-(x+shift))**2)/(2*s*s))
 # amplitudes are echo above min floor; normalize to baseline
 return amp*p
h=w=64
floor=-10.
base0=pattern(0,12.)
base1=pattern(6,5.0)
base2=pattern(12,5.0)
f0=echo_to_dbz(base0,min_dbz=floor,max_dbz=70)
f1=echo_to_dbz(base1,min_dbz=floor,max_dbz=70)
f2=echo_to_dbz(base2,min_dbz=floor,max_dbz=70)
# Frame 1 missing old-frame echo region; does not touch pair1's B->C active area.
f1[:,13:20]=float('nan')
frames=torch.stack((f0,f1,f2))

base_cfg=NowcastConfig(minimum_phase_correlation_psr=0.,phase_correlation_sidelobe_radius_px=2,pair_echo_dilation_px=0,minimum_growth_overlap_support=1.,horizon_minutes=10)
pr=prepare_input(frames,base_cfg)
lin=dbz_to_echo(pr.frames_dbz,min_dbz=base_cfg.min_dbz,max_dbz=base_cfg.max_dbz)
for ij in ((1,2),(0,2),(0,1)):
 e=_estimate_available_pair(pr.frames_dbz,pr.observed_mask,lin,*ij,base_cfg,None)
 print("EST",ij, None if e is None else (e[0].tolist(), float(e[1].value),float(e[1].overlap_support),float(e[1].aligned_previous_integral),float(e[1].current_integral),float(e[2])))

for ratio in (1.5,):
 cfg=NowcastConfig(minimum_phase_correlation_psr=0.,phase_correlation_sidelobe_radius_px=2,pair_echo_dilation_px=0,minimum_growth_overlap_support=1.,minimum_pair_confidence_ratio=ratio,horizon_minutes=10)
 try:
  out=nowcast(frames,cfg)
  m=out.metadata
  print('ratio',ratio,'motion',m.motion_pair_selection,m.motion_pair_count,'growth',m.growth_pair_selection,m.growth_pair_count,'disp',out.state.displacement_yx.tolist(),'growth',float(out.state.log_growth_per_step),'psr',float(m.minimum_phase_correlation_psr),'source',m.state_path_mode,m.state_path_pair_count,'obs support',float(m.observation_source_support.sum()),'state echo max',float(out.state.echo_linear.max()),'valid',int(out.valid_mask[0].sum()))
  print('paths',m.observation_path)
 except Exception as e: print('ERR',ratio,type(e).__name__,e)
