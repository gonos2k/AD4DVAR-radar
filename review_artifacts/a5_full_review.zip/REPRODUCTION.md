# A5 investigation evidence

Base: 286c0c9416a645ec4350b24ab9e9faca6584bb56. No product fix is included.

Use `summary.json` for root adjudications and `FIFTH_CODE_REVIEW_CHECKLIST.md` for the
prioritized open work. `reports/*.json` retains individual reviewer opinions;
some original severities are intentionally narrowed or retracted in root adjudication.

Environment: Python 3.12.13 / PyTorch 2.13.0 CPU. Source hashes are in manifest.json.
Run a probe from the repository root with its explicitly selected Python:

```sh
OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONPATH=src:tests \
  /Users/yhlee/ADVAR/.venv/bin/python /tmp/advar-a5-review/probes/root/weighted_loss_probe.py
```

Other root-rerun probes are listed in `summary.json`. Scripts reference the original
workspace/scratch paths and some import synthetic test fixtures. When reproducing
elsewhere, adjust those paths and use a separate environment. Do not recreate a
shared environment or run all scripts blindly: some simulate blocking special files,
concurrency, malformed signed artifacts or CLI file collisions in their own scratch
directories. No real radar, user data, or deployment action is required.

`reads.jsonl` records requested source spans and hashes, not a proof of semantic
correctness. Tests overlap across reviewers: do not sum their pass counts. The
repository-wide local baseline, real-radar skill, MPS/CUDA and current operational
deployment have not been certified by these probes. CI metadata is time-stamped
and distinguishes the previous main from the active PR head.

Synthetic NPZ/model fixtures and script logs are included where retained. Some
historical inlined probes survive only as exact command/output text; their narrower
evidence level is preserved in the report. Check archive_member_sha256.json for
member integrity. This archive is review evidence, not a signed scientific release.
