import torch
from advar.nowcast import NowcastConfig, nowcast, prepare_input, _estimate_available_pair
from advar.physics import dbz_to_echo
h=w=64
yy,xx=torch.meshgrid(torch.arange(h,dtype=torch.float64),torch.arange(w,dtype=torch.float64),indexing='ij')
def p(shift):
 p=torch.full((h,w),-10.,dtype=torch.float64)
 for y,x,s,a in [(24,16,3,22),(37,19,4,18),(18,27,2,20),(42,30,2.5,19),(29,34,3,17),(49,23,2,16)]:
  p=torch.maximum(p,a*torch.exp(-((yy-y)**2+(xx-(x+shift))**2)/(2*s*s)))
 return p
base0=p(0);base1=p(6);base2=p(12)
for off in (0,2,4,6,8,10,15):
 f0=base0+off;f1=base1.clone();f2=base2.clone();f1[:,13:20]=float('nan')
 frames=torch.stack((f0,f1,f2));cfg=NowcastConfig(minimum_phase_correlation_psr=0.,phase_correlation_sidelobe_radius_px=2,pair_echo_dilation_px=0,minimum_growth_overlap_support=1.,horizon_minutes=10)
 prep=prepare_input(frames,cfg);lin=dbz_to_echo(prep.frames_dbz,min_dbz=cfg.min_dbz,max_dbz=cfg.max_dbz)
 es=[]
 for ij in ((1,2),(0,2)):
  e=_estimate_available_pair(prep.frames_dbz,prep.observed_mask,lin,*ij,cfg,None)
  es.append(None if e is None else (e[0].tolist(),float(e[1].value),float(e[1].overlap_support),float(e[1].aligned_previous_integral),float(e[1].current_integral),float(e[2])))
 out=nowcast(frames,cfg);m=out.metadata
 print('off',off,'EST',es,'SEL',m.motion_pair_selection,m.growth_pair_selection,'state',out.state.displacement_yx.tolist(),float(out.state.log_growth_per_step))
