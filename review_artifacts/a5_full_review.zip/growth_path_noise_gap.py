import torch, math
from advar.nowcast import NowcastConfig, nowcast, prepare_input, _estimate_available_pair
from advar.physics import dbz_to_echo
h=w=64
yy,xx=torch.meshgrid(torch.arange(h),torch.arange(w),indexing='ij')
def p(shift):
 p=torch.full((h,w),-10.,dtype=torch.float64)
 for y,x,s,a in [(24,16,3,22),(37,19,4,18),(18,27,2,20),(42,30,2.5,19),(29,34,3,17),(49,23,2,16)]:
  p=torch.maximum(p,a*torch.exp(-((yy-y)**2+(xx-(x+shift))**2)/(2*s*s)))
 return p
base0=p(0);base1=p(6);base2=p(12)
for amp0 in (5.,8.,10.,15.):
 for n in (10,30,100,300,800):
  g=torch.Generator().manual_seed(100+n); inds=torch.randperm(h*w,generator=g)[:n]; noise_mask=torch.zeros(h*w,dtype=torch.bool);noise_mask[inds]=True;noise_mask=noise_mask.reshape(h,w)
  # keep noise out of expected core broad box, and old-hole region
  noise_mask[:,:10]=False;noise_mask[:,-10:]=False;noise_mask[:,13:20]=False
  f0=base0+0 # amp0 scale by dBZ offset? linear generated below
  # Make f0 by linear amp0, current 5 linear
  lin0=dbz_to_echo(base0,min_dbz=-10,max_dbz=70)*amp0/5
  lin1=dbz_to_echo(base1,min_dbz=-10,max_dbz=70)
  lin2=dbz_to_echo(base2,min_dbz=-10,max_dbz=70)
  from advar.physics import echo_to_dbz
  f0=echo_to_dbz(lin0,min_dbz=-10,max_dbz=70); f1=echo_to_dbz(lin1,min_dbz=-10,max_dbz=70);f2=echo_to_dbz(lin2,min_dbz=-10,max_dbz=70)
  f1[noise_mask]=35.
  f1[:,13:20]=float('nan')
  # Make a low echo, latest-observation gap away from detected cores so both pairs remain available.
  f1[:,50:54]=0.0
  f2[:,50:54]=float('nan')
  frames=torch.stack((f0,f1,f2)); cfg=NowcastConfig(minimum_phase_correlation_psr=0.,phase_correlation_sidelobe_radius_px=2,pair_echo_dilation_px=0,minimum_growth_overlap_support=1.,horizon_minutes=10)
  prep=prepare_input(frames,cfg);lin=dbz_to_echo(prep.frames_dbz,min_dbz=cfg.min_dbz,max_dbz=cfg.max_dbz)
  e1=_estimate_available_pair(prep.frames_dbz,prep.observed_mask,lin,1,2,cfg,None);e2=_estimate_available_pair(prep.frames_dbz,prep.observed_mask,lin,0,2,cfg,None)
  if e1 is None or e2 is None: continue
  out=nowcast(frames,cfg);m=out.metadata
  if m.motion_pair_selection is not m.growth_pair_selection:
    print('amp',amp0,'n',n,'point',float(out.state.echo_linear[20,51]),'psr',float(e1[2]),float(e2[2]),'motion',m.motion_pair_selection,'growth',m.growth_pair_selection,'disp',out.state.displacement_yx.tolist(),'g',float(out.state.log_growth_per_step),'est',float(e1[1].value),float(e2[1].value),'sup',float(e1[1].overlap_support),float(e2[1].overlap_support))
