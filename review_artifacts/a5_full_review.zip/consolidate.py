"""Package the bounded A5 investigation; never modify product files."""
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

repo = Path('/Users/yhlee/ADVAR')
root = Path('/tmp/advar-a5-review')
out = repo / 'review_artifacts'

# Each tuple is (root status, root priority, adjudication/scope), in report order.
# Original reviewer text is retained in the archive; these are the final judgments.
decisions = {
 'artifacts': [('boundary','P3','Re-signed inconsistent duplicate metadata; nested numerical replay remains valid and downstream FSO rejects the false-negative flag.')],
 'cli': [('confirmed','P2','Input artifact is overwritten by --report, then revalidation fails; scratch-only public CLI probe.'),('boundary','P3','Forced concurrent parent symlink replacement; not an ordinary immutable input path.'),('unproven',None,'Cross-case shared files can be intentional. No independent-case or uniqueness promise was established.')],
 'geometry_build': [('withdrawn',None,'Projected-metre input is a documented caller precondition; the resolver does not certify arbitrary CRS.'),('known_scope',None,'Existing DEP-002 in nonauthoritative historical deployment scaffold; not a new P0 current-product defect.')],
 'intervention': [('boundary','P2','Supported separate raw/source masks permit a no-effect raw correction with zero physical norm; normal pre-intersected producers limit occurrence.'),('boundary','P3','Wrong-type raw analysis JSON; typed AnalysisConfig already rejects it.')],
 'lab_ci': [('unproven',None,'Operator benchmark memory preflight opportunity. Post-run RSS/time thresholds are not proven hard input budgets; no OOM exercised.'),('confirmed','P3','Optional MPS workflow has unpinned Torch resolution; reproducibility issue, not a demonstrated backend numerical failure.')],
 'ledger_1': [('confirmed','P3','Accepted upper-case key hex disagrees with lower-case receipt producer; availability/config normalization.'),('confirmed','P3','Aware timestamps with different offsets sort incorrectly as raw strings.'),('boundary','P3','Wrong annotated provenance field type; no numerical or compatibility bypass demonstrated.')],
 'ledger_2': [('boundary','P2','Cross-plan signed coverage accepted at operational provenance boundary; final normal holdout rechecks plan/mask. Current operational inference unsupported; no full decision fixture.'),('boundary','P2','Concurrent identical provenance append fails idempotent history side effect; retry availability, not wrong forecast.')],
 'ledger_3': [('unproven',None,'Static final-check timing hypothesis. A check always has a later return interval; no full public race or linearization-point violation established.'),('unproven',None,'Existing crash/retry candidate; source publication order known, typed process-death/restart reproduction still missing.')],
 'ledger_4': [('boundary','P3','Malformed externally supplied snapshot; normal producer has nonempty active support and masks maps.'),('boundary','P3','Malformed tile norms can disagree with maps; normal producer derives them correctly.'),('boundary','P3','Malformed impact can disagree with map times innovation; normal producer guarded.')],
 'nowcast_1': [('confirmed','P2','Root reran public variational_nowcast: omitted quality rejected, explicit source-masked zero quality accepted.')],
 'nowcast_2': [('unproven','P3','Initial same-coordinate source-time/lead-time comparison invalid. Correct remap found no valid cell composed entirely of undefined state. Only configurable cutoff semantics remains.')],
 'numerics': [],
 'promotion_1': [('boundary','P3','Coverage caller metadata accepted early, but final holdout compares input/full digests (13729-13737); original unguarded-scoring claim narrowed.'),('boundary','P3','Malformed duplicate site/time plan rejected later by derivation; early-validation consistency.'),('confirmed','P2','Root public probes: ordinary FP16 256x256 failure; FP32 representable weighted result becomes inf, masked-out extreme finite prediction produces NaN.')],
 'promotion_2': [('boundary','P3','Availability timestamp mismatch accepted before scoring; final promotion rejects it. No final statistical bypass.')],
 'promotion_3': [('source_confirmed','P2','Floor indexing confirmed in helper and caller traced. Full signed public holdout fixture not assembled.'),('source_confirmed','P2','Publication vs scoring support mismatch confirmed in helper/caller; full signed public promotion not executed.'),('theory_followup','P2','Point weights exclude all censored samples. Need event-specific interval/threshold semantics; never treat every censored sample as known clear. Full public promotion counterexample absent.')],
 'promotion_4': [],
 'promotion_5': [('boundary','P3','Signed wrong digest accepted offline; ordinary issuer writes current digest and current operational inference unsupported.'),('boundary','P3','Signed sequence-2/genesis inconsistency accepted offline; live ledger checks predecessor.'),('boundary','P3','Signed expiry pair outside normal issuer contract; runtime closure/file metadata patched in probe. No live deployment claim.')],
 'regression_gaps': [('test_note',None,'Local zero-background test weak; other control/JVP tests partly cover mutant.'),('test_note',None,'Local finite-only test weak; exact observation residual oracles exist elsewhere.'),('test_note',None,'Local zero-residual/self-score test weak; nonuniform nonzero M0 oracles exist elsewhere.')],
 'runtime': [('boundary','P3','Synthetic ldd unresolved-entry omission; known historical native-closure concern, not an actual broken Linux runtime.'),('boundary','P3','FIFO helper hang reachable from stdlib or metadata-owned files in malformed runtime; normal regular-file wheels unaffected.'),('boundary','P3','Explicit moved= wrong-shape diagnostic input; internal normal nowcast constructs the matching grid.')],
 'sensitivity_1': [('confirmed','P1','Root reran current v22 public fixture; spatial quality/std omission confirmed. Temporal runtime role requires explicit separation from source-selection certification.')],
 'sensitivity_2': [('boundary','P3','torch.equal dtype-insensitivity at standalone replay boundaries; normal current VerificationBundle dtype guard rejects these mutations.')],
 'sensitivity_3': [('confirmed','P1','Root reran successful public removal vs re-inferred retained prior: scores .04431874046394474 vs .015242213929648809. Separate source-mask omission less fully exercised.')],
 'sensitivity_4': [('confirmed','P2','Partial-prior fallback physical channel missing despite +.01 actual initial-state change. Exploratory FSOI uses relaxed curvature tolerance; branch unknown, not certified learning.'),('diagnostic_question','P3','Zero Taylor delta measures no variation; trivial linearity=1 alone is not an independent validation. Config semantics, not forecast arithmetic.')],
 'test_ledger': [('test_note',None,'Migration fixture has no historical rows; not a reproduced data-loss bug.'),('test_note',None,'Clock-rejection test lacks rollback assertions; not a reproduced commit-after-rejection.'),('boundary','P3','Standalone decoded evaluation-list binding deserves direct negative test; current main promotion loader does check list/digests.')],
 'test_nowcast': [('unproven',None,'Boolean-as-float permissiveness alone is not a demonstrated numeric failure.'),('boundary','P3','Rehashed wrong-type PSR metadata; ordinary metadata producer uses expected type.')],
 'test_promotion_1': [('test_note',None,'Subset of exact-type regression cases; no runtime bypass proven.'),('test_note',None,'Unpatched end-to-end replay exists. Independent final score oracle remains a narrower opportunity.'),('test_note',None,'Specific tests stop before persistence; do not infer all durable paths are untested.')],
 'test_promotion_2': [('test_note',None,'Named test patches scorer; an unpatched integration test exists at 3270-4880.'),('test_gap','P3','Retain PIT-value oracle gap only. Independent NLL oracles reject constant nll=1.'),('test_gap','P3','Full family/key oracle weak; other finite-sample bound and bootstrap-invariance tests exist.')],
 'test_promotion_3': [('test_note',None,'Geometry names hide deliberate unsupported deployment stop; no current unsafe deployment.'),('boundary','P3','Forged frozen single-site geometry contract reaches resolver; ordinary constructors and holdout plan digest guard present.'),('test_note',None,'Tautological positive catalog test; producer has real mismatch checks.')],
 'test_promotion_4': [('source_confirmed','P2','README diagnostic-only joint-min conflicts with current conjunctive gate. Helper numbers/caller confirmed, full signed alternate-probability fixture absent.'),('boundary','P3','Explicit empty preflight maps accepted; normal compute path generates complete maps.')],
 'test_sensitivity_1': [('duplicate','P1','Coverage evidence for A5-01; not a second product defect.'),('test_gap','P3','M0 whitened numerical scale oracle weak, producer test currently availability focused.'),('test_gap','P3','Current-generation weight composition needs independent numeric expectation; A5-01 is concrete motivating case.')],
 'test_sensitivity_2': [('confirmed','P2','Root reran same-adjoint crosscheck: 28 accepted censored cells, public map 0 vs unmasked max195673.1732. Nondefault thresholds, frozen branch unknown.'),('unproven',None,'Boolean numeric input permissiveness does not itself establish numerical/learning failure.')],
 'test_variational': [('test_gap','P3','Independent Hessian and zero-information covariance tests exist. Nontrivial public posterior-to-physical conversion remains weak.'),('test_gap','P3','Named polished diagnostic test self-consistent; other robust-gradient and sensitivity stationarity oracles partly cover path.'),('test_note',None,'Specific saturation rejection test absent; no runtime failure established by test absence alone.')],
 'variational_1': [('boundary','P3','Explicit extreme footprint/tile settings; allocation calls intercepted before OOM, no ordinary-case resource failure.'),('confirmed','P2','Crossreview reached exact cap with normal estimator initialization; inward robust objective AD near0 vs finite decrease. One-sided boundary issue, no final solver false acceptance reproduced.')],
 'variational_2': [('confirmed','P3','Root public raw20/21/20 inputs, FP32delta2e38 orFP64delta1e308: expected quadratic limit1.125, currentcost/gradient0; defaultdelta unaffected.')],
}

manifest = json.loads((root/'manifest.json').read_text())
for item in manifest['files']:
    assert hashlib.sha256((repo/item['file']).read_bytes()).hexdigest() == item['sha256'], item['file']

reports = {p.stem: json.loads(p.read_text()) for p in (root/'reports').glob('*.json')}
assert len(reports) == 34 and reports.keys() == decisions.keys(), (len(reports), reports.keys()-decisions.keys())
adjudications = []
for agent, report in sorted(reports.items()):
    assert len(report['findings']) == len(decisions[agent]), agent
    for index, (finding, decision) in enumerate(zip(report['findings'], decisions[agent]), 1):
        status, priority, note = decision
        adjudications.append(dict(agent=agent, finding_index=index, title=finding['title'],
                                  reviewer_severity=finding['severity'], root_status=status,
                                  root_priority=priority, root_note=note,
                                  location=finding['location'], report=f'reports/{agent}.json'))

freeze = subprocess.check_output(['uv','pip','freeze','--python',str(repo/'.venv/bin/python')], text=True, cwd=repo)
(root/'environment-after.txt').write_text(freeze)
assert freeze == (root/'environment-before.txt').read_text(), 'environment changed'
assert not subprocess.check_output(['git','diff','--name-only'],cwd=repo,text=True).strip(), 'tracked changes'

coverage = json.loads((root/'coverage.json').read_text())
assert all(f['covered_lines'] == f['lines'] for f in coverage['files'])
# Independently reconstruct coverage from the final read logs, not just the earlier summary.
source_hashes = {f['file']:f['sha256'] for f in manifest['files']}
covered = {f['file']:set() for f in manifest['files']}
read_count = 0
for p in (root/'probes').glob('*/reads.jsonl'):
    for line in p.read_text().splitlines():
        row = json.loads(line)
        if row['file'] in source_hashes:
            assert row['sha256'] == source_hashes[row['file']]
            covered[row['file']].update(range(row['start'],row['end']+1))
            read_count += 1
for f in manifest['files']:
    assert set(range(1,f['lines']+1)) <= covered[f['file']], f['file']
(root/'final_coverage_check.json').write_text(json.dumps(dict(
    files=len(covered), total_lines=sum(f['lines'] for f in manifest['files']),
    logged_read_calls=read_count, hash_mismatches=0, missing_lines=0),indent=2)+'\n')
ci = {}
for label, run in [('main_2398e5f','33993713947'),('pr158_286c0c9','33996929420')]:
    data = json.loads(subprocess.check_output(['gh','run','view',run,'--json','headSha,status,conclusion,jobs,url'],text=True,cwd=repo))
    data['jobs']=[{k:j[k] for k in ('name','status','conclusion','startedAt','completedAt','url')} for j in data['jobs']]
    ci[label] = data
    (root/(label+'_ci.json')).write_text(json.dumps(data,indent=2)+'\n')

summary = dict(
    base_commit=manifest['base'], reviewed_at_utc=datetime.now(timezone.utc).isoformat(),
    purpose='Additional investigation; product fixes remain open in FIFTH_CODE_REVIEW_CHECKLIST.md',
    agent_model='gpt-5.6-luna', reasoning_effort='xhigh', agent_count=34,
    scope={'git_tracked_files':len(manifest['files']), 'source_read_log_lines':sum(f['lines'] for f in manifest['files']),
           'all_assigned_ranges_covered':True, 'coverage_is_not_correctness_proof':True,
           'not_run':['whole local baseline','real radar hindcast','MPS/CUDA end-to-end']},
    environment={'python':'3.12.13','torch':'2.13.0','probe_backend':'CPU','package_manifest_unchanged':True},
    product_source_changed=False, original_reports=34, status_counts=dict(Counter(x['root_status'] for x in adjudications)),
    counts_note='Reviewer findings are not deduplicated production-bug counts; priorities describe only the stated scope.',
    source_manifest='manifest.json', coverage='coverage.json', ci=ci,
    root_reproduced=['nowcast_1/source_mask_default_quality.py','root/huber_public_input.py','root/weighted_loss_probe.py',
                     'sensitivity_1/v16_expected_probe.py','sensitivity_3/exo_wrong_impact.py',
                     'sensitivity_3/crosscheck_sensitivity_2_same_adjoint.py','cli/report_collision.py'],
    strengths=['nonnegative direct remap and explicit boundary outflow','fixed GN operator and true PCG residual',
               'scale-normalized ensemble centering and stable core metrics','separate missing/clear/censored meanings',
               'fixed A/B baseline domain','conservative unknown P0 branch status'],
    retracted=['factor3 for conjunctive intersection-union skill gate','wrong caller CRS as a new product defect',
               'learned raw canonical fill must equal physical configurable clamp',
               'source-time and forecast-time masks can be compared without advection',
               'same-family rolling raw-slot overlap implies independent duplicate events'],
    adjudications=adjudications,
)
(root/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
(out/'a5_full_review.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:summary[k] for k in ('original_reports','scope','status_counts')},ensure_ascii=False))

# Every scratch file is review-owned. Exclude cache/bytecode; synthetic fixtures are not real radar data.
archive_path = out/'a5_full_review.zip'
with zipfile.ZipFile(archive_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    files = [p for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc']
    hashes = {}
    for p in sorted(files):
        rel = str(p.relative_to(root))
        data = p.read_bytes()
        archive.writestr(rel,data)
        hashes[rel] = hashlib.sha256(data).hexdigest()
    archive.write(repo/'FIFTH_CODE_REVIEW_CHECKLIST.md','FIFTH_CODE_REVIEW_CHECKLIST.md')
    archive.writestr('archive_member_sha256.json', json.dumps(hashes,sort_keys=True,indent=2)+'\n')
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    hashes = json.loads(archive.read('archive_member_sha256.json'))
    assert all(hashlib.sha256(archive.read(name)).hexdigest() == digest for name,digest in hashes.items())
print('archive',archive_path,'members',len(hashes),'sha256',hashlib.sha256(archive_path.read_bytes()).hexdigest())
