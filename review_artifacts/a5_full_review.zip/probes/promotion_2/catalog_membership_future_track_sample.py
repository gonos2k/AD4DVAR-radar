import sys
from dataclasses import replace

sys.path.insert(0, "/Users/yhlee/ADVAR/src")
sys.path.insert(0, "/Users/yhlee/ADVAR/tests")

from test_promotion import NeuralPriorPromotionTests
import advar.promotion as promotion_module


fixture = NeuralPriorPromotionTests("runTest")
holdout_plan = fixture.plan()
catalog_plan = holdout_plan.physical_event_catalog_plan
event_1 = fixture.event_catalog(1)
event_2 = fixture.event_catalog(2)
spatial_1 = fixture.event_spatial_evidence(
    event_1,
    case_id="case-1",
    full_analysis_input_digest=event_1.member_full_analysis_input_digests[0],
    source_object_evidence_digest="a" * 64,
)
spatial_2 = fixture.event_spatial_evidence(
    event_2,
    case_id="case-2",
    full_analysis_input_digest=event_2.member_full_analysis_input_digests[0],
    source_object_evidence_digest="b" * 64,
)
track = event_1.object_track_artifact
future_membership = replace(
    spatial_1,
    track_sample_index=1,
    track_sample_time=track.timestamps[1],
    track_object_mask_digest=track.object_mask_digests[1],
    source_object_evidence_digest=track.object_mask_digests[1],
)
result = promotion_module.PhysicalEventCatalogResult.from_plan(
    catalog_plan,
    event_evidences=(event_1, event_2),
    case_spatial_membership_evidences=(future_membership, spatial_2),
    cataloged_at="2026-08-10T03:00:00Z",
    adjudicator_private_key=fixture.regime_labeler_key(),
)
promotion_module.validate_physical_event_catalog_result(result, catalog_plan)
scoring_receipt = fixture.scoring_start_receipt_for(catalog_plan, result)
modified_manifest = replace(
    fixture.manifest(),
    physical_event_catalog_result=result,
    candidate_scoring_start_receipt=scoring_receipt,
    candidate_scoring_started_at=scoring_receipt.started_at,
)
promotion_module._validate_physical_event_catalogs_against_plan(
    modified_manifest,
    holdout_plan,
)
print("case_1_input_available=", future_membership.input_available_time)
print("case_1_track_sample_time=", future_membership.track_sample_time)
print("future_sample_after_input_available=", future_membership.track_sample_time > future_membership.input_available_time)
print("accepted_result_digest=", result.result_digest)
print("final_event_catalog_plan_check=", "validated")
