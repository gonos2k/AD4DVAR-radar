import sys

sys.path.insert(0, "/Users/yhlee/ADVAR/src")
sys.path.insert(0, "/Users/yhlee/ADVAR/tests")

from test_promotion import NeuralPriorPromotionTests
import advar.promotion as promotion_module


fixture = NeuralPriorPromotionTests("runTest")
original = fixture.plan()
unit_1, original_unit_2 = original.meteorological_sampling_units
shared_slot = unit_1.raw_observation_slot_digests[0]
new_unit_2 = promotion_module.MeteorologicalSamplingUnit(
    raw_observation_slot_digests=(
        shared_slot,
        original_unit_2.raw_observation_slot_digests[1],
        original_unit_2.raw_observation_slot_digests[2],
    ),
    canonical_geodetic_footprint_digest=(
        original_unit_2.canonical_geodetic_footprint_digest
    ),
)
union_slots = tuple(
    sorted(
        set(unit_1.raw_observation_slot_digests)
        | set(new_unit_2.raw_observation_slot_digests)
    )
)
original_family = original.promotion_experiment_family
training_receipt = fixture.training_raw_registry_receipt()
reservation = promotion_module.GlobalSamplingReservationReceipt.issue(
    experiment_scope_digest=promotion_module._promotion_experiment_scope_digest(
        holdout_cohort_digest=original_family.holdout_cohort_digest,
        parent_prior_digest=original_family.parent_prior_digest,
        trials=original_family.trials,
        winner_selection_rule_digest=original_family.winner_selection_rule_digest,
    ),
    raw_observation_slot_digests=union_slots,
    registry_id=original_family.global_sampling_reservation.registry_id,
    authority_id=original_family.global_sampling_reservation.authority_id,
    authority_private_key=promotion_module.Ed25519PrivateKey.from_private_bytes(
        b"\x22" * 32
    ),
    reserved_at=original_family.global_sampling_reservation.reserved_at,
    registry_sequence_number=training_receipt.registry_sequence_number + 1,
    previous_registry_root_digest=training_receipt.committed_registry_root_digest,
)
modified_family = promotion_module.PromotionExperimentFamily(
    holdout_cohort_digest=original_family.holdout_cohort_digest,
    meteorological_sampling_unit_digests=(
        unit_1.sampling_unit_digest,
        new_unit_2.sampling_unit_digest,
    ),
    raw_observation_slot_digests=union_slots,
    global_sampling_reservation=reservation,
    parent_prior_digest=original_family.parent_prior_digest,
    trials=original_family.trials,
    winner_selection_rule_digest=original_family.winner_selection_rule_digest,
)
print("accepted_family_digest=", modified_family.family_digest)
print("unit_slot_intersection=", sorted(set(unit_1.raw_observation_slot_digests) & set(new_unit_2.raw_observation_slot_digests)))
print("overlap_count=", len(set(unit_1.raw_observation_slot_digests) & set(new_unit_2.raw_observation_slot_digests)))
print("family_union_slot_count=", len(modified_family.raw_observation_slot_digests))
print("validated=", "yes")
