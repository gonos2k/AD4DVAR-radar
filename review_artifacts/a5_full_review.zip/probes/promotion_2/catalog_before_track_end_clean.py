import sys
import json
import sqlite3
import tempfile
from dataclasses import replace
from dataclasses import asdict
from pathlib import Path
sys.path.insert(0, '/Users/yhlee/ADVAR/src')
sys.path.insert(0, '/Users/yhlee/ADVAR/tests')
from test_promotion import NeuralPriorPromotionTests
from advar.promotion import (
    PhysicalEventCatalogResult,
    validate_physical_event_catalog_result,
    TrustedProcessStartReceipt,
    validate_trusted_process_start_receipt,
)
from advar.ledger import EpisodeLedger

fixture = NeuralPriorPromotionTests('runTest')
holdout_plan = fixture.plan()
plan = holdout_plan.physical_event_catalog_plan
event_1 = fixture.event_catalog(1)
event_2 = fixture.event_catalog(2)
spatial_1 = fixture.event_spatial_evidence(
    event_1,
    case_id='case-1',
    full_analysis_input_digest=event_1.member_full_analysis_input_digests[0],
    source_object_evidence_digest='a' * 64,
)
spatial_2 = fixture.event_spatial_evidence(
    event_2,
    case_id='case-2',
    full_analysis_input_digest=event_2.member_full_analysis_input_digests[0],
    source_object_evidence_digest='b' * 64,
)
result = PhysicalEventCatalogResult.from_plan(
    plan=plan,
    cataloged_at='2026-08-10T00:30:00Z',
    event_evidences=(event_1, event_2),
    case_spatial_membership_evidences=(spatial_1, spatial_2),
    adjudicator_private_key=fixture.regime_labeler_key(),
)
validate_physical_event_catalog_result(result, plan)
with tempfile.TemporaryDirectory(dir='/tmp/advar-a5-review/probes/promotion_2') as directory:
    ledger = EpisodeLedger(Path(directory))
    with sqlite3.connect(ledger.index_path) as connection:
        connection.execute(
            'INSERT INTO neural_prior_holdout_plans '
            '(plan_digest, plan_id, plan_json, policy_digest, '
            'trust_store_digest, registered_at, created_at) '
            'VALUES (?, ?, ?, ?, ?, ?, ?)',
            (
                holdout_plan.plan_digest,
                holdout_plan.plan_id,
                json.dumps(asdict(holdout_plan), sort_keys=True),
                '6' * 64,
                '7' * 64,
                holdout_plan.registered_at,
                '2026-08-07T00:00:00+00:00',
            ),
        )
    appended = ledger.append_physical_event_catalog_result(holdout_plan, result)
    print('ledger_append_result_digest=', appended)
receipt = TrustedProcessStartReceipt.from_plan(
    plan,
    catalog_result_digest=result.result_digest,
    process_kind='candidate_scoring',
    subject_digests=('c' * 64,),
    process_algorithm_digest=fixture.plan().scoring_algorithm_digest,
    process_runtime_digest=fixture.plan().scoring_runtime_digest,
    execution_contract_digest=fixture.plan().scoring_execution_contract_digest,
    job_id='candidate-scoring-job',
    launch_nonce='b' * 64,
    scheduler_sequence_number=2,
    previous_receipt_digest=None,
    started_at='2026-08-10T00:31:00Z',
    scheduler_private_key=fixture.scheduler_key(),
)
validate_trusted_process_start_receipt(receipt, plan, catalog_result=result)
print('accepted_result_digest=', result.result_digest)
print('cataloged_at=', result.cataloged_at)
print('event_end_times=', [event.end_time for event in (event_1, event_2)])
print('cataloged_before_event_end=', result.cataloged_at < event_2.end_time)
print('trusted_scoring_start_before_all_track_ends=', receipt.started_at < event_2.end_time)
print('start=', receipt.started_at, 'remaining_track_end=', event_2.end_time)
print('validated=', 'yes')
