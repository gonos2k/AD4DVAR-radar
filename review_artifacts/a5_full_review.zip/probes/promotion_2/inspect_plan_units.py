import sys
sys.path.insert(0, '/Users/yhlee/ADVAR/src'); sys.path.insert(0, '/Users/yhlee/ADVAR/tests')
from test_promotion import NeuralPriorPromotionTests
f=NeuralPriorPromotionTests('runTest'); p=f.plan()
print('cases', len(p.cases))
for c in p.cases:
 print(c.case_id, c.physical_event_digest, c.meteorological_sampling_unit_digest, c.input_plan_digest, c.issue_time)
print('units',len(p.meteorological_sampling_units))
for u in p.meteorological_sampling_units:
 print(u.sampling_unit_digest, u.raw_observation_slot_digests)
print('slots',len(p.raw_observation_slot_plans))
for s in p.raw_observation_slot_plans:
 print(s.slot_digest,s.radar_site_digest,s.acquisition_valid_time)
