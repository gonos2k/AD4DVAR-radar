import sys
from dataclasses import replace

sys.path.insert(0, "/Users/yhlee/ADVAR/src")
sys.path.insert(0, "/Users/yhlee/ADVAR/tests")

from test_promotion import NeuralPriorPromotionTests
import advar.promotion as promotion_module


fixture = NeuralPriorPromotionTests("runTest")
original = fixture.plan()
case_1, case_2 = original.cases
input_1, input_2 = original.input_plans
slots = original.raw_observation_slot_plans
shared = slots[0]
middle = replace(
    slots[3],
    radar_site_digest=shared.radar_site_digest,
    acquisition_valid_time="2026-08-09T12:00:00Z",
)
final = replace(slots[5], radar_site_digest=shared.radar_site_digest)
new_slots = (slots[0], slots[1], slots[2], middle, final)
new_input_2 = replace(
    input_2,
    valid_times=(
        shared.acquisition_valid_time,
        middle.acquisition_valid_time,
        final.acquisition_valid_time,
    ),
    observation_valid_time=final.acquisition_valid_time,
)
unit_1, _ = original.meteorological_sampling_units
unit_2 = promotion_module.MeteorologicalSamplingUnit(
    raw_observation_slot_digests=(shared.slot_digest, middle.slot_digest, final.slot_digest),
    canonical_geodetic_footprint_digest="6" * 64,
)
geometry_1, geometry_2 = original.range_geometry_contracts
geometry_2 = replace(
    geometry_2,
    radar_site_digest=geometry_1.radar_site_digest,
    radar_x_m=geometry_1.radar_x_m,
    radar_y_m=geometry_1.radar_y_m,
    radar_site_location_digest=geometry_1.radar_site_location_digest,
)
range_1, range_2 = original.range_band_contracts
range_2 = replace(
    range_2,
    grid_contract_digest=new_input_2.grid_contract_digest,
    range_geometry_contract_digest=geometry_2.contract_digest,
)
case_2 = replace(
    case_2,
    input_plan_digest=new_input_2.plan_digest,
    meteorological_sampling_unit_digest=unit_2.sampling_unit_digest,
    range_band_contract_digest=range_2.contract_digest,
)
new_cases = (case_1, case_2)
original_family = original.promotion_experiment_family
new_cohort = promotion_module._holdout_dataset_digest(new_cases)
training_receipt = fixture.training_raw_registry_receipt()
reservation = promotion_module.GlobalSamplingReservationReceipt.issue(
    experiment_scope_digest=promotion_module._promotion_experiment_scope_digest(
        holdout_cohort_digest=new_cohort,
        parent_prior_digest=original_family.parent_prior_digest,
        trials=original_family.trials,
        winner_selection_rule_digest=original_family.winner_selection_rule_digest,
    ),
    raw_observation_slot_digests=tuple(sorted(set(item.slot_digest for item in new_slots))),
    registry_id=original_family.global_sampling_reservation.registry_id,
    authority_id=original_family.global_sampling_reservation.authority_id,
    authority_private_key=promotion_module.Ed25519PrivateKey.from_private_bytes(b"\x22" * 32),
    reserved_at=original_family.global_sampling_reservation.reserved_at,
    registry_sequence_number=training_receipt.registry_sequence_number + 1,
    previous_registry_root_digest=training_receipt.committed_registry_root_digest,
)
family = promotion_module.PromotionExperimentFamily(
    holdout_cohort_digest=new_cohort,
    meteorological_sampling_unit_digests=(unit_1.sampling_unit_digest, unit_2.sampling_unit_digest),
    raw_observation_slot_digests=tuple(sorted(set(item.slot_digest for item in new_slots))),
    global_sampling_reservation=reservation,
    parent_prior_digest=original_family.parent_prior_digest,
    trials=original_family.trials,
    winner_selection_rule_digest=original_family.winner_selection_rule_digest,
)
modified = replace(
    original,
    cases=new_cases,
    input_plans=(input_1, new_input_2),
    raw_observation_slot_plans=new_slots,
    meteorological_sampling_units=(unit_1, unit_2),
    range_band_contracts=(range_1, range_2),
    range_geometry_contracts=(geometry_1, geometry_2),
    promotion_experiment_family=family,
)
promotion_module.validate_neural_prior_holdout_plan(modified)
print("accepted_plan_digest=", modified.plan_digest)
print("case_sampling_units=", [item.meteorological_sampling_unit_digest for item in modified.cases])
print("unit_slot_intersection=", sorted(set(unit_1.raw_observation_slot_digests) & set(unit_2.raw_observation_slot_digests)))
print("overlap_count=", len(set(unit_1.raw_observation_slot_digests) & set(unit_2.raw_observation_slot_digests)))
print("validated=", "yes")
