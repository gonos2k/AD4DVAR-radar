import sys
sys.path.insert(0, '/Users/yhlee/ADVAR/src'); sys.path.insert(0, '/Users/yhlee/ADVAR/tests')
from test_promotion import NeuralPriorPromotionTests
import advar.promotion as p
f = NeuralPriorPromotionTests('runTest'); policy = f.policy(for_decision_rule=True)
for values in ([1.0] * 20, [0.8] * 20):
 for cluster_count in (20, 1):
  clusters = tuple((format(i, '064x') if cluster_count == 20 else 'a' * 64) for i in range(20))
  lower, upper = p._event_fractional_rate_interval(values, clusters, policy, family_size=1)
  mean_upper = p._bounded_event_mean_upper_bound(values, clusters, policy, family_size=1, absolute_bound=1.0)
  print('value=', values[0], 'cluster_count=', len(set(clusters)), 'fractional_interval=', (lower, upper), 'mean_upper=', mean_upper)
