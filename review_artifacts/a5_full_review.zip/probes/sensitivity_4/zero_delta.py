import sys;sys.path.insert(0,'tests')
import torch
from dataclasses import replace
from test_sensitivity import _current_verification_bundle,result_for
from advar.nowcast import *
from advar.physics import dbz_to_echo
from advar.sensitivity import SensitivityConfig,compute_sensitivity_snapshot
config=NowcastConfig(horizon_minutes=20);latest=torch.full((8,8),20.,dtype=torch.float64)
grid=RadarGridTimeContract(valid_times=('2026-08-05T00:00:00Z','2026-08-05T00:10:00Z','2026-08-05T00:20:00Z'),dx_m=1000.,dy_m=1000.,projection='EPSG:5179',grid_hash='a'*64,spatial_grid_contract='radar-spatial-grid-identity-v6',grid_shape_yx=(8,8),projected_crs_digest=radar_projected_crs_semantic_digest('EPSG:5179'),metric_domain_digest=CURRENT_RADAR_METRIC_DOMAIN.digest,metric_domain_evidence_digest=CURRENT_RADAR_METRIC_DOMAIN_EVIDENCE.digest,cell_center_origin_xy_m=(1e6,2e6),grid_coordinate_dtype=RADAR_PROJECTED_GRID_COORDINATE_DTYPE,cell_center_convention=RADAR_PROJECTED_GRID_CELL_CENTER_CONVENTION)
echo=dbz_to_echo(latest,min_dbz=config.min_dbz,max_dbz=config.max_dbz);state=RadarState(echo,latest.new_zeros(2),latest.new_zeros(()));result=result_for(state,config,frames=torch.stack((latest,latest,latest)),grid_time_contract=grid)
support=torch.ones_like(latest);support[4:6]=.1;support[6:]=0.;result=forecast_from_state(state,replace(result.metadata,local_motion_verified_support=support,local_growth_verified_support=support,local_dynamics_verified_support=support),config,run=result.run)
truth=torch.full_like(result.forecast_dbz,10.);truth[:,4:]=30.;truth[1]+=2.;bundle=_current_verification_bundle(truth,valid_times=('2026-08-05T00:30:00Z','2026-08-05T00:40:00Z'),grid_time_contract=grid)
sc=SensitivityConfig(metric_names=('log_echo_mse',),full_map_lead_minutes=(10,20),tile_size=4,linearity_delta=(0.,0.,0.),require_verification_lineage=True)
s=compute_sensitivity_snapshot(latest,result,bundle,sensitivity_config=sc)
print('linearity_delta',sc.linearity_delta,'components',s.trust_components,'trust_score',s.trust_score,'scores',s.forecast_scores[:,0].tolist(),'control',s.control_sensitivity[:,0].tolist())
