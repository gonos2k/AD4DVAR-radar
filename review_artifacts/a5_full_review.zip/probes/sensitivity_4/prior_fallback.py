from dataclasses import replace
from pathlib import Path
import sys
sys.path.insert(0, 'tests')
import torch
import advar
assert Path(advar.__file__).resolve().parent == Path('/Users/yhlee/ADVAR/src/advar')
from test_sensitivity import VariationalFSOTests
from advar.nowcast import ForecastRunContract
from advar.variational import (
    NeuralPriorInferenceRunner, NeuralPriorStateContract,
    NeuralPriorProbabilityContract, neural_prior_state_censor_policy_digest,
    variational_nowcast,
)
from advar.sensitivity import (
    VariationalAdjointConfig, VariationalObservationPerturbation,
    compute_variational_fsoi,
)

class PartiallyValidPrior(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.register_buffer('anchor', torch.tensor(0.0, dtype=torch.float64))
    def forward(self, frames):
        mean = frames[0] + self.anchor
        std = torch.exp(0.02 * frames[0])
        valid = torch.ones_like(mean)
        valid[3, 3] = 0.0
        support = (mean >= 5.0).to(mean)
        event = torch.ones_like(mean)
        return mean, std, valid, support, event, mean, std

VariationalFSOTests.setUpClass()
frames = VariationalFSOTests.frames
nowcast = VariationalFSOTests.nowcast_config
analysis_config = VariationalFSOTests.analysis_config
sensitivity = VariationalFSOTests.sensitivity_config

def make_prior(frames):
    run = ForecastRunContract.from_inputs(nowcast, frames, torch.isfinite(frames), None)
    return NeuralPriorInferenceRunner(
        PartiallyValidPrior().eval(), lambda value: value, example_frames=frames,
        state_contract=NeuralPriorStateContract(
            state_product_digest='a'*64, state_qc_pipeline_digest='9'*64,
            state_mask_policy_digest='3'*64,
            state_censor_policy_digest=neural_prior_state_censor_policy_digest(
                detection_limit_dbz=5.0, censor_temperature_dbz=1.0,
                censored_background_policy=analysis_config.censored_background_policy,
                minimum_dbz=-10.0, maximum_dbz=70.0),
            support_threshold_dbz=5.0, minimum_state_dbz=-10.0,
            maximum_state_dbz=70.0, minimum_state_std_dbz=0.1,
            maximum_state_std_dbz=20.0, valid_decision_probability=0.6,
            support_decision_probability=0.7),
        probability_contract=NeuralPriorProbabilityContract(
            support_threshold_dbz=5.0, support_product_digest='a'*64,
            qc_pipeline_digest='9'*64, reflectivity_resolution_dbz=0.5,
            quantization_origin_dbz=-10.0),
        model_contract_digest='4'*64, feature_schema_digest='5'*64,
        training_manifest_digest='6'*64, dependency='radar_dependent'), run

runner, run = make_prior(frames)
application = runner.infer(frames, input_run=run, role='candidate')
forecast, analysis = variational_nowcast(
    frames, nowcast_config=nowcast,
    analysis_config=replace(analysis_config, maximum_outer_iterations=20),
    neural_prior=application)
lin = analysis.linearization
assert lin is not None
print('import', Path(advar.__file__).resolve())
print('accepted', analysis.converged, analysis.degraded)
print('base_fallback', float(lin.frozen.initial_background_dbz[3, 3]))
print('detected_prior_valid', bool(lin.observations.detected_mask[0, 3, 3]), bool(lin.frozen.neural_prior_valid_mask[3, 3]))
changed = frames.clone()
changed[0, 3, 3] += 0.01
runner2, run2 = make_prior(changed)
application2 = runner2.infer(changed, input_run=run2, role='candidate')
forecast2, analysis2 = variational_nowcast(
    changed, nowcast_config=nowcast,
    analysis_config=replace(analysis_config, maximum_outer_iterations=20),
    neural_prior=application2)
lin2 = analysis2.linearization
assert lin2 is not None
print('changed_accepted', analysis2.converged, analysis2.degraded)
print('changed_fallback', float(lin2.frozen.initial_background_dbz[3, 3]))
print('fallback_delta', float(lin2.frozen.initial_background_dbz[3, 3] - lin.frozen.initial_background_dbz[3, 3]))
delta = changed - frames
perturbation = VariationalObservationPerturbation.from_radar_dbz_delta(
    delta, lin, neural_prior_runner=runner, neural_prior_application=application)
print('physical_initial_channel', perturbation.initial_background_dbz[:, 3, 3].tolist())
verification = torch.where(torch.isfinite(forecast.forecast_dbz), forecast.forecast_dbz - 0.5, forecast.forecast_dbz)
fsoi = compute_variational_fsoi(
    forecast, analysis, verification, perturbation,
    sensitivity_config=sensitivity,
    adjoint_config=VariationalAdjointConfig(
        maximum_gauss_newton_relative_curvature_defect=1.0e9),
    neural_prior_runner=runner, neural_prior_application=application)
print('accepted_fsoi_initial_map_center', fsoi.observation.initial_background_dbz.maps[..., 3, 3].tolist())
print('accepted_fsoi_total_impact', fsoi.observation.total.sum_by_time.tolist())
print('accepted_fsoi_baseline_branch', fsoi.baseline_dynamics_branch_status)
