import types

import torch

from advar import promotion


cfg = types.SimpleNamespace(interval_minutes=30)
metric_config = types.SimpleNamespace(metric_domain="issued")
verification = types.SimpleNamespace(
    valid_mask=torch.tensor([[[True, True]]]),
    frames_dbz=torch.zeros((1, 1, 2)),
    metric_weight=torch.tensor([[[0.0, 1.0]]]),
)


def result(mask):
    return types.SimpleNamespace(
        run=types.SimpleNamespace(config=cfg),
        state=types.SimpleNamespace(echo_linear=torch.ones((1, 2))),
        valid_mask=mask,
    )


parent = result(torch.tensor([[[False, True]]]))
candidate = result(torch.tensor([[[True, True]]]))
parent_weights = promotion._resolved_forecast_domain_weights(
    parent, verification, (30,), metric_config
)
candidate_weights = promotion._resolved_forecast_domain_weights(
    candidate, verification, (30,), metric_config
)
print("actual_parent_issued", parent.valid_mask[0].tolist())
print("actual_candidate_issued", candidate.valid_mask[0].tolist())
print("parent_metric_support", (parent_weights > 0).tolist())
print("candidate_metric_support", (candidate_weights > 0).tolist())
print(
    "top_level_newly_issued_count",
    int(torch.count_nonzero((candidate_weights > 0) & ~(parent_weights > 0))),
)
print(
    "actual_newly_issued_count",
    int(torch.count_nonzero(candidate.valid_mask[0] & ~parent.valid_mask[0])),
)
