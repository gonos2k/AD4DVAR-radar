import torch


valid = torch.tensor([[True, True]])
quality = torch.ones((1, 2))
observation_state_is_censored = torch.tensor([[True, False]])
metric_weight = quality * (~observation_state_is_censored).to(quality)
support_target = valid & (torch.tensor([[-10.0, 12.0]]) >= 5.0)
prior_valid = valid & (metric_weight > 0.0)
print("metric_weight_for_censored_and_echo", metric_weight.tolist())
print("support_target_for_censored_and_echo", support_target.tolist())
print("uncertainty_evaluation_mask", prior_valid.tolist())
