import types

import torch

from advar import promotion
from advar.sensitivity import SensitivityConfig


cfg = types.SimpleNamespace(interval_minutes=30)
result = types.SimpleNamespace(
    run=types.SimpleNamespace(config=cfg),
    state=types.SimpleNamespace(echo_linear=torch.tensor(1.0)),
    valid_mask=torch.tensor([[[False, False]], [[True, True]]]),
)
verification = types.SimpleNamespace(
    valid_mask=torch.ones((2, 1, 2), dtype=torch.bool),
    frames_dbz=torch.zeros((2, 1, 2)),
)
metric_config = types.SimpleNamespace(metric_domain="issued")

print(
    "coverage_for_declared_45m",
    promotion._forecast_coverage(result, verification, (45,), metric_config).tolist(),
)
print(
    "coverage_for_declared_60m",
    promotion._forecast_coverage(result, verification, (60,), metric_config).tolist(),
)
print("resolved_frame_for_45m", 45 // cfg.interval_minutes - 1)
print("config_accepts_off_grid_lead", SensitivityConfig(full_map_lead_minutes=(45,)).full_map_lead_minutes)
