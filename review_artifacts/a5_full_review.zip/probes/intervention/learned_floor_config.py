import torch
from advar._learned_input import learned_radar_input_features
from advar.nowcast import NowcastConfig, ForecastRunContract, prepare_input

config = NowcastConfig(min_dbz=-20.0, max_dbz=70.0)
frames = torch.full((3, 2, 2), -15.0, dtype=torch.float64)
masks = torch.ones_like(frames, dtype=torch.bool)
masks[:, 0, 0] = False
run = ForecastRunContract.from_inputs(config, frames, masks, None)
features = learned_radar_input_features(
    torch.where(masks, frames, torch.full_like(frames, -10.0)),
    masks,
    torch.where(masks, masks.to(frames), torch.zeros_like(frames)),
    torch.where(masks, torch.full_like(frames, 2.0), torch.ones_like(frames)),
    torch.ones_like(masks),
)
prepared = prepare_input(frames, config, accepted_mask=masks)
print('config_min_dbz', config.min_dbz)
print('learned_invalid_dbz', float(features[0, 0, 0, 0]))
print('prepared_fields', tuple(prepared.__dataclass_fields__))
print('prepared_invalid_dbz', float(prepared.frames_dbz[0, 0, 0]))
print('run_integrity', 'yes' if run.validate_integrity() is None else 'no')
