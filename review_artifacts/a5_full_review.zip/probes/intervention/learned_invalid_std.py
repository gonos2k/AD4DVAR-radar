from pathlib import Path

import torch

import advar
from advar._learned_input import learned_radar_input_features


assert Path(advar.__file__).resolve().parent == Path("/Users/yhlee/ADVAR/src/advar")
frames = torch.full((3, 1, 1), -10.0, dtype=torch.float64)
qc = torch.zeros_like(frames, dtype=torch.bool)
quality = torch.zeros_like(frames)
source = torch.ones_like(frames, dtype=torch.bool)
std2 = torch.full_like(frames, 2.0)
std9 = torch.full_like(frames, 9.0)
features2 = learned_radar_input_features(frames, qc, quality, std2, source)
features9 = learned_radar_input_features(frames, qc, quality, std9, source)
print("invalid_feature_std2", features2[3, 0, 0, 0].item())
print("invalid_feature_std9", features9[3, 0, 0, 0].item())
print("features_equal", torch.equal(features2, features9))
