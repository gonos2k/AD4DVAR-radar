from pathlib import Path

import torch

import advar
from advar._learned_input import learned_radar_input_features
from advar.nowcast import NowcastConfig, prepare_input
from test_ledger import _prospective_run_and_context


assert Path(advar.__file__).resolve().parent == Path("/Users/yhlee/ADVAR/src/advar")
frames = torch.full((3, 2, 2), 100.0, dtype=torch.float64)
masks = torch.ones_like(frames, dtype=torch.bool)
features = learned_radar_input_features(
    frames,
    masks,
    masks.to(frames),
    torch.full_like(frames, 2.0),
    masks,
)
run, _, _, _ = _prospective_run_and_context(frames, masks)
run.validate_integrity()
prepared = prepare_input(frames, NowcastConfig(), accepted_mask=masks)
print("learned_features_dbz", features[0, 0, 0, 0].item())
print("prepared_observation_dbz", prepared.frames_dbz[-1, 0, 0].item())
print("run_integrity", "yes")
print("configured_max_dbz", NowcastConfig().max_dbz)
