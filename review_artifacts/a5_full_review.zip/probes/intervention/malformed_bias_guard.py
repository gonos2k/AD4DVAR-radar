import json
from dataclasses import replace
import torch
from advar._digest import json_digest
from advar.calibration import OperationalCalibrationManifest
from advar.intervention import (
    InterventionActionGenerator,
    InterventionInputContext,
    ProspectiveInterventionDecision,
    ReusableInterventionPolicyEvidence,
)
from advar.nowcast import ForecastRunContract, operational_runtime_profile_digest
from test_ledger import _prospective_run_and_context

class AddDbz(torch.nn.Module):
    def forward(self, context):
        delta = torch.zeros_like(context[0])
        delta[0, 0, 0] = 0.1
        return delta, torch.tensor(True, device=context.device)

frames = torch.zeros((3, 2, 2), dtype=torch.float64)
masks = torch.ones_like(frames, dtype=torch.bool)
base_run, _, plan_digest, _ = _prospective_run_and_context(frames, masks)
analysis = {
    'execution_mode': 'operational',
    'operational_calibration_id': 'prospective-test',
    'observation_common_bias_std_dbz': '1.0',
}
analysis_json = json.dumps(analysis, sort_keys=True, separators=(',', ':'))
manifest = OperationalCalibrationManifest.from_json(base_run.operational_calibration_manifest_json)
manifest = replace(
    manifest,
    profile_kind='p1',
    expected_runtime_profile_digest=operational_runtime_profile_digest(
        base_run.config,
        base_run.grid_time_contract,
        analysis_config=analysis,
    ),
)
run = ForecastRunContract.from_inputs(
    base_run.config,
    frames,
    masks,
    None,
    observation_quality_weight=masks.to(frames),
    observation_std_dbz=torch.full_like(frames, 2.0),
    grid_time_contract=base_run.grid_time_contract,
    analysis_config_json=analysis_json,
    analysis_config_digest=json_digest(analysis),
    analysis_input_digest='a'*64,
    operational_calibration_manifest_json=manifest.json,
    operational_calibration_manifest_digest=manifest.digest,
    operational_calibration_approval_digest=manifest.digest,
    operational_data_identity_json=base_run.operational_data_identity_json,
    operational_data_identity_digest=base_run.operational_data_identity_digest,
    input_plan_json=base_run.input_plan_json,
    input_plan_digest=base_run.input_plan_digest,
)
context = InterventionInputContext.from_inputs(
    frames_dbz=frames,
    observation_masks=masks,
    quality_weight=masks.to(frames),
    observation_std_dbz=torch.full_like(frames, 2.0),
    background_frames_dbz=None,
    radar_id='radar-1',
    applicability_mask=torch.ones_like(masks),
    run=run,
)
generator = InterventionActionGenerator.from_model(
    AddDbz().eval(), context,
    intervention_type='realized_sensor_correction',
)
policy = ReusableInterventionPolicyEvidence(
    policy_id='malformed-bias',
    action_generator_digest=generator.generator_digest,
    context_schema_digest=context.context_schema_digest,
    applicability_region_digest=context.applicability_region_digest,
    execution_policy_digest='e'*64,
    allowed_intervention_types=('realized_sensor_correction',),
    maximum_absolute_delta_dbz=2.0,
    maximum_changed_fraction=1.0,
    validation_evidence_digests=('d'*64,),
)
try:
    decision = ProspectiveInterventionDecision.from_policy(
        policy, action_generator=generator, decision_id='d1', case_id='case-1', radar_id='radar-1',
        intervention_type='realized_sensor_correction', actual_input_context=context,
        actual_input_before_run=run, input_plan_digest=plan_digest,
        decision_basis_digest='d'*64, decision_policy_digest='e'*64,
        decision_trust_store_digest='f'*64, decided_at='2026-08-08T00:22:00Z',
        observation_valid_time='2026-08-08T00:20:00Z', input_available_time='2026-08-08T00:21:00Z',
        decision_deadline='2099-08-08T00:30:00Z', publication_time='2099-08-08T01:00:00Z',
    )
    print('run_integrity', 'yes' if run.validate_integrity() is None else 'no')
    print('bias_field_type', type(json.loads(run.analysis_config_json)['observation_common_bias_std_dbz']).__name__)
    print('decision_accepted', True)
except Exception as error:
    print('decision_accepted', False)
    print(type(error).__name__, str(error))
