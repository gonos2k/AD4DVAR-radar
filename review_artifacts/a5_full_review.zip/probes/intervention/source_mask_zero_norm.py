from pathlib import Path

import torch
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

import advar
from advar.intervention import (
    InterventionActionGenerator,
    InterventionInputContext,
    ProspectiveInterventionDecision,
    RealizedInterventionReceipt,
    ReusableInterventionPolicyEvidence,
)
from advar.nowcast import ForecastRunContract
from test_ledger import _prospective_run_and_context


assert Path(advar.__file__).resolve().parent == Path("/Users/yhlee/ADVAR/src/advar")


class AddDbz(torch.nn.Module):
    def forward(self, context):
        delta = torch.zeros_like(context[0])
        delta[0, 0, 0] = 1.0
        return delta, torch.tensor(True, device=context.device)


frames = torch.zeros((3, 2, 2), dtype=torch.float64)
masks = torch.ones_like(frames, dtype=torch.bool)
base_run, _, plan_digest, _ = _prospective_run_and_context(frames, masks)
source = torch.zeros_like(masks)
quality = torch.zeros_like(frames)
raw_std = torch.full_like(frames, 2.0)
context_std = torch.ones_like(frames)


def make_run(values):
    return ForecastRunContract.from_inputs(
        base_run.config,
        values,
        masks,
        None,
        observation_quality_weight=quality,
        observation_std_dbz=raw_std,
        source_available_mask=source,
        grid_time_contract=base_run.grid_time_contract,
        analysis_config_json=base_run.analysis_config_json,
        operational_calibration_manifest_json=(
            base_run.operational_calibration_manifest_json
        ),
        operational_calibration_manifest_digest=(
            base_run.operational_calibration_manifest_digest
        ),
        operational_calibration_approval_digest=(
            base_run.operational_calibration_approval_digest
        ),
        operational_data_identity_json=base_run.operational_data_identity_json,
        operational_data_identity_digest=base_run.operational_data_identity_digest,
        input_plan_json=base_run.input_plan_json,
        input_plan_digest=base_run.input_plan_digest,
    )


def make_context(values, run):
    return InterventionInputContext.from_inputs(
        frames_dbz=values,
        observation_masks=masks,
        quality_weight=quality,
        observation_std_dbz=context_std,
        background_frames_dbz=None,
        radar_id="radar-1",
        applicability_mask=torch.ones_like(masks),
        run=run,
    )


before_run = make_run(frames)
before = make_context(frames, before_run)
after_frames = frames.clone()
after_frames[0, 0, 0] += 1.0
after_run = make_run(after_frames)
after = make_context(after_frames, after_run)
generator = InterventionActionGenerator.from_model(
    AddDbz().eval(),
    before,
    intervention_type="realized_sensor_correction",
)
policy = ReusableInterventionPolicyEvidence(
    policy_id="source-missing",
    action_generator_digest=generator.generator_digest,
    context_schema_digest=before.context_schema_digest,
    applicability_region_digest=before.applicability_region_digest,
    execution_policy_digest="e" * 64,
    allowed_intervention_types=("realized_sensor_correction",),
    maximum_absolute_delta_dbz=2.0,
    maximum_changed_fraction=1.0,
    validation_evidence_digests=("d" * 64,),
)
decision = ProspectiveInterventionDecision.from_policy(
    policy,
    action_generator=generator,
    decision_id="d1",
    case_id="case-1",
    radar_id="radar-1",
    intervention_type="realized_sensor_correction",
    actual_input_context=before,
    actual_input_before_run=before_run,
    input_plan_digest=plan_digest,
    decision_basis_digest="d" * 64,
    decision_policy_digest="e" * 64,
    decision_trust_store_digest="f" * 64,
    decided_at="2026-08-08T00:22:00Z",
    observation_valid_time="2026-08-08T00:20:00Z",
    input_available_time="2026-08-08T00:21:00Z",
    decision_deadline="2099-08-08T00:30:00Z",
    publication_time="2099-08-08T01:00:00Z",
)
receipt = RealizedInterventionReceipt.from_decision(
    decision,
    actual_input_before_context=before,
    actual_input_before_run=before_run,
    actual_input_after_context=after,
    actual_input_after_run=after_run,
    action_policy=policy,
    action_generator=generator,
    executor_key_id="exec",
    executor_trust_store_digest="0" * 64,
    executor_private_key=Ed25519PrivateKey.generate(),
    executor_sequence_number=1,
    applied_time="2026-08-08T00:23:00Z",
    receipt_time="2026-08-08T00:23:00Z",
)
print("source_mask_all_false", bool(torch.all(~source)))
print("context_observation_mask_all_true", bool(torch.all(before.observation_masks)))
print("fixed_context_unchanged", before_run.fixed_input_context_digest == after_run.fixed_input_context_digest)
print("learned_feature_digest_unchanged", before_run.learned_model_input_features_digest == after_run.learned_model_input_features_digest)
print("receipt_accepted", isinstance(receipt, RealizedInterventionReceipt))
print("safety_norm", decision.action_safety_diagnostics_json)
