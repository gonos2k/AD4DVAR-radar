import torch, json
from test_ledger import _prospective_run_and_context
run, ctx, plan, _ = _prospective_run_and_context(torch.zeros((3,2,2),dtype=torch.float64), torch.ones((3,2,2),dtype=torch.bool))
print(run.operational_calibration_manifest_json)
print(run.operational_data_identity_json)
