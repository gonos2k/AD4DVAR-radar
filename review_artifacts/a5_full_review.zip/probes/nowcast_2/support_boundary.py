import torch
from advar.nowcast import NowcastConfig, nowcast
from advar.physics import echo_to_dbz, remap

def one(dx):
    torch.manual_seed(0)
    h=w=48
    yy,xx=torch.meshgrid(torch.arange(h,dtype=torch.float64),torch.arange(w,dtype=torch.float64),indexing='ij')
    # multiple Gaussian echoes within patch, finite region
    base=torch.zeros(h,w,dtype=torch.float64)
    for y,x,s,a in [(18,17,3.0,30),(27,26,4.0,20),(35,17,2.0,15),(16,32,2.5,18),(32,33,3.5,25)]:
        base += a*torch.exp(-((yy-y)**2+(xx-x)**2)/(2*s*s))
    # positive in central finite window; leave zero below threshold but finite there
    m1=torch.zeros_like(base)
    m1[8:41,8:41]=1
    f1=base.clone(); f1[m1==0]=torch.nan
    # shift f1 by dx with zero pad; use linear echo as physical field
    moved=remap(base, torch.tensor([0.,dx],dtype=torch.float64))
    m2=remap(m1, torch.tensor([0.,dx],dtype=torch.float64))
    # make latest missing all positions where support maybe low, but retain patch
    f2=moved.clone(); f2[m2<=0.5]=torch.nan
    f0=torch.full_like(base,float('nan'))
    frames=torch.stack([f0,echo_to_dbz(f1,min_dbz=-10,max_dbz=70),echo_to_dbz(f2,min_dbz=-10,max_dbz=70)])
    cfg=NowcastConfig(minimum_phase_correlation_psr=0.0, phase_correlation_sidelobe_radius_px=2, pair_echo_dilation_px=0, minimum_growth_overlap_support=1.0, min_publish_support=.5, support_presence_threshold=.59, horizon_minutes=10)
    try:
      out=nowcast(frames,cfg)
      s=out.metadata.source_support
      print('dx',dx,'status',out.metadata.data_status,'sel',out.metadata.motion_pair_selection,'pair',out.metadata.motion_pair_count,'disp',out.state.displacement_yx.tolist(),'support minmax',float(s.min()),float(s.max()),'low count',int(((s>0)&(s<=cfg.support_presence_threshold)).sum()),'valid0',int(out.valid_mask[0].sum()),'obs path',out.metadata.observation_path,'obs sum',float(out.metadata.observation_source_support.sum()))
      vals=s[(s>0)&(s<=cfg.support_presence_threshold)]
      print('unique',torch.unique(s).tolist()[:30]); print('lowvals',vals[:20].tolist())
      if vals.numel():
        mask=(s>0)&(s<=cfg.support_presence_threshold)&out.valid_mask[0]
        print('published low',int(mask.sum()),'echo finite',bool(torch.isfinite(out.forecast_dbz[0][mask]).all()),'echo vals',out.forecast_dbz[0][mask][:10].tolist())
    except Exception as e:
      print('ERR',dx,type(e).__name__,e)
for dx in (.2,.4,.5,.6,.8,1.2):one(dx)
