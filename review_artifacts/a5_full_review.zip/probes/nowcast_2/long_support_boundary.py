import torch
from advar.nowcast import NowcastConfig, nowcast
from advar.physics import echo_to_dbz, remap

def one(dx,thr):
    h=w=48
    yy,xx=torch.meshgrid(torch.arange(h,dtype=torch.float64),torch.arange(w,dtype=torch.float64),indexing='ij')
    base=torch.zeros(h,w,dtype=torch.float64)
    for y,x,s,a in [(18,17,3.0,30),(27,26,4.0,20),(35,17,2.0,15),(16,32,2.5,18),(32,33,3.5,25)]:
        base += a*torch.exp(-((yy-y)**2+(xx-x)**2)/(2*s*s))
    m0=torch.zeros_like(base);m0[8:41,8:41]=1
    f0=base.clone();f0[m0==0]=torch.nan
    moved=remap(base,torch.tensor([0.,2*dx],dtype=torch.float64))
    m2=remap(m0,torch.tensor([0.,2*dx],dtype=torch.float64))
    f2=moved.clone();f2[m2<=thr]=torch.nan
    f1=torch.full_like(base,float('nan'))
    frames=torch.stack([echo_to_dbz(f0,min_dbz=-10,max_dbz=70), f1, echo_to_dbz(f2,min_dbz=-10,max_dbz=70)])
    cfg=NowcastConfig(minimum_phase_correlation_psr=0.,phase_correlation_sidelobe_radius_px=2,pair_echo_dilation_px=0,minimum_growth_overlap_support=1.,min_publish_support=.5,support_presence_threshold=.6,horizon_minutes=10)
    try:
      out=nowcast(frames,cfg); out.validate_issuance()
      s=out.metadata.source_support
      print('dx',dx,'mthr',thr,'sel',out.metadata.motion_pair_selection,'pairs',out.metadata.motion_pair_count,'disp',out.state.displacement_yx.tolist(),'sum',float(s.sum()),'unique',torch.unique(s).tolist()[:20],'low',int(((s>0)&(s<=cfg.support_presence_threshold)).sum()),'valid',int(out.valid_mask[0].sum()),'obs sum',float(out.metadata.observation_source_support.sum()),'path',out.metadata.observation_path)
      low=(s>0)&(s<=cfg.support_presence_threshold)
      print('low valid',int((low&out.valid_mask[0]).sum()),'low vals',s[low][:20].tolist()); print('valid low dbz',out.forecast_dbz[0][low&out.valid_mask[0]][:10].tolist()); print('low state echo',out.state.echo_linear[low][:10].tolist()); print('radar low',int((low&out.radar_state_anchored_valid_mask[0]).sum()),'dyn low',int((low&out.radar_dynamics_anchored_valid_mask[0]).sum()))
    except Exception as e: print('ERR',dx,thr,type(e).__name__,e)
for dx in (.2,.3,.4,.5,.6):
 for t in (.2,.4,.5,.7): one(dx,t)
