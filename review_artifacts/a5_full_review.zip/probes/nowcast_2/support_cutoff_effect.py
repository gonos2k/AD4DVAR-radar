import torch
from advar.nowcast import NowcastConfig, nowcast
from advar.physics import echo_to_dbz, remap

def frames_for_case():
    h=w=48
    yy,xx=torch.meshgrid(torch.arange(h,dtype=torch.float64),torch.arange(w,dtype=torch.float64),indexing='ij')
    base=torch.zeros(h,w,dtype=torch.float64)
    for y,x,s,a in [(18,17,3.0,30),(27,26,4.0,20),(35,17,2.0,15),(16,32,2.5,18),(32,33,3.5,25)]:
        base += a*torch.exp(-((yy-y)**2+(xx-x)**2)/(2*s*s))
    m0=torch.zeros_like(base);m0[8:41,8:41]=1
    f0=base.clone();f0[m0==0]=torch.nan
    moved=remap(base,torch.tensor([0.,.6],dtype=torch.float64))
    m2=remap(m0,torch.tensor([0.,.6],dtype=torch.float64))
    f2=moved.clone();f2[m2<=.7]=torch.nan
    f1=torch.full_like(base,float('nan'))
    return torch.stack([echo_to_dbz(f0,min_dbz=-10,max_dbz=70),f1,echo_to_dbz(f2,min_dbz=-10,max_dbz=70)])

frames=frames_for_case()
common=dict(minimum_phase_correlation_psr=0.,phase_correlation_sidelobe_radius_px=2,pair_echo_dilation_px=0,minimum_growth_overlap_support=1.,min_publish_support=.5,horizon_minutes=10)
hi=NowcastConfig(**common,support_presence_threshold=.6)
lo=NowcastConfig(**common,support_presence_threshold=1.e-6)
rhi=nowcast(frames,hi);rhi.validate_issuance()
rlo=nowcast(frames,lo);rlo.validate_issuance()
s=rhi.metadata.source_support
d=rhi.state.displacement_yx
low=(s>0)&(s<=hi.support_presence_threshold)
defined=(s>hi.support_presence_threshold).to(dtype=s.dtype)
def_at_lead=remap(defined,d)
v=rhi.valid_mask[0]
all_undef=v&(def_at_lead<=1e-12)
low_at_lead=remap(low.to(dtype=s.dtype),d)
both=v&rlo.valid_mask[0]&torch.isfinite(rhi.forecast_dbz[0])&torch.isfinite(rlo.forecast_dbz[0])
diff=(rhi.forecast_dbz[0]-rlo.forecast_dbz[0]).abs()
print('high support threshold',hi.support_presence_threshold,'low config',lo.support_presence_threshold)
print('high source low cells',int(low.sum()),'high valid lead1',int(v.sum()),'all-undefined valid lead1',int(all_undef.sum()),'defined remap min over valid',float(def_at_lead[v].min()))
print('high valid with low-source contribution',int((v&(low_at_lead>0)).sum()),'max dBZ difference there',float(diff[v&(low_at_lead>0)].max()))
print('same valid masks',bool(torch.equal(rhi.valid_mask,rlo.valid_mask)),'both finite cells',int(both.sum()),'max dBZ difference',float(diff[both].max()),'mean dBZ difference',float(diff[both].mean()),'changed >0.1 dBZ',int((both&(diff>.1)).sum()))
