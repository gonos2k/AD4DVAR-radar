"""Show that the assigned PIT tests accept a numerically wrong scorer."""
import importlib.util
from pathlib import Path
from unittest.mock import patch

import torch

path = Path("/Users/yhlee/ADVAR/tests/test_promotion.py")
spec = importlib.util.spec_from_file_location("test_promotion", path)
module = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(module)
promotion = module.promotion_module
original = promotion._truncated_gaussian_diagnostics


def wrong(location, scale, reference, **kwargs):
    # Preserve the product's invalid-lattice checks so only the numerical
    # oracle is mutated for the valid calls in the two tests.
    if reference.numel() == 3 or kwargs.get("reflectivity_resolution_dbz") == 1.0e-6:
        return torch.ones_like(reference, dtype=torch.float64), torch.zeros_like(
            reference, dtype=torch.float64
        )
    return original(location, scale, reference, **kwargs)


with patch.object(promotion, "_truncated_gaussian_diagnostics", side_effect=wrong):
    module.NeuralPriorPromotionTests(
        "test_conditional_pit_replaces_raw_truncated_z_score"
    ).run()
    module.NeuralPriorPromotionTests(
        "test_quantized_threshold_uses_interval_midpoint_pit"
    ).run()
print("both assigned PIT tests passed with nll=1 and pit=0 for valid inputs")
