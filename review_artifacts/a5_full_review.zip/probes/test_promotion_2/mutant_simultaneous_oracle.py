"""Show that the assigned simultaneous inference test ignores its bounds."""
import importlib.util
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

path = Path("/Users/yhlee/ADVAR/tests/test_promotion.py")
spec = importlib.util.spec_from_file_location("test_promotion", path)
module = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(module)

wrong_result = SimpleNamespace(test_count=420, method="exact_sign_enumeration", effective_replicates=4, bounds={}, comparison_bounds={})
with patch.object(module.promotion_module, "_simultaneous_uncertainty_upper_bounds", return_value=wrong_result):
    module.NeuralPriorPromotionTests(
        "test_simultaneous_uncertainty_count_covers_family_components_groups"
    ).run()
print("assigned simultaneous inference test passed with empty numerical bounds")
