import sys,json
sys.path.insert(0,'/Users/yhlee/ADVAR/src')
import torch
import advar.variational as v
rows=[]
for dtype,delta in [(torch.float32,2e38),(torch.float64,1e308)]:
 frames=torch.stack([torch.full((3,3),value,dtype=dtype) for value in [20.,21.,20.]])
 obs,frozen=v.prepare_analysis(frames,analysis_config=v.AnalysisConfig(pseudo_huber_delta=delta))
 control=v.initial_control(frozen)
 residual=v._whitened_observation_residual(control,obs,frozen)
 cost=v.robust_objective(control,obs,frozen)
 grad=torch.func.grad(lambda x:v.robust_objective(x,obs,frozen))(control)
 rows.append({'dtype':str(dtype),'delta':delta,'raw_frames':[20.,21.,20.],'objective':float(cost),'quadratic_limit':float(.5*residual.double().square().sum()),'gradient_norm':float(grad.norm()),'finite_gradient':bool(grad.isfinite().all())})
print(json.dumps(rows,indent=2))
