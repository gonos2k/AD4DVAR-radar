"""Public API probes; all mathematical answers fit FP32, ordinary case fits FP16."""
import json
from pathlib import Path
import torch
from advar.promotion import weighted_training_target_loss

rows = []
for dtype in (torch.float16, torch.float32):
    prediction = torch.ones((256, 256), dtype=dtype, requires_grad=True)
    target = torch.zeros_like(prediction)
    quality = torch.ones_like(prediction)
    valid = torch.ones_like(prediction, dtype=torch.bool)
    try:
        loss = weighted_training_target_loss(prediction, target, valid, quality)
        rows.append(dict(case="256x256_unit_error", dtype=str(dtype), expected=1., actual=float(loss)))
    except ValueError as error:
        rows.append(dict(case="256x256_unit_error", dtype=str(dtype), expected=1., error=str(error)))

# A representable weighted answer, despite an unrepresentable unweighted square.
prediction = torch.tensor([1e20, 0.], dtype=torch.float32, requires_grad=True)
target = torch.zeros_like(prediction)
quality = torch.tensor([1e-10, 1.], dtype=torch.float32)
valid = torch.ones_like(prediction, dtype=torch.bool)
loss = weighted_training_target_loss(prediction, target, valid, quality)
reference = (quality.double() * (prediction.double() - target.double()).square()).sum() / quality.double().sum()
rows.append(dict(case="small_weight_large_finite_error", dtype="torch.float32", expected=float(reference), actual=str(float(loss))))

# Mask-first contract must not turn an excluded finite prediction into NaN loss.
valid = torch.tensor([False, True])
quality = torch.tensor([0., 1.], dtype=torch.float32)
loss = weighted_training_target_loss(prediction, target, valid, quality)
rows.append(dict(case="excluded_large_finite_prediction", expected=0., actual=str(float(loss))))
text = json.dumps(rows, indent=2, allow_nan=False)
print(text)
Path(__file__).with_suffix('.json').write_text(text + '\n')
