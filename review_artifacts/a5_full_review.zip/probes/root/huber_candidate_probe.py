import json,math
import torch
rows=[]
for dtype,delta,r in [(torch.float32,2e38,1.),(torch.float64,1e308,1.),(torch.float32,1e10,1e-18),(torch.float64,1e200,1e-100),(torch.float32,2.,1e20),(torch.float64,1e-200,1e200)]:
 x=torch.tensor(r,dtype=dtype,requires_grad=True);d=x.new_tensor(delta)
 m=torch.maximum(x.abs(),d)
 xn=x/m;dn=d/m
 denom=torch.hypot(xn,dn)+dn
 candidate=(d*xn)*(x/denom)
 original=d*(x*(x/(torch.hypot(x,d)+d)))
 # Python float reference scaled by whichever of r/d or d/r avoids overflow.
 if r<=delta:
  expected=r*(r/(math.hypot(r/delta,1.)+1.))
 else:
  expected=delta*(r/(math.hypot(1.,delta/r)+delta/r))
 rows.append({'dtype':str(dtype),'delta':delta,'residual':r,'original':float(original.detach()),'candidate':float(candidate.detach()),'reference':expected,'candidate_gradient':float(torch.autograd.grad(candidate,x)[0])})
print(json.dumps(rows,indent=2))
