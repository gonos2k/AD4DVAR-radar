import sys,json
from pathlib import Path
sys.path.insert(0,'/Users/yhlee/ADVAR/src')
from dataclasses import replace
import torch
import advar.variational as v
assert Path(v.__file__).resolve().is_relative_to(Path('/Users/yhlee/ADVAR/src'))
rows=[]
for dtype,delta in [(torch.float32,2e38),(torch.float64,1e308)]:
 config=v.AnalysisConfig(pseudo_huber_delta=delta)
 obs,frozen=v.prepare_analysis(torch.full((3,3,3),20.,dtype=dtype),analysis_config=config)
 control=v.initial_control(frozen)
 altered=replace(obs,dbz=obs.dbz+2.)
 residual=v._whitened_observation_residual(control,altered,frozen)
 cost=v.robust_objective(control,altered,frozen)
 gradient=torch.func.grad(lambda c:v.robust_objective(c,altered,frozen))(control)
 expected=.5*residual.double().square().sum()
 rows.append({'dtype':str(dtype),'delta':delta,'residual_min':float(residual.min()),'residual_max':float(residual.max()),'objective':float(cost),'quadratic_limit':float(expected),'gradient_finite':bool(torch.isfinite(gradient).all()),'gradient_norm':float(gradient.norm())})
print(json.dumps(rows,indent=2))
