import json
import sys
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
sys.path.insert(0, '/Users/yhlee/ADVAR/tests')
sys.path.insert(0, '/Users/yhlee/ADVAR/src')

from test_run_artifact import ForecastRunArtifactTests
from advar.variational import NeuralPriorInferenceRunner
from advar.promotion import _validate_operational_deployment_decision_certificate
from advar.promotion import validate_neural_prior_deployment_decision_artifact
import advar.promotion as promotion
import advar.ledger as ledger


fixture = ForecastRunArtifactTests('runTest')
frames = fixture.frames()
input_run = fixture._current_provenance_run(frames)
runner = NeuralPriorInferenceRunner(
    fixture._Prior().eval(),
    lambda value: value[0],
    example_frames=frames,
    state_contract=fixture._state_contract(),
    probability_contract=fixture._probability_contract(),
    model_contract_digest='2' * 64,
    feature_schema_digest='3' * 64,
    training_manifest_digest='4' * 64,
    allow_constant_uncertainty=True,
    dependency='radar_dependent',
)
selection = fixture._deployment_selection(runner, input_run, frames)
artifact = json.loads(selection.deployment_decision_artifact_json)
cert_values = dict(artifact['operational_decision_certificate'])
cert_values.pop('certificate_digest')
cert = __import__('advar.promotion', fromlist=['_operational_deployment_decision_certificate_from_payload'])._operational_deployment_decision_certificate_from_payload(cert_values)
decision_core = dict(artifact)
for key in (
    'operational_decision_certificate',
    'operational_decision_publication_receipt',
    'operational_decision_activation_receipt',
    'operational_decision_commit_authorization_receipt',
):
    decision_core.pop(key)
trust = fixture._deployment_certificate_trust()
print('original certificate validates')
_validate_operational_deployment_decision_certificate(cert, decision_payload=decision_core, authority_trust_store=trust)
print('embedded trust digest', cert.authority_trust_store_digest)
forged_values = dict(cert.payload)
forged_values['authority_trust_store_digest'] = '8' * 64
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
signer = Ed25519PrivateKey.from_private_bytes(b'\x05' * 32)
forged_values['authority_signature_hex'] = signer.sign(json.dumps({k:v for k,v in forged_values.items() if k != 'authority_signature_hex'}, sort_keys=True, separators=(',', ':')).encode()).hex()
forged = __import__('advar.promotion', fromlist=['_operational_deployment_decision_certificate_from_payload'])._operational_deployment_decision_certificate_from_payload(forged_values)
try:
    _validate_operational_deployment_decision_certificate(forged, decision_payload=decision_core, authority_trust_store=trust)
except Exception as e:
    print('forged rejected', type(e).__name__, str(e))
else:
    print('forged ACCEPTED')

forged_artifact = dict(artifact)
forged_artifact['operational_decision_certificate'] = forged.payload | {'certificate_digest': forged.certificate_digest}
# Reissue the dependent ledger receipts over the modified certificate so that
# the public artifact path sees the same complete signed chain.
pub_values = dict(artifact['operational_decision_publication_receipt'])
pub_values.pop('receipt_digest')
pub_orig = promotion._operational_decision_publication_receipt_from_payload(pub_values)
act_values = dict(artifact['operational_decision_activation_receipt'])
act_values.pop('receipt_digest')
act_orig = promotion._operational_decision_activation_receipt_from_payload(act_values)
auth_values = dict(artifact['operational_decision_commit_authorization_receipt'])
auth_values.pop('receipt_digest')
auth_orig = promotion._operational_decision_commit_authorization_receipt_from_payload(auth_values)
ledger_signer = promotion.Ed25519DeploymentAuthoritySigner(
    'test-ledger', Ed25519PrivateKey.from_private_bytes(b'\x03' * 32),
    fixed_signing_time=pub_orig.issued_at,
)
pub = promotion._issue_operational_decision_publication_receipt(
    forged, decision_row_committed_at=pub_orig.decision_row_committed_at,
    signer=ledger_signer, authority_trust_store=trust,
)
act = promotion._issue_operational_decision_activation_receipt(
    forged, pub, publication_payload_committed_at=act_orig.publication_payload_committed_at,
    activation_authorized_at=act_orig.activation_authorized_at,
    publication_guard_interval_seconds=act_orig.publication_guard_interval_seconds,
    committed_chain_root_digest=act_orig.committed_chain_root_digest,
    signer=ledger_signer, authority_trust_store=trust,
)
auth = promotion._issue_operational_decision_commit_authorization_receipt(
    forged, act, terminal_commit_authorized_at=auth_orig.terminal_commit_authorized_at,
    signer=ledger_signer, authority_trust_store=trust,
)
for name, value in (
    ('operational_decision_publication_receipt', pub),
    ('operational_decision_activation_receipt', act),
    ('operational_decision_commit_authorization_receipt', auth),
):
    forged_artifact[name] = value.payload | {'receipt_digest': value.receipt_digest}
forged_artifact_json = json.dumps(forged_artifact, sort_keys=True, separators=(',', ':'))
with (
    patch.object(promotion, '_load_promotion_deployment_authority_trust_store', return_value=trust),
    patch.object(promotion, '_load_learning_policy_trust_store', return_value=fixture._deployment_policy_trust(selection.deployment_decision_artifact_json)),
    patch.object(ledger, '_load_raw_ingestor_trust_store', return_value=SimpleNamespace(content_digest='9' * 64)),
    patch.object(ledger, '_load_training_target_source_trust_store', return_value=fixture._training_target_source_trust()),
):
    try:
        digest = validate_neural_prior_deployment_decision_artifact(
            forged_artifact_json,
            deployment_certificate_trust_store_path='/etc/advar/deployment-authorities.json',
            deployment_policy_trust_store_path='/etc/advar/deployment-policies.json',
            raw_ingestor_trust_store_path='/etc/advar/raw-ingestors.json',
            training_target_source_trust_store_path='/etc/advar/training-target-sources.json',
            require_current_runtime=False,
        )
    except Exception as e:
        print('public forged rejected', type(e).__name__, str(e))
    else:
        print('public forged ACCEPTED', digest)

# The standalone promotion-certificate validator has the analogous gap: a
# signed sequence >1 may still point at the genesis predecessor.  The live
# EpisodeLedger loader checks the predecessor row separately, but this
# validator is what artifact replay uses when no live ledger is requested.
promotion_cert = promotion._ledgered_promotion_deployment_certificate_from_payload(
    {k: v for k, v in artifact['promotion_deployment_certificate'].items()
     if k != 'certificate_digest'}
)
evidence = promotion._decode_current_neural_prior_promotion_evidence(
    promotion_cert.promotion_evidence_payload_json
)
old_promotion_receipt = promotion._ledger_issuance_receipt_from_payload(
    json.loads(promotion_cert.ledger_issuance_receipt_payload_json)
)
bad_ledger = promotion._issue_ledger_issuance_receipt(
    ledger_instance_digest=old_promotion_receipt.ledger_instance_digest,
    sequence_number=2,
    previous_certificate_digest=promotion.PROMOTION_DEPLOYMENT_CERTIFICATE_GENESIS_DIGEST,
    promotion_evidence_digest=evidence.promotion_evidence_digest,
    scoring_replay_bundle_digest=evidence.scoring_replay_bundle_digest,
    scoring_replay_archive_sha256=old_promotion_receipt.scoring_replay_archive_sha256,
    scoring_evaluation_payload_sha256=old_promotion_receipt.scoring_evaluation_payload_sha256,
    scoring_artifact_digest=evidence.scoring_artifact_digest,
    scoring_completion_receipt_digest=evidence.scoring_completion_receipt_digest,
    scoring_completion_completed_at=old_promotion_receipt.scoring_completion_completed_at,
    issued_at=old_promotion_receipt.issued_at,
    signer=promotion.Ed25519DeploymentAuthoritySigner(
        'test-ledger', Ed25519PrivateKey.from_private_bytes(b'\x03' * 32),
        fixed_signing_time=old_promotion_receipt.issued_at,
    ),
    authority_trust_store=trust,
)
bad_certificate = promotion._issue_ledgered_promotion_deployment_certificate(
    evidence,
    issued_at=cert.issued_at,
    ledger_issuance_receipt=bad_ledger,
    signer=promotion.Ed25519DeploymentAuthoritySigner(
        'test-promotion', Ed25519PrivateKey.from_private_bytes(b'\x04' * 32),
        fixed_signing_time=cert.issued_at,
    ),
    authority_trust_store=trust,
    raw_ingestor_trust_store_digest=evidence.raw_ingestor_trust_store_digest,
)
try:
    promotion._validate_ledgered_promotion_deployment_certificate(
        bad_certificate, authority_trust_store=trust, promotion_evidence=evidence
    )
except Exception as e:
    print('bad promotion chain rejected', type(e).__name__, str(e))
else:
    print('bad promotion chain ACCEPTED (sequence 2 points to genesis)')
