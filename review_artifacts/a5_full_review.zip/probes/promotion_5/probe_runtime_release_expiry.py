from pathlib import Path
import json
import os
import tempfile
from types import SimpleNamespace
from unittest.mock import patch

from test_review_legacy_loaders import _authority_fixture
import advar.promotion as promotion

authority = _authority_fixture()
release = promotion._issue_deployment_bundle_release_approval(
    deployment_bundle_digest='a' * 64,
    bundle_manifest_digest='b' * 64,
    source_commit='c' * 40,
    repository='review/repository',
    source_ref='refs/tags/review',
    platform='linux-x86_64-cpu',
    runtime_mode='deployable',
    expires_at='2026-09-07T00:00:00Z',
    signer=promotion.Ed25519DeploymentAuthoritySigner(
        'review-release', authority.release_key,
        fixed_signing_time='2026-08-09T00:00:44Z',
    ),
    authority_trust_store=authority.trust,
)
with patch.object(promotion, '_validate_deployment_bundle_release_approval'):
    runtime = promotion._issue_deployment_runtime_activation_receipt(
        release_approval=release,
        runtime_tree_digest='d' * 64,
        interpreter_closure_digest='e' * 64,
        installation_attestation_sha256='f' * 64,
        deployment_instance_digest='1' * 64,
        host_identity_digest='2' * 64,
        runtime_mode='deployable',
        activation_sequence_number=1,
        previous_activation_receipt_digest=(
            promotion.DEPLOYMENT_RUNTIME_ACTIVATION_GENESIS_DIGEST
        ),
        expires_at='2026-09-08T00:00:00Z',
        signer=promotion.Ed25519DeploymentAuthoritySigner(
            'review-runtime', authority.runtime_key,
            fixed_signing_time='2026-08-09T00:00:45Z',
        ),
        authority_trust_store=authority.trust,
    )
print('release expires', release.expires_at)
print('runtime expires', runtime.expires_at)
try:
    promotion._validate_deployment_runtime_activation_receipt(
        runtime,
        release_approval=release,
        authority_trust_store=authority.trust,
        required_valid_through='2026-09-06T00:00:00Z',
    )
except Exception as error:
    print('rejected', type(error).__name__, str(error))
else:
    print('ACCEPTED despite runtime expiry after release expiry')

with tempfile.TemporaryDirectory() as directory:
    release_path = Path(directory) / 'release.json'
    runtime_path = Path(directory) / 'runtime.json'
    release_path.write_bytes(
        (json.dumps(
            release.payload | {'approval_digest': release.approval_digest},
            sort_keys=True,
            separators=(',', ':'),
        ) + '\n').encode()
    )
    runtime_path.write_bytes(
        (json.dumps(
            runtime.payload | {'receipt_digest': runtime.receipt_digest},
            sort_keys=True,
            separators=(',', ':'),
        ) + '\n').encode()
    )
    real_fstat = os.fstat

    def root_owned_metadata(descriptor: int) -> SimpleNamespace:
        metadata = real_fstat(descriptor)
        return SimpleNamespace(
            st_mode=metadata.st_mode,
            st_uid=0,
            st_size=metadata.st_size,
            st_dev=metadata.st_dev,
            st_ino=metadata.st_ino,
            st_mtime_ns=metadata.st_mtime_ns,
        )

    with (
        patch.object(
            promotion,
            '_load_promotion_deployment_authority_trust_store',
            return_value=authority.trust,
        ),
        patch.object(promotion, 'validate_current_runtime_closure'),
        patch.object(promotion.os, 'fstat', side_effect=root_owned_metadata),
    ):
        try:
            loaded = promotion.load_deployment_runtime_activation_receipt(
                runtime_path,
                release_approval_path=release_path,
                authority_trust_store_path='/etc/advar/deployment-authorities.json',
                required_valid_through='2026-09-06T00:00:00Z',
            )
        except Exception as error:
            print('public loader rejected', type(error).__name__, str(error))
        else:
            print('public loader ACCEPTED', loaded.receipt_digest)
