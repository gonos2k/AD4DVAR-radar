import sys

sys.path.insert(0, "/Users/yhlee/ADVAR")
import torch
import advar

assert advar.__file__.startswith("/Users/yhlee/ADVAR/src/advar")
from tests.test_sensitivity import _current_verification_bundle
from advar.nowcast import (
    RadarGridTimeContract,
    CURRENT_RADAR_METRIC_DOMAIN,
    CURRENT_RADAR_METRIC_DOMAIN_EVIDENCE,
    RADAR_PROJECTED_GRID_COORDINATE_DTYPE,
    RADAR_PROJECTED_GRID_CELL_CENTER_CONVENTION,
    radar_projected_crs_semantic_digest,
)

grid = RadarGridTimeContract(
    valid_times=(
        "2026-08-05T00:00:00Z",
        "2026-08-05T00:10:00Z",
        "2026-08-05T00:20:00Z",
    ),
    dx_m=1000.0,
    dy_m=1000.0,
    projection="EPSG:5179",
    grid_hash="1" * 64,
    spatial_grid_contract="radar-spatial-grid-identity-v6",
    grid_shape_yx=(2, 2),
    projected_crs_digest=radar_projected_crs_semantic_digest("EPSG:5179"),
    metric_domain_digest=CURRENT_RADAR_METRIC_DOMAIN.digest,
    metric_domain_evidence_digest=CURRENT_RADAR_METRIC_DOMAIN_EVIDENCE.digest,
    cell_center_origin_xy_m=(1_000_000.0, 2_000_000.0),
    grid_coordinate_dtype=RADAR_PROJECTED_GRID_COORDINATE_DTYPE,
    cell_center_convention=RADAR_PROJECTED_GRID_CELL_CENTER_CONVENTION,
)
frames = torch.full((1, 2, 2), 10.0, dtype=torch.float64)
fresh = _current_verification_bundle(
    frames,
    valid_times=("2026-08-05T00:30:00Z",),
    grid_time_contract=grid,
    acquisition_time_offset_seconds=0.0,
)
stale = _current_verification_bundle(
    frames,
    valid_times=("2026-08-05T00:30:00Z",),
    grid_time_contract=grid,
    acquisition_time_offset_seconds=-60.0,
)
for name, bundle in (("fresh", fresh), ("stale", stale)):
    derivation = bundle.observation_error_derivation
    assert derivation is not None
    raw = derivation.raw_inputs
    print(name, "contract", derivation.plan.contract, raw.contract)
    print(name, "age", raw.acquisition_age_seconds.flatten().tolist())
    print(name, "quality", derivation.quality_weight.flatten().tolist())
    print(name, "std", derivation.observation_std_dbz.flatten().tolist())
    print(name, "metric", bundle.metric_weight.flatten().tolist())
