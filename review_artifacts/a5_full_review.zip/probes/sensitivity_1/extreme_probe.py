import sys
from dataclasses import replace

sys.path.insert(0, "/Users/yhlee/ADVAR")
import torch
import advar

assert advar.__file__.startswith("/Users/yhlee/ADVAR/src/advar")
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from tests.test_sensitivity import _current_verification_bundle
from advar.sensitivity import (
    VerificationObservationMaskEvidence,
    VerificationObservationDerivationInputs,
    derive_verification_observation_masks,
    derive_verification_observation_error,
)
from advar.nowcast import (
    RadarGridTimeContract,
    CURRENT_RADAR_METRIC_DOMAIN,
    CURRENT_RADAR_METRIC_DOMAIN_EVIDENCE,
    RADAR_PROJECTED_GRID_COORDINATE_DTYPE,
    RADAR_PROJECTED_GRID_CELL_CENTER_CONVENTION,
    radar_projected_crs_semantic_digest,
)

grid = RadarGridTimeContract(
    valid_times=(
        "2026-08-05T00:00:00Z",
        "2026-08-05T00:10:00Z",
        "2026-08-05T00:20:00Z",
    ),
    dx_m=1000.0,
    dy_m=1000.0,
    projection="EPSG:5179",
    grid_hash="1" * 64,
    spatial_grid_contract="radar-spatial-grid-identity-v6",
    grid_shape_yx=(2, 2),
    projected_crs_digest=radar_projected_crs_semantic_digest("EPSG:5179"),
    metric_domain_digest=CURRENT_RADAR_METRIC_DOMAIN.digest,
    metric_domain_evidence_digest=CURRENT_RADAR_METRIC_DOMAIN_EVIDENCE.digest,
    cell_center_origin_xy_m=(1_000_000.0, 2_000_000.0),
    grid_coordinate_dtype=RADAR_PROJECTED_GRID_COORDINATE_DTYPE,
    cell_center_convention=RADAR_PROJECTED_GRID_CELL_CENTER_CONVENTION,
)
bundle = _current_verification_bundle(
    torch.full((1, 2, 2), 10.0, dtype=torch.float64),
    valid_times=("2026-08-05T00:30:00Z",),
    grid_time_contract=grid,
)
derivation = bundle.observation_error_derivation
assert derivation is not None
old_plan = derivation.plan
old_evidence = derivation.raw_inputs.mask_derivation.raw_evidence
geometry = derivation.raw_inputs.mask_derivation.geometry
new_plan = replace(old_plan, maximum_acquisition_age_seconds=1.7e308)
private = Ed25519PrivateKey.from_private_bytes(b"\x39" * 32)
offset = torch.full_like(
    old_evidence.acquisition_time_offset_seconds_by_source,
    -1.0e308,
)
evidence = VerificationObservationMaskEvidence.issue(
    plan=new_plan,
    geometry=geometry,
    valid_times=old_evidence.source_identity.valid_times,
    acquisition_valid_times_by_source=(
        old_evidence.source_identity.acquisition_valid_times_by_source
    ),
    grid_contract_digest=old_evidence.source_identity.grid_contract_digest,
    radar_product_digest=old_evidence.source_identity.radar_product_digest,
    native_verification_source_identity_digest=(
        old_evidence.source_identity.native_verification_source_identity_digest
    ),
    source_registry=derivation.source_registry,
    source_authority_id=old_evidence.source_identity.source_authority_id,
    source_authority_private_key=private,
    source_observed_at=old_evidence.source_identity.source_observed_at,
    reflectivity_dbz_by_source=old_evidence.reflectivity_dbz_by_source,
    acquisition_time_offset_seconds_by_source=offset,
    observation_report_kind_by_source=old_evidence.observation_report_kind_by_source,
    source_availability_by_time=old_evidence.source_availability_by_time,
    beam_blockage_fraction_by_source=old_evidence.beam_blockage_fraction_by_source,
    attenuation_qc_score_by_source=old_evidence.attenuation_qc_score_by_source,
    range_elevation_validity_domain_digest=(
        old_evidence.range_elevation_validity_domain_digest
    ),
    beam_blockage_visibility_mask_digest=(
        old_evidence.beam_blockage_visibility_mask_digest
    ),
    spatial_correlation_block_digest=old_evidence.spatial_correlation_block_digest,
)
mask = derive_verification_observation_masks(
    plan=new_plan,
    raw_evidence=evidence,
    source_registry=derivation.source_registry,
    geometry=geometry,
)
raw = VerificationObservationDerivationInputs.from_mask_derivation(mask)
result = derive_verification_observation_error(
    plan=new_plan,
    raw_verification_source=raw,
    source_registry=derivation.source_registry,
)
print("contracts", new_plan.contract, raw.contract, mask.contract)
print("growth", new_plan.temporal_error_growth_dbz_per_second)
print("valid cells", int(result.valid_mask.sum()))
print("quality finite", bool(torch.isfinite(result.quality_weight).all()))
print("std finite", bool(torch.isfinite(result.observation_std_dbz).all()))
print("std", result.observation_std_dbz.flatten().tolist())
print("age", raw.acquisition_age_seconds.flatten().tolist())
