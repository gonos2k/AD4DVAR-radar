import sys

sys.path.insert(0, "/Users/yhlee/ADVAR")
import torch
import advar

assert advar.__file__.startswith("/Users/yhlee/ADVAR/src/advar")
from tests.test_sensitivity import _current_verification_bundle
from advar.nowcast import (
    RadarGridTimeContract,
    CURRENT_RADAR_METRIC_DOMAIN,
    CURRENT_RADAR_METRIC_DOMAIN_EVIDENCE,
    RADAR_PROJECTED_GRID_COORDINATE_DTYPE,
    RADAR_PROJECTED_GRID_CELL_CENTER_CONVENTION,
    radar_projected_crs_semantic_digest,
)

grid = RadarGridTimeContract(
    valid_times=(
        "2026-08-05T00:00:00Z",
        "2026-08-05T00:10:00Z",
        "2026-08-05T00:20:00Z",
    ),
    dx_m=1000.0,
    dy_m=1000.0,
    projection="EPSG:5179",
    grid_hash="1" * 64,
    spatial_grid_contract="radar-spatial-grid-identity-v6",
    grid_shape_yx=(2, 2),
    projected_crs_digest=radar_projected_crs_semantic_digest("EPSG:5179"),
    metric_domain_digest=CURRENT_RADAR_METRIC_DOMAIN.digest,
    metric_domain_evidence_digest=CURRENT_RADAR_METRIC_DOMAIN_EVIDENCE.digest,
    cell_center_origin_xy_m=(1_000_000.0, 2_000_000.0),
    grid_coordinate_dtype=RADAR_PROJECTED_GRID_COORDINATE_DTYPE,
    cell_center_convention=RADAR_PROJECTED_GRID_CELL_CENTER_CONVENTION,
)
bundle = _current_verification_bundle(
    torch.full((1, 2, 2), 10.0, dtype=torch.float64),
    valid_times=("2026-08-05T00:30:00Z",),
    grid_time_contract=grid,
    acquisition_time_offset_seconds=-60.0,
)
derivation = bundle.observation_error_derivation
assert derivation is not None
raw = derivation.raw_inputs
mask = raw.mask_derivation
assert mask is not None
evidence = mask.raw_evidence
_, indices, _, _, _, _, ranges, elevations, blockage, attenuation = (
    advar.sensitivity._selected_verification_spatial_evidence(evidence)
)
effective_range = torch.gather(
    evidence.ground_range_upper_km_by_source,
    0,
    indices.unsqueeze(0),
).squeeze(0)
range_fraction = (effective_range / float(derivation.plan.maximum_range_km)).clamp(0.0, 1.0)
elevation_scale = max(
    abs(float(derivation.plan.minimum_elevation_deg)),
    abs(float(derivation.plan.maximum_elevation_deg)),
    torch.finfo(raw.frames_dbz.dtype).eps,
)
elevation_fraction = (elevations.abs() / elevation_scale).clamp(max=1.0)
range_reliability = (1.0 - 0.5 * range_fraction).clamp(0.5, 1.0)
spatial_quality = (
    attenuation * (1.0 - blockage) * range_reliability
).clamp(0.0, 1.0)
spatial_multiplier = (
    1.0 + range_fraction + elevation_fraction + blockage + (1.0 - attenuation)
)
age = raw.acquisition_age_seconds
temporal_decay = torch.exp(
    -torch.pow(
        age / float(derivation.plan.temporal_quality_decay_scale_seconds),
        float(derivation.plan.temporal_quality_decay_power),
    )
)
temporal_error = (
    float(derivation.plan.temporal_error_growth_dbz_per_second) * age
)
expected_quality = spatial_quality * temporal_decay
expected_std = torch.sqrt(
    (2.0 * spatial_multiplier).square() + temporal_error.square()
)
print("contract", derivation.plan.contract, raw.contract)
print("age", age.flatten().tolist())
print("actual quality", derivation.quality_weight.flatten().tolist())
print("expected quality", expected_quality.flatten().tolist())
print("actual std", derivation.observation_std_dbz.flatten().tolist())
print("expected std", expected_std.flatten().tolist())
print("metric weight", bundle.metric_weight.flatten().tolist())
