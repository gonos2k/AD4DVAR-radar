import json

import torch
from torch.func import jvp

from advar.nowcast import (
    NowcastConfig,
    RadarGridTimeContract,
    estimate_state,
)
from advar.variational import (
    AnalysisConfig,
    _bounded_vector_update,
    analysis_trajectory,
    prepare_analysis,
    robust_objective,
)


grid = RadarGridTimeContract(
    valid_times=(
        "2020-01-01T00:00:00Z",
        "2020-01-01T00:10:00Z",
        "2020-01-01T00:20:00Z",
    ),
    dx_m=1000.0,
    dy_m=1000.0,
    projection="EPSG:3857",
    grid_hash="0" * 64,
)

# A deterministic, finite radar sequence with one accepted pair.  The third
# frame is clear, so the long/recent alternatives do not replace the pair.
generator = torch.Generator().manual_seed(7)
size = 32
base = 8.0 + torch.rand((size, size), generator=generator, dtype=torch.float64) * 30.0
frames = torch.stack(
    (
        base,
        torch.roll(base, shifts=(2, 2), dims=(0, 1)),
        torch.zeros_like(base),
    )
)
base_config = NowcastConfig(minimum_phase_correlation_psr=2.0)
unbounded_state, metadata = estimate_state(
    frames,
    base_config,
    grid_time_contract=grid,
)
cap = float(
    grid.projected_ground_speed_upper_from_displacement(
        unbounded_state.displacement_yx,
        base_config.interval_minutes * 60,
    )
)
bounded_config = NowcastConfig(
    minimum_phase_correlation_psr=2.0,
    maximum_motion_speed_mps=cap,
)
observations, frozen = prepare_analysis(
    frames,
    nowcast_config=bounded_config,
    analysis_config=AnalysisConfig(motion_increment_scale_mps=1.0),
    grid_time_contract=grid,
)

control = torch.zeros(
    frozen.active_field_index.numel() + 3,
    dtype=frames.dtype,
)
baseline_velocity = grid.projected_velocity_xy(
    frozen.baseline_state.displacement_yx,
    bounded_config.interval_minutes,
)
inward_velocity_direction = -baseline_velocity / torch.linalg.vector_norm(
    baseline_velocity
)
inward_control = torch.zeros_like(control)
inward_control[-3:-1] = inward_velocity_direction


def public_displacement(value: torch.Tensor) -> torch.Tensor:
    return analysis_trajectory(value, frozen).displacement_yx


public_value, public_jvp = jvp(
    public_displacement,
    (control,),
    (inward_control,),
)
epsilon = 1.0e-4
public_inward_value = public_displacement(control + epsilon * inward_control)
public_inward_difference = (public_inward_value - public_value) / epsilon
objective_value = robust_objective(control, observations, frozen)
objective_gradient = torch.func.grad(
    lambda value: robust_objective(value, observations, frozen)
)(control)
objective_inward_ad_directional = torch.dot(
    objective_gradient,
    inward_control,
)
objective_inward_finite_difference = (
    robust_objective(control + epsilon * inward_control, observations, frozen)
    - objective_value
) / epsilon

direct_limit = torch.tensor(30.0, dtype=torch.float64)
direct_background = torch.tensor([30.0, 0.0], dtype=torch.float64)
direct_zero_control = torch.zeros(2, dtype=torch.float64)
direct_inward_control = torch.tensor([-1.0, 0.0], dtype=torch.float64)


def direct_update(value: torch.Tensor) -> torch.Tensor:
    return _bounded_vector_update(
        direct_background,
        value,
        2.0,
        direct_limit,
    )


direct_value, direct_jvp = jvp(
    direct_update,
    (direct_zero_control,),
    (direct_inward_control,),
)
direct_inward_value = direct_update(
    epsilon * direct_inward_control,
)
direct_inward_difference = (direct_inward_value - direct_value) / epsilon

result = {
    "conclusion": {
        "finding_is_mathematically_valid": True,
        "exact_boundary_is_reachable_from_supported_initialization": True,
        "scope": "Exact physical-speed equality only; interior tanh saturation remains asymptotic.",
        "kkt_interpretation": "At v=(L,0), minimizing v_x has feasible inward direction d=(-1,0) with negative one-sided derivative, so the boundary is not a KKT point. AD's zero radial derivative does not certify KKT stationarity.",
        "reachability_qualification": "The cap is selected equal to a finite estimate_state speed in this probe; all inputs are ordinary finite radar tensors and the accepted pair is not a huge forged dynamics control.",
    },
    "direct_boundary": {
        "value": direct_value.tolist(),
        "ad_jvp_inward": direct_jvp.tolist(),
        "finite_difference_inward": direct_inward_difference.tolist(),
        "physical_scale": 2.0,
    },
    "public_supported_initialization": {
        "configured_speed_cap_mps": cap,
        "unbounded_estimate_displacement_yx": unbounded_state.displacement_yx.tolist(),
        "baseline_displacement_yx": frozen.baseline_state.displacement_yx.tolist(),
        "baseline_velocity_xy_mps": baseline_velocity.tolist(),
        "baseline_speed_upper_mps": float(
            grid.projected_ground_speed_upper_from_displacement(
                frozen.baseline_state.displacement_yx,
                bounded_config.interval_minutes * 60,
            )
        ),
        "tendency_pair_count": metadata.tendency_pair_count,
        "data_status": metadata.data_status.value,
        "ad_jvp_inward_displacement": public_jvp.tolist(),
        "finite_difference_inward_displacement": public_inward_difference.tolist(),
        "robust_objective_at_boundary": float(objective_value),
        "robust_objective_ad_inward_directional": float(
            objective_inward_ad_directional
        ),
        "robust_objective_finite_inward_directional": float(
            objective_inward_finite_difference
        ),
        "speed_after_inward_step_mps": float(
            grid.projected_ground_speed_upper_from_displacement(
                public_inward_value,
                bounded_config.interval_minutes * 60,
            )
        ),
    },
}
print(json.dumps(result, sort_keys=True, indent=2))
