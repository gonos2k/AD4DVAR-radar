import torch

from advar.nowcast import ForecastRunContract, NowcastConfig
from advar.variational import AnalysisConfig, variational_nowcast


frames = torch.zeros((3, 4, 4), dtype=torch.float64)
observation_masks = torch.ones_like(frames, dtype=torch.bool)
source_available_mask = torch.ones_like(observation_masks)
source_available_mask[:, 0, 0] = False

try:
    ForecastRunContract.from_inputs(
        NowcastConfig(),
        frames,
        observation_masks,
        None,
        source_available_mask=source_available_mask,
    )
    print("contract default-quality case: accepted")
except Exception as exc:
    print("contract default-quality case:", type(exc).__name__, str(exc))

explicit_quality = observation_masks.to(frames)
explicit_quality[:, 0, 0] = 0.0
try:
    run = ForecastRunContract.from_inputs(
        NowcastConfig(),
        frames,
        observation_masks,
        None,
        observation_quality_weight=explicit_quality,
        source_available_mask=source_available_mask,
    )
    print("contract explicit-zero-quality case: accepted", run.source_available_mask_digest[:12])
except Exception as exc:
    print("contract explicit-zero-quality case:", type(exc).__name__, str(exc))

try:
    result, _ = variational_nowcast(
        frames,
        source_available_mask=source_available_mask,
        analysis_config=AnalysisConfig(
            maximum_outer_iterations=1,
            maximum_pcg_iterations=1,
        ),
    )
    print("variational default-quality case: accepted", result.run.source_available_mask_digest[:12])
except Exception as exc:
    print("variational default-quality case:", type(exc).__name__, str(exc))

try:
    result, _ = variational_nowcast(
        frames,
        quality_weight=explicit_quality,
        source_available_mask=source_available_mask,
        analysis_config=AnalysisConfig(
            maximum_outer_iterations=1,
            maximum_pcg_iterations=1,
        ),
    )
    print("variational explicit-zero-quality case: accepted", result.run.source_available_mask_digest[:12])
except Exception as exc:
    print("variational explicit-zero-quality case:", type(exc).__name__, str(exc))
