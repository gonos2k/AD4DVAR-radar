import ast
from pathlib import Path

source_path = Path('/Users/yhlee/ADVAR/src/advar/ledger.py')
tree = ast.parse(source_path.read_text(encoding='utf-8'))
target = next(
    node for node in ast.walk(tree)
    if isinstance(node, ast.FunctionDef)
    and node.name == 'append_neural_prior_scoring_replay_bundle'
)
events = []
for node in ast.walk(target):
    if not isinstance(node, ast.Call):
        continue
    if isinstance(node.func, ast.Name) and node.func.id == '_publish_durable_directory':
        events.append(('_publish_durable_directory', node.lineno))
    if (
        isinstance(node.func, ast.Attribute)
        and node.func.attr == 'execute'
        and node.args
        and isinstance(node.args[0], ast.Constant)
        and isinstance(node.args[0].value, str)
        and 'INSERT INTO neural_prior_scoring_replay_bundles' in node.args[0].value
    ):
        events.append(('bundle_row_insert', node.lineno))
print('function=', target.name)
print('events=', sorted(events, key=lambda item: item[1]))
