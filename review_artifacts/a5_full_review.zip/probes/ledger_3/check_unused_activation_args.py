import ast
from pathlib import Path

source_path = Path('/Users/yhlee/ADVAR/src/advar/ledger.py')
tree = ast.parse(source_path.read_text(encoding='utf-8'))
target = next(
    node for node in ast.walk(tree)
    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
    and node.name == '_ensure_operational_decision_activation_receipt'
)
argument_names = {
    arg.arg for arg in target.args.args + target.args.kwonlyargs
}
loads = {
    name: sum(
        isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load) and node.id == name
        for node in ast.walk(target)
    )
    for name in sorted(argument_names)
}
print('function=', target.name)
print('argument_load_counts=', loads)
print('source_lines=', target.lineno, target.end_lineno)
