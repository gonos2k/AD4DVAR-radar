"""Force the acceptance parent-directory check/use symlink race."""

from __future__ import annotations

from dataclasses import replace
from hashlib import sha256
import json
from pathlib import Path
import shutil
import sys
import tempfile

sys.path.insert(0, "/Users/yhlee/ADVAR/src")
sys.path.insert(0, "/Users/yhlee/ADVAR")

import advar.acceptance as acceptance  # noqa: E402
from tests.test_acceptance import RealCaseAcceptanceTests  # noqa: E402


def main() -> None:
    with tempfile.TemporaryDirectory() as directory:
        workspace = Path(directory).resolve()
        root = workspace / "root"
        outside = workspace / "outside"
        root.mkdir()
        outside.mkdir()
        manifest = RealCaseAcceptanceTests().fixture(root)
        shutil.copytree(root / "case-1", outside / "case-1")

        first = manifest.cases[0].artifacts[0]
        outside_victim = outside / first.relative_path
        outside_data = json.dumps(
            {"artifact_digest": "f" * 64, "contract": first.product_contract},
            sort_keys=True,
        ).encode()
        outside_victim.write_bytes(outside_data)
        outside_victim.chmod(0o600)
        forged_reference = replace(
            first,
            file_sha256=sha256(outside_data).hexdigest(),
            product_artifact_digest="f" * 64,
        )
        forged_case = replace(
            manifest.cases[0],
            artifacts=(forged_reference, *manifest.cases[0].artifacts[1:]),
        )
        forged_manifest = replace(
            manifest,
            cases=(forged_case, *manifest.cases[1:]),
        )

        original_path = acceptance._artifact_path
        original_read = acceptance._read_single_snapshot
        state = {"swapped": False, "outside_file_read": False}

        def swap_after_parent_check(root_path: Path, relative_path: str) -> Path:
            path = original_path(root_path, relative_path)
            if relative_path == first.relative_path and not state["swapped"]:
                state["swapped"] = True
                (root / "case-1").rename(root / "case-1-safe")
                (root / "case-1").symlink_to(
                    outside / "case-1",
                    target_is_directory=True,
                )
            return path

        def read_after_swap(path: Path, *, maximum_bytes: int) -> bytes:
            data = original_read(path, maximum_bytes=maximum_bytes)
            if state["swapped"] and path.name == "01-native_radar_artifact.json":
                state["outside_file_read"] = (
                    path.resolve() == outside_victim.resolve()
                )
                (root / "case-1").unlink()
                (root / "case-1-safe").rename(root / "case-1")
                state["swapped"] = False
            return data

        acceptance._artifact_path = swap_after_parent_check
        acceptance._read_single_snapshot = read_after_swap
        try:
            try:
                acceptance.verify_real_case_acceptance(
                    forged_manifest,
                    artifact_root=root,
                )
            except Exception as error:  # noqa: BLE001 - probe records the failure.
                print("verification_succeeded:", False)
                print("error:", type(error).__name__, str(error))
            else:
                print("verification_succeeded:", True)
            print("outside_file_read:", state["outside_file_read"])
        finally:
            acceptance._artifact_path = original_path
            acceptance._read_single_snapshot = original_read


if __name__ == "__main__":
    main()
