"""Reproduce acceptance report output colliding with a referenced artifact."""

from __future__ import annotations

import subprocess
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, "/Users/yhlee/ADVAR/src")
sys.path.insert(0, "/Users/yhlee/ADVAR")

from advar.acceptance import verify_real_case_acceptance  # noqa: E402
from tests.test_acceptance import RealCaseAcceptanceTests  # noqa: E402


def main() -> None:
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory).resolve()
        manifest = RealCaseAcceptanceTests().fixture(root)
        manifest_path = root / "manifest.json"
        manifest_path.write_text(manifest.json, encoding="utf-8")
        victim = root / manifest.cases[0].artifacts[0].relative_path
        original = victim.read_bytes()
        command = [
            "/Users/yhlee/ADVAR/.venv/bin/python",
            ".github/scripts/run_real_case_acceptance.py",
            "--manifest",
            str(manifest_path),
            "--artifact-root",
            str(root),
            "--report",
            str(victim),
        ]
        completed = subprocess.run(
            command,
            cwd="/Users/yhlee/ADVAR",
            check=False,
            capture_output=True,
            text=True,
        )
        print("script_exit:", completed.returncode)
        print("victim_changed:", victim.read_bytes() != original)
        try:
            verify_real_case_acceptance(manifest, artifact_root=root)
        except Exception as error:  # noqa: BLE001 - probe records the failure.
            print("reverify:", type(error).__name__, str(error))
        else:
            print("reverify: passed")


if __name__ == "__main__":
    main()
