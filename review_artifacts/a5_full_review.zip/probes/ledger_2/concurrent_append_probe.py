from __future__ import annotations

import importlib
from concurrent.futures import ThreadPoolExecutor
from threading import Barrier
from unittest.mock import patch

from advar import ledger as ledger_module
from advar.ledger import EpisodeLedger


def main() -> None:
    test_promotion = importlib.import_module("test_promotion")
    case = test_promotion.NeuralPriorPromotionTests("runTest")
    original = EpisodeLedger.append_operational_analysis_input_provenance
    state: dict[str, object] = {"calls": 0, "errors": []}
    barrier = Barrier(2)

    def concurrent_first(self: EpisodeLedger, *args: object, **kwargs: object):
        calls = int(state["calls"])
        state["calls"] = calls + 1
        if calls != 0:
            return original(self, *args, **kwargs)
        errors: list[tuple[str, str]] = []

        def invoke() -> str:
            barrier.wait(timeout=10)
            try:
                return original(self, *args, **kwargs)
            except Exception as error:  # noqa: BLE001 - probe evidence
                errors.append((type(error).__name__, str(error)))
                raise

        with ThreadPoolExecutor(max_workers=2) as executor:
            futures = [executor.submit(invoke) for _ in range(2)]
            for future in futures:
                try:
                    future.result()
                except Exception:
                    pass
        state["errors"] = errors
        # The fixture intentionally expects the simulated post-commit crash;
        # preserve that contract after exposing the concurrent append result.
        raise RuntimeError("postcommit crash")

    with patch.object(
        EpisodeLedger,
        "append_operational_analysis_input_provenance",
        concurrent_first,
    ):
        try:
            case.test_future_operational_provenance_does_not_require_holdout()
        except Exception as error:  # noqa: BLE001 - report probe outcome
            state["fixture_error"] = (type(error).__name__, str(error))

    print({"calls": state["calls"], "errors": state["errors"], "fixture_error": state.get("fixture_error")})


if __name__ == "__main__":
    main()
