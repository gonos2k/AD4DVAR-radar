from __future__ import annotations

from pathlib import Path

import torch

from advar.promotion import (
    NeuralPriorInputPlan,
    OperationalIssuanceDomainPlan,
    ResolvedSourceCoverageArtifact,
    SourceRadarRegistry,
    validate_resolved_source_coverage_artifact,
)


def main() -> None:
    source = Path("/Users/yhlee/ADVAR/src/advar/ledger.py").read_text()
    append_start = source.index("    def append_operational_analysis_input_provenance(\n")
    append_end = source.index(
        "    def append_neural_prior_holdout_scoring_input_artifact(\n",
        append_start,
    )
    append = source[append_start:append_end]
    assert "resolved_source_coverage.issuance_domain_plan_digest" not in append
    assert "resolved_source_coverage.grid_contract_digest" not in append
    assert "resolved_source_coverage.source_radar_registry_digest" not in append

    input_plan = NeuralPriorInputPlan(
        valid_times=(
            "2026-08-08T00:00:00Z",
            "2026-08-08T00:10:00Z",
            "2026-08-08T00:20:00Z",
        ),
        grid_contract_digest="0" * 64,
        radar_product_digest="1" * 64,
        qc_pipeline_digest="2" * 64,
        background_cycle_rule_digest="3" * 64,
        mask_policy_digest="4" * 64,
        observation_valid_time="2026-08-08T00:20:00Z",
        input_available_time="2026-08-08T00:21:00Z",
        decision_deadline="2026-08-08T00:22:00Z",
        publication_time="2026-08-08T00:25:00Z",
    )
    registry = SourceRadarRegistry(
        radar_site_digests=("a" * 64, "b" * 64),
        source_selection_policy_digest="5" * 64,
    )
    key_hex = "00" * 32
    # The key is only needed as a well-formed plan field for this probe.
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

    key = Ed25519PrivateKey.from_private_bytes(b"\x02" * 32)
    key_hex = key.public_key().public_bytes_raw().hex()
    common = dict(
        case_id="case",
        grid_contract_digest=input_plan.grid_contract_digest,
        radar_source_contract_digest="6" * 64,
        lead_minutes=(60,),
        publication_policy_digest="7" * 64,
        source_coverage_policy_digest=registry.source_selection_policy_digest,
        permanent_exclusion_policy_digest="8" * 64,
        publication_eligible_mask_digest="9" * 64,
        permanent_exclusion_mask_digest="a" * 64,
        radar_source_kind="mosaic",
        source_radar_registry_digest=registry.registry_digest,
        source_radar_count=2,
        data_ingestor_id="ingestor",
        data_ingestor_public_key_hex=key_hex,
    )
    nominal_a = torch.ones((1, 2, 2), dtype=torch.bool)
    nominal_b = nominal_a.clone()
    nominal_b[0, 0, 0] = False
    plan_a = OperationalIssuanceDomainPlan(
        **common,
        source_coverage_mask_digest=(
            __import__("advar.promotion", fromlist=["tensor_digest"]).tensor_digest(nominal_a)
        ),
    )
    plan_b = OperationalIssuanceDomainPlan(
        **common,
        source_coverage_mask_digest=(
            __import__("advar.promotion", fromlist=["tensor_digest"]).tensor_digest(nominal_b)
        ),
    )
    coverage_b = ResolvedSourceCoverageArtifact.from_observations(
        plan_b,
        input_plan,
        registry,
        nominal_source_coverage_mask=nominal_b,
        source_radar_index_map=torch.zeros((2, 2), dtype=torch.int64),
        outage_mask=torch.zeros((2, 2), dtype=torch.bool),
        dynamic_qc_valid_mask=torch.ones((2, 2), dtype=torch.bool),
        input_bundle_digest="a" * 64,
        full_analysis_input_digest="b" * 64,
        resolved_at="2026-08-08T00:21:00Z",
        data_ingestor_id="ingestor",
        data_ingestor_private_key=key,
    )
    validate_resolved_source_coverage_artifact(coverage_b)
    print({
        "coverage_valid": True,
        "coverage_plan": coverage_b.issuance_domain_plan_digest,
        "registered_plan": plan_a.plan_digest,
        "plans_differ": coverage_b.issuance_domain_plan_digest != plan_a.plan_digest,
        "missing_guard": True,
    })


if __name__ == "__main__":
    main()
