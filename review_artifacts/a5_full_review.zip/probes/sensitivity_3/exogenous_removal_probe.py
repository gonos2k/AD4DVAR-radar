from pathlib import Path
import sys
from unittest.mock import patch
import torch
sys.path.insert(0, '/Users/yhlee/ADVAR/src')
sys.path.insert(1, '/Users/yhlee/ADVAR/tests')
from test_variational import _prior
from advar.sensitivity import compute_variational_observation_removal_impact
from advar.variational import AnalysisConfig, variational_nowcast

y,x=torch.meshgrid(torch.arange(8,dtype=torch.float64),torch.arange(8,dtype=torch.float64),indexing='ij')
frames=torch.stack(tuple(-10+40*torch.exp(-((y-c)**2+(x-c)**2)/4) for c in (3.,3.5,4.)))
prior=_prior(frames,20.0,'candidate',dependency='exogenous')
ac=AnalysisConfig(censored_background_policy='floor', maximum_outer_iterations=24, maximum_pcg_iterations=100, pcg_relative_tolerance=1e-8)
forecast,analysis=variational_nowcast(frames,analysis_config=ac,neural_prior=prior)
print('nominal',analysis.converged,analysis.degraded,analysis.p1_forecast_eligible,analysis.linearization is not None,forecast.metadata.dynamics_source)
if analysis.linearization is not None:
    lin=analysis.linearization
    mask=torch.zeros_like(lin.observations.valid_mask)
    idx=torch.nonzero(lin.observations.detected_mask)
    print('detected',idx.shape)
    if idx.numel(): mask[tuple(idx[0].tolist())]=True
    # very tiny removal; this may change branch but should be admissible
    try:
      out=compute_variational_observation_removal_impact(forecast,analysis,forecast.forecast_dbz,mask)
      print('impact_success',out.removed_forecast_run_digest, out.removed_analysis_digest)
    except Exception as e:
      print('impact_error',type(e).__name__,str(e))
