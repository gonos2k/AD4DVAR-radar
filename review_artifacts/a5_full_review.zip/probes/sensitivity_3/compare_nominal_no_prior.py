import sys; sys.path.insert(0,'/Users/yhlee/ADVAR/src'); sys.path.insert(1,'/Users/yhlee/ADVAR/tests')
import torch
from test_variational import _prior
from advar.variational import AnalysisConfig,variational_nowcast

y,x=torch.meshgrid(torch.arange(8,dtype=torch.float64),torch.arange(8,dtype=torch.float64),indexing='ij'); frames=torch.stack(tuple(-10+40*torch.exp(-((y-c)**2+(x-c)**2)/4) for c in (3.,3.5,4.)))
prior=_prior(frames,0.0,'candidate',dependency='exogenous')
ac=AnalysisConfig(censored_background_policy='floor',maximum_outer_iterations=24,maximum_pcg_iterations=100,pcg_relative_tolerance=1e-8)
f,a=variational_nowcast(frames,analysis_config=ac,neural_prior=prior)
print('prior nominal',a.converged,a.degraded,a.p1_forecast_eligible,a.reason,a.linearization is not None)
mask=torch.ones_like(frames,dtype=torch.bool); mask[0,2,2]=False
f2,a2=variational_nowcast(frames,analysis_config=ac,qc_mask=mask)
print('no prior removed',a2.converged,a2.degraded,a2.p1_forecast_eligible,a2.reason,a2.linearization is not None)
