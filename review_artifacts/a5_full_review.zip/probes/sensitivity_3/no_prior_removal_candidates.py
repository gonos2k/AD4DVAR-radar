import sys
sys.path.insert(0,'/Users/yhlee/ADVAR/src')
import torch
from advar.variational import AnalysisConfig, variational_nowcast

y,x=torch.meshgrid(torch.arange(8,dtype=torch.float64),torch.arange(8,dtype=torch.float64),indexing='ij'); frames=torch.stack(tuple(-10+40*torch.exp(-((y-c)**2+(x-c)**2)/4) for c in (3.,3.5,4.)))
ac=AnalysisConfig(censored_background_policy='floor',maximum_outer_iterations=12,maximum_pcg_iterations=100,pcg_relative_tolerance=1e-8)
f,a=variational_nowcast(frames,analysis_config=ac)
print('nominal',a.converged,a.degraded,a.p1_forecast_eligible,a.reason)
for coord in [(2,2,2),(2,3,3),(2,4,4),(1,2,2),(1,3,3),(1,4,4),(0,2,2),(0,3,3),(0,4,4),(2,0,0),(1,0,0),(0,0,0)]:
 m=torch.ones_like(frames,dtype=torch.bool); m[coord]=False
 try:
  ff,aa=variational_nowcast(frames,analysis_config=ac,qc_mask=m)
  print(coord,aa.converged,aa.degraded,aa.p1_forecast_eligible,aa.reason)
 except Exception as e: print(coord,'EXC',type(e).__name__,e)
