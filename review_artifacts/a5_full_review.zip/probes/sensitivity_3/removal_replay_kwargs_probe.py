import sys
sys.path.insert(0, '/Users/yhlee/ADVAR/src'); sys.path.insert(1, '/Users/yhlee/ADVAR/tests')
from unittest.mock import patch
import torch
from test_variational import _prior
from advar.sensitivity import compute_variational_observation_removal_impact, ObservationRemovalConfig, SensitivityConfig
import advar.sensitivity as sm
from advar.variational import AnalysisConfig, variational_nowcast

y,x=torch.meshgrid(torch.arange(8,dtype=torch.float64),torch.arange(8,dtype=torch.float64),indexing='ij')
frames=torch.stack(tuple(-10+40*torch.exp(-((y-c)**2+(x-c)**2)/4) for c in (3.,3.5,4.)))
prior=_prior(frames,0.0,'candidate',dependency='exogenous')
ac=AnalysisConfig(censored_background_policy='floor',maximum_outer_iterations=24,maximum_pcg_iterations=100,pcg_relative_tolerance=1e-8)
forecast,analysis=variational_nowcast(frames,analysis_config=ac,neural_prior=prior)
lin=analysis.linearization
assert lin is not None
idx=torch.nonzero(lin.observations.detected_mask)[0]
mask=torch.zeros_like(lin.observations.valid_mask); mask[tuple(idx.tolist())]=True
seen={}
def fake_nowcast(frames_dbz, **kwargs):
    seen.update(kwargs)
    raise RuntimeError('sentinel')
try:
    with patch.object(sm, 'variational_nowcast', fake_nowcast):
        compute_variational_observation_removal_impact(
            forecast, analysis, forecast.forecast_dbz, mask,
            sensitivity_config=SensitivityConfig(full_map_lead_minutes=(10,),metric_names=('log_echo_mse',)),
            removal_config=ObservationRemovalConfig(maximum_removed_area_km2=None),
        )
except RuntimeError as e:
    print('raised', str(e))
print('nominal_prior_dependency', lin.frozen.neural_prior_dependency)
print('nominal_source_digest', forecast.run.source_available_mask_digest)
print('replay_kwargs', sorted(seen))
print('passes_neural_prior', 'neural_prior' in seen)
print('passes_source_available_mask', 'source_available_mask' in seen)
