import sys
sys.path.insert(0,'/Users/yhlee/ADVAR/src'); sys.path.insert(1,'/Users/yhlee/ADVAR/tests')
import torch
from test_variational import _prior_runner
from advar.nowcast import NowcastConfig, ForecastRunContract
from advar.variational import AnalysisConfig, variational_nowcast

y,x=torch.meshgrid(torch.arange(8,dtype=torch.float64),torch.arange(8,dtype=torch.float64),indexing='ij'); frames=torch.stack(tuple(-10+40*torch.exp(-((y-c)**2+(x-c)**2)/4) for c in (3.,3.5,4.)))
runner=_prior_runner(0.0,'candidate',example_frames=frames,dependency='exogenous'); ac=AnalysisConfig(censored_background_policy='floor',maximum_outer_iterations=12,maximum_pcg_iterations=100,pcg_relative_tolerance=1e-8)
run=ForecastRunContract.from_inputs(NowcastConfig(),frames,torch.ones_like(frames,dtype=torch.bool),None); prior=runner.infer(frames,input_run=run,role='candidate')
f,a=variational_nowcast(frames,analysis_config=ac,neural_prior=prior); print('nominal prior',a.converged,a.degraded,a.p1_forecast_eligible,a.reason)
for coord in [(2,2,2),(2,3,3),(2,4,4),(1,2,2),(0,0,0)]:
 m=torch.ones_like(frames,dtype=torch.bool);m[coord]=False
 # no prior path
 ff,aa=variational_nowcast(frames,analysis_config=ac,qc_mask=m); print(coord,'no prior',aa.converged,aa.degraded,aa.p1_forecast_eligible,aa.reason)
 # re-infer prior bound to changed qc/input run
 changed_run=ForecastRunContract.from_inputs(NowcastConfig(),frames,m,None)
 changed_prior=runner.infer(frames,input_run=changed_run,role='candidate')
 try:
  f2,a2=variational_nowcast(frames,analysis_config=ac,qc_mask=m,neural_prior=changed_prior); print(coord,'proper prior',a2.converged,a2.degraded,a2.p1_forecast_eligible,a2.reason)
 except Exception as e: print(coord,'proper prior EXC',type(e).__name__,e)
