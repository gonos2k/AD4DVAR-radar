# Cross-check of test_sensitivity_2 first finding

The runnable cross-check is `crosscheck_sensitivity_2_adj_map.py` and was run with:

```text
OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -u /tmp/advar-a5-review/probes/sensitivity_3/crosscheck_sensitivity_2_adj_map.py
```

Output:

```text
analysis True False True
mid_censored_count 28
P0_derivative_max_mid_censored 1349843.5642489796
adjoint_map_max_mid_censored 0.0
adjoint_map_nonzero_mid_censored 0
baseline_branch_status unknown
```

This computes the actual `compute_variational_fso` baseline dynamics adjoint map under `echo_threshold_dbz=0` and `detection_limit_dbz=5`, not only the P0 Jacobian. The stronger companion `crosscheck_sensitivity_2_same_adjoint.py` captures the exact adjoint solution used by FSO, then evaluates the same VJP with only the output mask changed from `detected_mask` to the perturbation contract's `valid_mask & observed_mask`.

Its output is:

```text
analysis True False True
mid_censored_count 28
captured_adjoint_solution_norm 0.021616348825241178
actual_fso_map_max_mid_censored 0.0
same_adjoint_expected_unmasked_max_mid_censored 195673.17320960973
same_adjoint_expected_unmasked_nonzero_mid_censored 28
actual_map_equals_original_masked True
baseline_branch_status unknown
```

Thus the same nonzero adjoint cotangent reaches every one of the 28 mid-censored cells, and the public map removes it solely through the `detected_mask` gate. The `unknown` branch status limits the result's automated-learning certification, but does not remove the exploratory FSO map defect.
