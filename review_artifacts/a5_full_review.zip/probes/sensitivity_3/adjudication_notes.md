# Removal replay adjudication

The runnable probe is `exo_wrong_impact.py` and was run with:

```text
OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -u /tmp/advar-a5-review/probes/sensitivity_3/exo_wrong_impact.py
```

Observed output:

```text
nominal_prior_dependency exogenous
removed_path_status [[True]] [[0.04431874046394474]]
proper_prior_status True False True step_tolerance [[0.015242213929648809]]
removed_minus_proper [[0.029076526534295932]]
abs_difference 0.029076526534295932
```

The current public removal path succeeds because its replay omits `neural_prior`; the comparison result is therefore a no-prior denial. The reference result re-infers the same exogenous prior on the changed QC/input run before solving. The companion boundary probe is `removal_replay_kwargs_probe.py`, whose output is in `removal_replay_kwargs.txt` and shows both omitted kwargs.
