from dataclasses import replace
from pathlib import Path
import sys
import torch
sys.path.insert(0, '/Users/yhlee/ADVAR/src')
sys.path.insert(1, '/Users/yhlee/ADVAR/tests')
import test_sensitivity as t
import advar.sensitivity as sm
from advar.variational import variational_nowcast

assert Path(sm.__file__).resolve() == Path('/Users/yhlee/ADVAR/src/advar/sensitivity.py')
t.VariationalFSOTests.setUpClass(); C=t.VariationalFSOTests
nc=replace(C.nowcast_config, echo_threshold_dbz=0.0)
ac=replace(C.analysis_config, detection_limit_dbz=5.0, maximum_outer_iterations=20)
forecast, analysis=variational_nowcast(C.frames, nowcast_config=nc, analysis_config=ac)
assert analysis.linearization is not None
lin=analysis.linearization; obs=lin.observations; frozen=lin.frozen
mid=obs.censored_mask & (obs.dbz >= 0.0)
verification=torch.where(torch.isfinite(forecast.forecast_dbz), forecast.forecast_dbz-0.5, forecast.forecast_dbz)
calls=[]
original=sm._frozen_baseline_dynamics_observation_sensitivity
def capture(*args, **kwargs):
    calls.append((args, kwargs))
    return original(*args, **kwargs)
sm._frozen_baseline_dynamics_observation_sensitivity=capture
try:
    fso=sm.compute_variational_fso(
        forecast, analysis, verification,
        sensitivity_config=sm.SensitivityConfig(
            metric_names=('log_echo_mse',), full_map_lead_minutes=(10,), tile_size=4,
        ),
    )
finally:
    sm._frozen_baseline_dynamics_observation_sensitivity=original
assert calls
args, kwargs = calls[0]
path, adjoint_solution, control, call_obs, call_frozen = args[:5]
assert call_obs is obs and call_frozen is frozen
expected_path=replace(path, active_mask=obs.valid_mask & frozen.observed_mask)
expected=original(*((expected_path, adjoint_solution, control, obs, frozen)+args[5:]), **kwargs)
actual_map=fso.observation.baseline_dynamics_dbz.maps[0,0]
mid_expected=expected[mid]
print('analysis', analysis.converged, analysis.degraded, analysis.p1_forecast_eligible)
print('mid_censored_count', int(mid.sum()))
print('captured_adjoint_solution_norm', float(torch.linalg.vector_norm(adjoint_solution)))
print('actual_fso_map_max_mid_censored', float(actual_map[mid].abs().max()))
print('same_adjoint_expected_unmasked_max_mid_censored', float(mid_expected.abs().max()))
print('same_adjoint_expected_unmasked_nonzero_mid_censored', int(torch.count_nonzero(mid_expected)))
print('actual_map_equals_original_masked', bool(torch.equal(actual_map, original(*args, **kwargs))))
print('baseline_branch_status', fso.baseline_dynamics_branch_status)
