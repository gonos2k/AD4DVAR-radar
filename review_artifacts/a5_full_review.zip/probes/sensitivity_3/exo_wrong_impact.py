import sys
sys.path.insert(0,'/Users/yhlee/ADVAR/src'); sys.path.insert(1,'/Users/yhlee/ADVAR/tests')
import torch
from test_variational import _prior_runner
from advar.nowcast import NowcastConfig, ForecastRunContract
import advar.sensitivity as sm
from advar.variational import AnalysisConfig, variational_nowcast

y,x=torch.meshgrid(torch.arange(8,dtype=torch.float64),torch.arange(8,dtype=torch.float64),indexing='ij'); frames=torch.stack(tuple(-10+40*torch.exp(-((y-c)**2+(x-c)**2)/4) for c in (3.,3.5,4.)))
runner=_prior_runner(0.0,'candidate',example_frames=frames,dependency='exogenous'); ac=AnalysisConfig(censored_background_policy='floor',maximum_outer_iterations=12,maximum_pcg_iterations=100,pcg_relative_tolerance=1e-8)
run=ForecastRunContract.from_inputs(NowcastConfig(),frames,torch.ones_like(frames,dtype=torch.bool),None); prior=runner.infer(frames,input_run=run,role='candidate')
nominal,analysis=variational_nowcast(frames,analysis_config=ac,neural_prior=prior)
assert analysis.linearization is not None and analysis.converged and not analysis.degraded and analysis.p1_forecast_eligible
coord=(2,2,2); m=torch.ones_like(frames,dtype=torch.bool);m[coord]=False; removal_mask=torch.zeros_like(frames,dtype=torch.bool); removal_mask[coord]=True
cfg=sm.SensitivityConfig(full_map_lead_minutes=(10,),metric_names=('log_echo_mse',))
impact=sm.compute_variational_observation_removal_impact(nominal,analysis,nominal.forecast_dbz,removal_mask, sensitivity_config=cfg, removal_config=sm.ObservationRemovalConfig(maximum_removed_area_km2=None))
# Re-run the denial with the retained exogenous runner, bound to changed QC/input.
changed_run=ForecastRunContract.from_inputs(NowcastConfig(),frames,m,None); changed_prior=runner.infer(frames,input_run=changed_run,role='candidate')
proper_forecast,proper_analysis=variational_nowcast(frames,analysis_config=ac,qc_mask=m,neural_prior=changed_prior)
verification=sm._resolve_verification(nominal.forecast_dbz,nominal,cfg)
proper_scores,_=sm._resolved_forecast_scores(proper_forecast,proper_analysis.state,verification,(10,),cfg)
print('nominal_prior_dependency',analysis.linearization.frozen.neural_prior_dependency)
print('removed_path_status',impact.metric_available.tolist(),impact.removed_scores.tolist())
print('proper_prior_status',proper_analysis.converged,proper_analysis.degraded,proper_analysis.p1_forecast_eligible,proper_analysis.reason,proper_scores.tolist())
print('removed_minus_proper', (impact.removed_scores-proper_scores).tolist())
print('abs_difference', float(torch.nan_to_num(impact.removed_scores-proper_scores).abs().max()))
