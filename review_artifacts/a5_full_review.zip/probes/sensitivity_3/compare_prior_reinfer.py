import sys; sys.path.insert(0,'/Users/yhlee/ADVAR/src'); sys.path.insert(1,'/Users/yhlee/ADVAR/tests')
import torch
from test_variational import _prior, _prior_runner
from advar.variational import AnalysisConfig,ForecastRunContract,variational_nowcast

y,x=torch.meshgrid(torch.arange(8,dtype=torch.float64),torch.arange(8,dtype=torch.float64),indexing='ij'); frames=torch.stack(tuple(-10+40*torch.exp(-((y-c)**2+(x-c)**2)/4) for c in (3.,3.5,4.)))
runner=_prior_runner(0.0,'candidate',example_frames=frames,dependency='exogenous'); run=ForecastRunContract.from_inputs(AnalysisConfig if False else __import__('advar.nowcast',fromlist=['NowcastConfig']).NowcastConfig(),frames,torch.ones_like(frames,dtype=torch.bool),None); prior=runner.infer(frames,input_run=run,role='candidate'); ac=AnalysisConfig(censored_background_policy='floor',maximum_outer_iterations=24,maximum_pcg_iterations=100,pcg_relative_tolerance=1e-8)
f,a=variational_nowcast(frames,analysis_config=ac,neural_prior=prior); print('prior nominal',a.converged,a.degraded,a.p1_forecast_eligible,a.reason)
mask=torch.ones_like(frames,dtype=torch.bool); mask[0,2,2]=False
changed_run=ForecastRunContract.from_inputs(__import__('advar.nowcast',fromlist=['NowcastConfig']).NowcastConfig(),frames,mask,None)
changed_prior=runner.infer(frames,input_run=changed_run,role='candidate')
f2,a2=variational_nowcast(frames,analysis_config=ac,qc_mask=mask,neural_prior=changed_prior); print('reinf prior removed',a2.converged,a2.degraded,a2.p1_forecast_eligible,a2.reason,a2.linearization is not None)
