from pathlib import Path
import sys
sys.path.insert(0, '/Users/yhlee/ADVAR/src'); sys.path.insert(1, '/Users/yhlee/ADVAR/tests')
import torch
from test_variational import _prior
from advar.sensitivity import compute_variational_observation_removal_impact, ObservationRemovalConfig, SensitivityConfig
from advar.variational import AnalysisConfig, variational_nowcast
y,x=torch.meshgrid(torch.arange(8,dtype=torch.float64),torch.arange(8,dtype=torch.float64),indexing='ij')
frames=torch.stack(tuple(-10+40*torch.exp(-((y-c)**2+(x-c)**2)/4) for c in (3.,3.5,4.)))
prior=_prior(frames,0.0,'candidate',dependency='exogenous')
ac=AnalysisConfig(censored_background_policy='floor', maximum_outer_iterations=24, maximum_pcg_iterations=100, pcg_relative_tolerance=1e-8)
forecast,analysis=variational_nowcast(frames,analysis_config=ac,neural_prior=prior)
lin=analysis.linearization; print('nominal',analysis.converged,analysis.degraded,analysis.p1_forecast_eligible,lin is not None)
if lin is not None:
  inds=torch.nonzero(lin.observations.detected_mask)
  for j,coord in enumerate(inds.tolist()):
    mask=torch.zeros_like(lin.observations.valid_mask); mask[tuple(coord)]=True
    try:
      out=compute_variational_observation_removal_impact(forecast,analysis,forecast.forecast_dbz,mask,removal_config=ObservationRemovalConfig(maximum_removed_area_km2=None),sensitivity_config=SensitivityConfig(full_map_lead_minutes=(10,),metric_names=('log_echo_mse',)))
      print('SUCCESS',j,coord,out.removed_analysis_digest)
      break
    except Exception as e:
      print('ERR',j,coord,type(e).__name__,str(e))
