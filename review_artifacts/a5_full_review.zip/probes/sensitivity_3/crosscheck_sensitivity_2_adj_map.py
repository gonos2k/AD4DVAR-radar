from dataclasses import replace
from pathlib import Path
import sys
import torch
sys.path.insert(0, '/Users/yhlee/ADVAR/src')
sys.path.insert(1, '/Users/yhlee/ADVAR/tests')
import test_sensitivity as t
import advar.sensitivity as sm
from advar.variational import variational_nowcast
assert Path(sm.__file__).resolve() == Path('/Users/yhlee/ADVAR/src/advar/sensitivity.py')
t.VariationalFSOTests.setUpClass(); C=t.VariationalFSOTests
nc=replace(C.nowcast_config, echo_threshold_dbz=0.0)
ac=replace(C.analysis_config, detection_limit_dbz=5.0, maximum_outer_iterations=20)
forecast, analysis=variational_nowcast(C.frames, nowcast_config=nc, analysis_config=ac)
assert analysis.linearization is not None
lin=analysis.linearization; obs=lin.observations; frozen=lin.frozen
mid=obs.censored_mask & (obs.dbz >= 0.0)
x=obs.dbz.detach().clone()
j=torch.func.jacrev(lambda v: sm._baseline_dynamics_from_observation(v, frozen))(x)
verification=torch.where(torch.isfinite(forecast.forecast_dbz), forecast.forecast_dbz-0.5, forecast.forecast_dbz)
fso=sm.compute_variational_fso(forecast, analysis, verification, sensitivity_config=sm.SensitivityConfig(metric_names=('log_echo_mse',), full_map_lead_minutes=(10,), tile_size=4))
adjoint_map=fso.observation.baseline_dynamics_dbz.maps[0,0]
print('analysis', analysis.converged, analysis.degraded, analysis.p1_forecast_eligible)
print('mid_censored_count', int(mid.sum()))
print('P0_derivative_max_mid_censored', float(j[:,mid].abs().max()))
print('adjoint_map_max_mid_censored', float(adjoint_map[mid].abs().max()))
print('adjoint_map_nonzero_mid_censored', int(torch.count_nonzero(adjoint_map[mid])))
print('baseline_branch_status', fso.baseline_dynamics_branch_status)
