import sys
sys.path.insert(0, '/Users/yhlee/ADVAR/src')
import advar.promotion as p
from types import SimpleNamespace
policy = SimpleNamespace(confidence_level=0.95)
for n in range(1, 2000):
    vals=[1.0]*n
    clusters=[f'event-{i}' for i in range(n)]
    a,_=p._event_fractional_rate_interval(vals, clusters, policy, family_size=28)
    b,_=p._event_fractional_rate_interval(vals, clusters, policy, family_size=56)
    if a >= 0.8 and b < 0.8:
        print({'n_all_success_events':n,'lower_bound_family_28':a,'lower_bound_family_56':b,'threshold':0.8})
        break
else:
    print('no crossing')
