import sys
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0, '/Users/yhlee/ADVAR/src')
import advar.promotion as p

metric = SimpleNamespace(weather_regime='convective')
issuance = SimpleNamespace(weather_regime='convective')
plan = SimpleNamespace(
    promotion_experiment_family=SimpleNamespace(total_family_size=1),
    range_band_contracts=(
        SimpleNamespace(registered_active_range_regime_sets=(('near_range',), ('far_range',))),
    ),
)
policy = SimpleNamespace(required_range_metrics=(metric,), required_range_issuance=(issuance,))
actual = p._classifier_simultaneous_family_size(plan, policy)
endpoints = len(p._CLASSIFIER_SIMULTANEOUS_ENDPOINTS)
known_reference_regimes = ('convective', 'stratiform')
print({
    'registered_weather_used_by_helper': ('convective',),
    'known_reference_regimes_in_compute_path': known_reference_regimes,
    'registered_range_sets_used_by_helper': 2,
    'classifier_endpoints': endpoints,
    'computed_family_size': actual,
    'minimum_family_size_for_all_recall_endpoints': len(known_reference_regimes) * 2 * endpoints,
    'undercoverage_factor': (len(known_reference_regimes) * 2 * endpoints) / actual,
})
