import sys
sys.path.insert(0, '/Users/yhlee/ADVAR/src')
import advar.promotion as p
from types import SimpleNamespace
policy = SimpleNamespace(confidence_level=0.95, allow_shadow_small_sample_bootstrap=False)
for n in (192, 329, 400):
  # Choose a feasible normalized improvement just above the current UCB threshold.
  clusters = [f'{i:064x}' for i in range(n)]
  radius_current = p._bounded_event_mean_upper_bound([0.0] * n, clusters, policy, family_size=1, absolute_bound=1.0)
  score = 0.05 + radius_current + 1e-6
  scores = [score] * n
  current = p._cluster_bounds(scores, clusters, policy, candidate_family_size=1, absolute_bound=1.0)
  correct = p._cluster_bounds(scores, clusters, policy, candidate_family_size=3, absolute_bound=1.0)
  print({'n_events': n, 'normalized_score': score, 'current_mean_lower': current[2], 'correct_mean_lower': correct[2], 'threshold': 0.05})
