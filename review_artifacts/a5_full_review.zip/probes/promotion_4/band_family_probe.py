import sys
sys.path.insert(0, '/Users/yhlee/ADVAR/src')
import advar.promotion as p
from types import SimpleNamespace
policy = SimpleNamespace(confidence_level=0.95, allow_shadow_small_sample_bootstrap=False)
# Two observed range groups -> source uses family_size=2, while 3 gates/group need 6.
for n in range(2, 2000):
    vals = [1.0] * n
    clusters = [f'{i:064x}' for i in range(n)]
    current = p._cluster_bounds([0.2] * n, clusters, policy, candidate_family_size=2, absolute_bound=1.0)
    correct = p._cluster_bounds([0.2] * n, clusters, policy, candidate_family_size=6, absolute_bound=1.0)
    if current[2] >= 0.05 and correct[2] < 0.05:
        print({'observed_groups': 2, 'n_all_equal_beneficial_events_per_group': n, 'normalized_score': 0.2, 'current_family_size': 2, 'current_bounds': current, 'joint_family_size_for_3_gates_per_group': 6, 'correct_bounds': correct, 'promotion_threshold': 0.05})
        break
