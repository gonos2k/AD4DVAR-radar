import sys
sys.path.insert(0, '/Users/yhlee/ADVAR/src')
import advar.promotion as p
from types import SimpleNamespace
policy=SimpleNamespace(confidence_level=0.95)
for n in (10,20,50,100,200,500,1000):
 vals=[.2]*n; clusters=[f'e{i}' for i in range(n)]
 x=[-p._bounded_event_mean_upper_bound([-v for v in vals],clusters,policy,family_size=m,absolute_bound=1.0) for m in (1,3,6)]
 print(n,x)
