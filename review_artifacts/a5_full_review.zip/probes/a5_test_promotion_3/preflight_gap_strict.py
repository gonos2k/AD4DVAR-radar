import importlib.util
import os
import sys
from pathlib import Path

sys.path.insert(0, "/Users/yhlee/ADVAR/src")
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
import advar
assert Path(advar.__file__).resolve().is_relative_to(Path("/Users/yhlee/ADVAR/src/advar"))
import advar.promotion as promotion
spec = importlib.util.spec_from_file_location("test_promotion", "/Users/yhlee/ADVAR/tests/test_promotion.py")
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
case = mod.NeuralPriorPromotionTests("runTest")
plan = case.plan()
from dataclasses import replace
policy = replace(case.policy(), allow_shadow_small_sample_bootstrap=False)
counts = case.classifier_subset_counts(1_000_000)
# The caller-provided path accepts empty cell lists even when policy requires cells.
r = promotion.promotion_sample_size_preflight(
    plan,
    policy,
    available_physical_events=1_000_000,
    metric_cell_event_counts=(),
    issuance_cell_event_counts=(),
    classifier_subset_event_counts=counts,
)
print("required_metric_cells", len(policy.required_range_metrics))
print("required_issuance_cells", len(policy.required_range_issuance))
print("returned_metric_cells", len(r.metric_cell_event_counts))
print("returned_issuance_cells", len(r.issuance_cell_event_counts))
print("cell_feasible", r.cell_feasible)
print("classifier_subset_feasible", r.classifier_subset_feasible)
print("feasible", r.feasible)
