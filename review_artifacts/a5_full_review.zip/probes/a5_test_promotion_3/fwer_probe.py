from types import SimpleNamespace
import sys
sys.path.insert(0, "/Users/yhlee/ADVAR/src")
from advar import promotion as p
assert p.__file__.startswith("/Users/yhlee/ADVAR/src/advar/")
policy = SimpleNamespace(confidence_level=0.95, allow_shadow_small_sample_bootstrap=False)
scores=[0.2]*1000
clusters=[f"e{i}" for i in range(1000)]
for fam in (2,6):
    out=p._cluster_bounds(scores,clusters,policy,candidate_family_size=fam,absolute_bound=1.0)
    print(f"family={fam} beneficial_lower={out[0]:.12f} harmful_upper={out[1]:.12f} mean_lower={out[2]:.12f}")
