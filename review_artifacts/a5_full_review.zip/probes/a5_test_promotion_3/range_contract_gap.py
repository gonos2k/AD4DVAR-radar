import os, sys
from pathlib import Path
os.environ['OMP_NUM_THREADS']='1'; os.environ['MKL_NUM_THREADS']='1'
sys.path.insert(0, '/Users/yhlee/ADVAR/src')
from advar import range_geometry as rg
assert Path(rg.__file__).resolve().is_relative_to(Path('/Users/yhlee/ADVAR/src/advar'))
import torch
x=torch.tensor([[0.,100.],[0.,100.]])
y=torch.tensor([[0.,0.],[100.,100.]])
c=rg.RangeGeometryContract(
 radar_site_digest='a'*64, radar_site_location_digest='b'*64, grid_contract_digest='c'*64,
 radar_x_m=0., radar_y_m=0., range_regime_labels=('near','far'), radial_distance_edges_m=(0.,120.,300.),
 horizontal_range_rule_digest='d'*64, grid_x_m_digest=rg.tensor_digest(x), grid_y_m_digest=rg.tensor_digest(y))
stale=c.contract_digest
object.__setattr__(c,'radar_x_m',100.)
try:
 c.validate_integrity()
except ValueError as exc:
 print('validate_integrity', type(exc).__name__, str(exc))
p=rg.resolve_range_geometry(c, grid_x_m=x, grid_y_m=y)
print('resolved_with_stale_digest', p.range_geometry_contract_digest == stale)
print('active_range_regimes', p.active_range_regimes)
print('near_mask_sum', int(p.mask('near').sum()))
