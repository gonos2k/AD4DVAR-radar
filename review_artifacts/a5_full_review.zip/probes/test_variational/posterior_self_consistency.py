import sys
import unittest
from unittest.mock import patch

sys.path.insert(0, "/Users/yhlee/ADVAR/src")
sys.path.insert(0, "/Users/yhlee/ADVAR")

import torch

import advar.variational as variational_module
from tests.test_variational import VariationalAnalysisTests


case = VariationalAnalysisTests(
    "test_p1_confidence_uses_physical_posterior_uncertainty"
)
result = unittest.TestResult()
with patch.object(
    variational_module,
    "_posterior_physical_dynamics_uncertainty",
    side_effect=lambda control, frozen, diagnostics: (
        control.new_zeros(()),
        control.new_zeros(()),
    ),
):
    case.run(result)

print(
    {
        "tests_run": result.testsRun,
        "failures": [(str(test), traceback) for test, traceback in result.failures],
        "errors": [(str(test), traceback) for test, traceback in result.errors],
        "expected_posterior_helper": "zero tensors",
        "observation": "the full confidence test still passes",
    }
)
