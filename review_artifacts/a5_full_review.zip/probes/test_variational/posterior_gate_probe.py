import sys
from dataclasses import replace
import math
from unittest.mock import patch

sys.path.insert(0, "/Users/yhlee/ADVAR/src")
sys.path.insert(0, "/Users/yhlee/ADVAR")

import torch

import advar.variational as variational_module
from advar.nowcast import RadarGridTimeContract
from tests.test_variational import VariationalAnalysisTests
from advar.variational import AnalysisConfig, initial_control


case = VariationalAnalysisTests("runTest")
observations, frozen = case.stationary_problem()
contract = RadarGridTimeContract(
    valid_times=(
        "2026-08-03T00:00:00Z",
        "2026-08-03T00:10:00Z",
        "2026-08-03T00:20:00Z",
    ),
    dx_m=1000.0,
    dy_m=1000.0,
    projection="EPSG:5179",
    grid_hash="c" * 64,
)
frozen = replace(
    frozen,
    nowcast_config=replace(
        frozen.nowcast_config,
        maximum_motion_speed_mps=30.0,
        pair_echo_dilation_m=1000.0,
        phase_correlation_sidelobe_radius_m=1000.0,
    ),
    analysis_config=AnalysisConfig(
        execution_mode="operational",
        operational_calibration_id="test-calibration-v1",
        amplitude_information_policy="operational_fallback",
        amplitude_confidence_policy="operational_fallback",
        motion_increment_scale_mps=2.0,
        causal_support_uncertainty_m=1000.0,
        amplitude_displacement_tolerance_m=1000.0,
    ),
    grid_time_contract=contract,
)

huge = lambda control, frozen, diagnostics: (
    control.new_tensor(100.0),
    control.new_tensor(100.0),
)
with patch.object(
    variational_module,
    "_motion_speed_saturation_margin",
    return_value=100.0,
), patch.object(
    variational_module,
    "_posterior_physical_dynamics_uncertainty",
    side_effect=huge,
):
    result = variational_module._analysis_result(
        initial_control(frozen),
        observations,
        frozen,
        1.0,
        0.5,
        1,
        ((0, 0),),
        True,
        "converged",
    )

print(
    {
        "used_fallback": result.used_fallback,
        "reason": result.reason,
        "expected_gate": "posterior_dynamics_saturation_margin",
    }
)
