from dataclasses import replace
from pathlib import Path
import tempfile

from advar.ledger import EpisodeLedger, SensitivityEpisode, _validate_m0_snapshot
from test_ledger import _computed_snapshot, _contract

source = _computed_snapshot()
assert source.direct.impact is not None and source.direct.tile_impact is not None
assert source.observation_innovation_dbz is not None
assert source.observation_innovation_mask is not None
maps = source.direct.maps.clone()
norm = source.direct.norm.clone()
tiles = source.direct.tile_norm.clone()
impact = source.direct.impact.clone()
tile_impact = source.direct.tile_impact.clone()
# The first retained map corresponds to full-map lead index 2. Give it a unit
# derivative while preserving all norm contracts, then claim an unrelated
# signed impact. The source innovation is finite and valid at [0, 0].
maps[0, 0, 0, 0] = 1.0
norm[2, 0] = 1.0
tiles[2, 0, 0, 0] = 1.0
assert bool(source.observation_innovation_mask[0, 0])
expected_from_visible_map = float(
    source.observation_innovation_dbz[0, 0]
)
impact[2, 0] = 123.0
tile_impact[2, 0, 0, 0] = 123.0
bad = replace(
    source,
    direct=replace(
        source.direct,
        maps=maps,
        norm=norm,
        tile_norm=tiles,
        impact=impact,
        tile_impact=tile_impact,
    ),
)
_validate_m0_snapshot(bad)
print('accepted expected_visible_map_times_innovation=', expected_from_visible_map)
print('accepted_stored_impact=', float(impact[2, 0]))
episode = SensitivityEpisode(
    episode_id='mismatched-impact',
    issue_time='2026-07-26T05:00:00+00:00',
    radar_id='KTLX',
    contract=_contract(bad),
    snapshot=bad,
)
with tempfile.TemporaryDirectory() as directory:
    ledger = EpisodeLedger(Path(directory))
    ledger.append(episode)
    loaded = ledger.load(episode.episode_id)
    print('public_append=accepted persisted_impact=', float(loaded.arrays['direct_observation_impact'][2, 0]))
