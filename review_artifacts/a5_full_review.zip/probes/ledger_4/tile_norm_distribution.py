from dataclasses import replace
import torch
from advar.sensitivity import compute_sensitivity_snapshot, SensitivityConfig
from advar.nowcast import NowcastConfig, nowcast
from advar.ledger import _validate_m0_snapshot, EpisodeLedger, SensitivityEpisode
from pathlib import Path
import tempfile
from test_ledger import _contract

config=NowcastConfig()
frames=torch.full((3,2,2),20.0,dtype=torch.float64)
background=frames-0.5
result=nowcast(frames,config,background_frames_dbz=background,background_age_minutes=10.0)
verification=frames.new_full((config.forecast_steps,2,2),20.0)
source=compute_sensitivity_snapshot(frames[-1],result,verification,latest_background_dbz=background[-1],sensitivity_config=SensitivityConfig(metric_names=('log_echo_mse',),tile_size=1))
print('shape maps/norm/tiles',source.direct.maps.shape,source.direct.norm.shape,source.direct.tile_norm.shape)
# Construct one available retained map with a single unit cell; then place the
# same whole norm in a different tile. The aggregate remains 1.
maps=source.direct.maps.clone(); norm=source.direct.norm.clone(); tiles=source.direct.tile_norm.clone()
position=0; lead=source.full_map_lead_minutes.index(source.full_map_lead_minutes[position])
lead_idx=source.lead_minutes.index(source.full_map_lead_minutes[position])
assert bool(source.metric_available[lead_idx,0]), source.metric_available
maps[position,0]=0; maps[position,0,0,0]=1
norm[lead_idx,0]=1
tiles[lead_idx,0]=0; tiles[lead_idx,0,1,1]=1
bad=replace(source,direct=replace(source.direct,maps=maps,norm=norm,tile_norm=tiles))
_validate_m0_snapshot(bad)
print('accepted with map_tile_00=1 but stored_norm_tile_11=1')
episode=SensitivityEpisode(episode_id='misplaced-tile-norm',issue_time='2026-07-26T05:00:00+00:00',radar_id='KTLX',contract=_contract(bad),snapshot=bad)
with tempfile.TemporaryDirectory() as directory:
    ledger=EpisodeLedger(Path(directory))
    ledger.append(episode)
    loaded=ledger.load(episode.episode_id)
    print('public_append=accepted persisted_tile_00=',float(loaded.arrays['tile_direct_sensitivity_norm'][lead_idx,0,0,0]),'persisted_tile_11=',float(loaded.arrays['tile_direct_sensitivity_norm'][lead_idx,0,1,1]))
