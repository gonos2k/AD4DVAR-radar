from dataclasses import replace
from pathlib import Path
import tempfile
import torch
from advar.ledger import EpisodeLedger, SensitivityEpisode, _validate_m0_snapshot
from test_ledger import _computed_snapshot, _contract
source = _computed_snapshot()
mask = source.latest_sensitivity_mask.clone(); mask[0,0] = False
maps = source.direct.maps.clone(); norm = source.direct.norm.clone(); tiles = source.direct.tile_norm.clone()
maps[0,0,0,0] = 1.0; norm[2,0] = 1.0; tiles[2,0,0,0] = 1.0
bad = replace(source, latest_sensitivity_mask=mask, direct=replace(source.direct,maps=maps,norm=norm,tile_norm=tiles,impact=None,tile_impact=None),observation_innovation_dbz=None,observation_innovation_mask=None)
_validate_m0_snapshot(bad)
print('private_validation=accepted nonzero_retained_direct_map_outside_active_mask')
episode=SensitivityEpisode(episode_id='direct-outside-mask',issue_time='2026-07-26T05:00:00+00:00',radar_id='KTLX',contract=_contract(bad),snapshot=bad)
with tempfile.TemporaryDirectory() as directory:
 ledger=EpisodeLedger(Path(directory)); ledger.append(episode); print('public_append=accepted')
