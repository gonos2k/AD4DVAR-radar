import tempfile
from dataclasses import replace
from pathlib import Path
import torch
from advar.ledger import EpisodeLedger, SensitivityEpisode, _validate_m0_snapshot
from test_ledger import _computed_snapshot, _contract

source = _computed_snapshot()
print('shape', tuple(source.direct.tile_norm.shape))
print('tile_norm', source.direct.tile_norm)
 # Make one retained direct map/norm pair nonzero, then store the opposite sign
 # for its tile norm. Squaring makes the aggregate unchanged.
maps = source.direct.maps.clone()
maps[0, 0, 0, 0] = 1.0
norm = source.direct.norm.clone()
norm[2, 0] = 1.0
tiles = source.direct.tile_norm.clone()
idx = (2, 0, 0, 0)
old = float(tiles[idx])
tiles[idx] = -1.0
bad = replace(source, direct=replace(source.direct, maps=maps, norm=norm, tile_norm=tiles))
_validate_m0_snapshot(bad)
print('private_validation=accepted', 'old=', old, 'new=', float(tiles[idx]))
episode = SensitivityEpisode(
    episode_id='negative-tile-norm',
    issue_time='2026-07-26T05:00:00+00:00',
    radar_id='KTLX',
    contract=_contract(bad),
    snapshot=bad,
)
with tempfile.TemporaryDirectory() as directory:
    ledger = EpisodeLedger(Path(directory))
    path = ledger.append(episode)
    loaded = ledger.load(episode.episode_id)
    print('public_append=accepted', path.is_dir())
    print('persisted_tile=', float(loaded.arrays['tile_direct_sensitivity_norm'][idx]))
