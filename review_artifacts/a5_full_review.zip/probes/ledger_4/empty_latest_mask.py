from dataclasses import replace
from pathlib import Path
import tempfile
import torch

from advar.ledger import EpisodeLedger, SensitivityEpisode, _validate_m0_snapshot
from test_ledger import _computed_snapshot, _contract

source = _computed_snapshot()
empty_mask = torch.zeros_like(source.latest_sensitivity_mask)
direct = replace(
    source.direct,
    impact=None,
    tile_impact=None,
)
bad = replace(
    source,
    latest_sensitivity_mask=empty_mask,
    direct=direct,
    observation_innovation_dbz=None,
    observation_innovation_mask=None,
)
_validate_m0_snapshot(bad)
print('private_validation=accepted all_false_latest_sensitivity_mask')
episode = SensitivityEpisode(
    episode_id='empty-latest-mask',
    issue_time='2026-07-26T05:00:00+00:00',
    radar_id='KTLX',
    contract=_contract(bad),
    snapshot=bad,
)
with tempfile.TemporaryDirectory() as directory:
    ledger = EpisodeLedger(Path(directory))
    ledger.append(episode)
    loaded = ledger.load(episode.episode_id)
    print('public_append=accepted persisted_true_count=', int(loaded.arrays['latest_sensitivity_mask'].sum()))
