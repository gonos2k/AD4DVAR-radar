from pathlib import Path
import sys
from unittest.mock import patch

import torch

import advar

assert Path(advar.__file__).resolve().parent == Path("/Users/yhlee/ADVAR/src/advar")
sys.path.insert(0, "/Users/yhlee/ADVAR/tests")
import test_a2_numerics  # noqa: E402
import advar.variational as variational  # noqa: E402


def mutant(control, observations, frozen):
    # Validation still runs, but the residual ignores changed observations.
    return torch.zeros_like(observations.dbz)


with patch.object(variational, "_observation_residual", mutant):
    test_a2_numerics.test_canonical_observations_are_finite_without_binding_frozen_state()
print("mutant_test_result=PASS")
