from pathlib import Path
import sys
from unittest.mock import patch

import torch

import advar

assert Path(advar.__file__).resolve().parent == Path("/Users/yhlee/ADVAR/src/advar")
sys.path.insert(0, "/Users/yhlee/ADVAR/tests")
import test_numerical_review  # noqa: E402
import advar.variational as variational  # noqa: E402


def mutant(background, control, scale, limit):
    # Plausible regression: update silently ignores the control increment.
    return background


with patch.object(variational, "_bounded_vector_update", mutant):
    test_numerical_review.NumericalReviewTests(
        "test_zero_background_velocity_derivatives"
    ).run()
print("mutant_test_result=PASS")
