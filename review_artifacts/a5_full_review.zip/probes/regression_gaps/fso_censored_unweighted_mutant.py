from pathlib import Path
import sys
from unittest.mock import patch

import torch

import advar

assert Path(advar.__file__).resolve().parent == Path("/Users/yhlee/ADVAR/src/advar")
sys.path.insert(0, "/Users/yhlee/ADVAR/tests")
import test_a2_fso  # noqa: E402
import advar.sensitivity as sensitivity  # noqa: E402


def mutant(
    name,
    forecast_linear,
    truth_linear,
    valid,
    nowcast_config,
    sensitivity_config,
    grid_time_contract=None,
):
    # Plausible regression: typed/finite weights are ignored in score reduction.
    floor = 10.0 ** (nowcast_config.min_dbz / 10.0)
    difference = torch.log(forecast_linear + floor) - torch.log(truth_linear + floor)
    mask = (valid > 0).to(difference.dtype)
    return (difference.square() * mask).sum() / mask.sum().clamp_min(
        torch.finfo(difference.dtype).tiny
    )


with patch.object(sensitivity, "forecast_metric", mutant):
    test_a2_fso.test_current_v22_censored_weight_binds_p1_domain_and_score()
print("mutant_test_result=PASS")
