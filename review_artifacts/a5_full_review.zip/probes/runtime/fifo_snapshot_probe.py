from pathlib import Path
from tempfile import TemporaryDirectory
import os

import advar.runtime_closure as runtime


with TemporaryDirectory() as temporary:
    fifo = Path(temporary) / "runtime.fifo"
    os.mkfifo(fifo)
    print("before snapshot", flush=True)
    runtime._runtime_file_snapshot(fifo, deployable=False)
    print("after snapshot", flush=True)
