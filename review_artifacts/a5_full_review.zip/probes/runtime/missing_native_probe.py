from pathlib import Path
from subprocess import CompletedProcess
from tempfile import TemporaryDirectory
from unittest.mock import patch

import advar.runtime_closure as runtime


with TemporaryDirectory() as temporary:
    root = Path(temporary) / "site-packages"
    source = root / "package/extension.so"
    source.parent.mkdir(parents=True)
    source.write_bytes(b"extension")
    missing = CompletedProcess(
        args=("ldd", str(source)),
        returncode=0,
        stdout="libcritical.so => not found\n",
        stderr="",
    )
    with (
        patch.object(runtime.platform, "system", return_value="Linux"),
        patch.object(runtime.subprocess, "run", return_value=missing),
    ):
        result = runtime._linked_native_libraries(
            (source,), deployable=False, import_roots=(root,)
        )
    print(result)
