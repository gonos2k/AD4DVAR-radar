import torch

from advar.diagnostics import audit_transport


echo = torch.ones((2, 2), dtype=torch.float64)
moved = torch.zeros((3, 3), dtype=torch.float64)
moved[:2, :2] = 1.0
audit = audit_transport(echo, torch.zeros(2, dtype=torch.float64), moved=moved)
print(audit)
