# A5 bounded review instructions

Repository /Users/yhlee/ADVAR, frozen review base 286c0c9416a645ec4350b24ab9e9faca6584bb56.
User explicitly requests full-codebase team investigation from mathematical, numerical, engineering and meteorological perspectives. Use GREEN to check claimed invariants and RED to seek counterexamples. Report evidence, not blanket safety.

Read /Users/yhlee/ADVAR/ledger_1S.md. You are READ-ONLY for the repository. Do NOT edit code/tests/docs/git, change branches, install dependencies, invoke uv/pip/venv, or modify any shared environment. NEVER run `uv run`. Do not spawn agents. Your only permitted writes are your named report and your own scratch subtree under /tmp/advar-a5-review/probes/ledger_1/.
Use ONLY /Users/yhlee/ADVAR/.venv/bin/python explicitly (Python3.12.13/Torch2.13.0). For probes set OMP_NUM_THREADS=1 MKL_NUM_THREADS=1. Do not run full test suites, backend/MPS work, remote CI or external writes. Small read-only numerical probes or selected tests are allowed. Own scratch outputs only. Imported repository must be asserted to /Users/yhlee/ADVAR/src/advar; do not accidentally use graphify-out isolated copies.

Assignment is /tmp/advar-a5-review/assignments/ledger_1.json. Read every assigned range carefully, with additional callers/callees only as needed. For auditable source reads use:
  /Users/yhlee/ADVAR/.venv/bin/python /tmp/advar-a5-review/read_source.py ledger_1 PATH START END
Each call max350lines; batch sequential small ranges and inspect all returned text (raise output token budget if necessary; don't accept truncation). Script appends honest read ranges to probes/ledger_1/reads.jsonl. Do not claim unexamined ranges. Final coverage may be partial if meaningful review cannot be completed, but explain gaps.

Check known fixes in SECOND_CODE_REVIEW_RESOLUTION.md and FOURTH_CODE_REVIEW_CHECKLIST.md to avoid republishing resolved bugs. Full prior audits are historical, not proof current code is correct. Source code is primary evidence.

Prioritize mathematical function correctness over mere finite outputs; norm/scale/tolerance, gradients and frozen vs resolved operators, units and times, weighted metric consistency, missingness/clear/censored semantics, uncertainty/inference assumptions, resource bounds and persistence races, source/serialization integrity. Trace upper guards: a private helper counterexample rejected at public boundary is a limited boundary finding, not an end-to-end defect. Do not recommend new registries or layers, speculative redesign, or weaken conservative certification. Genuine model limits are not implementation bugs. Use primary sources if external niche scientific facts require verification.

Expected output: /tmp/advar-a5-review/reports/ledger_1.json and optional .md. JSON keys: agent, reviewed_ranges (file,start,end), findings (title, severity, location, actual_vs_expected, affected_public_path, upper_guards_checked, probe_path, classification, minimal_fix), strengths, limitations. Max3 strongest new findings; rank confirmed supported normal paths above forged artifacts/extreme unsupported inputs. If none found say no new confirmed issue in inspected range, never entire repo is bug-free. A failing small reproducible script plus exact command/output is preferred. Preserve output logs in own scratch dir.
Send root any promising critical issue promptly, then finish assigned review. Final message concise with paths, findings, genuine scope.
