import torch, math
from advar.nowcast import NowcastConfig, nowcast, prepare_input, _estimate_available_pair
from advar.physics import dbz_to_echo, echo_to_dbz, remap
h=w=64
yy,xx=torch.meshgrid(torch.arange(h),torch.arange(w),indexing='ij')
def p(shift):
 p=torch.full((h,w),-10.,dtype=torch.float64)
 for y,x,s,a in [(24,16,3,22),(37,19,4,18),(18,27,2,20),(42,30,2.5,19),(29,34,3,17),(49,23,2,16)]:
  p=torch.maximum(p,a*torch.exp(-((yy-y)**2+(xx-(x+shift))**2)/(2*s*s)))
 return p
base0=p(0);base1=p(6);base2=p(12)
amp0=8.;n=1
g=torch.Generator().manual_seed(100+n);inds=torch.randperm(h*w,generator=g)[:n];noise_mask=torch.zeros(h*w,dtype=torch.bool);noise_mask[inds]=True;noise_mask=noise_mask.reshape(h,w);noise_mask[:,:10]=False;noise_mask[:,-10:]=False;noise_mask[:,13:20]=False
lin0=dbz_to_echo(base0,min_dbz=-10,max_dbz=70)*amp0/5
lin1=dbz_to_echo(base1,min_dbz=-10,max_dbz=70);lin2=dbz_to_echo(base2,min_dbz=-10,max_dbz=70)
f0=echo_to_dbz(lin0,min_dbz=-10,max_dbz=70);f1=echo_to_dbz(lin1,min_dbz=-10,max_dbz=70);f2=echo_to_dbz(lin2,min_dbz=-10,max_dbz=70)
f1[noise_mask]=35.;f1[:,13:20]=float('nan');f1[:,50:54]=0.;f2[:,50:54]=float('nan')
frames=torch.stack((f0,f1,f2));cfg=NowcastConfig(minimum_phase_correlation_psr=0.,phase_correlation_sidelobe_radius_px=2,pair_echo_dilation_px=0,minimum_growth_overlap_support=1.,maximum_pair_growth_disagreement=0.05,horizon_minutes=10)
out=nowcast(frames,cfg);out.validate_issuance();m=out.metadata
print('selection',m.motion_pair_selection.value,m.growth_pair_selection.value,'pairs',m.motion_pair_count,m.growth_pair_count,'displacement',out.state.displacement_yx.tolist(),'growth',float(out.state.log_growth_per_step),'path',m.observation_path)
for y,x in [(20,51),(20,50),(20,53),(30,51)]:
 print('point',y,x,'state',float(out.state.echo_linear[y,x]),'support',float(m.source_support[y,x]),'f1',float(f1[y,x]),'f2',float(f2[y,x]) if torch.isfinite(f2[y,x]) else 'nan','forecast',float(out.forecast_dbz[0,y,x]) if torch.isfinite(out.forecast_dbz[0,y,x]) else 'nan')
# Compute per-pair public estimates for evidence and source point's expected selected-vs-motion-coupled growth.
prep=prepare_input(frames,cfg);lin=dbz_to_echo(prep.frames_dbz,min_dbz=cfg.min_dbz,max_dbz=cfg.max_dbz)
no_growth=remap(lin[1],out.state.displacement_yx)[20,51]
print('point no_growth_source',float(no_growth),'actual_growth_factor',float(out.state.echo_linear[20,51]/no_growth),'selected_growth_factor',math.exp(float(out.state.log_growth_per_step)))
for ij in ((1,2),(0,2)):
 e=_estimate_available_pair(prep.frames_dbz,prep.observed_mask,lin,*ij,cfg,None)
 print('estimate',ij,'motion',e[0].tolist(),'growth',float(e[1].value),'support',float(e[1].overlap_support),'psr',float(e[2]))
