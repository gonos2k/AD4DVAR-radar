# Ledger I/O A2 result

Resolved A2-09, A2-10, and A2-11 in `src/advar/ledger.py` with regression
coverage in `tests/test_a2_ledger_io.py`.

## Rationale

- A2-09 now checks duplicate receipt/decision identities while the SQLite
  write lock is held, records whether the action writer published this call's
  directory, and removes that directory when the row insert, publication
  clock check, or commit fails. A pre-existing directory is replayed and is
  never removed by this rollback path. The durable writer also removes its own
  newly renamed directory if the directory fsync fails.
- A2-10 now acquires `BEGIN IMMEDIATE` and checks the trusted clock both after
  lock acquisition and after the INSERT, immediately before an explicit
  commit. A late source-coverage row therefore rolls back. Existing duplicate
  `IntegrityError` to `FileExistsError` behavior remains.
- A2-11 now re-reads the immutable commit and holdout identities after a
  compare/update miss. A valid winner's signed preparation receipt and active
  state are adopted only when the artifact, plan, payload, checksums, path,
  trust digest, and linked holdout identity still match. Both the no-receipt
  preparation race and the prepared-to-active race are idempotent; a changed
  identity still fails closed.

## Validation

- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-a2-implementation/run_pytest.py /tmp/advar-a2-implementation/ledger_io tests/test_a2_ledger_io.py -q` — 3 passed.
- Same runner with `tests/test_ledger.py -q` — 50 passed, 41 subtests passed.
- Same runner with the targeted promotion/recovery selectors — 6 passed.
- Adapted public A2-09 orphan probe — one indexed directory remained and the failed duplicate receipt directory was removed.
- Adapted public A2-10 deadline probe — late append raised `ValueError` and retained no row.
- Adapted public A2-11 concurrent probe — both workers returned the artifact digest and final state was `active, 1`.
- `python -m py_compile src/advar/ledger.py tests/test_a2_ledger_io.py` and `git diff --check` passed.

The full promotion module run was intentionally interrupted after 13 tests and
329 seconds because it is a broad, multi-minute numerical suite; no test
failure was observed before interruption. The focused tests cover the changed
transaction boundaries. Failure injection covers SQLite duplicate/clock
rollback and forced post-commit recovery; it does not simulate an OS power
loss during directory fsync.

Follow-up commit `68cad84ac40a7cf5927eb69ffd01fd2bb9709d9e` removes the unused
pre-write existence variable and reacquires `BEGIN IMMEDIATE` after rollback
before checking the receipt row or removing the newly published directory.
This closes the retry gap between rollback and cleanup; a retry that owns the
writer lock and commits the receipt is observed and its pre-existing directory
is preserved. The focused regression set remains 4 passed including the
existing public receipt round-trip.

Exact follow-up validation:

```text
OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I \
  /tmp/advar-a2-implementation/run_pytest.py \
  /tmp/advar-a2-implementation/ledger_io \
  tests/test_a2_ledger_io.py \
  tests/test_ledger.py::EpisodeLedgerTests::test_prospective_decision_and_executor_receipt_round_trip -q
→ 4 passed in 3.23s
```

The cleanup/retry lock argument is source-reviewed and supported by the public
orphan probe; a separately coordinated concurrent cleanup/retry regression was
not added because the available public fixture did not provide a stable failure
injection boundary without testing timing rather than the ledger contract.

Follow-up cleanup review (A2-24, extending A2-09/A2-11) found the same
rollback window in holdout and operational provenance publication. Both paths
now mark ownership immediately after a new directory is renamed into place,
before the parent-directory fsync can fail. Their rollback cleanup reacquires
`BEGIN IMMEDIATE`, checks the committed provenance identity while holding the
writer lock, removes only an uncommitted directory, fsyncs the parent
directory, and commits the cleanup transaction. A pre-existing or concurrently
committed artifact is therefore retained while a retry cannot index the
directory between the check and removal.

Exact follow-up validation after this change:

```text
python -m py_compile src/advar/ledger.py tests/test_a2_ledger_io.py
git diff --check
OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I \
  /tmp/advar-a2-implementation/run_pytest.py \
  /tmp/advar-a2-implementation/ledger_io \
  tests/test_a2_ledger_io.py \
  tests/test_promotion.py::NeuralPriorPromotionTests::test_future_operational_provenance_does_not_require_holdout \
  tests/test_promotion.py::NeuralPriorPromotionTests::test_recovery_rechecks_processor_and_derivation_chronology \
  tests/test_ledger.py::EpisodeLedgerTests::test_prospective_decision_and_executor_receipt_round_trip -q
→ 6 passed in 4.82s
```

The direct post-rename fsync fault-injection regression was added to the public
operational fixture. It verified that the failed new directory was removed with
no committed row, and that a later valid pre-existing orphan directory remained
available for reuse. Exact selector result: `tests/test_a2_ledger_io.py` — 4
passed in 2.36s with the ownership-before-fsync source fix applied. A separate
coordinated cleanup/retry timing regression remains not run because the public
fixtures do not expose a stable interleaving boundary; the direct fault
injection tests the ownership contract without relying on timing.
