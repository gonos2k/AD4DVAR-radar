# Promotion A2 implementation result

Resolved A2-02 and A2-04.

## A2-02: physical event association

`_events_associate` now treats any common track time as an overlap case. It
uses the existing symmetric minimum relative-track distance and symmetric
spatial-envelope IoU there, without choosing an arbitrary earlier event. For
disjoint intervals, the unique chronological ordering still extrapolates the
earlier terminal velocity and enforces the configured maximum time gap.

The invariant is that swapping event arguments cannot change either the common
time interval or the minimum distance over that interval. Disjoint intervals
have one physically meaningful temporal order, so chronology is used only in
that branch.

## A2-04: simultaneous uncertainty inference

Automatic promotion now evaluates the bounded empirical-Bernstein UCB directly
and reports deterministic diagnostics (`effective_replicates=1`, zero estimated
bootstrap tail and Monte Carlo error, and no randomized multiplier). It does
not construct multiplier rows. The exploratory shadow-bootstrap branch retains
the previous exact-sign/studentized multiplier calculation and tail behavior.

## Files

- `src/advar/promotion.py`
- `tests/test_a2_promotion.py`

## Verification

- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-a2-implementation/run_pytest.py /tmp/advar-a2-implementation/promotion tests/test_a2_promotion.py -vv` — 5 passed.
- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-a2-implementation/run_pytest.py /tmp/advar-a2-implementation/promotion tests/test_review_promotion_statistics.py tests/test_promotion.py -k 'promotion_statistics or simultaneous_uncertainty_count_covers_family_components_groups or automatic_uncertainty_never_treats_zero_variance_as_certainty or automatic_small_sample_aggregate_does_not_use_point_bootstrap' -vv` — 4 passed.
- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-a2-implementation/run_pytest.py /tmp/advar-a2-implementation/promotion tests/test_review_promotion_contracts.py tests/test_promotion.py -k 'physical_event or cross_radar_motion_components_cannot_be_split or same_physical_storm_across_days_and_radars_is_one_cluster' -vv` — 10 passed.
- An isolated exploratory probe with `allow_shadow_small_sample_bootstrap=True` retained `studentized_multiplier`, randomized diagnostics, and sample-count-dependent tail replicates.
- `git diff --check` and Python compilation passed.

## Commit

`b346596` (`Fix promotion association and bounded uncertainty`)

## Risks and limits

The event tests use the existing public signed catalog constructors with small
synthetic tracks. They verify connected/disconnected ordering and chronology
limits, but do not establish the quality of any real radar object tracker.
The bounded UCB remains subject to the existing event-independence assumption.
