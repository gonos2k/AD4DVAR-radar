# FSO A2 implementation result

Resolved A2-01 and A2-17 in the FSO-owned scope.

## Changes

- `src/advar/sensitivity.py`
  - Extended `_metric_domain_weight()` with an optional resolved verification
    metric weight. It now returns one detached product of the forecast domain
    and typed FSO verification weight.
  - Routed M0, P1 FSO/FSOI, resolved scoring, and learning re-solves through
    that product before support checks, scores, derivatives, metric-domain
    sums/digests, and learning comparison.
  - Kept raw Tensor verification behavior unchanged: its resolved weight is
    the finite mask, so the product is identical to the legacy domain mask.
  - Bound v4 learning approval evidence to
    `FirstOrderValidation.nominal_full_analysis_input_digest`, while retaining
    v1-v3 evidence compatibility.

- `tests/test_a2_fso.py`
  - Added current v22 censored M0 and P1 checks, spatial no-support P1 check,
    fractional detached-weight check, and forged v4 full-analysis-input
    approval rejection.

## Validation

- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-a2-implementation/run_pytest.py /tmp/advar-a2-implementation/fso tests/test_a2_fso.py --maxfail=1`
  - 5 passed.
- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-a2-implementation/run_pytest.py /tmp/advar-a2-implementation/fso tests/test_sensitivity.py --maxfail=1`
  - 93 passed.
- `git diff --check`
  - passed.

Commit: `b18da85` (`Fix typed verification weights in FSO metrics`).

The current v22 fixture is synthetic and deterministic, but follows the
production geometry, mask derivation, and verification bundle construction.
The root agent must resolve any textual conflict in `sensitivity.py` with its
baseline-branch certification edit when cherry-picking this commit.
