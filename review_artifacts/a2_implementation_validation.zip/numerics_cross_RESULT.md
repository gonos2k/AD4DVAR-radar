# Numerics cross-review follow-up result

Follow-up commits: `f8038a5` (`Harden cross-dtype remap and control admission`)
and `4144ba5` (`Preserve remap displacement device before fraction cast`).
It was applied after numerics baseline commit `99d0046caa759e1b867deb07c5bc13927c14e041`.

## Scope and rationale

- `src/advar/physics.py`
  - A finite `float64` displacement of `(1e308, -1e308)` with a `float32`
    echo previously overflowed when the displacement was cast to echo dtype
    before frozen-cell selection, causing public `remap()` to reject it.
    Direct `remap_core()` produced NaN fractions from `inf - inf`.
  - The follow-up keeps the original finite displacement dtype through frozen
    branch selection and fraction arithmetic, then casts only finite clamped
    fractions to echo dtype. The whole-domain branch remains zero and its
    echo/displacement AD paths remain connected and finite.
  - Integer-boundary frozen-cell derivatives remain on the existing branch
    semantics and are covered independently.

- `src/advar/variational.py`
  - `validate_analysis_linearization_content()` now calls the existing
    `_validate_control()` before remap-cell matching/indexing. This rejects
    malformed controls with wrong dtype, extra tail values, or short length;
    the expected control contract remains exactly
    `active_field_index.numel() + 3` values with the frozen state's dtype and
    device.

- `tests/test_a2_numerics_cross.py`
  - Covers the `float32` echo / `float64` `(1e308, -1e308)` remap through
    JVP, VJP, and backward, asserting finite all-zero output and derivatives.
  - Covers the cross-dtype integer boundary at frozen cell `(1, 0)` with the
    expected branch derivative.
  - Covers wrong-dtype, extra-tail, and short control admission after
  content-addressing a linearization.
  - The MPS regression test covers a float32 MPS echo with a CPU float64
    displacement through forward and JVP. It is skipped when MPS is absent.

- MPS verification showed that `f8038a5` still moved a CPU float64
  displacement to the MPS echo device before fraction formation, which fails
  because MPS does not support float64. `4144ba5` keeps the original device and
  dtype through frozen-cell validation and clamping, then copies only the
  finite clamped fractions to the echo. On the available MPS runtime,
  displacements `1.0`, `1e20`, and `1e308` all produced finite forward/JVP
  results. CPU float32 displacement VJP also passes; CPU float64 displacement
  VJP remains a PyTorch MPS limitation because its gradient would need an MPS
  float64 tensor.

- The proposed `reference.new_tensor((float(cell.y), float(cell.x)))` cell
  construction was independently compared with the existing stack of scalar
  additions for float32/float64 references, displacement `1.0`, and finite
  `1e308`. Values, JVP, VJP, and backward gradients matched exactly. The
  existing stack was left unchanged in this follow-up.

## Exact validation

- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-a2-implementation/run_pytest.py /tmp/advar-a2-implementation/fso tests/test_a2_numerics_cross.py --maxfail=1`
  - 6 passed (including the available-MPS regression).
- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-a2-implementation/run_pytest.py /tmp/advar-a2-implementation/fso tests/test_a2_numerics.py tests/test_a2_numerics_cross.py tests/test_shift_zero.py --maxfail=1`
  - 14 passed.
- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-a2-implementation/run_pytest.py /tmp/advar-a2-implementation/fso tests/test_variational.py -k 'final_linearization_tracks_remap_branch_changes or p1_linearization_artifact or detected_censored_and_once_whitened_residuals or three_observation_blocks_are_explicit or final_linearization_is_polished_to_stationarity' --maxfail=1`
  - 4 passed, 138 deselected.
- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-a2-implementation/run_pytest.py /tmp/advar-a2-implementation/fso tests/test_a2_fso.py --maxfail=1`
  - 5 passed.
- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-a2-implementation/run_pytest.py /tmp/advar-a2-implementation/fso tests/test_matrix_free.py --maxfail=1`
  - 10 passed.
- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-a2-implementation/run_pytest.py /tmp/advar-a2-implementation/fso tests/test_a2_numerics.py tests/test_shift_zero.py --maxfail=1`
  - 9 passed.
- `git diff --check`
  - passed before commit.

## Limits

No full repository baseline or CUDA run was performed. The giant-shift case is
an accepted finite-input numerical boundary and is tested with a minimal 2x2
CPU field. Control-admission checks exercise the public content validator with
a converged minimal P1 linearization; they do not claim an operational
artifact was emitted with malformed control data. MPS float64 VJP remains
backend-limited as described above.

## Root final cross-device refinement review

The root checkout's final physics refinement was reviewed read-only after
`4144ba5`. It keeps the existing scalar stack construction because the
`new_tensor((float(y), float(x)))` sequence fails under the MPS
`functorch` dispatch key. The fraction conversion is split at the backend
boundary:

- MPS source fractions first move to the echo device while retaining their
  supported source dtype, then narrow or widen on CPU to the echo dtype.
- Non-MPS source fractions cast to the echo dtype on their source device, then
  move to the echo device.

This preserves the differentiable displacement path in both directions. It
avoids MPS float64 in forward and reverse mode, and each device/dtype transfer
is necessary for the corresponding cross-device case; same-device/same-dtype
`.to` calls are no-ops. The added tests cover CPU float64 motion to MPS float32
echo with JVP and VJP, plus MPS float32 motion to CPU float64 echo with VJP.
No new correctness finding or needless-copy concern was identified. This was
a source review only; the root agent ran the final scoped test set separately.
