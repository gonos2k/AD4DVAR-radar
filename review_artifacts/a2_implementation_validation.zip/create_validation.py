import hashlib, json, platform, re, subprocess, sys, xml.etree.ElementTree as ET, zipfile
from pathlib import Path
root = Path('/Users/yhlee/ADVAR')
work = Path('/tmp/advar-a2-implementation')
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
records = []
unique = set()
for name in ('root_sensitivity', 'integration', 'final_followup'):
    path = work / (name + '.xml')
    if not path.exists():
        continue
    tree = ET.parse(path)
    cases = tree.findall('.//testcase')
    failures = [c.attrib for c in cases if c.find('failure') is not None or c.find('error') is not None]
    assert not failures, failures
    unique.update((c.attrib['classname'], c.attrib['name']) for c in cases)
    records.append({'name': name, 'case_count': len(cases), 'junit_suites': [s.attrib for s in tree.findall('testsuite')], 'log': (work / (name + '.log')).read_text()})
changed = subprocess.check_output(['git', 'diff', '--name-only', 'fc0dc6d', 'HEAD'], cwd=root, text=True).splitlines()
files = {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in changed if (name.startswith('src/') or name.startswith('tests/') or name.startswith('.github/') or name == 'AGENTS.md') and (root / name).is_file()}
report = {'implementation_base': 'fc0dc6d7c6ada07ad1b610b63a0d7daff2c9fc89', 'implementation_commit': head, 'status': 'local_scoped_tests_passed_remote_final_ci_pending', 'unique_test_cases': len(unique), 'test_runs': records, 'file_sha256': files, 'environment': {'platform': platform.platform(), 'python': sys.version, 'torch': __import__('torch').__version__, 'OMP_NUM_THREADS': '1', 'MKL_NUM_THREADS': '1'}, 'limits': ['No repeated full local baseline', 'No CUDA or full MPS P1 claim', 'No real radar forecast skill evaluation', 'Historical raw audit archives remain immutable', 'Final commit CI is tracked in PR checks and KG index']}
report['typecheck'] = (work / 'types_final_after_followup.log').read_text()
assert '0 errors' in report['typecheck']
(root / 'review_artifacts/a2_implementation_validation.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
selected = [p for p in work.iterdir() if p.is_file() and (p.name.endswith(('_RESULT.md', '.log', '.xml')) or p.name in {'INSTRUCTIONS.md', 'run_pytest.py', 'create_validation.py'})]
manifest = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in selected}
archive = root / 'review_artifacts/a2_implementation_validation.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as bundle:
    for path in sorted(selected):
        bundle.write(path, path.name)
    bundle.writestr('manifest.json', json.dumps(manifest, indent=2))
print(json.dumps({'head': head, 'unique_test_cases': len(unique), 'archive_files': len(selected) + 1, 'archive_bytes': archive.stat().st_size, 'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest()}, indent=2))
