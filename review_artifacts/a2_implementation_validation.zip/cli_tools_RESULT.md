# A2 CLI tools result

Resolved A2-21, A2-22, and A2-23 in the isolated `cli_tools` worktree.

## Rationale

- A2-21: a pair velocity disagreement expressed in m/s is only meaningful with
  the grid spacing, projection, and valid times that define its metric and time
  conversion. The research CLI now rejects this option without the complete
  grid/time contract instead of allowing the pixel comparison fallback.
- A2-22: pair echo dilation, phase-correlation sidelobe radius, and minimum
  growth-overlap area are physical thresholds. They now participate in the
  existing CLI physical-option preflight, so missing metadata is reported as
  an argparse usage error before forecasting or publication.
- A2-23: the verifier accepts only `linux-x86_64-cpu`. The legacy builder now
  rejects a non-`x86_64` Linux host after read-only preflight and immediately
  before output creation, preserving the existing Linux-only diagnostic and
  avoiding ARM support or registry changes.

## Files

- `src/advar/cli.py`
- `.github/scripts/build_deployment_bundle.py`
- `tests/test_a2_cli_tools.py`

## Validation

- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-a2-implementation/run_pytest.py /tmp/advar-a2-implementation/cli_tools tests/test_a2_cli_tools.py` — 3 passed.
- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-a2-implementation/run_pytest.py /tmp/advar-a2-implementation/cli_tools tests/test_cli.py tests/test_deployment_bundle.py` — 27 passed.
- `ruff check src/advar/cli.py .github/scripts/build_deployment_bundle.py tests/test_a2_cli_tools.py` — all checks passed.
- Original ARM platform probe — raised `ValueError: current deployment bundle requires Linux x86_64` before writing a bundle.
- `git diff --check` — passed.

## Risks and limits

The architecture check intentionally accepts exactly the verifier's existing
`x86_64` identity. Other Linux machine strings, including ARM, remain
unsupported. The CLI tests use a small synthetic radar input and validate the
public parser/output path; they do not claim operational forecast quality.

## Commit

`be8f2b148c3f18fc587aea11cf6fb9dfd5a138a2`
