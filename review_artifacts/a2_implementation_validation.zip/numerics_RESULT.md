# A2 numerics implementation result

Resolved A2-16, A2-18, A2-19, and A2-20.

The retained P1 linearization validator now checks the existing
`_analysis_remap_cells_match` relation after content addressing, so a
self-addressed artifact cannot retain a tangent branch inconsistent with its
control. Canonical `AnalysisObservations.dbz` values are required to be
finite at validation boundaries; raw NaN/Inf frame preparation still
canonicalizes invalid values, and finite observed-data perturbations continue
to work with a fixed frozen state. Remap fractions now construct frozen cell
coordinates through floating scalars, preserving the displacement AD operand
and allowing finite extreme shifts to take the existing whole-domain zero
path. Range partition evidence now rejects empty and duplicate regime labels.

Files:

- `src/advar/variational.py`
- `src/advar/physics.py`
- `src/advar/range_geometry.py`
- `tests/test_a2_numerics.py`

Validation:

- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-a2-implementation/run_pytest.py /tmp/advar-a2-implementation/numerics tests/test_a2_numerics.py` — 4 passed.
- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-a2-implementation/run_pytest.py /tmp/advar-a2-implementation/numerics tests/test_shift_zero.py tests/test_a2_numerics.py` — 9 passed, including available MPS remap derivative checks.
- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-a2-implementation/run_pytest.py /tmp/advar-a2-implementation/numerics tests/test_variational.py -k 'detected_censored_and_once_whitened_residuals or three_observation_blocks_are_explicit or common_bias_whitener_matches_dense_inverse_square_root or overlapping_common_bias_factorization_is_frozen_once or censored_background_is_independent_of_storage_value or final_linearization_is_polished_to_stationarity or final_linearization_tracks_remap_branch_changes or p1_linearization_artifact'` — 7 passed.
- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-a2-implementation/run_pytest.py /tmp/advar-a2-implementation/numerics tests/test_numerical_review.py tests/test_review_numerics.py` — 25 passed.
- `git diff --check` — passed.

Risks and limits: the extreme remap contract is for finite displacement
inputs; nonfinite displacement remains rejected. The remap branch check is
an artifact-content invariant and does not alter solver branch refreshes.
No full repository baseline was run.

Commit: `99d0046caa759e1b867deb07c5bc13927c14e041`
