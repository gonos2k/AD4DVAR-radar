# A2 artifact implementation results

Resolved A2-05, A2-06, and A2-07.

## Rationale

- `radar-spatial-grid-identity-v5` is the registry predecessor and audit-only
  projected scientific representation. Current `nowcast()` issuance and the
  current `forecast-run-v72` save/load boundary reject exactly that generation.
  v1-v4 research/grid paths remain constructible and usable, and historical
  artifact versions skip the current issuance gate so v5 byte/audit decoding
  remains available.
- Accepted numeric background ages are converted to `float` at the producer
  boundary and every serialized age scalar is explicitly `float64`. This keeps
  input-bundle identity and loader scalar contracts consistent.
- Legacy migration compares exact finite values while separately requiring
  identical NaN masks. No numeric tolerance was introduced.

## Files

- `src/advar/nowcast.py`
- `src/advar/run_artifact.py`
- `tests/test_a2_artifacts.py`

## Follow-up: direct current admission

The follow-up adds the same exact predecessor-v5 current-issuance gate to
`ForecastRunContract.from_inputs`. It does not add the gate to
`validate_integrity` or `forecast_from_state`, because legacy artifact loading
constructs the run directly and then replays it through `forecast_from_state`.
The regression builds a digest-consistent `forecast-run-v42` archive with the
v5 grid and verifies that it still loads and migrates. The gate compares only
the registered v5 predecessor, leaving v1-v4 research/grid construction
unchanged.

## Validation

- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-a2-implementation/run_pytest.py /tmp/advar-a2-implementation/artifacts tests/test_a2_artifacts.py`: 4 passed.
- Same runner with `tests/test_nowcast.py`: 167 passed.
- Same runner with `tests/test_run_artifact.py tests/test_review_run_identity.py`: 54 passed, 18 warnings.
- Same runner with focused 6-test selector across new/nowcast tests: 6 passed.
- `ruff check src/advar/nowcast.py src/advar/run_artifact.py tests/test_a2_artifacts.py`: passed.
- `git diff --check`: passed.
- An isolated compatibility probe created a consistent v5 artifact through the historical path and loaded it as `forecast-run-v71`.
- `... run_pytest.py ... tests/test_a2_artifacts.py`: 6 passed after the direct-admission follow-up.
- `... run_pytest.py ... tests/test_nowcast.py -k 'grid_time_contract_is_canonical'`: 1 passed.
- `... run_pytest.py ... tests/test_run_artifact.py -k 'round_trip_preserves_grid_time_contract or round_trip_preserves_scientific_projected_grid_identity or reduced_v42_artifact_keeps_legacy_background_migration'`: 2 passed, 46 deselected.
- `... run_pytest.py ... tests/test_promotion.py -k 'operational_range_geometry_must_match_current_run_grid or centroid_support_uses_the_full_affine_grid_diameter'`: 2 passed, 225 deselected; these exercise v1/default grid run construction.
- `git diff --check` and `python -m compileall -q src/advar/nowcast.py tests/test_a2_artifacts.py`: passed.

## Risks and limits

The v5 rejection is applied at current `nowcast()` and v72 artifact boundaries;
direct research estimators and historical loaders retain their existing broader
generation support. The repository's basedpyright executable was unavailable in
the provided environment, so static verification was limited to Ruff and
compile/import checks.

Commits: `c335147` (`Fix current artifact admission and legacy migration`),
`54204aa` (`Reject direct current issuance of audit-only grid`)
