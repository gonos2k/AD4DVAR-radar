# Root integration and cross-review

Implementation base fc0dc6d; final implementation 95c0ccd. Eight owner agents and peer reviews used gpt-5.6-luna / xhigh in isolated worktrees. Root applied all commits sequentially and preserved unrelated user files.

- Root P0 fix: finite matching samples are not a whole-interval proof. Nonzero observation-derived P0 paths become unknown; zero paths remain certified and absent paths remain not_applicable. Exploratory FSOI is retained, strict/learning rejects unknown. Full/half nonlinear checks remain independent. README states material availability limitation.
- Root branch and existing sensitivity suite: 95 passed, 111 subtests.
- Integrated A2, ledger, artifact, shift-zero, selected P1 and provenance tests: 148 passed, 173 subtests at 3cecbc2 product source.
- Final affected numerical/FSO/provenance tests after cross-device and ownership fixes: 28 passed, 91 subtests. Final product source is identical to 95c0ccd.
- Final basedpyright 1.39.9 product check: 0 errors, 0 warnings, 0 notes.
- New A2 test Ruff and git diff check passed. Broad product Ruff still has 38 pre-existing findings (baseline comparison retained); no unrelated rewrite.
- Two failed MPS intermediate probes are preserved: sequence constant construction under functorch and fused cross-device/dtype conversion. Final scalar-stack plus ordered device/dtype copies passed both directions. This is a local transport test, not full MPS P1 support.
- One initial integration command referenced nonexistent test_remap.py, collected no tests, then was corrected to the observed test_shift_zero.py path. The no-test collection log is retained.
- CI CPU pytest uses OMP_NUM_THREADS=1 / MKL_NUM_THREADS=1 to match local validation. Full suite and timeout unchanged. No Linux profiling claim; runtime identity intentionally records the thread setting.
- A2-24 shared provenance cleanup uses a write lock across retained-row check/removal. Ownership is set immediately after a new rename and before fsync. Public injected fsync failure cleans newly owned bytes and preserves preexisting orphan bytes; separate timed concurrent cleanup/retry test was not run.

No repeated full local baseline, CUDA, full MPS P1, live deployment, real radar skill evaluation, or full browser render was performed. Remote final-head CI is recorded in PR checks and KG after push. Historical archives remain immutable.
