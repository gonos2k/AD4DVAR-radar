# A2-08 intervention result

## Resolved

Prospective dBZ correction, QC, and operator-override actions now require a
non-identity transition in the canonical dBZ, observation-mask, or quality
channels before `ProspectiveInterventionDecision.from_policy()` can return a
decision. This closes the decision/receipt mismatch that allowed an operator
to approve a decision that could never produce a realized receipt.

The safety diagnostic `changed_pixel_count` remains based on the action's
selection mask. In particular, an override may report a selected pixel while
its dBZ delta is zero, but the canonical transition check rejects that action.
Quality-only QC deweighting remains a genuine transition. Existing receipt
checks for masked-cell standard-deviation normalization and active-cell
standard-deviation preservation remain unchanged.

## Files

- `src/advar/intervention.py`: canonical action transition projection and
  prospective safety rejection.
- `tests/test_a2_intervention.py`: regression coverage for zero dBZ, unchanged
  QC, same-value override, and genuine override changes.

## Validation

All commands used the assigned worktree source through `run_pytest.py` with
isolated Python and one OpenMP/MKL thread.

- `tests/test_a2_intervention.py`: **2 passed**
- `tests/test_review_intervention.py`: **3 passed**
- `tests/test_ledger.py`: **50 passed**
- Focused ledger selectors (`prospective_decision_and_executor_receipt_round_trip`,
  `typed_actions_plan_times_and_global_radius_fail_closed`, and
  `retrospective_replay_is_a_separate_audit_record`): **3 passed**
- `git diff --check`: passed

## Commit

`7ad535eb8b99a43d59ccf6d69df0ec97755a6db7` (`Reject prospective intervention no-ops`)

## Limits

No ledger source was modified. The no-op decision now fails before an operator
approval or ledger append can receive a valid decision; receipt-side transition
checks remain as defense in depth.
