# A2 ledger snapshot result

Resolved A2-12, A2-13, A2-14, and A2-15 on `agent/a2-fix-ledger_snapshot`.

## Theory and caller rationale

- A2-12: M0 publication now requires the typed snapshot feature tuple to equal
  the current `CONTEXT_FEATURE_NAMES` tuple. This aligns append-time validation
  with the current manifest verifier and prevents an indexed artifact that
  cannot verify.
- A2-13: when impacts are retained, unavailable metric cells require NaN tile
  impacts just as their whole-field impacts do. Available zero-gradient
  evidence remains valid and is not changed.
- A2-14: whitened tile norms are recomputed as the padded per-tile L2 norm of
  `direct map * observation_std_dbz`, but only for selected leads whose direct
  maps are actually retained. Unselected lead diagnostics are not fabricated
  or compared against absent maps. The check uses the existing norm tolerance
  (`rtol=1e-5`, `atol=1e-7`), preserving scale-aware `allclose` behavior.
- A2-15: both latest-frame spatial dimensions must be positive before tensor
  shapes and vacuous reductions are accepted.

## Files

- `src/advar/ledger.py`: `_validate_m0_snapshot` and adjacent `_tile_l2_norm`
  helper.
- `tests/test_a2_ledger_snapshot.py`: public append/verify/load regression
  coverage for valid computed snapshots and all four malformed boundaries.

## Verification

- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-a2-implementation/run_pytest.py /tmp/advar-a2-implementation/ledger_snapshot tests/test_a2_ledger_snapshot.py` — 5 passed.
- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -I /tmp/advar-a2-implementation/run_pytest.py /tmp/advar-a2-implementation/ledger_snapshot tests/test_ledger.py tests/test_review_ledger.py tests/test_a2_ledger_snapshot.py` — 61 passed.
- `git diff --check` — passed.
- Independent anisotropic tile padding oracle for `_tile_l2_norm` — passed.

## Commit

`b989552` (`Harden M0 snapshot publication validation`)

## Risks and limits

The schema equality applies to current M0 publication, while historical
manifest decoding remains governed by its existing schema-version rules.
Whitened equality intentionally cannot validate unselected lead maps because
those maps are not retained; existing shape and finite/NaN availability checks
still cover every stored whitened diagnostic.
