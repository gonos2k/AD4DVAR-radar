from pathlib import Path
import hashlib,json,shutil,zipfile
root=Path('/Users/yhlee/ADVAR'); work=Path('/tmp/advar-a5-fix')
draft=json.loads((work/'resolution-index-draft.json').read_text())
entries=draft['entries']
for item in entries:
    if item['resolution_state']=='resolved_pending_report_rewrite':
        item['resolution_state']='resolved'
        item['reason_or_limit']='The implementation report JSON was repaired and validated; implementation and focused regression evidence are retained in '+item['implementation_report']+'.'
    if item['finding_id']=='intervention.1':
        item['reason_or_limit']='In-memory contexts bind the supplied source mask. The existing durable archive has no source tensor, so append and replay reject a nontrivial source digest instead of reconstructing all-ones support. Legacy None/all-ones digests remain compatible.'
    if item['finding_id']=='promotion_3.3':
        item['reason_or_limit']='Censored intervals have positive event weight only when the threshold is strictly above their limit (with conservative roundoff margin). Confirmed clear is categorically non-echo regardless of stored dBZ. Both target factories require OBSERVED_ECHO plus the support threshold for echo labels, so intensity sees quantitative echo values only.'
    if item['finding_id']=='variational_1.1':
        item['reason_or_limit']='Pixel offsets are clipped to useful grid extents. Tile height and width are clipped independently, retaining covariance blocks and bounding padded area to under four times the grid. Arbitrary large grids still require O(HW) storage and can be expensive; there is no unlimited-size execution guarantee.'
    if item['finding_id']=='promotion_3.2':
        item['tests_added'].append('tests/test_a5_scoring.py::A5ScoringTests::test_issuance_change_fractions_use_operational_and_parent_denominators')
    item['unresolved_product_issue']=False
cross=[
 {'id':'pseudo_huber_forward_and_reverse_overflow','resolution':'Stable large-region factorization and scaled IRLS; value, gradient and second derivative are independently checked near the finite cost limit. Subnormal delta configurations are rejected explicitly at preparation.','evidence':['reports/variational_1.json','root-numerics-final.txt','tests/test_a5_variational.py']},
 {'id':'tiny_speed_parameters','resolution':'Preparation and the vector update reject projected scale, limit or scale/limit outside the normal finite state-dtype range.','evidence':['reports/variational_1.json','tests/test_a5_variational.py']},
 {'id':'skinny_tile_padding','resolution':'Remove zero-only rows/columns independently per axis; preserve blocks and JVP, bound padding area by four times input.','evidence':['reports/root_resources.json','tests/test_a5_resources.py']},
 {'id':'durable_partial_source_mask','resolution':'Explicitly reject unreconstructible current source masks in unchanged durable archive, keep legacy/all-ones support.','evidence':['reports/cross_engineering_followup.json']},
 {'id':'acceptance_root_error','resolution':'Normalize root open OSError to ValueError and use nonblocking file descriptors for FIFO rejection.','evidence':['reports/cross_engineering_followup.json']},
 {'id':'confirmed_clear_support_and_intensity','resolution':'Use typed OBSERVED_ECHO state plus threshold in both target factories; categorical clear keeps event weight and a false echo label regardless of stored floor.','evidence':['reports/cross_science.json','reports/a5fix_scoring.json']},
 {'id':'quality_gradient_scope','resolution':'Quality and mask are fixed target metadata. Regression tests verify prediction gradients, including zero-quality cells; no general quality-optimization derivative is claimed.','evidence':['src/advar/promotion.py','tests/test_a5_loss_stats.py']},
]
report={
 'schema':'a5-resolution-v1','review_base_commit':'286c0c9416a645ec4350b24ab9e9faca6584bb56','pr':'https://github.com/gonos2k/AD4DVAR-radar/pull/158',
 'team':{'model':'gpt-5.6-luna','reasoning_effort':'xhigh','implementation_agents':12,'independent_cross_reviews':3,'index_synthesis_agents':1},
 'original_adjudication_count':len(entries),'count_note':'These include duplicates, test notes and withdrawn claims; this is not a production-bug count.',
 'priority_items':{f'A5-{i:02d}':'resolved' for i in range(1,13)},'entries':entries,'cross_review_closures':cross,
 'validation':{'local_integration':'PENDING FINAL RUN','typecheck':'0 errors, 0 warnings (error-level report)','environment':'Python 3.12.13, Torch 2.13.0; shared package manifest unchanged','mps':'Local FP16/FP32 weighted-loss value/prediction-gradient probes passed; not P0/P1 certification','counterfactual':'New selected regressions on original 286c0c9 reproduced 27 failures including subtests, 9 passes and 2 resource tests deselected; original-source log included.','remote_ci':'Earlier 286c0c9 run 33996929420 passed all four jobs; final PR HEAD must be checked separately.'},
 'limitations':['No new real-radar hindcast or CUDA end-to-end run.','No full local baseline rerun; integration covers changed and related suites. Full CPU baseline is remote CI.','Operational inference remains unsupported; historical validators are not deployment authorization.','Some existing smoke tests test integration identity while numerical oracles are separate; this does not prove every durable malformed-input combination.','Source traversal coverage and passing tests are not proof of absence of defects.','Arbitrary grid sizes and all finite combinations of parameters/AD orders are not certified.'],
 'source_manifest':'final-source-hashes.json','investigation_archive_sha256':hashlib.sha256((root/'review_artifacts/a5_full_review.zip').read_bytes()).hexdigest(),
}
# Each original claim has one explicit disposition.
assert len({(e['agent'],e['finding_index']) for e in entries})==len(entries)==70
(root/'review_artifacts/a5_resolution.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
