A5 resolution evidence

Base source: 286c0c9416a645ec4350b24ab9e9faca6584bb56.
The resolution JSON is the final root adjudication; individual reports and integration.txt retain their historical pre-follow-up states. integration-final.txt is the final current-source integration result. former-regressions.txt is intentionally failing original-source counterfactual evidence.

Apply final.patch to the base source and copy tests/test_a5_*.py, or use PR158 final files; compare final-source-hashes.json. Use the existing pinned Python/Torch environment. Do not recreate a shared venv.

Run: OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 .venv/bin/python -m pytest -q tests/test_a5_*.py tests/test_a2_*.py tests/test_m0_linearity_weights.py tests/test_numerical_review.py tests/test_review_numerics.py tests/test_review_ledger.py tests/test_review_promotion_contracts.py tests/test_review_promotion_statistics.py --tb=short
Run: OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 .venv/bin/python root_numerics_final.py

Reports may contain original absolute scratch paths; corresponding reports/probes are preserved here. No full local baseline or new real-radar/CUDA end-to-end execution is claimed. Latest remote CI is on PR158 and may postdate this archive.
