# A5 resolution team

User authorized resolving the full A5 investigation. Repository /Users/yhlee/ADVAR,
base286c0c9, existing PR158 branch. Read AGENTS.md, FIFTH_CODE_REVIEW_CHECKLIST.md,
and relevant root adjudications in review_artifacts/a5_full_review.json. Raw evidence
is /tmp/advar-a5-review/reports and /tmp/advar-a5-review/probes.

Use gpt-5.6-luna xhigh. Do not spawn agents. Shared tree: edit only assigned functions
and own NEW test file(s), no whole-file formatting. Other agents edit different
functions in the same large modules; preserve their edits. No git branch/commit/push,
dependency or environment changes. Never uv run/pip install/recreate .venv.
Use /Users/yhlee/ADVAR/.venv/bin/python explicitly, OMP_NUM_THREADS=1 MKL_NUM_THREADS=1.
Scratch only /tmp/advar-a5-fix/probes/YOUR_TASK and own report.

Theory first: map mathematical function, missingness, numerical limit, AD and
constraints before patching. Preserve frozen GN/true PCG residual and unknown P0
branch restrictions. No new registries/architecture/speculative redesign. Small
direct tests must distinguish former vs fixed behavior, assert numerical value or
semantic relation, not only finite output. Test meaningful AD where changed.

Current scientific workflow is research/offline; operational inference intentionally
unsupported. Historical scaffold or malformed artifact findings are scoped; no
revival of deployment. Close a nonfinding with evidence instead of adding guards
for imaginary promises. For actionable bounded integrity flaws use a small direct
check and appropriate public-boundary test. Do not expand numerical scope via casts
that hide unsupported parameters. Keep legacy migrations compatible where intended.

No broad/full baseline runs. Run own focused tests once stable and necessary related
selectors, record commands/outputs. If tests require a shared helper edit, notify root.
Root performs combined integration checks and PR/docs/KG updates.

Output /tmp/advar-a5-fix/reports/YOUR_TASK.json: changed_files, resolved_items,
theory_and_choice, tests (commands/pass counts), regressions_distinguish_old,
remaining_or_closed_without_code (reason), risks. Send impactful decisions early.
