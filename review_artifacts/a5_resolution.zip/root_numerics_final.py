import math
import torch
from advar.variational import _pseudo_huber_cost
for dtype, delta in [(torch.float32, 2.), (torch.float64, 2.), (torch.float32, 2e19), (torch.float64, 1.5e154)]:
    high = float(torch.nextafter(torch.tensor(delta, dtype=dtype), torch.tensor(torch.inf, dtype=dtype)))
    for value in (0., 1e-4, high, -high):
        residual = torch.tensor([value], dtype=dtype, requires_grad=True)
        cost = _pseudo_huber_cost(residual, delta)
        gradient = torch.autograd.grad(cost, residual, create_graph=True)[0]
        curvature = torch.autograd.grad(gradient, residual)[0]
        radius = math.hypot(value, delta)
        expected_gradient = delta * (value / radius)
        expected_curvature = (delta / radius)**3
        assert torch.isfinite(cost) and torch.isfinite(gradient) and torch.isfinite(curvature)
        torch.testing.assert_close(gradient, residual.new_tensor([expected_gradient]), rtol=3e-6, atol=0.)
        torch.testing.assert_close(curvature, residual.new_tensor([expected_curvature]), rtol=3e-6, atol=0.)
        jvp = torch.func.jvp(lambda r: _pseudo_huber_cost(r, delta), (residual.detach(),), (torch.ones_like(residual),))[1]
        torch.testing.assert_close(jvp, gradient.detach(), rtol=3e-6, atol=0.)
        print(dtype, 'delta', delta, 'residual', value, 'cost/gradient/curvature/JVP', cost.item(), gradient.item(), curvature.item(), jvp.item(), 'PASS')
print('16 value / first derivative / second derivative / JVP cases passed')
