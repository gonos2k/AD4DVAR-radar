from pathlib import Path
import tempfile, sqlite3
from advar.ledger import EpisodeLedger, ModelContract

results=[]
with tempfile.TemporaryDirectory(prefix='a5-ledger-') as td:
    ledger=EpisodeLedger(Path(td))
    rows=[('z','2026-01-01T01:00:00+01:00'),('u','2026-01-01T00:30:00Z'),('a','2025-12-31T23:00:00-01:00')]
    with sqlite3.connect(ledger.index_path) as c:
      for i,(eid,t) in enumerate(rows):
       c.execute('INSERT INTO episodes(episode_id,issue_time,radar_id,contract_hash,model_commit,trust_score,promotion_eligible,impact_available,indirect_observation_sensitivity_available,manifest_sha256,arrays_sha256,path,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',(eid,t,'K','c'*64,'m',1.0,0,0,0,'a'*64,'b'*64,'p','t'))
      c.commit()
    ordered=[x['episode_id'] for x in ledger.list_episodes()]
    results.append({'probe':'utc_offset_order','pass':ordered==['u','z','a'],'value':ordered})
    # strict model field runtime type rejected
    try: ModelContract(model_commit=1,residual_contract_version='x',forecast_metric_version='x',observation_contract_version='x',forecast_integrator_version='x',grid_geometry_version='x',radar_qc_version='x',nowcast_config_digest='a'*64,sensitivity_config_digest='b'*64)
    except ValueError as e: results.append({'probe':'model_contract_typed_fields','pass':True,'error':str(e)})
    else: results.append({'probe':'model_contract_typed_fields','pass':False})
print(results)
assert all(item['pass'] for item in results)
