from pathlib import Path
import sys
sys.path.insert(0, "/Users/yhlee/ADVAR")
import tempfile
from tests.test_acceptance import RealCaseAcceptanceTests
from advar.acceptance import verify_real_case_acceptance
with tempfile.TemporaryDirectory(prefix='a5-root-') as td:
    base=Path(td); root=base/'root'; root.mkdir(); manifest=RealCaseAcceptanceTests().fixture(root)
    bad=base/'bad-root'; bad.write_bytes(b'not a directory'); bad.chmod(0o600)
    try: verify_real_case_acceptance(manifest,artifact_root=bad)
    except Exception as e: print(type(e).__name__,str(e)); assert type(e).__name__=='NotADirectoryError'
    else: raise AssertionError('accepted non-directory')
