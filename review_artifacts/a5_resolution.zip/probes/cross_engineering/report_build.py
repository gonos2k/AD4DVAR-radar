import json
from pathlib import Path
report = {
    "task": "cross_engineering",
    "changed_files": [],
    "reviewed_files": [
        "src/advar/acceptance.py",
        ".github/scripts/run_real_case_acceptance.py",
        "src/advar/runtime_closure.py",
        "src/advar/ledger.py",
        "src/advar/intervention.py (adjacent legacy-context check)",
    ],
    "resolved_items": [
        {
            "finding": "cli_report_collision",
            "status": "green",
            "resolution": "The CLI now checks report identity against the manifest, every declared input, hardlinks/symlinks, and the artifact tree before verification, then publishes complete bytes with a fsynced sibling replacement.",
            "evidence": [
                "tests/test_a5_io_runtime.py: 14 passed, 6 subtests passed",
                "tests/test_acceptance.py + tests/test_runtime_closure.py + tests/test_a5_io_runtime.py: 20 passed, 6 subtests passed",
            ],
        },
        {
            "finding": "acceptance_parent_replacement",
            "status": "green_on_supported_posix",
            "resolution": "The acceptance reader binds root and each parent with directory descriptors, O_NOFOLLOW, type/mode checks, and closes file/parent descriptors on success and failure. The race fixture repaired the replaced path while reading the originally opened inode.",
            "evidence": [
                "A5 I/O race test passed",
                "100 nested reads and 100 symlink-error reads had no /dev/fd delta on Darwin",
            ],
        },
        {
            "finding": "runtime_special_file_blocking",
            "status": "green",
            "resolution": "Runtime snapshots reject a FIFO before open; a replacement race opens nonblocking and fstat rejects the replacement inode.",
            "evidence": [
                "tests/test_a5_io_runtime.py runtime FIFO selectors passed",
                "runtime probe regular snapshot/FIFO replacement behavior passed",
            ],
        },
        {
            "finding": "runtime_unresolved_ldd",
            "status": "green",
            "resolution": "The Linux native closure parser now scans stdout and stderr and fails closed on an unresolved `not found` entry. Normal relocatable native-library identity remains unchanged.",
            "evidence": [
                "tests/test_runtime_closure.py native-library selector passed",
                "runtime probe rejected unresolved stderr and retained site-relative identity",
            ],
        },
        {
            "finding": "ledger_cross_plan_source_coverage",
            "status": "green",
            "resolution": "Operational mosaic source coverage is now checked against the issuance plan, input plan, grid/source/policy digests, time lineage, registry/count, ingestor identity/key, nominal mask digest, and optional run/site digests.",
            "evidence": [
                "tests/test_promotion.py selected source-coverage/mosaic/catalog selectors: 8 passed, 219 deselected",
            ],
        },
        {
            "finding": "ledger_scoring_replay_orphan_retry",
            "status": "green",
            "resolution": "The scoring replay retry takes the SQLite writer lock, removes only an unindexed target digest, republishes deterministic bytes, and exception cleanup rechecks the row under the same lock before deleting. Indexed bytes are preserved.",
            "evidence": [
                "tests/test_a5_ledger_storage.py: 9 passed, 18 warnings",
                "test_scoring_replay_crash_durability: 1 passed",
                "public orphan/retry regression is included in the A5 ledger storage suite",
            ],
        },
        {
            "finding": "ledger_legacy_typed_loads",
            "status": "green",
            "resolution": "Strict ModelContract field typing and UTC-aware list ordering did not break the exercised historical schemas or signed prospective receipt loader.",
            "evidence": [
                "tests/test_ledger.py legacy/schema selectors: 12 passed, 38 deselected, 8 subtests passed",
                "tests/test_ledger.py prospective/legacy receipt selectors: 2 passed",
                "direct UTC-offset ordering and wrong ModelContract field type probes passed",
            ],
        },
        {
            "finding": "ledger_operational_duplicate_retry",
            "status": "code_review_green_bounded_tests_incomplete",
            "resolution": "The retained commit check and idempotent latest-history entry check are ordered under BEGIN IMMEDIATE, so an identical retry either reuses the committed row or rebuilds after a rolled-back orphan. A full operational issuance selector was intentionally bounded and was not used as a pass claim.",
            "evidence": [
                "Current control flow inspected at ledger.py:10946-11059 and 11584-11826",
                "No source edit made during this cross-review",
            ],
        },
    ],
    "findings": [
        {
            "id": "cross_engineering_acceptance_root_error_type",
            "severity": "P3",
            "status": "needs_patch",
            "location": "src/advar/acceptance.py:_read_artifact_snapshot",
            "title": "Non-directory artifact root leaks OSError instead of the public ValueError contract",
            "evidence": "Public verify_real_case_acceptance with an absolute regular file as artifact_root raises NotADirectoryError from root os.open(O_DIRECTORY|O_NOFOLLOW); base implementation lstat-checked the root and raised ValueError('acceptance artifact root must be non-writable'). The root os.open is outside the OSError-wrapping try.",
            "impact": "The input is still rejected fail-closed, but callers that handle invalid acceptance inputs through ValueError now see an unanticipated platform OSError.",
            "recommended_action": "Move root os.open into the OSError-wrapping scope or normalize its OSError to ValueError while preserving descriptor cleanup.",
        },
        {
            "id": "cross_engineering_intervention_source_mask_not_retained",
            "severity": "P2",
            "status": "needs_patch",
            "location": "src/advar/ledger.py:_artifact_intervention_context; src/advar/intervention.py:_canonical_action_input_state",
            "title": "Durable intervention replay cannot validate a nontrivial source mask",
            "evidence": "transition.npz stores before/after observation masks and quality/std but no source mask; the manifest stores only source_available_mask_digest. _artifact_intervention_context does not set _source_available_mask, and _source_mask fallback treats the missing field as all ones. A bounded synthetic context with observation mask true, quality zero at a source-unavailable cell, and a dBZ delta there produced changed_invalid_pixel_count=0 and passed _compute_action_safety; the source-aware context rejects the same action. Direct _canonical_action_input_state on the rebuilt context raises AttributeError because it dereferences _source_available_mask directly.",
            "impact": "Legacy all-source contexts remain compatible, but a current durable artifact with a non-all-ones source digest has ambiguous physical support and can accept a source-unavailable correction during replay.",
            "recommended_action": "Within the existing artifact contract, retain and validate the source mask where current source digest is nontrivial, or reject replay as ambiguous; use _source_mask(context) in _canonical_action_input_state. Do not add a registry.",
        },
    ],
    "theory_and_choice": {
        "acceptance": "A directory-fd walk is the binding primitive for path components; O_NOFOLLOW and descriptor type checks prevent symlink/special-file substitutions, while fstat before/after ties bytes to one immutable inode. The output path is checked before and after manifest expansion and atomically replaced.",
        "runtime": "A regular-file snapshot must remain one inode with unchanged size, mtime, mode, and owner. O_NONBLOCK bounds a race that replaces a checked path with a FIFO. Linux ldd failures and explicit unresolved entries are fatal; non-Linux native closure remains empty under the existing Linux deployment-only contract.",
        "ledger": "Rows and content-addressed directories are linearized with the SQLite writer lock. A published unindexed directory is disposable on retry; an indexed row is authoritative. New source coverage checks bind signed bytes to the exact operational plan without changing legacy typed schema readers.",
    },
    "tests": [
        {
            "command": "OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -m pytest -q tests/test_acceptance.py tests/test_runtime_closure.py tests/test_a5_io_runtime.py --disable-warnings --maxfail=1",
            "result": "20 passed, 6 subtests passed",
        },
        {
            "command": "OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -m pytest -q tests/test_a5_ledger_storage.py --disable-warnings --maxfail=1",
            "result": "9 passed, 18 warnings",
        },
        {
            "command": "OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -m pytest -q tests/test_ledger.py -k 'legacy or schema_one or schema_three or schema_four or schema_five or schema_fifteen or v29_holdout or v30_holdout or replay_v19' --disable-warnings --maxfail=1",
            "result": "12 passed, 38 deselected, 8 subtests passed",
        },
        {
            "command": "OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -m pytest -q tests/test_promotion.py -k 'dynamic_source_coverage or complete_mosaic_outage_uses_signed_missing_receipts or mosaic_issuance_domain_requires_dynamic_resolution or physical_event_catalog_result_is_fixed_before_candidate_scoring or physical_event_catalog_signature_binds_case_membership' --disable-warnings --maxfail=1",
            "result": "8 passed, 219 deselected",
        },
        {
            "command": "OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -m pytest -q tests/test_promotion.py::NeuralPriorPromotionTests::test_scoring_replay_crash_durability --disable-warnings --maxfail=1",
            "result": "1 passed",
        },
        {
            "command": "bounded probes under /tmp/advar-a5-fix/probes/cross_engineering",
            "result": "acceptance/runtime/ledger probes passed; root-file probe reproduced NotADirectoryError; intervention probe reproduced missing-source safety acceptance and direct canonicalization AttributeError",
        },
    ],
    "regressions_distinguish_old": [
        "The root-file error-type regression is distinct from the original symlink/output collision cases: public root symlinks are rejected by verify_real_case_acceptance before the descriptor walk, while a regular-file root reaches root os.open and leaks NotADirectoryError.",
        "The source-mask finding is distinct from the exercised legacy path: fixtures with no retained/nontrivial source digest use the historical all-ones interpretation and their action/receipt round trips pass; a synthetic nontrivial source-unavailable cell is the counterexample.",
        "No normal acceptance producer, runtime regular-file snapshot, source-coverage/mosaic producer, scoring orphan retry, or exercised legacy typed loader failed in the bounded test set.",
    ],
    "remaining_or_closed_without_code": [
        {
            "finding": "acceptance cross-case shared artifact path",
            "status": "closed_without_code",
            "reason": "Root adjudication marked this unproven because shared files can be intentional and no independent-case uniqueness promise was established.",
        },
        {
            "finding": "Windows acceptance dir_fd behavior",
            "status": "boundary",
            "reason": "Current deployment bundle and locked runtime are explicitly Linux-only; bounded supported-platform evidence covers Darwin and the Linux-specific branch is unit-mocked. Windows dir_fd/O_DIRECTORY behavior was not treated as a supported producer contract.",
        },
        {
            "finding": "Darwin native-library closure",
            "status": "closed_without_code",
            "reason": "runtime_closure.py intentionally returns no ldd closure off Linux; the deployment bundle contract is Linux-only and the existing Darwin shared-cache limitation is documented outside this diff.",
        },
    ],
    "risks": [
        "The two needs_patch findings were reported without modifying source, per the independent cross-review instruction.",
        "The operational issuance selector was bounded by wall time and is not represented as a pass; code-level BEGIN IMMEDIATE ordering and the public scoring orphan regression provide the retry evidence available here.",
        "The shared tree contains unrelated edits from other agents; no reset, dependency, environment, or source changes were made during this review.",
    ],
}
out = Path('/tmp/advar-a5-fix/reports/cross_engineering.json')
out.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(out)
