from pathlib import Path
import tempfile, os
from unittest.mock import patch
import subprocess
import advar.runtime_closure as r

results=[]
with tempfile.TemporaryDirectory(prefix='a5-runtime-') as td:
    p=Path(td)/'x.py'; p.write_bytes(b'abc'); p.chmod(0o600)
    results.append({'probe':'regular_snapshot','value':r._runtime_file_snapshot(p,deployable=False)})
    fifo=Path(td)/'x.fifo'; os.mkfifo(fifo)
    try: r._runtime_file_snapshot(fifo,deployable=False)
    except ValueError as e: results.append({'probe':'fifo_reject_before_open','pass':True,'error':str(e)})
    else: results.append({'probe':'fifo_reject_before_open','pass':False})
    source=Path(td)/'ext.so'; source.write_bytes(b'x'); lib=Path(td)/'libnative.so'; lib.write_bytes(b'l')
    completed=subprocess.CompletedProcess(('ldd',str(source)),0,'libnative.so => '+str(lib)+' (0x0)\n','libmissing.so => not found\n')
    with patch.object(r.platform,'system',return_value='Linux'),patch.object(r.subprocess,'run',return_value=completed):
      try: r._linked_native_libraries((source,),deployable=False,import_roots=(Path(td),))
      except ValueError as e: results.append({'probe':'stderr_unresolved_rejected','pass':True,'error':str(e)})
      else: results.append({'probe':'stderr_unresolved_rejected','pass':False})
    completed2=subprocess.CompletedProcess(('ldd',str(source)),0,'libnative.so => '+str(lib)+' (0x0)\n','')
    with patch.object(r.platform,'system',return_value='Linux'),patch.object(r.subprocess,'run',return_value=completed2):
      got=r._linked_native_libraries((source,),deployable=False,import_roots=(Path(td),))
      results.append({'probe':'native_path_identity','pass':got[0]['path']=='site-0/libnative.so','value':got})
print({'platform':os.uname().sysname,'results':results})
assert all(x.get('pass',True) for x in results)
