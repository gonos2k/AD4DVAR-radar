from pathlib import Path
import os,tempfile
from advar.acceptance import _read_artifact_snapshot

def fdset():
    try:
        return {int(x) for x in os.listdir('/dev/fd') if x.isdigit()}
    except Exception:
        return set()

results=[]
with tempfile.TemporaryDirectory(prefix='a5-accept-') as td:
    base=Path(td); root=base/'root'; root.mkdir(); (root/'nested').mkdir()
    os.chmod(root,0o700); os.chmod(root/'nested',0o700)
    f=root/'nested'/'x'; f.write_bytes(b'abc'); os.chmod(f,0o600)
    before=fdset();
    for _ in range(100):
        assert _read_artifact_snapshot(root,'nested/x',maximum_bytes=100)==b'abc'
    after=fdset(); results.append({'probe':'nested_regular_success','pass':before==after,'fd_delta':sorted(after-before)})
    link=root/'nested'/'link'; link.symlink_to(f)
    try: _read_artifact_snapshot(root,'nested/link',maximum_bytes=100)
    except ValueError as e: results.append({'probe':'file_symlink_rejected','pass':True,'error':str(e)})
    else: results.append({'probe':'file_symlink_rejected','pass':False})
    # parent symlink path component
    alias=root/'alias'; alias.symlink_to(root/'nested',target_is_directory=True)
    try: _read_artifact_snapshot(root,'alias/x',maximum_bytes=100)
    except ValueError as e: results.append({'probe':'parent_symlink_rejected','pass':True,'error':str(e)})
    else: results.append({'probe':'parent_symlink_rejected','pass':False})
    # root symlink is rejected by O_NOFOLLOW
    rootalias=base/'rootalias'; rootalias.symlink_to(root,target_is_directory=True)
    try: _read_artifact_snapshot(rootalias,'nested/x',maximum_bytes=100)
    except (ValueError, OSError) as e: results.append({'probe':'root_symlink_rejected','pass':True,'error':type(e).__name__+': '+str(e)})
    else: results.append({'probe':'root_symlink_rejected','pass':False})
    before=fdset()
    for _ in range(100):
        try: _read_artifact_snapshot(root,'nested/link',maximum_bytes=100)
        except ValueError: pass
    after=fdset(); results.append({'probe':'error_fd_cleanup','pass':before==after,'fd_delta':sorted(after-before)})
print({'platform':os.uname().sysname,'results':results})
assert all(x['pass'] for x in results)
