import json
from pathlib import Path
p=Path('/tmp/advar-a5-fix/reports/cross_engineering.json')
report=json.loads(p.read_text(encoding='utf-8'))
report['followup'] = {
    'changed_files': [
        'src/advar/acceptance.py',
        'src/advar/intervention.py',
        'src/advar/ledger.py',
        'tests/test_a5_artifacts_intervention.py',
    ],
    'resolution': [
        'Moved acceptance root os.open inside the OSError normalization scope; descriptor cleanup remains in the finally block.',
        'Changed _canonical_action_input_state to use _source_mask(context), whose all-ones fallback now allocates only when the field is absent.',
        'Added a durable source-mask boundary: because transition.npz has no source array, append and replay accept only None or the digest of an all-ones source mask. Rebuilt legacy contexts now explicitly carry that all-ones mask. Nontrivial source availability fails closed without a new archive version or registry.',
        'Added O_NONBLOCK to the final acceptance-file open so a FIFO substitution reaches the regular-file check instead of blocking.',
    ],
    'tests': [
        {
            'command': 'OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -m pytest -q tests/test_a5_artifacts_intervention.py --disable-warnings --maxfail=1',
            'result': '14 passed, 18 warnings',
        },
        {
            'command': 'OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -m pytest -q tests/test_ledger.py -k \'test_prospective_decision_and_executor_receipt_round_trip or test_legacy_v2_prospective_receipt_loads_as_signed_audit or test_typed_actions_plan_times_and_global_radius_fail_closed\' --disable-warnings --maxfail=1',
            'result': '3 passed, 47 deselected',
        },
        {
            'command': 'OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -m pytest -q tests/test_a2_ledger_io.py -k \'artifact or intervention or receipt\' --disable-warnings --maxfail=1',
            'result': '1 passed, 3 deselected',
        },
        {
            'command': 'OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -m pytest -q tests/test_acceptance.py tests/test_runtime_closure.py tests/test_a5_io_runtime.py --disable-warnings --maxfail=1',
            'result': '20 passed, 6 subtests passed',
        },
        {
            'command': 'OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -m pytest -q tests/test_a5_ledger_storage.py --disable-warnings --maxfail=1',
            'result': '9 passed, 18 warnings',
        },
    ],
    'boundary_test_cases': [
        'Nontrivial source digest: durable append rejects before creating a target directory.',
        'Nontrivial manifest source digest: reconstruction helper rejects because the archive cannot prove the mask.',
        'Legacy None digest: rebuilt context receives explicit all-ones source mask and canonical action state validates.',
        'All-ones source digest: rebuilt context remains accepted under the durable digest check.',
        'Nontrivial manifest source digest: artifact-context loader rejects before replay can use an ambiguous mask.',
        'Non-directory acceptance root: public helper now raises ValueError (normalized) rather than leaking NotADirectoryError.',
        'FIFO final component: O_NONBLOCK lets the acceptance helper reject it without blocking.',
    ],
    'remaining_risk': 'Partial source availability is intentionally nondurable under the unchanged transition archive contract; the boundary rejects it rather than claiming it can be replayed.',
}
# Preserve the original cross-review findings/tests verbatim and add this follow-up.
p.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
q=p.with_name('cross_engineering_followup.json')
q.write_text(json.dumps({'task': report['task'], 'followup': report['followup']}, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(p)
print(q)
