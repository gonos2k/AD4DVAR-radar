import torch
from advar.intervention import DbzCorrectionAction, ReusableInterventionPolicyEvidence, _compute_action_safety, _canonical_action_input_state
from advar.intervention import _INTERVENTION_CONTEXT_SCHEMA_DIGEST
from advar._digest import json_digest

ctx=object.__new__(__import__('advar.intervention',fromlist=['InterventionInputContext']).InterventionInputContext)
shape=(1,1,3)
for k,v in {
 '_frames_dbz':torch.full(shape,20.,dtype=torch.float32),
 '_observation_masks':torch.ones(shape,dtype=torch.bool),
 '_source_available_mask':torch.tensor([[[1,0,1]]],dtype=torch.bool),
 '_quality_weight':torch.tensor([[[1.,0.,1.]]]),
 '_observation_std_dbz':torch.ones(shape),
 '_background_frames_dbz':None,
 '_applicability_mask':torch.ones(shape,dtype=torch.bool),
 'min_dbz':0.,'max_dbz':80.,'missing_fill_dbz':0,
}.items(): object.__setattr__(ctx,k,v)
policy=ReusableInterventionPolicyEvidence(
 policy_id='p', action_generator_digest='a'*64, context_schema_digest='b'*64,
 applicability_region_digest='c'*64, execution_policy_digest='d'*64,
 allowed_intervention_types=('realized_sensor_correction',), maximum_absolute_delta_dbz=5.,
 validation_evidence_digests=('e'*64,), maximum_changed_pixel_count=3,
 maximum_changed_fraction=1., maximum_changed_area_km2=100.,
 maximum_global_diagonal_standardized_l2=10., maximum_tile_diagonal_standardized_l2=10.,
)
a=DbzCorrectionAction(torch.tensor([[[0.,1.,0.]]]))
results=[]
try:
  diag=_compute_action_safety(a,ctx,policy,minimum_dbz=0.,maximum_dbz=80.,cell_area_m2=1.)
  results.append({'probe':'source_aware_direct_safety','pass':False,'changed_invalid':diag.changed_invalid_pixel_count})
except ValueError as e:
  results.append({'probe':'source_aware_direct_safety','pass':True,'error':str(e)})
try:
  _canonical_action_input_state(a,ctx)
except AttributeError as e:
  results.append({'probe':'rebuilt_context_direct_canonicalization','pass':True,'error':str(e)})
else: results.append({'probe':'rebuilt_context_direct_canonicalization','pass':False})
print(results)
