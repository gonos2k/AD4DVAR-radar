from pathlib import Path
import hashlib,json,subprocess,zipfile
root=Path('/Users/yhlee/ADVAR'); work=Path('/tmp/advar-a5-fix')
subprocess.run(['python3',str(work/'build_resolution.py')],check=True)
j=json.loads((root/'review_artifacts/a5_resolution.json').read_text())
log=(work/'integration-final.txt').read_text()
assert '203 passed, 18 warnings, 83 subtests passed' in log
assert (work/'typecheck.txt').read_text().strip()=='0 errors, 0 warnings, 0 notes'
assert (work/'environment-before.txt').read_bytes()==(work/'environment-after.txt').read_bytes()
assert '16 value / first derivative / second derivative / JVP cases passed' in (work/'root-numerics-final.txt').read_text()
for e in j['entries']:
    if e['finding_id'] in ('promotion_3.1','promotion_3.2'):
        e['reason_or_limit']=e['reason_or_limit'].split(' Full signed public promotion')[0]+' Focused public-target/helper regressions and related integration passed. These do not constitute a complete signed operational promotion execution.'
j['validation']['local_integration']='203 passed, 18 TorchScript deprecation warnings, 83 subtests passed in 177.92s; changed and related suites, not full baseline.'
j['validation']['extreme_huber']='16 independent FP32/FP64 cost, first derivative, second derivative and JVP cases passed, including near finite-cost overflow.'
j['validation']['dependency_locks']='Four hashed Linux closures synchronized; checker passed.'
j['validation']['final_source_sha256']=json.loads((work/'final-source-hashes.json').read_text())
j['validation']['remote_ci']='Earlier 286c0c9 run 33996929420 passed all four jobs. Latest A5 commit CI is pending push; inspect PR158 for current status.'
(root/'review_artifacts/a5_resolution.json').write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
p=root/'FIFTH_CODE_REVIEW_RESOLUTION.md';s=p.read_text().replace('<!-- FINAL_VALIDATION -->','- Python 3.12.13 / Torch 2.13.0 CPU: 변경·관련 통합 시험 **203 passed, 83 subtests passed** (177.92초). TorchScript deprecation 경고 18개.\n- basedpyright: **0 errors, 0 warnings**. 의존성 lock 정합성 검사 통과. 환경 package 목록 전후 동일.\n- FP32·FP64 Huber 16개 독립 사례에서 비용·1차/2차 미분·JVP가 해석값과 일치한다.\n- 새 회귀시험 일부를 수정 전 `286c0c9` 소스에 적용하면 27개 실패(하위 시험 포함), 9개 통과. 기존 오류를 검출하는 증거이며 현재 코드의 실패가 아니다.\n- 전체 CPU baseline은 [PR #158 CI](https://github.com/gonos2k/AD4DVAR-radar/pull/158/checks)에서 실행한다. 이 기록을 커밋할 때 최신 A5 CI는 아직 시작 전이다.\n  이전 `286c0c9` CI `33996929420`의 네 작업 성공을 A5 변경의 검증으로 사용하지 않는다.\n')
p.write_text(s)
# Include owned source diff and exact new tests; retain earlier failed logs as historical evidence.
(work/'final.patch').write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=root))
files={}
for name in ('build_resolution.py','package_resolution.py','root_numerics_final.py','root-numerics-final.txt','final.patch','final-source-hashes.json','integration-final.txt','integration.txt','former-regressions.txt','promotion-integration.txt','resources.txt','typecheck.txt','environment-before.txt','environment-after.txt','kg-update.txt','pr-before-push.json','INSTRUCTIONS.md'):
    files[name]=work/name
for folder in ('reports','probes'):
    for p in (work/folder).rglob('*'):
        if p.is_file() and '__pycache__' not in p.parts and p.suffix in ('.json','.py','.txt','.md','.log'):
            files[str(p.relative_to(work))]=p
for p in root.glob('tests/test_a5_*.py'):
    files[str(p.relative_to(root))]=p
for p in (root/'FIFTH_CODE_REVIEW_RESOLUTION.md',root/'FIFTH_CODE_REVIEW_CHECKLIST.md',root/'review_artifacts/a5_resolution.json'):
    files[str(p.relative_to(root))]=p
for name,p in files.items():
    if p.suffix=='.json': json.loads(p.read_text())
readme='''A5 resolution evidence\n\nBase source: 286c0c9416a645ec4350b24ab9e9faca6584bb56.\nThe resolution JSON is the final root adjudication; individual reports and integration.txt retain their historical pre-follow-up states. integration-final.txt is the final current-source integration result. former-regressions.txt is intentionally failing original-source counterfactual evidence.\n\nApply final.patch to the base source and copy tests/test_a5_*.py, or use PR158 final files; compare final-source-hashes.json. Use the existing pinned Python/Torch environment. Do not recreate a shared venv.\n\nRun: OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 .venv/bin/python -m pytest -q tests/test_a5_*.py tests/test_a2_*.py tests/test_m0_linearity_weights.py tests/test_numerical_review.py tests/test_review_numerics.py tests/test_review_ledger.py tests/test_review_promotion_contracts.py tests/test_review_promotion_statistics.py --tb=short\nRun: OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 .venv/bin/python root_numerics_final.py\n\nReports may contain original absolute scratch paths; corresponding reports/probes are preserved here. No full local baseline or new real-radar/CUDA end-to-end execution is claimed. Latest remote CI is on PR158 and may postdate this archive.\n'''
archive=root/'review_artifacts/a5_resolution.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    z.writestr('README.txt',readme)
    for name,p in sorted(files.items()): z.write(p,name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    print('archive members',len(z.namelist()))
print('sha256',hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes',archive.stat().st_size)
