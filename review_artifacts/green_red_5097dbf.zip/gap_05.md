# GREEN bounded review — `src/advar/ledger.py` lines 20001–22296

Baseline: `5097dbfd1ddf51483578bef5889ebc809ff024f`. The assigned range was read in contiguous bounded chunks, with caller context for `EpisodeLedger.append`, `verify`, the promotion decoders, and schema initialization. No repository files were changed.

## Findings

### P2 — persisted whitened tile sensitivity is accepted without checking its defining relation

- Reachable path: `EpisodeLedger.append` calls `_validate_m0_snapshot` at [ledger.py:4966](/Users/yhlee/ADVAR/src/advar/ledger.py:4966), which reaches [ledger.py:22050](/Users/yhlee/ADVAR/src/advar/ledger.py:22050). A current producer creates `whitened_tile_norm` as the tile L2 norm of `direct_gradient * observation_std_dbz` (the producer path is in `sensitivity.py`), and `_snapshot_arrays` persists it at [ledger.py:21246](/Users/yhlee/ADVAR/src/advar/ledger.py:21246).
- The validator checks only shape, floating dtype, finiteness for available entries, and NaN for unavailable entries. It never compares the selected full-map rows with `direct.maps * observation_std_dbz` and never checks any defining relation for the remaining lead rows. Therefore a finite, arbitrary whitened summary can be committed and returned by `load` while its declared sensitivity units are false.
- Minimal CPU probe (Torch 2.13, Python 3.12.13) built a one-lead, one-metric snapshot with `direct.maps = ones`, `observation_std_dbz = ones`, and `whitened_tile_norm = zeros`; `_validate_m0_snapshot` returned successfully (`accepted inconsistent whitened tile norm`). The mathematically expected tile norm is 2, not 0.
- Smallest sound direction: for every selected lead, recompute tile L2 norms from the stored direct map and positive observation standard deviation and compare with scale-aware tolerances; for unselected leads either persist enough direct maps to check the relation or define the summary as unavailable. Keep NaN masking aligned with metric availability.

### P2 — non-finite metric evidence values bypass the range and masking contract

- Reachable path: the evidence loop at [ledger.py:22004](/Users/yhlee/ADVAR/src/advar/ledger.py:22004) computes `finite = torch.isfinite(value)` and validates only `value[finite]`. `+inf` and `-inf` are therefore skipped. The later source-evidence closure also masks on `torch.isfinite`, so the same entries evade closure validation. `_snapshot_arrays` then persists them.
- The producer's evidence channels are dimensionless fractions/scores and are constrained to `[0, 1]` in the snapshot contract. Missing evidence is represented by NaN. Allowing infinity for either an available or unavailable metric makes an invalid value durable and causes downstream quality/closure logic to silently treat it as missing.
- Minimal CPU probe with an unavailable metric and `path_evidence_by_metric = +inf`, `observation_source_fraction_by_metric = -inf` returned successfully (`accepted inf evidence on unavailable metric`). The same validator accepts infinity for available entries as well.
- Smallest sound direction: require each evidence element to be either finite in `[0, 1]` or NaN; require unavailable metric entries to be NaN, and reject infinities before any masked closure calculation.

### P2 — trust components and trust score are not bounded as quality quantities

- Reachable path: `_validate_m0_snapshot` only checks finiteness and exact key set at [ledger.py:22160](/Users/yhlee/ADVAR/src/advar/ledger.py:22160), then checks that `trust_score` equals their product at [ledger.py:22167](/Users/yhlee/ADVAR/src/advar/ledger.py:22167). It never enforces the `[0, 1]` codomain used by the producer's quality calculations.
- The producer path in `sensitivity.py` returns `verification_quality` and `metric_support` as means of Boolean masks, clamps linearity/evidence quality to `[0, 1]`, and validates `pair_conflict_trust_penalty` in `(0, 1]`; its product is therefore in `[0, 1]`. `SensitivitySnapshot` has no currentness marker and the ledger does not rederive these components from a source forecast before append. A caller can append a snapshot with `linearity = 2.0` and `trust_score = 2.0`; the actual append/verify/load CPU probe persisted `manifest_trust_score: 2.0`. `list_episodes(minimum_trust=...)` then treats this malformed episode as higher trust than the scale permits.
- Smallest sound direction: validate every trust component and the product in `[0, 1]` (with the existing finite and product checks), preserving the producer's clamped quality semantics. If a wider trust scale is intentional, that scale needs to be made explicit in the manifest contract and threshold API.

## Verification and limits

Commands run with `PYTHONPATH=src:tests OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python /tmp/advar-green-red-5097dbf/gap_05_probes.py` (Python 3.12.13, Torch 2.13, CPU). The runnable probe uses the current computed snapshot, mutates only the contract-gap field, then performs actual `EpisodeLedger.append`, `verify`, and `load` round trips. It reproduced durable `inf` evidence and durable `trust_score: 2.0`; the earlier validator-only probe also reproduced the inconsistent whitened norm. JSON output is in [`gap_05_probes.stdout.json`](/tmp/advar-green-red-5097dbf/gap_05_probes.stdout.json). No MPS/CUDA, full baseline tests, source edits, or commits were performed. The report is bounded to the assigned ledger range; promotion/sensitivity producer implementations were read only for caller and defining-contract context.
