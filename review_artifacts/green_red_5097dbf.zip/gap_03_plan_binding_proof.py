"""Static proof of the replay-input/plan binding gap (repository read-only)."""
from pathlib import Path

text = Path("/Users/yhlee/ADVAR/src/advar/ledger.py").read_text(encoding="utf-8")
start = text.index("    def append_neural_prior_scoring_replay_bundle(")
end = text.index("    def load_neural_prior_scoring_replay_bundle(", start)
method = text[start:end]

assert "plan = ordered_cases[0].plan" in method
assert "scoring_input_artifact.holdout_plan_digest" not in method
assert 'WHERE artifact_digest = ?' in method
assert 'WHERE process_kind = \'candidate_scoring\'' in method
print("plan source: ordered_cases[0].plan")
print("artifact plan equality in append method: absent")
print("registered input SQL predicate: artifact_digest only")
print("start SQL predicate: process_kind only; subject digest checked, plan/catalog omitted")
print("constructive valid-pair condition: artifact A and replay cases B may share ordered_case_ids;\n"
      "their product factories are independent, and no append check compares A.plan_digest to B.plan_digest")
