# GREEN / RED bounded review — unit 20

## Scope and method

Reviewed every assigned line of `src/advar/intervention.py:1-2754` in eight
bounded, untruncated reads (`1-350`, `351-700`, `701-1050`, `1051-1400`,
`1401-1750`, `1751-2100`, `2101-2450`, and `2451-2754`). Additional caller
and contract context was read in `ledger.py:5220-5445,5560-6165,6110-6425`,
`nowcast.py:4700-5405,3300-3450`, `variational.py:3040-3135,4210-4300`,
`sensitivity.py:10260-10510,14320-14485`, and the relevant intervention tests
(`tests/test_ledger.py:2240-3310`). No source files, tests, or repository
state were changed. No MPS/CUDA or full baseline suite was used.

## GREEN findings

The action context binds tensor digests, the resolved input-plan identity,
canonicalization bounds, radar applicability region, and the complete current
run. Exported action generators are reloaded and run twice, so their output
shape, dtype, finiteness, applicability, and determinism are checked before
an action is committed. Safety limits cover per-pixel dBZ, changed count and
fraction, physical changed area, diagonal-standardized perturbation, and QC
precision-scale perturbation. The v6 grid path checks current metric-domain
evidence and fails closed for uncertain area bounds.

The prospective/receipt path binds decision, generator, policy, action payload,
before context, input-plan lineage, operator/executor signatures, trusted
clock ordering, and a durable before/action/after artifact. Exact action replay
checks dBZ/mask/quality tensor results, including equal-NaN-location semantics.
The learning-based realized intervention path separately verifies the approved
physical perturbation, resolved-issuance validation lineage, physical input
bundle, metric guardrails, and automation-only coverage/fallback constraints.

## RED findings

1. **Medium severity — a QC receipt can change observation error standard
   deviations without being bound to the approved action.**

   Reachable path: `RealizedInterventionReceipt.from_decision()` calls
   `validate_intervention_action_transition()` (`intervention.py:2240-2266`),
   and the live ledger caller invokes the same validator before recording
   (`ledger.py:6268-6288`). The validator's generic unchanged-run list at
   `intervention.py:2535-2553` omits `observation_std_dbz_digest`. The QC
   branch at `2579-2588` checks only that mask or quality changed and that the
   fixed context digest changed; the standard-deviation equality check exists
   only in the non-QC branch at `2589-2602`. `InterventionInputContext` binds
   the after context to its run's standard-deviation digest, so an executor
   can provide a valid QC mask/quality transition plus a different error
   field, and the fixed/full input digests naturally change. The action payload
   has no standard-deviation field, and action safety was computed using only
   the before standard deviations (`1327-1381`), so the unapproved error model
   is accepted into the receipt and durable artifact.

   A CPU probe built a normal prospective run/context and a deweight QC
   generator. The after run/context used the exact generated quality transition
   but `observation_std_dbz = 9.0` everywhere instead of `2.0`. Both
   `validate_intervention_action_transition()` and
   `RealizedInterventionReceipt.from_decision()` accepted it, printing:
   `receipt accepted True std changed True`.

   Expected contract: a typed QC action may change only its declared valid mask
   and quality weights; the observation-error model on cells still active after
   QC is fixed run context. A whole-tensor digest equality would be too strict:
   `InterventionInputContext.from_inputs()` canonicalizes newly masked cells'
   standard deviation to `1.0`, so a legitimate mask transition can change the
   normalized digest even when the active cells remain exactly unchanged. The
   smallest sound direction is to compare before/after normalized standard
   deviations on the after-active mask (QC cannot create observations), or to
   compare an explicitly normalized active-cell digest, and reject any active
   cell change. If changing active-cell error is intended, it needs an explicit
   action field and safety contract. Durable replay must enforce the same
   active-cell invariant.

2. **Low severity — a zero-effect generator can be committed as a prospective
   decision that no executor receipt can realize.**

   Reachable path: `_compute_action_safety()` (`intervention.py:1354-1447`)
   allows `changed_pixel_count == 0`; neither
   `ProspectiveInterventionDecision.from_policy()` nor its post-init contract
   rejects that action. A CPU probe with a dBZ generator returning an all-zero
   delta produced a valid decision with
   `changed_pixel_count 0`. When an executor supplies the unchanged after
   input, `validate_action_tensor_replay()` succeeds, but receipt construction
   then rejects the same action because `RealizedInterventionReceipt` requires
   a changed input (`2200-2205`, with the transition's dBZ branch also
   rejecting equal frame/bundle digests at `2594-2598`). Thus the ledger can
   record an approved prospective action which is structurally impossible to
   realize, wasting the decision window and requiring manual cleanup.

   The smallest sound direction is to reject a zero-effect action when the
   prospective decision is generated (or define and persist an explicit
   no-op outcome instead of treating it as a realized intervention). A simple
   `count > 0` precondition should be applied consistently to dBZ, QC, and
   override actions if no-op actions are not a supported operation.

## Hypotheses checked but not promoted

`source_available_mask_digest` is included in the generic unchanged-run tuple,
so the QC branch does not have the analogous source-availability loophole.
The omission of learned-feature digest is intentional for QC because those
features are expected to change as quality weights/masks change; the typed
action still does not expose an independent learned-feature input.

`_run_uses_correlated_observation_error()` treats malformed nonnumeric config
values as zero, but ordinary `AnalysisConfig` construction rejects those
values and current production runs carry its canonical JSON. I did not count
this constructor-bypass behavior as a live defect in the bounded review.

NaN payloads are deliberately treated as equivalent by
`_same_tensor_with_nan()` and action canonicalization; I did not classify that
semantic choice as a defect.

## Validation

Environment: `/Users/yhlee/ADVAR/.venv/bin/python` (Python 3.12.13, Torch 2.13,
CPU-only), `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1`. Targeted inline CPU probes:

```text
OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python /tmp/advar-green-red-5097dbf/gap_20_probes.py
# Result is saved verbatim in /tmp/advar-green-red-5097dbf/gap_20_probes.stdout.

OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python - <<'PY'
# Construct _prospective_run_and_context() and a zero-dBZ generator; call
# ProspectiveInterventionDecision.from_policy().
# Result: decision accepted changed pixels 0
PY
```

No formal test suite, source fix, commit, MPS, or CUDA was used.
