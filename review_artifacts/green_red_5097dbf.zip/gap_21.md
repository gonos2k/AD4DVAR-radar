# GREEN / RED bounded review — unit 21

## Scope and method

Reviewed every assigned line of `src/advar/nowcast.py:1-6442` in bounded,
untruncated 250-line reads. The final assigned portion was read with
`sed -n '6251,6500p'`; lines 6251–6442 are the assigned coverage and
6443–6500 was incidental context. Additional caller context was read only for
the two findings: `nowcast.py:6443-6660,10180-10225`,
`ledger.py:8050-8120,10970-11035`, and `intervention.py:740-800`. No source
files, tests, or repository state were changed. No MPS/CUDA or full baseline
suite was used.

Targeted CPU probe:

```text
OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python - <<'PY'
from dataclasses import replace
import torch
from advar.nowcast import ForecastRunContract, NowcastConfig, RadarGridTimeContract
frames = torch.ones((3, 2, 2), dtype=torch.float64)
masks = torch.ones_like(frames, dtype=torch.bool)
run = ForecastRunContract.from_inputs(NowcastConfig(), frames, masks, None)
tampered = replace(run, input_bundle_digest='0' * 64)
try:
    tampered.validate_integrity()
    print('TAMPER_PROBE accepted_input_bundle_digest=True')
except Exception as error:
    print('TAMPER_PROBE rejected', type(error).__name__, error)
grid = RadarGridTimeContract(
    valid_times=('2026-01-01T00:00:00Z', '2026-01-01T00:10:00Z',
                 '2026-01-01T00:20:00Z'),
    dx_m=1000.5, dy_m=2000.5, projection='EPSG:5179', grid_hash='a' * 64)
integer = torch.tensor((1, 1), dtype=torch.int64)
print('INTEGER_PROBE dtype=', integer.dtype, 'matrix=',
      grid.pixel_to_projected_matrix_m, 'output=',
      grid.projected_displacement_xy(integer).tolist())
PY
```

Result on Python 3.12.13 / Torch 2.13 CPU:

```text
TAMPER_PROBE accepted_input_bundle_digest=True
INTEGER_PROBE dtype= torch.int64 matrix= ((1000.5, 0.0), (0.0, -2000.5)) output= [1000, -2000]
```

## GREEN findings

The affine grid validator derives determinant, axis lengths, singular values,
conditioning, and representable spacing from one canonical binary64 matrix,
and rejects non-finite, singular, badly conditioned, or axis-inconsistent
matrices. Scientific v5/v6 grids additionally bind cell centers to the
registered EPSG:5179 metric envelope. The four-corner domain check is
sufficient for this affine image because the accepted projected rectangle is
convex.

The directed physical metric helpers preserve nominal values separately from
outward binary64 enclosures. Products, sums, differences, square roots, the
affine norm, determinant, and the projection scale budget all widen by
`nextafter` in the appropriate direction. Ground-radius footprints partition
offsets into certainly-inside, uncertain, and possibly-inside sets and fail
closed for nonmonotone consumers when the annulus is uncertain. The metric
evidence report independently recomputes its sample and scale reductions.

Temporal/grid contracts enforce timezone-aware canonical timestamps, interval
spacing, background age, physical-motion requirements, shape binding, and the
current metric evidence digest for v6. Forecast input construction binds all
input tensors and operational lineage into digests; forecast result issuance
also includes the input bundle in the run identity. These are coherent when
the complete `ForecastResult` validation path is used.

## RED / falsifiable findings

1. **Medium severity — `ForecastRunContract.validate_integrity()` does not
   recompute `input_bundle_digest`.** At `src/advar/nowcast.py:5154-5161` it
   only checks that `input_bundle_digest` is a SHA-256-shaped string. The
   bundle formula at `5508-5530` is fully determined by stored fields
   (`input_frames_digest`, observation/background digests and age, grid
   digest, and operational digests), so it can be recomputed without the
   original tensors. A `dataclasses.replace` tampering probe changed the
   digest to 64 zeroes and `run.validate_integrity()` accepted it. This is a
   reachable trust boundary: current ledger and intervention callers invoke
   `run.validate_integrity()` directly (`ledger.py:8092,11010`,
   `intervention.py:777`). The complete forecast result identity may catch
   this later, but callers that validate a run directly can accept a false
   input identity. The smallest theoretically sound direction is to rebuild
   the canonical bundle payload from the stored digest fields (or factor a
   digest helper accepting digests) and compare it during `validate_integrity`.

2. **Low severity — legacy affine conversion silently truncates non-floating
   inputs.** `RadarGridTimeContract.projected_displacement_xy()` at
   `src/advar/nowcast.py:3558-3576` preserves the input dtype for non-MPS
   non-v6 grids and constructs the affine matrix in that dtype, but performs
   no dtype validation. An integer tensor therefore turns a matrix such as
   `1000.5` into integer `1000` and returns an integer result. The probe above
   returns `[1000, -2000]`; the affine contract's mathematical result is
   `[1000.5, -2000.5]`. The authoritative norm/speed helpers explicitly
   restrict inputs to float32/float64, while this public conversion is used by
   `projected_velocity_xy()` and `ForecastResult.projected_velocity_mps_xy`.
   The smallest sound direction is to reject non-floating/non-binary32/64
   displacement tensors before matrix construction, or explicitly promote to
   float64 on CPU while preserving the declared output contract. The inverse
   conversion has the related inconsistency that integer input reaches
   `torch.linalg.solve` and fails with a backend runtime error instead of a
   contract `ValueError`.

## Hypotheses and limits

`ForecastRunContract.from_inputs()` does not explicitly check that background
tensors share the frame device/dtype, so mismatches may produce a later tensor
runtime error; I did not classify this as a defect because downstream forecast
entry points may establish that precondition and the assigned code does not
claim cross-device inputs. Integer affine displacement is likewise outside the
normal forecast state path, which supplies floating state tensors, but the
public contract method currently accepts it and computes the wrong value.

No formal test suite was run, per the bounded-review instruction. The exact
read coverage and probe environment are recorded in the companion JSON.
