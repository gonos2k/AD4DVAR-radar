from pathlib import Path
import json
import traceback
import torch
from advar.variational import prepare_analysis, initial_control, residual_vector, solve_analysis, AnalysisConfig
from advar.matrix_free import jvp

torch.set_num_threads(1)
y, x = torch.meshgrid(torch.arange(16.), torch.arange(16.), indexing="ij")
frames = torch.stack([-10 + 45 * torch.exp(-((x-6-.5*i)**2 + (y-7-.3*i)**2)/12) for i in range(3)])
rows = []
for device in ["cpu", "mps"]:
    row = {"device": device, "torch": torch.__version__}
    try:
        obs, frozen = prepare_analysis(frames.to(device), analysis_config=AnalysisConfig(maximum_outer_iterations=1))
        control = initial_control(frozen)
        residual = lambda c: residual_vector(c, obs, frozen)
        row["forward_finite"] = bool(torch.isfinite(residual(control)).all())
        try:
            value, tangent = jvp(residual, control, torch.ones_like(control))
            row["jvp"] = {"value_finite": bool(torch.isfinite(value).all()), "tangent_finite": bool(torch.isfinite(tangent).all())}
        except Exception:
            row["jvp_error"] = traceback.format_exc()
        try:
            result = solve_analysis(obs, frozen)
            row["solve"] = {"reason": result.reason, "used_fallback": result.used_fallback, "initial_objective": result.initial_objective, "final_objective": result.final_objective}
        except Exception:
            row["solve_error"] = traceback.format_exc()
    except Exception:
        row["setup_error"] = traceback.format_exc()
    rows.append(row)
out = Path(__file__).with_suffix(".json")
out.write_text(json.dumps(rows, indent=2) + "\n")
print(json.dumps(rows, indent=2))
