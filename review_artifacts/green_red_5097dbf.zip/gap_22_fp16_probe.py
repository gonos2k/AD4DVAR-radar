import torch

from advar.nowcast import NowcastConfig, nowcast


config = NowcastConfig(horizon_minutes=10)
for dtype in (torch.float16, torch.float32):
    frames = torch.full((3, 32, 32), config.min_dbz, dtype=dtype)
    for step in range(3):
        frames[step, 16 + step, 16] = 20.0
    try:
        result = nowcast(frames, config)
        print(dtype, "ok", result.state.displacement_yx.tolist())
    except Exception as error:
        print(dtype, type(error).__name__, str(error))
