"""Tiny adjudication probes for gap 06; CPU-only and dependency-light."""

import json
from types import SimpleNamespace

import torch

from advar.calibration import OperationalDataIdentity
from advar.nowcast import _validate_input_plan_lineage, _validate_input_plan_resolution
from advar.promotion import (
    NeuralPriorInputPlan,
    OperationalIssuanceDomainArtifact,
    OperationalIssuanceDomainPlan,
    tensor_digest,
)


def input_plan_v1_reaches_current_resolver() -> None:
    times = (
        "2026-01-01T00:00:00Z",
        "2026-01-01T00:10:00Z",
        "2026-01-01T00:20:00Z",
    )
    values = {
        "valid_times": times,
        "grid_contract_digest": "1" * 64,
        "radar_product_digest": "2" * 64,
        "qc_pipeline_digest": "3" * 64,
        "background_cycle_rule_digest": "4" * 64,
        "mask_policy_digest": "5" * 64,
        "observation_valid_time": times[-1],
        "input_available_time": "2026-01-01T00:21:00Z",
        "decision_deadline": "2026-01-01T00:22:00Z",
        "publication_time": "2026-01-01T00:23:00Z",
        "contract": "neural-prior-input-plan-v1",
    }
    for tag in ("neural-prior-input-plan-v1", "legacy-opaque-input-plan-v1", "garbage"):
        accepted = NeuralPriorInputPlan(**(values | {"contract": tag}))
        print("input_plan_contract", tag, "accepted", accepted.plan_digest[:8])
    for malformed_times in (
        (times[-1],),
        (times[1], times[0], times[-1]),
        (times[0], times[0], times[-1]),
    ):
        accepted = NeuralPriorInputPlan(**(values | {"valid_times": malformed_times}))
        print("input_plan_times", malformed_times, "accepted", accepted.plan_digest[:8])
    plan = NeuralPriorInputPlan(**values)
    payload = json.dumps(plan.payload, sort_keys=True, separators=(",", ":"))
    identity = OperationalDataIdentity(
        radar_class="probe",
        qc_pipeline_digest=values["qc_pipeline_digest"],
        observation_error_model_digest="6" * 64,
        background_model_digest="7" * 64,
        radar_product_digest=values["radar_product_digest"],
        background_cycle_rule_digest=values["background_cycle_rule_digest"],
        mask_policy_digest=values["mask_policy_digest"],
    )
    grid = SimpleNamespace(digest=values["grid_contract_digest"], valid_times=times)
    _validate_input_plan_lineage(payload, plan.plan_digest)
    try:
        _validate_input_plan_resolution(payload, identity.json, grid)
    except Exception as error:  # exact current resolver failure is the evidence
        print("input_plan_v1_constructor", "accepted")
        print("input_plan_v1_lineage", "accepted")
        print("input_plan_v1_current_resolver", type(error).__name__, str(error))


def unknown_source_kind_reaches_static_artifact() -> None:
    mask = torch.ones((1, 2, 2), dtype=torch.bool)
    exclusion = torch.zeros_like(mask)
    plan = OperationalIssuanceDomainPlan(
        case_id="probe",
        grid_contract_digest="1" * 64,
        radar_source_contract_digest="2" * 64,
        lead_minutes=(60,),
        publication_policy_digest="3" * 64,
        source_coverage_policy_digest="4" * 64,
        permanent_exclusion_policy_digest="5" * 64,
        publication_eligible_mask_digest=tensor_digest(mask),
        source_coverage_mask_digest=tensor_digest(mask),
        permanent_exclusion_mask_digest=tensor_digest(exclusion),
        radar_source_kind="bogus",
    )
    artifact = OperationalIssuanceDomainArtifact.from_masks(
        plan,
        publication_eligible_mask=mask,
        source_coverage_mask=mask,
        permanent_exclusion_mask=exclusion,
    )
    print("unknown_source_kind_constructor", plan.radar_source_kind)
    print("unknown_source_kind_artifact", tuple(artifact.eligible_cell_counts))


if __name__ == "__main__":
    input_plan_v1_reaches_current_resolver()
    unknown_source_kind_reaches_static_artifact()
