# RED engineering audit

Baseline: `5097dbfd1ddf51483578bef5889ebc809ff024f0`. This is a provisional audit artifact. The coverage JSON records only ranges actually read; the remaining ranges are listed explicitly instead of being labeled as reviewed.

## Finding

**P3 — mixed-device mask and uncertainty tensors lack early contract validation.**

- [nowcast.py:4754](/Users/yhlee/ADVAR/src/advar/nowcast.py:4754) validates shape and dtype for `observation_masks`, `observation_quality_weight`, and `observation_std_dbz`, but does not validate their devices against `frames_dbz.device`. The source explicitly enforces this invariant for `source_available_mask` at [nowcast.py:4778](/Users/yhlee/ADVAR/src/advar/nowcast.py:4778), and later tensor operations require the same device.
- [intervention.py:778](/Users/yhlee/ADVAR/src/advar/intervention.py:778) has the same omission for its masks, weights, and standard deviations.
- Minimal repro on the current checkout (no MPS required):
  ```text
  frames = torch.zeros((3, 4, 4), dtype=torch.float32)       # CPU
  masks = torch.ones_like(frames, dtype=torch.bool)           # CPU
  quality = torch.ones_like(frames, device="meta")            # other device
  ForecastRunContract.from_inputs(NowcastConfig(), frames, masks, None,
                                  observation_quality_weight=quality)
  -> RuntimeError: Tensor.item() cannot be called on meta tensors
  ```
  The equivalent mask case raises `NotImplementedError: Cannot copy out of meta tensor; no data!`. These are reachable input combinations and occur before a useful contract error; CPU/MPS mixed inputs reproduce the same unchecked path when MPS is available.
- Expected behavior is an early `ValueError` identifying a device mismatch, before `torch.all` or masking. Impact is a malformed request producing backend-specific failures and making the input contract non-deterministic across devices.
- Minimal theory-consistent remediation is to validate `value.device == frames_dbz.device` for masks, quality weights, and standard deviations in both constructors before finite checks, and add one CPU/alternate-device regression case. This finding does not recommend rejecting background tensors without a demonstrated runtime contract requirement. No repository files were changed by this audit.

## Verification

The current promotion tail implementation was stress-checked with `location=45, std=1, target=5, threshold=0`; the canonical float64 probe returns finite diagnostics (`nll=794.6334302644476`, `pit=-8.125890664701908`). The earlier direct-survival-tail failure is therefore resolved on this baseline and is not reported.

Bounded tests completed:

- `.venv/bin/python` 3.12.13 / Torch 2.13.0: `test_contract_registry.py test_runtime.py test_runtime_closure.py test_acceptance.py` — 17 passed, 3 subtests.
- System Python 3.10.11: the same focused suite — 17 passed, 3 subtests.
- With bounded `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1`, direct current-checkout runs passed CLI (21 tests), ledger (50 tests), nowcast (167 tests), and deployment bundle (6 tests). Earlier bounded runs also passed run artifact (48 tests) and selected promotion numerical cases (7 tests). No full baseline suite was run.

Reviewed contract paths found no additional confirmed defects in the completed ranges. Resource/archive checks, digest canonicalization, acceptance file identity checks, run/linearization artifact round trips, lock checker logic, and initial-field server paths passed their focused checks.

## Gaps and environment

The exact completed ranges and remaining gaps are in [red_engineering_coverage.json](/tmp/advar-green-red-5097dbf/red_engineering_coverage.json). Large ledger, promotion, nowcast, intervention, deployment-generator, and lock-file ranges remain for parent/delegated review. The system Python 3.10 and project virtualenv Python 3.12 environments were both recorded; no source or git changes were made.
