# GREEN/RED review unit 7

Scope: `src/advar/promotion.py:5001-10000`, with continuation/caller context in the same module, `src/advar/ledger.py`, and focused promotion tests. Baseline: `5097dbfd1ddf51483578bef5889ebc809ff024f0`. The assigned source range was read in contiguous 300-line bounded commands (the final command was 200 lines); no source files were changed.

The range implements content-addressed training shards and train-only normalization, signed training/classifier lineage, signed regime references, trusted process receipts, physical-event tracks/catalogs, legacy audit payloads, and the current holdout/experiment-family commitments. The principal invariants are digest/address equality, canonical JSON/time, signature authority equality, split/event disjointness, train-only normalization, bounded archive members, and physically plausible track speed/acceleration before association.

## Findings

### MEDIUM — physical-track acceleration check accepts accelerations above its stated 0.25 m/s² limit

Locations: `src/advar/promotion.py:7406-7423` and the duplicate recheck at `7507-7518`.

The contract rejects track acceleration above `0.25 m/s²`, but both checks divide the change in adjacent segment velocities by `max(1.0, (t[i+2]-t[i]).total_seconds()/2)`. There is no minimum timestamp spacing in `PhysicalEventTrackArtifact`; canonical timestamps only need to be strictly increasing. Thus intervals shorter than two seconds are assigned a one-second denominator and the physical acceleration is understated.

Reproduction (CPU, Python 3.12/Torch 2.13): a track at `t=0, 0.1, 0.2 s` with x positions `0, 0, 0.01 m` has segment speeds `0` and `0.1 m/s`, so true acceleration is `0.1 / 0.1 = 1 m/s²`. Construction was accepted (`terminal_velocity_xy_mps=(0.1, 0.0)`). The accepted track can flow through `PhysicalEventCatalogEvidence.from_members` and `PhysicalEventCatalogResult.from_plan`; those validators repeat the same weakened formula, so event association receives a track outside the stated physical bound.

Smallest sound direction: use the actual midpoint-to-midpoint duration without the one-second clamp, or explicitly add and enforce a documented minimum sample spacing before using the clamp. The constructor and retained-object validator must use the same corrected rule.

### MEDIUM — regime-reference validator accepts malformed signed fields

Locations: `src/advar/promotion.py:6908-6932`; current ledger decode path `src/advar/ledger.py:20964-20971`.

`validate_regime_reference_evidence` checks the contract, plan/labeler identity, retained digest, time ordering, signature length, and Ed25519 signature, but never validates `full_analysis_input_digest`, `verification_bundle_digest`, `observed_regime`, or `observed_storm_id`. The normal factory (`from_plan`) checks these fields, but the current ledger decoder intentionally reconstructs with `_new_regime_reference_evidence` and only compares the payload digest. A valid signature from the preregistered key over a malformed payload therefore passes the public validator.

Reproduction (CPU): a `RegimeReferencePlan` was created with a valid test key; a payload signed by that key used `full_analysis_input_digest="not-a-digest"`, `verification_bundle_digest="also-not-a-digest"`, and empty regime/storm strings. `_new_regime_reference_evidence` followed by `validate_regime_reference_evidence` printed `ACCEPTED_MALFORMED_REFERENCE`.

The later scoring/promotion paths do call the validator (`promotion.py:13710` and `21288`), so this is currently a delayed integrity failure rather than an immediate promotion bypass. It remains reachable through ledger load and any consumer that treats a decoded current candidate manifest as valid. Smallest sound direction: enforce the factory field invariants in `validate_regime_reference_evidence` (digest syntax, nonempty canonical labels), and invoke that validation while decoding/current-manifest construction when the corresponding plan is available.

## Hypotheses / limitations

- `TrainingFeatureDatasetArtifact.__post_init__` retains every feature tensor in `feature_snapshots` (`promotion.py:5676-5692`) while its aggregate contract permits up to 256 GiB expanded data. This is a real scalability concern for a large accepted dataset, but I did not allocate a large archive or classify it as a defect because deployment-sized limits and executor behavior outside the bounded range need confirmation.
- Legacy holdout classes in this range are explicitly audit-only and were not treated as current-operation bugs.
- No MPS/CUDA, full baseline suite, or source changes were used.

## Verification

Commands, all with `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python`:

1. Constructed the 0.1-second, 1 m/s² track; result: **accepted**, demonstrating the acceleration-bound defect.
2. Constructed and Ed25519-signed the malformed regime-reference payload; result: **accepted by `validate_regime_reference_evidence`**, demonstrating missing schema checks.

Both probes used CPU only. No formal tests were run, per the bounded-review instruction forbidding a full baseline.

Rerunnable probe source and captured stdout are [gap_07_probes.py](/tmp/advar-green-red-5097dbf/gap_07_probes.py) and [gap_07_probes_stdout.json](/tmp/advar-green-red-5097dbf/gap_07_probes_stdout.json). The captured result records the canonicalized timestamps, the actual 0.1-second midpoint duration versus the implementation's clamped one-second denominator, and `promotion_bypass_demonstrated: false` for the malformed-reference case: it demonstrates a decoder/standalone-validator schema gap, not a complete typed promotion bypass.
