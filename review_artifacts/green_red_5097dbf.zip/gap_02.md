# RED bounded review — `src/advar/ledger.py:5001-10000`

Baseline: `5097dbfd1ddf51483578bef5889ebc809ff024f`  
Review status: complete for the assigned range; no source or git files changed.

## Confirmed finding

### MEDIUM — source-coverage append can commit after its issue deadline

`EpisodeLedger.append_resolved_source_coverage_artifact` is documented as a
pre-issue append (line 7805), but it samples `datetime.now()` once at lines
7827-7835 and then opens the database and performs the INSERT at lines
7836-7859. There is no final trusted-clock check before the transaction commits.
The stored `created_at` is the stale pre-check timestamp (`now.isoformat()` at
line 7857), so the ledger can claim a pre-deadline append after the wall clock
has crossed the decision deadline.

Evidence: `/tmp/advar-green-red-5097dbf/gap_02_deadline_probe.py` uses valid
field-shaped inputs, stubs only the already-independent artifact validator, and
delays the exact coverage INSERT by 600 ms with a 100 ms deadline. It prints
`accepted_after_deadline=True` under
`OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python`.
The focused existing test
`NeuralPriorPromotionTests.test_dynamic_source_coverage_must_be_ledgered_before_deadline`
passes, but it exercises only a fixed clock before/after the call and does not
cover this interleaving.

Smallest sound direction: acquire the write lock and re-read the trusted clock
immediately before the INSERT/commit (or perform a final check inside the
transaction and raise so the context rolls the write back). Record the final
check's timestamp as `created_at` if it is part of the chronology evidence.

## Lower-confidence contract gap requiring owner confirmation

### Coverage identity is not bound to the analysis run in provenance append/replay

At lines 8277-8283, the current provenance append validates a supplied
`ResolvedSourceCoverageArtifact` only for its own digest, `case_id`, and the
derivation's source-selection digest. The coverage artifact's
`input_bundle_digest` and `full_analysis_input_digest` are not compared with
`run.input_bundle_digest` and `run.full_analysis_input_digest`. The recovery
replay at lines 9838-9847 likewise checks type/case/grid/registry and omits
those two identity fields. `ResolvedSourceCoverageArtifact` explicitly carries
those fields, and downstream operational-domain validation treats them as
input lineage, so a trusted but stale signed coverage mask for the same case,
grid, and radar registry could be reused with a different raw input run.

This is recorded as a contract hypothesis rather than a confirmed defect: an
end-to-end fixture that constructs two otherwise valid signed coverage/run
pairs was not rebuilt in this bounded unit. If those fields are intended only
as informational metadata, no issue exists; if they are the intended binding,
both append and replay need equality checks against the run/derivation.

## Engineering observation

`append_realized_intervention_receipt` writes and renames the durable action
artifact at lines 6380-6389 before inserting the receipt and before the final
publication-time check at lines 6390-6405. If that check, the receipt INSERT,
or a later transaction operation raises, SQLite rolls back but the already
renamed directory remains unindexed under `interventions_dir`. The normal
loader cannot reach it, and repeated failed executor submissions can consume
the bounded artifact storage. This was not elevated to a confirmed severity
finding because the full signed intervention fixture was outside this unit's
small probe budget; cleanup/quarantine should be considered around the
filesystem publication boundary.

## Validation

- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -m py_compile src/advar/ledger.py` — pass.
- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -m unittest tests.test_promotion.NeuralPriorPromotionTests.test_dynamic_source_coverage_must_be_ledgered_before_deadline` — pass (`Ran 1 test`).
- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python /tmp/advar-green-red-5097dbf/gap_02_deadline_probe.py` — reproduced the late-commit acceptance.
- No baseline suite, MPS, CUDA, or source fixes were run.

