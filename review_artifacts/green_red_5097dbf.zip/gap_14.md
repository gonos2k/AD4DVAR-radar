# RED bounded review — unit 14

Scope: `tests/test_promotion.py:1-5000`, read completely in contiguous bounded chunks. The range contains the promotion test imports and fixtures, current/legacy contract tests, deployment-certificate binding checks, replay tensor/backend checks, and the first part of the full product semantic-replay-to-promotion test. The latter's function-boundary continuation (`5001-5053`) was read as context. Current production callers were read in `src/advar/promotion.py` and `src/advar/ledger.py` for the replay, promotion, certificate, and applicability paths.

## Findings

### MEDIUM test-oracle gap — the full semantic-replay promotion test has no independent metric oracle

Location: `tests/test_promotion.py:4608-4609`, `4978-4987`, and `5022-5033` (the test starts at line 3270).

`test_full_product_semantic_replay_reaches_promotion_without_scorer_patch` first obtains `evaluation = replay_case.recompute_evaluation()` (line 4608). It then builds the `HoldoutScoringArtifact` from that same result (lines 4978-4987), and passes the same object to `compute_neural_prior_promotion` (lines 5022-5033). The replay load assertion compares its output to the same implementation-produced evaluation digest (lines 4851-4859). Consequently, the test proves product wiring, digest/lineage checks, and that promotion can consume a self-consistent result; it does not independently establish that the metric, uncertainty, classifier, or issuance values are scientifically correct. A regression in `PriorHoldoutEvaluation.from_forecasts` or the replay scorer can change both the initial value and the sealed scoring artifact in lockstep while this test still reaches `evidence.eligible`.

This is a real regression-detection gap in the test, not evidence of a current production bypass: the current production entry point does dispatch to `ScoringReplayCaseArtifact.recompute_evaluation()` (`src/advar/promotion.py:16298-16305`), and the test's stated purpose is to exercise that path without a callback patch. The smallest sound test direction is to assert at least one hand-computed value from a minimal fixture (for example, the one-cell `log_echo_mse`/issuance score and its expected direction), or to build the promotion artifact from an independently computed expected evaluation and assert the replay result against it. Keep the existing product-path test for plumbing and add the independent oracle for numerical correctness.

No confirmed reachable production defect was established in the assigned test range. The legacy contract checks intentionally construct audit-only generations; the current generation and CPU/device guards are exercised and passed.

## Validation

Environment: `/Users/yhlee/ADVAR/.venv/bin/python` (Python 3.12.13, Torch 2.13), CPU only, `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1`.

Focused execution of all 16 tests whose definitions are in lines 1-5000:

`OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -m pytest -q tests/test_promotion.py -k 'physical_applicability_contract_versions_are_new_generations or holdout_plan_requires_every_preregistered_observation_error_plan or current_holdout_rejects_legacy_observation_error_plan or semantic_replay_generation_stops_before_operational_deployment or deployment_certificate_binds_the_full_promotion_preimage or v15_promotion_remains_audit_only or v18_promotion_remains_audit_only or pr108_contracts_remain_audit_only or pr105_contracts_remain_audit_only or immediately_previous_contracts_remain_audit_only or pr102_contracts_remain_audit_only or previous_physical_contracts_load_as_audit_only or semantic_replay_role_schema_rejects_wrong_dtype or semantic_replay_requires_one_device_across_every_role or scoring_backend_is_cpu_only or full_product_semantic_replay_reaches_promotion_without_scorer_patch'`

Result: **16 passed**, 211 deselected, 18 warnings, 566.93 seconds. No source files were modified and no baseline suite was run.

## Context and limitations

The test range does not include the later replay mutation tests (for example, forecast-tensor-after-rehash and exact-background-shape cases); those were not used to claim coverage here. No MPS/CUDA execution was performed. The finding concerns oracle independence only; it does not claim that the current replay formulas are wrong.
