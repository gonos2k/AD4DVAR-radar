# Bounded RED/GREEN review — `src/advar/promotion.py` lines 1–5000

Baseline: `5097dbfd1ddf51483578bef5889ebc809ff024f`. The assigned range was read in contiguous bounded chunks, with current ledger, nowcast, range-geometry, and promotion-test caller context. No repository source files, tests, or baseline artifacts were changed.

## Findings

### P2 — `NeuralPriorInputPlan` accepts arbitrary contract tags and non-canonical time sequences

- Reachable path: [`NeuralPriorInputPlan.__post_init__`](/Users/yhlee/ADVAR/src/advar/promotion.py:2818) validates digests and latency but never checks `self.contract`, the number of valid times, uniqueness, or increasing order. The object is then content-addressed at line 2846 and is reconstructed from durable ledger payloads in `ledger.py:4463-4467`, `8931-8932`, and `14163-14167`.
- Minimal CPU probe (`Python 3.12.13`, Torch 2.13) constructed the same valid fields with each of `neural-prior-input-plan-v1`, `legacy-opaque-input-plan-v1`, and `garbage`; all were accepted and assigned a `plan_digest`. A one-element plan and an unsorted/duplicate `valid_times` tuple are also accepted as long as the last element equals `observation_valid_time`.
- Expected contract: the class advertises `neural-prior-input-plan-v2`, while current run lineage requires the typed v2 payload and the three ordered model times. The later run resolver may reject some malformed instances, but the holdout/operational plan validators can durably commit them before a run exists, producing pre-registered digests that cannot resolve consistently. An unknown contract is also liable to be dispatched as a legacy/current payload by adjacent compatibility code.
- Smallest sound direction: require the exact current contract (or dispatch legacy plans to a separate typed class), require exactly the supported number of unique strictly increasing valid times, and require the final time to equal `observation_valid_time`.

### P2 — `OperationalIssuanceDomainPlan` accepts an unrecognized `radar_source_kind`

- Reachable path: [`OperationalIssuanceDomainPlan.__post_init__`](/Users/yhlee/ADVAR/src/advar/promotion.py:3255) branches only on `== "mosaic"`; for v2 any other value with no dynamic fields falls through and is accepted. Current callers use the value to choose static versus mosaic behavior in `OperationalIssuanceDomainArtifact.from_masks` and holdout/operational provenance validation.
- Minimal CPU probe built a v2 plan with `radar_source_kind="bogus"` and valid digests/masks; construction succeeded and the plan retained `bogus`. The implementation subsequently treats it as the single-site/static branch, so a typo silently changes the declared topology rather than failing closed.
- Expected contract: the declared `Literal["single_site", "mosaic"]` is part of the identity and controls source-coverage trust, source registry requirements, and publication-domain resolution. A third value has no defined semantics and must not be persisted as a valid plan.
- Smallest sound direction: reject values outside `{"single_site", "mosaic"}` before the v1/v2 branch; retain the existing v1 static restriction and v2 mosaic dynamic-field checks.

## Green checks and limits

The canonical raw-grid artifact correctly snapshots source bytes, validates QC against the raw validity mask, and uses fixed fills/weights for excluded cells. Raw-volume and missing-observation receipts bind slot/time/site identities and verify signatures. Mosaic source coverage correctly distinguishes the current issuance map from the per-valid-time history map, including selected missing-volume rejection; that distinction is intentional for publication versus historical input derivation. Background NaN values are intentional missing-data markers and are cleaned/masked by the nowcast input preparation path, so the earlier finite-background suspicion is withdrawn. The trust-store decoder's malformed-record filtering is fail-closed for authority use and does not alter the pinned reconstructed digest; it is therefore not retained as a defect. Training shard loading uses one descriptor-backed byte snapshot, content-addressed filenames, no-follow checks, archive bounds, and tensor digests. The weighted target loss masks invalid cells before aggregation and normalizes by effective quality weight.

## Verification

Commands used `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python` (Python 3.12.13, Torch 2.13), CPU only. The saved probe [`gap_06_probes.py`](/tmp/advar-green-red-5097dbf/gap_06_probes.py) and stdout [`gap_06_probes.stdout.txt`](/tmp/advar-green-red-5097dbf/gap_06_probes.stdout.txt) reproduce: a v1 `NeuralPriorInputPlan` is accepted and passes generic lineage validation before the current resolver raises `KeyError('issue_time')`; and `radar_source_kind="bogus"` is accepted and produces a static issuance artifact. No MPS/CUDA, full baseline tests, source fixes, or commits were run. The assigned source range was read fully; caller context was read separately where noted in the coverage artifact.
