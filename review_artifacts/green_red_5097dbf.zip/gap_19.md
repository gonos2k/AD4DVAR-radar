# GREEN / RED bounded review — unit 19

## Scope and method

Read every line of .github/scripts/build_deployment_bundle.py:1-2089 in bounded
chunks (1-360, 361-720, 721-1080, 1081-1440, 1441-1800, and 1801-2089)
and every line of .github/scripts/generate_metric_domain_evidence.py:1-961
in bounded chunks (1-360, 361-720, and 721-961). I read the applicable
repository instructions, the contract-domain routing map, runtime-closure
implementation, deployment tests, current geodetic report validator/call
sites, CI invocations, README legacy deployment procedure, and relevant PR
checklists.

The current checkout is 5097dbfd1ddf51483578bef5889ebc809ff024f0. The current
scientific product consumes the committed EPSG:5179 report through
src/advar/nowcast.py; CI invokes the generator for source-only and execution
environment checks. The bundle/activation script is explicitly documented as
legacy engineering scaffolding, is not called by required CI or current
scientific/operational product paths, and candidate-smoke artifacts do not
authorize LIVE use. No source or test files were modified, no broad suite was
run, and no MPS/CUDA was used.

## GREEN assessment

The geodetic generator preserves the important current contracts: canonical
C/UTC/offline PROJ settings, rejection of nonempty loader override variables,
exact EPSG:5179 authority and area-of-use metadata, PROJ/projinfo/proj.db
identity hashes, source-byte binding, dynamic-library closure metadata, and
canonical JSON output. Its projected coverage construction is explicitly
sampled: it projects 10,001 points on each geographic edge, applies inward
integer-metre ceil/floor bounds, then inverse-checks 10,001 points on each
projected edge. The committed values reproduce exactly on this host
(592664..1576674 m, 976711..2251910 m; inverse extrema remain inside the EPSG
envelope). A separate 101x101 interior inverse probe found no escape. This is
evidence for the registered sampled contract, not an independent geodetic
proof; the report and current validator correctly retain
independent_geodetic_revalidation_required.

The deployment script correctly binds wheel bytes, exact lock hashes, CPU-only
Torch, audit/SBOM/installation payloads, runtime-tree digest, interpreter
closure, bundle digest, release approval, distinct activation authority, and
activation predecessor. Runtime-tree scanning rejects symlinks, unowned files,
import hooks, bytecode artifacts, unexpected distributions, and mutable
deployable paths. Existing bounded tests exercise these invariants.

## RED findings

1. **P2 legacy engineering — native-library closure can silently be incomplete and is selected by PATH.**

   In build_deployment_bundle.py:312-340, each closure scan invokes the bare
   command ldd and accepts only lines containing an absolute path. A normal
   ldd line such as libmissing.so => not found is silently skipped, so the
   attested native_libraries list can be empty or partial while the
   extension/interpreter will fail to load on the target. The generator has
   the same PATH selection at generate_metric_domain_evidence.py:251-287:
   it records the path returned by shutil.which("ldd"), but invokes ["ldd", ...]
   through PATH again. A PATH-prepended inspector can report only its arguments
   (or no dependencies), and the generator records that fabricated closure
   hash as successful execution-environment evidence. The generator does not
   reject an empty Linux closure before writing a report; the later product
   validator rejects empty closure, but generation itself has already reported
   success.

   The expected engineering contract is that every non-system linked dependency
   is resolved and that the inspector executable used for enumeration is the
   same content-addressed executable whose hash is recorded. The actual current
   deployment path can attest a missing/omitted native dependency, and the
   current generator path can attest a PATH-selected fake inspector. This is
   legacy-only in this repository because the bundle flow is not a current
   product authority.

   A tiny CPU probe patched subprocess.run for the bundle helper to return
   libmissing.so => not found; the helper returned [] rather than failing. A
   second isolated probe placed a temporary fake ldd first on PATH, isolated
   the Linux branch with platform/ELF mocks, and observed the recorded
   inspector path change to the temporary file while the closure contained
   only the fake script's argument paths. The current generator's real Darwin
   run was not used as Linux evidence.

   The smallest sound direction is to resolve ldd once, invoke that absolute
   path, bind its executable hash/version into the closure contract, reject
   every non-system not found/unparseable dependency line, and reject an empty
   closure where the platform requires file-backed dependencies. A contract
   generation update and regression probes should cover a missing dependency
   and PATH substitution.

2. **P2 legacy engineering — direct activation receipt verification accepts an already-expired receipt.**

   issue_runtime_activation_receipt checks only activated_at < expires_at and
   activated_at <= now (build_deployment_bundle.py:1457-1478). The corresponding
   verifier has the same checks at :1608-1624, but never requires expires_at
   >= now. Thus a correctly signed receipt with activated_at =
   2026-08-01T00:00:00Z and expires_at = 2026-08-02T00:00:00Z was accepted on
   the current 2026-09-05 checkout. The CLI verify-runtime-activation has no
   required_valid_through/current-time argument that would add this guard.

   The expected direct verifier contract for a current activation is that the
   receipt remains valid at verification time; an expired historical receipt
   may remain authenticity-readable only through an explicitly audit-only path.
   The current product's typed promotion/ledger validators normally supply a
   required-valid-through instant, so this is not a current product bypass, but
   the standalone legacy script advertises and exposes a weaker acceptance
   boundary.

   Reproduction used two deterministic Ed25519 keys and a canonical receipt;
   only the internal release-approval verifier was mocked to isolate the
   expiry predicate. The signed receipt with the past expiry returned its
   receipt digest (2e73b3819fd4dbce4d3b776fb5014bf6dda2dbc1da2e9b94ddc4b40e2f4b97c8)
   instead of raising. The smallest sound direction is to require expiry >=
   now in both issue/verify entry points, or to require an explicit current
   required_valid_through in the standalone verifier and retain a separate
   audit-only historical verifier.

3. **P2 legacy engineering — vulnerability-audit validation is not bound to the locked distribution set.**

   _validate_audit (build_deployment_bundle.py:111-121) only checks that the
   JSON has a list named dependencies and that every listed vulns list is empty.
   It does not require nonempty coverage, exact normalized package names/versions
   from the deployment lock, uniqueness, or absence of omitted lock entries. A
   supplied {"dependencies":[],"fixes":[]} is accepted, and build_bundle passes
   the audit to this validator without the locked package set. The resulting
   signed bundle can therefore label an unverified runtime as clean if the
   audit artifact was incomplete before signing.

   The expected contract implied by the error text ("incomplete or nonclean")
   and the bundle's lock/audit provenance is exact clean coverage of the locked
   distributions. This path is legacy-only and requires a trusted release
   process, but the standalone builder's input contract does not enforce it.
   A tiny CPU probe returned an empty audit object unchanged rather than
   raising.

   The smallest sound direction is to pass the normalized lock set and require
   one exact name/version record per locked package, with no duplicates or
   extras, before accepting the clean-vulnerability assertion. A focused
   empty/missing/version-mismatch audit regression is sufficient.

## Geometry, numerical, and provenance boundaries

No current false EPSG:5179 bound was established. The generator's use of binary
float before ceil/floor is theoretically not directed rounding: a true
projected boundary value within one floating-point ulp of an integer could
round to the integer and move an inward bound outward by one metre. On the
current committed toolchain, the closest sampled projected boundary value was
about 3.55e-05 m from an integer, far above the local float ulp, and the current
report is content-addressed to the exact toolchain. This remains a future
numerical hardening opportunity, not a reproduced current defect. Finite edge
sampling also cannot prove all interior extrema; that limitation is named by
the sampled coverage contract and the explicit independent-geodetic gate.

No other reachable defect was established in the assigned ranges. The active
source-binding and report validator checks, exact wheel/lock/runtime identity,
distinct release/activation keys, predecessor rules, and signed digest
relations were consistent with their stated contracts. Existing current
product paths enforce expiry/current trust through typed promotion/ledger
validators rather than this legacy script.

## Validation

Environment: /Users/yhlee/ADVAR/.venv/bin/python (Python 3.12.13, Torch 2.13
CPU), OMP_NUM_THREADS=1 MKL_NUM_THREADS=1; no MPS/CUDA.

Commands/results:

- .../generate_metric_domain_evidence.py --check-source-only: PASS (returned
  the current report SHA-256
  ceed652ab406b18b5f8550d2213ca0840ae224babe434d4ca1e1fec9ee7a0e62).
- Tiny _linked_native_libraries missing-dependency probe: returned [] (unexpected
  acceptance).
- Tiny signed expired-receipt probe: returned a digest (unexpected acceptance).
- Tiny _validate_audit({"dependencies":[],"fixes":[]}) probe: returned the
  object (unexpected acceptance).
- Tiny projected-coverage probe: current exact coverage reproduced and an
  independent 101x101 interior inverse sample found zero out-of-envelope
  points.
- No broad or full baseline tests were executed.

No source changes were made.

