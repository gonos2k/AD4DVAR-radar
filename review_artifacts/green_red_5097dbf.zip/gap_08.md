# RED bounded review — promotion.py unit 8

Baseline: `5097dbfd1ddf51483578bef5889ebc809ff024f`.

Scope reviewed: `src/advar/promotion.py:10001-15000`, with caller and replay context read separately. The assigned range covers the current holdout-plan policy, target identity and completed-case contracts, candidate-manifest validation, target factories, `RangeBandEvaluation`, and the first part of `PriorHoldoutEvaluation.from_forecasts`.

## Confirmed finding

**P2 — `RangeBandEvaluation` accepts physically impossible issuance and area evidence.**

- [promotion.py:12806](/Users/yhlee/ADVAR/src/advar/promotion.py:12806) validates that issuance counts are nonnegative and that the stored fractions match the stored counts, but never enforces the physical cardinality invariant
  `0 <= parent_issued_count_by_lead, candidate_issued_count_by_lead, withdrawn_count_by_lead, newly_issued_count_by_lead <= issuance_domain_cell_count_by_lead` (with the corresponding subset relations). It also does not bound confidence-weighted issued area by `issuance_domain_area_km2_by_lead`.
- The same constructor accepts a per-metric `metric_valid_area_km2[lead, metric]` larger than the aggregate `metric_valid_area_km2_by_lead[lead]`. In the live producer at [promotion.py:14855](/Users/yhlee/ADVAR/src/advar/promotion.py:14855), the former is computed from a boolean subset of the latter's common domain, so every per-metric area must be no larger than the aggregate area.
- These are reachable through the typed audit/replay path: [ledger.py:20265](/Users/yhlee/ADVAR/src/advar/ledger.py:20265) decodes serialized fields and calls `RangeBandEvaluation(**band_values)`; the constructor recomputes only the object digest, not these cross-field invariants. `compute_neural_prior_promotion` later consumes the aggregate tuple for range-band area gates ([promotion.py:22363](/Users/yhlee/ADVAR/src/advar/promotion.py:22363)) and the tensor for metric-cell area gates ([promotion.py:22549](/Users/yhlee/ADVAR/src/advar/promotion.py:22549)), so a malformed typed record can present contradictory inputs to different gates if it enters the scoring artifact. This review does not establish a signed end-to-end promotion bypass.
- Minimal CPU probe ([gap_08_probes.py](/tmp/advar-green-red-5097dbf/gap_08_probes.py), output [gap_08_probes.stdout.json](/tmp/advar-green-red-5097dbf/gap_08_probes.stdout.json); Python 3.12.13, Torch 2.13, `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1`) first verifies the live producer subset formulas, then constructs a current `RangeBandEvaluation` with one issuance-domain cell but `parent_issued_count_by_lead=(2,)`, `candidate_issued_count_by_lead=(2,)`, and issued areas `(2.0,)` against a domain area of `1.0`; construction succeeded and produced a digest. A second probe constructed `metric_valid_area_km2_by_lead=(1.0,)` with `metric_valid_area_km2=[[2.0]]`; construction also succeeded.
- Expected contract behavior is an early `ValueError` for impossible counts, subset violations, confidence-weighted area above the operational domain, or per-metric valid area above the common aggregate domain. The smallest sound direction is to add these cross-field checks in `RangeBandEvaluation.__post_init__` before digesting, and add decoder regression cases.

This is an evidence-integrity defect in a sealed scoring artifact path. The normal `from_forecasts` producer generates consistent values, so the probe does not claim that ordinary production scoring currently emits impossible counts; it demonstrates that the typed contract and replay decoder do not reject them.

## GREEN / RED contract review

The holdout plan and candidate manifest enforce canonical times, digest identity, training/holdout disjointness, source and event-catalog lineage, classifier independence, target visibility exclusion, and candidate/parent execution contracts. `PriorUncertaintyTarget` and `NeuralPriorStateCalibrationTarget` detach and clone source tensors, preserving scoring immutability. The paired metric path uses the parent domain as the fixed common reference, preventing a candidate from hiding withdrawn cells. The quantized truncated-Gaussian diagnostic uses log survival differences and clamps tail ratios before exponentiation; the current path produced finite values in the checked source.

No additional confirmed defect was established in the assigned range. Potential concerns about omitted legacy fields, frozen tensors, and target/source constants were checked against their current callers and are intentional audit or contract behavior. No source files or repository files were changed.

## Verification

- Read every line of the assigned range in bounded 500-line commands: `src/advar/promotion.py:10001-15000`.
- Read caller/replay context: `promotion.py:15740-15940`, `16680-17120`, `20580-21240`, `21220-21400`, `22140-22290`, `22320-22410`, `22520-22580`; `ledger.py:20220-20350`.
- Read focused promotion tests around evaluation construction and classifier-independence checks: `tests/test_promotion.py:14340-14720`, `15820-15940`, `17540-17620`, `20680-20770`.
- Probe command: `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python /tmp/advar-green-red-5097dbf/gap_08_probes.py`; producer subset checks were true and both impossible/inconsistent constructor cases were accepted (exit 0). Exact JSON output is retained in `gap_08_probes.stdout.json`.
- No full baseline suite, MPS, CUDA, source fix, or commit was run.

Remaining uncertainty: this review does not establish whether an external process can obtain a valid scheduler-signed completion receipt for a deliberately malformed scoring artifact; it establishes that the typed artifact and ledger decode contracts themselves accept the malformed values once presented.
