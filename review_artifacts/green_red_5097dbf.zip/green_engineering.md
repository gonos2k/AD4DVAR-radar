# GREEN engineering review

Baseline: `5097dbfd1ddf51483578bef5889ebc809ff024f0`.

This is a provisional engineering review. It covers the bounded source ranges listed in `green_engineering_coverage.json`; entries marked `executed` or `parsed` are behavioral/configuration evidence and are not source-read claims. The large ledger, promotion, nowcast, intervention, run-artifact and CLI bodies still require the parent’s Luna slice reviewers. Mathematical-core modules and their tests remain outside this review.

No actionable engineering defect was found in the bounded source ranges reviewed. The contract registry, canonical digest/provenance validators, learned-input contract, runtime identity, report-only acceptance harness, runtime closure, artifact archive preflight, deployment-bundle security checks, CLI input/output boundary, and initial-field lab request/state path were inspected for input contracts, resource limits, replay identity, path safety, error handling, and fail-closed behavior.

Validation evidence:

- `/Users/yhlee/ADVAR/.venv/bin/python` is Python 3.12.13 with Torch 2.13.0. Under `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1`, the authoritative narrow suite passed: `tests/test_contract_registry.py`, `tests/test_runtime.py`, `tests/test_runtime_closure.py`, and `tests/test_acceptance.py`: 17 tests and 3 subtests.
- The same authoritative environment passed `tests/test_deployment_bundle.py` and `tests/test_initial_field_lab.py`: 16 tests and 14 subtests.
- `node --check examples/initial_field_lab/app.js` and `node --test tests/test_initial_field_lab_ui.cjs` passed 2 UI tests.
- `.github/scripts/check_dependency_locks.py` passed: all four hashed Linux CPU closures are synchronized.
- A bounded CLI probe with a synthetic 3×8×8 input produced `nowcast-npz-v76`, forecast and validity arrays shaped `(18, 8, 8)`.
- `compileall` passed for the assigned Python sources. `.github/scripts/check_basedpyright.py` could not run in this checkout because the local venv does not contain `basedpyright`; CI’s locked environment supplies that dependency.

The earlier temporary-copy test run used `/opt/local/bin/python3.10` and added a temporary `from __future__ import annotations` line to the copied `matrix_free.py`. Those results are supplemental only. A transient import error observed with the shell’s default Python 3.9 was outside the project’s declared Python `>=3.10` floor; direct imports succeed under the authoritative 3.12 venv and Python 3.10. No repository source was changed.

Remaining gaps are recorded explicitly in the coverage JSON: `styles.css`, unreviewed portions of deployment/evidence scripts, and all large primary source/test slices not listed as bounded reads. Requirements locks and metric-domain JSON were parsed and their contracts/digests inventoried, but not manually line-reviewed. The interrupted promotion suite reached 20 passing tests before cancellation after 696 seconds; it is not a completion claim.
