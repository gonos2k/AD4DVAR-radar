from datetime import datetime, timedelta, timezone
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
import time
from unittest.mock import patch

import advar.ledger as ledger_module
from advar.ledger import EpisodeLedger


now = datetime.now(timezone.utc)
resolved_at = now.isoformat()
deadline = (now + timedelta(milliseconds=100)).isoformat()
plan = SimpleNamespace(
    radar_source_kind="mosaic",
    plan_digest="p" * 64,
    case_id="case",
    grid_contract_digest="g" * 64,
    data_ingestor_id="ing",
    data_ingestor_public_key_hex="k" * 64,
    source_radar_registry_digest="r" * 64,
    source_radar_count=1,
)
input_plan = SimpleNamespace(
    grid_contract_digest="g" * 64,
    input_available_time=resolved_at,
    decision_deadline=deadline,
    publication_time=(now + timedelta(seconds=1)).isoformat(),
    plan_digest="i" * 64,
)
resolved = SimpleNamespace(
    issuance_domain_plan_digest="p" * 64,
    case_id="case",
    input_available_at=resolved_at,
    decision_deadline=deadline,
    publication_time=input_plan.publication_time,
    data_ingestor_id="ing",
    data_ingestor_public_key_hex="k" * 64,
    source_radar_registry_digest="r" * 64,
    source_radar_count=1,
    artifact_digest="a" * 64,
    resolved_at=resolved_at,
    payload={"contract": "probe"},
)
domain = SimpleNamespace(
    plan_digest="p" * 64,
    resolved_source_coverage_artifact_digest="a" * 64,
    artifact_digest="d" * 64,
)


class DelayedConnection:
    def __init__(self, connection):
        self.connection = connection

    def __enter__(self):
        self.connection.__enter__()
        return self

    def __exit__(self, *args):
        return self.connection.__exit__(*args)

    def execute(self, sql, parameters=()):
        if sql.startswith(
            "INSERT INTO neural_prior_resolved_source_coverage_artifacts"
        ):
            time.sleep(0.6)
        return self.connection.execute(sql, parameters)


with TemporaryDirectory() as directory:
    ledger = EpisodeLedger(Path(directory))
    real_connect = EpisodeLedger._connect

    def delayed_connect(instance):
        return DelayedConnection(real_connect(instance))

    with (
        patch.object(
            ledger_module,
            "validate_resolved_source_coverage_artifact",
            lambda _artifact: None,
        ),
        patch.object(EpisodeLedger, "_connect", delayed_connect),
    ):
        ledger.append_resolved_source_coverage_artifact(
            plan, input_plan, resolved, domain
        )
    print("accepted_after_deadline=True")
