"""CPU-only counterexample for the automatic metric-cell tail gate."""

import json
import sys
from dataclasses import replace

sys.path.insert(0, "/Users/yhlee/ADVAR")

import advar.promotion as promotion
from tests.test_promotion import NeuralPriorPromotionTests


fixture = NeuralPriorPromotionTests(
    methodName="test_metric_cell_family_includes_local_issuance_bounds"
)
fixture.setUp()
try:
    # Use the current fixture plan and its production-like automatic mode.  The
    # helper reproduces the exact family-size arithmetic used by compute_neural_prior_promotion.
    policy = replace(
        fixture.policy(),
        allow_shadow_small_sample_bootstrap=False,
        bootstrap_samples=1024,
        minimum_bootstrap_tail_replicates=20,
    )
    family_size = fixture.plan().promotion_experiment_family.total_family_size
    metric_cell_test_count = max(
        1,
        4 * len(policy.required_range_metrics)
        + 4 * len(policy.required_range_issuance),
    )
    metric_cell_family_size = family_size * metric_cell_test_count
    diagnostics = promotion._bootstrap_tail_diagnostics(
        policy,
        family_size=metric_cell_family_size,
        enforce=False,
    )
    metric_cell_tail_ok = (
        diagnostics[1] >= policy.minimum_bootstrap_tail_replicates
    )
    # The actual automatic metric-cell branch uses this bounded UCB after the
    # tail gate.  It does not consume bootstrap replicates.
    bounded_upper = promotion._bounded_event_mean_upper_bound(
        [0.0, 0.0],
        ["event-1", "event-2"],
        policy,
        family_size=metric_cell_family_size,
        absolute_bound=1.0,
    )
    result = {
        "plan_family_size": family_size,
        "metric_cell_test_count": metric_cell_test_count,
        "metric_cell_family_size": metric_cell_family_size,
        "automatic_inference": not policy.allow_shadow_small_sample_bootstrap,
        "bootstrap_samples": policy.bootstrap_samples,
        "tail_replicates": diagnostics[1],
        "minimum_bootstrap_tail_replicates": policy.minimum_bootstrap_tail_replicates,
        "metric_cell_tail_ok": metric_cell_tail_ok,
        "bounded_ucb_upper_for_zero_scores": bounded_upper,
        "actual_gate_outcome": "reject_before_bounded_ucb"
        if not metric_cell_tail_ok
        else "continue_to_bounded_ucb",
    }
    assert result["automatic_inference"] is True
    assert result["metric_cell_tail_ok"] is False
    assert result["bounded_ucb_upper_for_zero_scores"] > 0.0
    favorable = []
    for samples in (1024, 16384):
        changed = replace(policy, bootstrap_samples=samples)
        tail = promotion._bootstrap_tail_diagnostics(
            changed, family_size=metric_cell_family_size, enforce=False
        )[1]
        upper = promotion._bounded_event_mean_upper_bound(
            [-0.5] * 1000, [f"event-{i}" for i in range(1000)], changed,
            family_size=metric_cell_family_size, absolute_bound=1.0,
        )
        favorable.append({
            "bootstrap_samples": samples, "tail_replicates": tail,
            "metric_cell_tail_ok": tail >= changed.minimum_bootstrap_tail_replicates,
            "bounded_upper": upper,
        })
    assert favorable[0]["bounded_upper"] == favorable[1]["bounded_upper"] < 0.0
    assert [row["metric_cell_tail_ok"] for row in favorable] == [False, True]
    result["same_favorable_events"] = favorable
    result["full_signed_promotion_replayed"] = False
    print(json.dumps(result, sort_keys=True))
finally:
    fixture.tearDown()
