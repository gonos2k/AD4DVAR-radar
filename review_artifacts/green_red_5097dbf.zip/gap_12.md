# RED bounded review — unit 12

Commit reviewed: `5097dbfd1ddf51483578bef5889ebc809ff024f0`.

Scope: `tests/test_ledger.py:1-5000`, including the ledger/model-contract,
episode serialization and schema compatibility, intervention decision/receipt,
legacy audit loading, and early schema migration tests in that range. The
corresponding current production paths in `src/advar/ledger.py` and
`src/advar/intervention.py` were traced as needed. No repository source or test
files were modified.

## Findings

### P2 — Episode verification does not bind manifest metadata to the immutable index

- Production path: [ledger.py:21358](/Users/yhlee/ADVAR/src/advar/ledger.py:21358)
  `_verify_manifest`, called by `EpisodeLedger.verify`.
- The index row written by `_insert_episode` contains `issue_time`, `radar_id`,
  `model_commit`, `trust_score`, and `impact_available`, while the episode
  manifest repeats those values (directly or through `contract`/manifest
  fields). `_verify_manifest` checks the manifest `episode_id`, contract hash,
  array layout, and several flags, but never compares `manifest["issue_time"]`
  or `manifest["radar_id"]` to `row["issue_time"]`/`row["radar_id"]`. It also
  does not reconcile the repeated trust score, impact flag, or contract model
  commit with their index columns.
- Expected contract behavior is that a verified episode has one immutable
  identity in both storage layers. Actual behavior is that a rewritten
  manifest can change the episode's time and radar identity while retaining a
  valid checksum and passing `verify`; callers of `load()` then receive the
  forged metadata while `list_episodes()` still reports the original index
  metadata. This creates a provenance split for selection, audit, and any
  consumer that trusts the loaded manifest.
- Reproducible CPU probe (current checkout, using the existing test snapshot;
  the probe dropped the immutable-row trigger only to emulate a tampered
  SQLite file, then updated the stored manifest hash):

  ```text
  manifest["issue_time"] = "2099-01-01T00:00:00Z"
  manifest["radar_id"] = "FORGED"
  ledger.verify("probe")
  -> accepted
  ledger.load("probe").manifest["issue_time"], ["radar_id"]
  -> ("2099-01-01T00:00:00Z", "FORGED")
  ```

- The assigned happy-path test [test_ledger.py:2006](/Users/yhlee/ADVAR/tests/test_ledger.py:2006)
  checks serialization and reopen equality but does not assert index/manifest
  identity or exercise this tamper path. The schema tests intentionally alter
  checksums and index hashes, so this threat model is already in scope.
- Smallest theory-consistent direction: during `_verify_manifest`, compare
  every duplicated index field with its manifest/contract counterpart (at
  least `issue_time`, `radar_id`, `contract.model_commit`, `trust_score`, and
  `impact_available`), and add one regression that rewrites those fields,
  recomputes the file/index hashes, and expects verification to reject.

### P2 — Current intervention receipt loading does not bind the requested digest to the SQL/JSON record

- Production path: [ledger.py:6427](/Users/yhlee/ADVAR/src/advar/ledger.py:6427)
  selects by the SQL `r.receipt_digest` key; [ledger.py:6520](/Users/yhlee/ADVAR/src/advar/ledger.py:6520)
  then removes the JSON `receipt_digest` and checks only that the reconstructed
  object matches the JSON value. Unlike the legacy branch at lines 6463–6468,
  the current branch never checks `retained_receipt_digest == receipt_digest`
  and does not select/compare the SQL key itself.
- Expected behavior is that `load_prospective_intervention(requested_digest)`
  returns exactly the record named by `requested_digest`, or rejects a
  database/key mismatch. Actual behavior is that if the SQL key is changed
  while `receipt_json` remains intact, querying the changed key returns the
  original receipt and the loader accepts it; the returned receipt carries a
  different `receipt_digest` than the caller requested. This defeats the
  lookup identity check under SQLite corruption or a privileged database
  mutation and can make audit links point at the wrong durable record.
- Targeted probe: after the existing current v5 round-trip setup, the probe
  changed the immutable SQL `receipt_digest` column to 64 `f` characters,
  retained the original JSON receipt, and called
  `load_prospective_intervention("f" * 64)`. With signature/artifact checks
  stubbed only to isolate the key-binding condition, current code returned:

  ```text
  ACCEPTED_KEY_MISMATCH
  returned receipt_digest = 3d9c3da9133075d528e1fb053e83b1ae3dc3ac7d972648529026c376afb8df17
  requested              = ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff
  ```

- The assigned round-trip test [test_ledger.py:2269](/Users/yhlee/ADVAR/tests/test_ledger.py:2269)
  validates a normal append/load and separately tests legacy linkage, but has
  no current-contract SQL-key/JSON-key mismatch case.
- Smallest direction: retain `r.receipt_digest` (and the SQL decision key) in
  the query result and require exact equality with the reconstructed current
  receipt/decision digests and the requested argument before any further
  verification; add a regression that tampers the SQL key and expects a
  `ValueError`.

## Validation and limits

No full baseline test suite was run, and no MPS/CUDA execution was used. The
only executable checks were the two tiny CPU probes described above, with
`OMP_NUM_THREADS=1 MKL_NUM_THREADS=1` and
`/Users/yhlee/ADVAR/.venv/bin/python` (Python 3.12.13, Torch 2.13). No formal
test command was run for this bounded review. Both findings require a modified
SQLite row (and, for the first, a matching rewritten manifest hash); normal
public append APIs are guarded by immutable triggers. They are reported
because the existing tests intentionally manipulate storage after dropping
those triggers and the loaders should still fail closed on such inconsistencies.

No additional confirmed deficiencies were found in the read range. Legacy
generation tests are intentionally audit-only and their current decoder paths
recompute/validate the historical payload digests; they were not treated as
live-operation support.
