"""Tiny CPU probes for gap 11 findings; no repository files are modified."""

from __future__ import annotations

import json
from types import SimpleNamespace
from unittest.mock import patch
import stat
import sys

sys.path.insert(0, "src")
sys.path.insert(0, ".")

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

import advar.promotion as p
from tests.test_promotion import NeuralPriorPromotionTests


def loader_probe() -> None:
    metadata = SimpleNamespace(
        st_mode=stat.S_IFREG | 0o600,
        st_uid=0,
        st_size=3,
        st_dev=1,
        st_ino=2,
        st_mtime_ns=3,
    )
    for function, kwargs in (
        (
            p.load_deployment_bundle_release_approval,
            {
                "authority_trust_store_path": "/tmp/trust",
                "required_valid_through": "2030-01-01T00:00:00Z",
            },
        ),
        (
            p.load_deployment_runtime_activation_receipt,
            {
                "release_approval_path": "/tmp/release",
                "authority_trust_store_path": "/tmp/trust",
                "required_valid_through": "2030-01-01T00:00:00Z",
            },
        ),
    ):
        reads: list[int] = []

        def fake_read(_fd: int, size: int) -> bytes:
            reads.append(size)
            return b"abc" if len(reads) == 1 else b""

        with (
            patch.object(p.os, "open", return_value=7),
            patch.object(p.os, "fstat", side_effect=[metadata, metadata]),
            patch.object(p.os, "read", side_effect=fake_read),
            patch.object(p.os, "close"),
        ):
            try:
                function("/tmp/input", **kwargs)
            except Exception as error:  # noqa: BLE001 - probe records exact failure
                print(
                    function.__name__,
                    type(error).__name__,
                    str(error),
                    "read_calls=",
                    len(reads),
                )


def fractional_sequence_probe() -> None:
    case = NeuralPriorPromotionTests("runTest")
    receipt = case.deployment_runtime_activation_receipt()
    release = case._latest_deployment_bundle_release_approval
    runtime_key = Ed25519PrivateKey.from_private_bytes(b"\x06" * 32)
    release_key = Ed25519PrivateKey.from_private_bytes(b"\x07" * 32)
    trust = p._PromotionDeploymentAuthorityTrustStore(
        keys={
            "test-runtime-activation": runtime_key.public_key(),
            "test-release-approval": release_key.public_key(),
        },
        content_digest="7" * 64,
        roles={
            "test-runtime-activation": frozenset({"runtime_activation"}),
            "test-release-approval": frozenset({"release_approval"}),
        },
        not_before={
            "test-runtime-activation": "2026-01-01T00:00:00+00:00",
            "test-release-approval": "2026-01-01T00:00:00+00:00",
        },
        not_after={
            "test-runtime-activation": "2031-01-01T00:00:00+00:00",
            "test-release-approval": "2031-01-01T00:00:00+00:00",
        },
        revoked_at={
            "test-runtime-activation": None,
            "test-release-approval": None,
        },
        ledger_instance_digests={
            "test-runtime-activation": frozenset(),
            "test-release-approval": frozenset(),
        },
    )
    values = dict(receipt.payload)
    values["activation_sequence_number"] = 1.5
    values["previous_activation_receipt_digest"] = "a" * 64
    values["authority_signature_hex"] = runtime_key.sign(
        p._RUNTIME_ACTIVATION_SIGNATURE_DOMAIN
        + json.dumps(
            {key: value for key, value in values.items() if key != "authority_signature_hex"},
            sort_keys=True,
            separators=(",", ":"),
        ).encode()
    ).hex()
    forged = p._deployment_runtime_activation_receipt_from_payload(values)
    p._validate_deployment_runtime_activation_receipt(
        forged,
        release_approval=release,
        authority_trust_store=trust,
        required_valid_through="2026-09-06T00:00:00Z",
    )
    print(
        "accepted fractional",
        forged.activation_sequence_number,
        type(forged.activation_sequence_number).__name__,
    )


def fallback_reason_probe() -> None:
    """Exercise the exact replay branch ordering with low confidence."""

    class FakeEvidence:
        deployment_eligible = True
        certified_applicability_regime_groups = (("known", "near"),)
        certified_range_geometry_contract_digests = ("g" * 64,)
        candidate_prior_digest = "c" * 64
        parent_prior_digest = "p" * 64
        deployment_regime_classifier_digest = "r" * 64
        deployment_regime_classifier_manifest_digest = "m" * 64
        semantic_replay_generation_digest = p.SEMANTIC_SCORING_REPLAY_GENERATION_DIGEST
        promotion_evidence_digest = "e" * 64

    class FakePolicy:
        candidate_prior_digest = "c" * 64
        parent_prior_digest = "p" * 64
        promotion_evidence_digest = "e" * 64
        promotion_deployment_certificate_digest = "x" * 64
        regime_classifier_digest = "r" * 64
        regime_classifier_manifest_digest = "m" * 64
        range_geometry_contract_digest = "g" * 64
        semantic_replay_generation_digest = p.SEMANTIC_SCORING_REPLAY_GENERATION_DIGEST
        minimum_regime_confidence = 0.8
        minimum_weather_top1_top2_gap = 0.05
        minimum_deployment_confidence_margin = 0.05

        @property
        def payload(self):
            return {
                "candidate_prior_digest": self.candidate_prior_digest,
                "parent_prior_digest": self.parent_prior_digest,
                "promotion_evidence_digest": self.promotion_evidence_digest,
                "promotion_deployment_certificate_digest": self.promotion_deployment_certificate_digest,
                "promotion_deployment_authority_trust_store_digest": "a" * 64,
                "regime_classifier_digest": self.regime_classifier_digest,
                "regime_classifier_manifest_digest": self.regime_classifier_manifest_digest,
                "range_geometry_contract_digest": self.range_geometry_contract_digest,
                "semantic_replay_generation_digest": self.semantic_replay_generation_digest,
                "mps_backend_certification_digest": None,
                "mps_backend_certification_policy_digest": None,
                "minimum_regime_confidence": self.minimum_regime_confidence,
                "minimum_weather_top1_top2_gap": self.minimum_weather_top1_top2_gap,
                "minimum_deployment_confidence_margin": self.minimum_deployment_confidence_margin,
                "contract": "deployed-neural-prior-policy-v17",
            }

        policy_digest = "q" * 64

    class FakeCertificate:
        certificate_digest = "x" * 64
        payload = {"certificate_digest": certificate_digest}

    regime = {
        "classifier_digest": "r" * 64,
        "regime": "known",
        "regime_confidence": 0.2,
        "weather_top1_top2_gap": 0.9,
        "is_ood": False,
        "full_analysis_input_digest": "i" * 64,
        "evidence_digest": "unused",
    }
    regime_payload = dict(regime)
    regime_payload.pop("evidence_digest")
    regime["evidence_digest"] = p.json_digest(regime_payload)
    ranges = {
        "active_range_regimes": ["near"],
        "range_geometry_contract_digest": "g" * 64,
        "evidence_digest": "unused",
    }
    range_payload = dict(ranges)
    range_payload.pop("evidence_digest")
    ranges["evidence_digest"] = p.json_digest(range_payload)
    cert = FakeCertificate()
    policy = FakePolicy()
    policy_payload = policy.payload | {"policy_digest": policy.policy_digest}
    decision = {
        "regime_classification_evidence": regime,
        "range_partition_evidence": ranges,
        "selection": {
            "fallback_reason": "ambiguous_classifier_branch",
            "selected_role": "parent",
            "selected_prior_digest": "p" * 64,
            "deployment_confidence_margin": -0.6,
        },
        "deployment_policy": policy_payload,
        "promotion_deployment_certificate": cert.payload,
        "policy_trust_store": {"content_digest": "t" * 64},
        "routing_semantic_replay_verified": True,
    }
    with patch.object(p, "NeuralPriorPromotionEvidence", FakeEvidence), patch.object(
        p, "DeployedNeuralPriorPolicy", FakePolicy
    ):
        reason, role, _, _ = p._replay_operational_deployment_selection(
            decision,
            promotion_deployment_certificate=cert,
            promotion_evidence=FakeEvidence(),
            policy=policy,
            policy_trust_store_digest="t" * 64,
            allow_committed_routing_evidence=True,
        )
    print("low_confidence_fallback", reason, role)


if __name__ == "__main__":
    loader_probe()
    fractional_sequence_probe()
    fallback_reason_probe()
