"""Exact CPU NaN/Inf evidence probes used for gap_13."""

import dataclasses
import sys

sys.path.insert(0, "tests")
import test_ledger  # noqa: E402


tests = test_ledger.EpisodeLedgerTests
tests.setUpClass()
case = tests("runTest")
case.setUp()
try:
    for value, episode_id in (
        (float("nan"), "nan-evidence"),
        (float("inf"), "inf-evidence"),
    ):
        evidence = case.snapshot.path_evidence_by_metric.clone()
        evidence[0, 0] = value
        episode = dataclasses.replace(
            case.episode(episode_id),
            snapshot=dataclasses.replace(
                case.snapshot,
                path_evidence_by_metric=evidence,
            ),
        )
        case.ledger.append(episode)
        case.ledger.verify(episode_id)
        print(f"{episode_id} accepted")
finally:
    case.tearDown()
