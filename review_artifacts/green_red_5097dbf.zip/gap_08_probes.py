"""Small CPU-only probes for gap 08.

The producer-side checks are written directly from the current
``from_forecasts`` masks.  The constructor probes then show that the same
cross-field physical constraints are not enforced by ``RangeBandEvaluation``.
"""

from __future__ import annotations

import json
import platform
import sys
from pathlib import Path

import torch

try:
    from advar import promotion as promotion_module
except ModuleNotFoundError:
    sys.path.insert(0, str(Path("/Users/yhlee/ADVAR/src")))
    from advar import promotion as promotion_module


def _base_kwargs() -> dict[str, object]:
    return {
        "range_regime": "low",
        "range_band_mask_digest": "a" * 64,
        "range_geometry_contract_digest": "b" * 64,
        "metric_change": torch.tensor([[0.0]]),
        "end_to_end_metric_change": torch.tensor([[0.0]]),
        "metric_available": torch.tensor([[True]]),
        "candidate_uncertainty_component_scores": (("support", 0.1),),
        "parent_uncertainty_component_scores": (("support", 0.2),),
        "uncertainty_component_differences": (("support", -0.1),),
        "uncertainty_component_sample_counts": (("support", 2),),
        "evaluated_area_km2": 1.0,
        "metric_valid_area_km2_by_lead": (1.0,),
        "metric_valid_area_km2": torch.tensor([[1.0]]),
        "issuance_domain_digest": "c" * 64,
        "issuance_domain_cell_count_by_lead": (1,),
        "issuance_domain_area_km2_by_lead": (1.0,),
        "parent_issued_count_by_lead": (1,),
        "candidate_issued_count_by_lead": (1,),
        "withdrawn_count_by_lead": (0,),
        "newly_issued_count_by_lead": (0,),
        "parent_fallback_count_by_lead": (0,),
        "candidate_fallback_count_by_lead": (0,),
        "parent_confidence_weighted_issued_area_by_lead": (1.0,),
        "candidate_confidence_weighted_issued_area_by_lead": (1.0,),
        "withdrawn_fraction_by_lead": torch.tensor([0.0]),
        "newly_issued_fraction_by_lead": torch.tensor([0.0]),
        "background_fallback_increase_by_lead": torch.tensor([0.0]),
        "confidence_weighted_coverage_change_by_lead": torch.tensor([0.0]),
        "probability_valid_area_km2": 1.0,
        "state_valid_area_km2": 1.0,
        "echo_pixel_count": 0,
        "clear_pixel_count": 2,
        "echo_object_count": 0,
        "state_echo_pixel_count": 0,
        "state_clear_pixel_count": 2,
        "state_echo_object_count": 0,
    }


def _construct(overrides: dict[str, object]) -> dict[str, object]:
    values = _base_kwargs()
    values.update(overrides)
    try:
        result = promotion_module.RangeBandEvaluation(**values)
    except Exception as error:  # pragma: no cover - probe output path
        return {"accepted": False, "error": type(error).__name__ + ": " + str(error)}
    return {
        "accepted": True,
        "evaluation_digest": result.evaluation_digest,
    }


def main() -> None:
    # These are the producer's subset relations in miniature:
    # metric availability selects from common weights; issued/fallback masks
    # are each intersected with operational_domain; confidence is in [0, 1].
    common_weights = torch.tensor([[[1.0, 1.0], [0.0, 1.0]]])
    metric_available = torch.tensor([[True]])
    per_metric_area = float(metric_available[0, 0]) * float(
        torch.count_nonzero(common_weights[0] > 0)
    )
    operational_domain = torch.tensor([[[True, False], [False, False]]])
    parent_issued = torch.tensor([[[True, False], [False, False]]]) & operational_domain
    confidence = torch.tensor([[[0.8, 0.8], [0.8, 0.8]]])
    confidence_area = float(torch.sum(confidence * parent_issued))
    producer_subset_checks = {
        "metric_area_le_common_area": per_metric_area <= float(
            torch.count_nonzero(common_weights[0])
        ),
        "issued_count_le_domain_count": int(torch.count_nonzero(parent_issued))
        <= int(torch.count_nonzero(operational_domain)),
        "confidence_area_le_domain_area": confidence_area
        <= float(torch.count_nonzero(operational_domain)),
    }

    print(
        json.dumps(
            {
                "environment": {
                    "python": platform.python_version(),
                    "torch": torch.__version__,
                    "device": "cpu",
                    "threads": 1,
                },
                "producer_subset_checks": producer_subset_checks,
                "constructor_probes": {
                    "impossible_issuance_counts_and_area": _construct(
                        {
                            "parent_issued_count_by_lead": (2,),
                            "candidate_issued_count_by_lead": (2,),
                            "parent_confidence_weighted_issued_area_by_lead": (2.0,),
                            "candidate_confidence_weighted_issued_area_by_lead": (2.0,),
                        }
                    ),
                    "per_metric_area_exceeds_common_area": _construct(
                        {"metric_valid_area_km2": torch.tensor([[2.0]])}
                    ),
                },
                "interpretation": "The live producer formulas satisfy the subset relations, while the typed constructor accepts contradictory serialized values. This probe does not establish a signed end-to-end promotion bypass.",
            },
            sort_keys=True,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
