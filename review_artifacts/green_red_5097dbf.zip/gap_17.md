# GREEN / RED bounded review — unit 17

## Scope and method

Reviewed every line of `tests/test_promotion.py:15001-20000`, including the
tests that begin before the assigned boundary only where their bodies entered
the range. Production context was read in `src/advar/promotion.py` for raw
input replay, training loss, event-weighted estimands, empirical-Bernstein
intervals, bounded event-mean bounds, classifier metric aggregation, and the
current callers. No source files, tests, baseline state, MPS, or CUDA were
changed.

Targeted validation used:

```text
OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -m pytest -q \
  tests/test_promotion.py::NeuralPriorPromotionTests::test_event_weighted_estimand_is_invariant_to_case_replication \
  tests/test_promotion.py::NeuralPriorPromotionTests::test_classifier_safety_gates_use_event_level_finite_sample_bounds \
  tests/test_promotion.py::NeuralPriorPromotionTests::test_mosaic_range_uses_the_resolved_source_radar
```

Result: 3 passed in 90.88s on Python 3.12.13 / Torch 2.13 CPU. A tiny CPU
probe independently reproduced the event-weighted mean (`0.5` before and
after case replication) and the one-event fractional interval (`[0.0, 1.0]`).

## GREEN findings

The statistical contract has a sound primary invariant: `_event_weighted_mean`
groups observations by `physical_event_digest`, averages within each event,
then averages event means. Replicating cases inside one event therefore cannot
change the estimand. The direct regression at lines 18084–18096 exercises this
with unequal case values and would fail under ordinary case-weighting.

The finite-sample classifier path uses the same event grouping for accuracy,
recall, OOD rates, range precision/recall/exact-set rates, and Brier scores.
The empirical-Bernstein interval groups within-event values before computing
variance and uses a family-adjusted alpha. One event deliberately receives the
uninformative `[0, 1]` interval. The production bounded-mean UCB similarly
aggregates event means and clamps to the declared support. The classifier
regression at lines 18098–18144 at least checks finite scores, lower/upper
ordering, support bounds, and that each reported score is enclosed by its
corresponding finite-sample upper/lower bound.

The surrounding tests establish useful engineering and lineage contracts:
mask-first quality-weighted target loss ignores invalid target cells; target
archives reject empty/non-finite values and oversized files; mosaic source
selection rejects duplicate site/time products and signed missing-volume
selection; background identity uses model-cycle times; training and holdout
raw/sampling identities cannot overlap; raw identities survive key rotation;
and operational provenance/deployment publication paths fail closed across
deadline, crash, lock, concurrent-chain, and retry scenarios. These assertions
trace current `promotion.py` and `ledger.py` callers rather than stale APIs.

## RED / falsifiable gaps

No reachable production defect was established from this bounded range. The
following are test-oracle weaknesses, not confirmed runtime failures:

1. **Low severity — classifier statistical test is not an independent oracle.**
   `test_classifier_safety_gates_use_event_level_finite_sample_bounds` asserts
   relationships among fields produced by the same `compute` implementation;
   it does not assert an independently calculated expected Brier value, event
   mean, family-adjusted alpha, or rejection decision. A mutant that changed a
   score and its bound together, returned a vacuous bound, or removed a gate
   while preserving the reported fields could pass. Add a small deterministic
   fixture with known event means and an independently calculated expected
   interval, then set one policy threshold just across the expected bound and
   assert the corresponding rejection reason.

2. **Low severity — replication invariance is tested only at the helper.**
   The direct helper test is strong for `_event_weighted_mean`, but no test in
   the assigned range duplicates cases through the full promotion evidence
   path and verifies unchanged classifier safety decisions/Brier bounds. A
   caller-level regression with one event represented by several cases would
   make the end-to-end estimand contract falsifiable.

3. **Unresolved hypothesis — simultaneous-family sizing is not numerically
   pinned.** The production classifier family size multiplies registered
   weather/range strata by the endpoint count and experiment-family size, but
   the assigned statistical test does not assert that exact count or its effect
   on alpha. A deterministic preflight/bound test should compare two policies
   differing only in family size and verify the larger family produces the
   wider bound (or rejects at the expected threshold). No evidence here shows
   the current formula is wrong; it is simply under-tested by this range.

The registered constants and supported model restrictions were treated as
contracts. The tests do not claim unsupported classifier label spaces or
non-finite tensors are operationally supported.

