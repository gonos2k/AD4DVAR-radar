"""Runnable bounded probes for gap 05 ledger validator findings.

Run from the repository root with:
  PYTHONPATH=src:tests OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 \
    .venv/bin/python /tmp/advar-green-red-5097dbf/gap_05_probes.py
"""

from dataclasses import replace
import json
import math
from pathlib import Path
import tempfile

import torch

from test_ledger import _computed_snapshot, _contract
from advar.ledger import EpisodeLedger, SensitivityEpisode


def _episode(snapshot, episode_id: str) -> SensitivityEpisode:
    return SensitivityEpisode(
        episode_id=episode_id,
        issue_time="2026-07-26T05:00:00+00:00",
        radar_id="KTLX",
        contract=_contract(snapshot),
        snapshot=snapshot,
    )


def _append_load(snapshot, episode_id: str) -> dict[str, object]:
    with tempfile.TemporaryDirectory() as directory:
        ledger = EpisodeLedger(Path(directory))
        episode = _episode(snapshot, episode_id)
        target = ledger.append(episode)
        ledger.verify(episode_id)
        loaded = ledger.load(episode_id)
        return {
            "target_exists": target.is_dir(),
            "manifest_trust_score": loaded.manifest["trust_score"],
            "loaded_path_evidence_0": str(
                loaded.arrays["path_evidence_by_metric"][0, 0]
            ),
            "loaded_path_evidence_0_is_infinite": bool(
                math.isinf(float(loaded.arrays["path_evidence_by_metric"][0, 0]))
            ),
        }


def main() -> None:
    source = _computed_snapshot()

    trust_components = {name: 1.0 for name in source.trust_components}
    trust_components["linearity"] = 2.0
    bad_trust = replace(
        source,
        trust_components=trust_components,
        trust_score=math.prod(trust_components.values()),
    )
    trust_roundtrip = _append_load(bad_trust, "gap05-trust-over-one")

    path_evidence = source.path_evidence_by_metric.clone()
    path_evidence[0, 0] = float("inf")
    bad_inf = replace(source, path_evidence_by_metric=path_evidence)
    inf_roundtrip = _append_load(bad_inf, "gap05-evidence-infinity")

    print(
        json.dumps(
            {
                "environment": {
                    "python": "3.12.13",
                    "torch": torch.__version__,
                    "device": "cpu",
                    "threads": 1,
                },
                "trust_over_one_append_load": trust_roundtrip,
                "evidence_infinity_append_load": inf_roundtrip,
                "accepted": {
                    "trust_score_gt_one": trust_roundtrip["manifest_trust_score"] > 1.0,
                    "evidence_infinity": inf_roundtrip["loaded_path_evidence_0_is_infinite"],
                },
            },
            sort_keys=True,
            allow_nan=False,
        )
    )


if __name__ == "__main__":
    main()
