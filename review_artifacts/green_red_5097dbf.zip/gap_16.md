# Unit 16 GREEN / RED review

Scope: `tests/test_promotion.py:10001-15000` (unit 16), with the continuation of `test_overlapping_windows_append_same_family` read through line 15180 for function-boundary context. I read the assigned test range in 200-line bounded chunks and inspected the current production callers in `src/advar/promotion.py`, `src/advar/sensitivity.py`, and the raw-resolution membership implementation in `src/advar/ledger.py`. No source or git changes were made.

## GREEN observations

The assigned calibration tests exercise the current quantized interval likelihood and lower-tail implementation rather than the old raw-tail behavior. `_standard_normal_log_interval_mass` reflects right-tail intervals before `logdiffexp`, and `_truncated_gaussian_diagnostics` uses conditional interval mass and midpoint PIT. The selected tail, PIT, local-threshold, large-NLL, and QC-invariance tests passed on the current code. The CPU-only replay contract and legacy audit-only paths are consistent with the current production contracts.

The range-domain tests are consistent with the implementation: publication, source, and permanent-exclusion masks are fixed by digest; mosaic source coverage is resolved in the input issue window and must be ledgered before the decision deadline; range masks are checked as a complete physical partition. The metric-support tests correctly derive log-echo support from the configured dBZ interval and centroid support from the full affine-grid corner diameter.

The event-rate tests correctly use physical-event clusters, preserve finite uncertainty for perfect/small samples, and include the current exact-sign or bounded-event inference family sizes. The tests that mention operational geometry/selection intentionally reach the frozen `infer_deployed_neural_prior` rejection (`OperationalDeploymentUnsupportedError`); they do not establish a live deployment path, which is consistent with the current package restriction.

## RED findings

### MEDIUM — sub-second physical-event tracks can violate the declared acceleration limit

`src/advar/promotion.py:7411-7418` and the duplicate recheck at `7509-7513` divide the change in adjacent segment velocities by `max(1.0, average_segment_duration_seconds)`. The physical contract permits any strictly increasing ISO timestamps, so the one-second floor changes the units and weakens the bound for sub-second samples. A track with timestamps `00:00:00`, `00:00:00.100000`, `00:00:00.200000` and x positions `0.0`, `0.03`, `0.035` is accepted. Its segment speeds are `0.30` and `0.05 m/s`, so the actual acceleration magnitude is `0.25 / 0.1 = 2.5 m/s²`, which violates the declared `0.25 m/s²` limit. The tiny probe was run with the repository Python 3.12/Torch 2.13 environment and printed `ACCEPTED (0.050000000000000044, 0.0)`.

This is reachable through `PhysicalEventTrackArtifact` construction and through the signed event-catalog validation path (`PhysicalEventCatalogEvidence.from_members` → `validate_physical_event_track_artifact`; the catalog-result validator invokes the same check). It can admit physically implausible tracks into association clustering. The smallest theoretically sound direction is to use the exact positive two-sample span `(parsed[index + 2] - parsed[index]).total_seconds() / 2.0` in both checks; strict timestamp ordering already prevents a zero denominator. Add a sub-second regression test. The existing `test_track_rejects_hidden_extreme_segment_speed` only exercises the independent 40 m/s segment-speed guard and does not catch this acceleration defect.

The private uncertainty helpers count the Boolean evaluation mask rather than positive-weight cells (`src/advar/promotion.py:16727-16801` and `16903-16973`). The independent cross-check confirmed that the shipped producer masks already include `quality_weight > 0` before these helpers are called (`src/advar/promotion.py:14181-14223`, `14285-14322`, and `14562-14614`), so this does not inflate current promotion sample gates. It remains a future private-helper input-contract fragility: a new caller that passes zero-weight cells inside its mask could overstate calibration counts. A defensive direction would define counts explicitly from `evaluation_mask & (evaluation_weight > 0)` or document/enforce the positive-weight mask invariant.

## Test-oracle / coverage gaps

The three tests at `tests/test_promotion.py:10723-10878` named for operational range-grid/partition validation call `infer_deployed_neural_prior`, whose current implementation unconditionally raises the frozen scientific-package `OperationalDeploymentUnsupportedError` before examining geometry, coordinates, or partition arguments. Their assertions therefore verify the unsupported-entrypoint restriction, not the named geometry invariants. This is intentional under the current deployment boundary, but those tests should not be counted as coverage for live geometry validation. No live caller currently exists to make this an operational defect.

## Targeted validation

Command (CPU only, one thread):

`OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -m pytest -q tests/test_promotion.py -k 'truncated_tail_score_is_stable_and_differentiable or conditional_pit_replaces_raw_truncated_z_score or quantized_threshold_uses_interval_midpoint_pit or quantized_point_diagnostic_uses_local_detection_limit or quantized_gaussian_upper_tail_has_finite_large_nll or qc_invalid_values_are_model_invariant or operational_domain_uses_publication_cells_as_denominator or brier_preflight_inverts_the_actual_upper_bound or automatic_uncertainty_never_treats_zero_variance_as_certainty or sample_size_preflight_rejects_an_impossible_small_holdout'`

Result: `10 passed, 217 deselected` in 104.60 seconds; 18 existing TorchScript deprecation warnings.

An additional read-only CPU probe reproduced the acceleration finding and was not a formal test. No MPS/CUDA or whole-baseline test run was used.
