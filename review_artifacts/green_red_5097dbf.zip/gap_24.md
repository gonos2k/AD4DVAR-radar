# GREEN bounded review — unit 24

Commit reviewed: `5097dbfd1ddf51483578bef5889ebc809ff024f`.

Scope: `tests/test_nowcast.py:3301-6352` and `tests/test_run_artifact.py:1-1500`, with current implementation context in `src/advar/nowcast.py` and `src/advar/run_artifact.py`. The assigned tests cover growth evidence availability and saturation, conservative remapping and positivity, projected radar-grid geometry and metric uncertainty, forecast issuance closure, provenance/digest contracts, deployment receipt checks, and forecast artifact round trips. No source or test files were modified.

## Findings

### P2 — A current run may retain background data while dropping the whole-background lineage digest

Production path: `ForecastRunContract.validate_integrity` in [nowcast.py:5187](/Users/yhlee/ADVAR/src/advar/nowcast.py:5187) validates `background_frames_digest` only when it is non-`None`, while the latest background tensor and age are checked independently through [nowcast.py:5228](/Users/yhlee/ADVAR/src/advar/nowcast.py:5228) and [nowcast.py:5301](/Users/yhlee/ADVAR/src/advar/nowcast.py:5301). There is no invariant requiring `background_frames_digest` and `latest_background_digest` to be co-present. The durable loader reconstructs these fields independently ([run_artifact.py:1374](/Users/yhlee/ADVAR/src/advar/run_artifact.py:1374), [run_artifact.py:1594](/Users/yhlee/ADVAR/src/advar/run_artifact.py:1594)).

Expected behavior is that a run containing a background tensor has complete background input identity: the whole background cube digest participates in the fixed input context and full analysis input identity. Actual behavior is that a run can contain a valid latest background tensor and `background_age_minutes`, while `background_frames_digest` is `None`; after recomputing the fixed-context, full-analysis-input, and forecast-run identity digests, `ForecastResult.validate_issuance()` accepts the result. This leaves a background-influenced forecast whose durable input lineage omits the source cube identity.

Reproducible CPU probe (current checkout; the probe only changed dataclass fields and recomputed the content digests needed to isolate this contract condition):

```text
frames = 3 x 8 x 8, left half NaN; background = 3 x 8 x 8 at 19 dBZ
nowcast(..., background_age_minutes=0.0)
-> metadata.background_used = True, background_contribution_fraction = 0.5
replace(run, background_frames_digest=None,
        fixed_input_context_digest=<recomputed with background=None>,
        full_analysis_input_digest=<recomputed>)
replace(result, run=<above>, forecast_run_digest=<recomputed>)
tampered.validate_issuance()
-> accepted
```

This is reachable through the current run/artifact validation path; normal construction via `ForecastRunContract.from_inputs` populates both fields, but a durable artifact or direct contract mutation can omit the whole-background digest and still pass all current issuance checks. The assigned round-trip tests verify normal persistence and many digest mismatches, but do not assert the co-presence invariant.

Legacy compatibility matters here. The v42 migration path intentionally permits old artifacts with the current full-context members absent; the added probe confirms a legacy v42 artifact with no whole-background digest still loads as an audit artifact. The check should therefore apply when the current full-context contract is present (the five full-context digests are all populated), while retaining the existing legacy all-absent path. Within current runs, require `background_frames_digest is not None` exactly when `latest_background_digest is not None` (and reject the opposite state). Add a current-contract regression that removes the whole-background digest, recomputes the derived context and run identity digests, and expects issuance/artifact loading to reject it; retain a legacy v42 migration regression to ensure audit compatibility.

## Contract and scientific review

The conservative remapper preserves non-negativity and closes the boundary outflow budget; direct long-lead remapping avoids repeated fractional diffusion. Growth evidence is weighted by advected support, fails closed below support/area thresholds, preserves saturation excess, and does not substitute high motion PSR for missing echo evidence. Current v6 projected-grid gates use directed affine distance, speed, determinant/area, and metric-domain uncertainty intervals; uncertain physical neighborhoods are excluded from certainty consumers. State/forecast issuance recomputes forecast fields and every evidence channel from the issued state, so modified forecast arrays, masks, metadata, or evidence are rejected.

The run-artifact loader preflights ZIP members and NPY headers, rejects unknown/duplicate/path-traversal/encrypted members, verifies the artifact digest, reconstructs typed grid/config/lineage objects, and calls run/result integrity validation. Current deployment tests correctly require terminal activation/commit receipts and bind deployment decisions to exact forecast-run lineage. A lower-priority type-hygiene observation is that several `NowcastConfig` fields in the general numeric tuple accept `True` because `bool` is an `int` in Python (for example `NowcastConfig(recent_weight=True)`); fields with explicit boolean guards reject it. This was not elevated as a primary scientific finding because the accepted value behaves as numeric 1.0 and is outside the intended typed configuration input rather than an untrusted runtime tensor.

## Validation and limits

Environment: `/Users/yhlee/ADVAR/.venv/bin/python` (Python 3.12.13, Torch 2.13), CPU only, `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1`.

* Tiny CPU probe covering empty/low-echo nowcast shape, four-cell fractional remap and mass conservation, current v6 ground-distance footprint partitioning, and NumPy C/F-order artifact digest equality — PASS.
* [gap_24_probes.py](/tmp/advar-green-red-5097dbf/gap_24_probes.py) — PASS: the current generated result accepted the omitted digest, while a legacy v42 artifact with absent full-context members loaded successfully as audit data. Captured output is in [gap_24_probes.stdout](/tmp/advar-green-red-5097dbf/gap_24_probes.stdout).
* No full baseline or MPS/CUDA tests were run, per the bounded-review instruction. No source fixes or commits were made.

## Caller trace

`nowcast()` builds a `ForecastRunContract` from the full observation/background inputs, then `forecast_from_state()` and `ForecastResult.validate_issuance()` invoke run integrity and forecast closure checks. `forecast_run_arrays()` serializes both `background_frames_digest` and the latest-background fields; `load_forecast_run()` reconstructs them independently, verifies the artifact digest, rebuilds the run, and calls `result.validate_issuance()`. The missing cross-field invariant therefore applies to both direct issuance validation and durable artifact loading.
