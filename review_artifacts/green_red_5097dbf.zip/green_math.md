# GREEN mathematics review

Commit reviewed: `5097dbfd1ddf51483578bef5889ebc809ff024f0`.

This is a read-only review. No repository files or git state were modified. The
requested Luna child delegation was unavailable in this agent context (no
collaboration tool was exposed), so this report records the ranges actually
read rather than claiming uninspected modules were complete. CPU only was used;
MPS probing remains with the root agent.

## Mathematical conclusions

The core physical and adjoint constructions are internally consistent under
their stated contracts.

* `physics.py:47-57` implements the monotone dBZ/linear-echo pair using
  `expm1`/`log1p`; the floor makes the inverse finite at zero. The bilinear
  remap (`physics.py:137-181`) has nonnegative weights that sum to one for an
  interior sample. Zero padding deliberately represents outflow at the edge,
  so global mass conservation is not an invariant; the transport audit must
  account for that lost boundary mass. `shift_zero` uses a clone before
  zeroing, preserving the source value and VJP behavior.
* The common-bias whitener read in `variational.py:4575-5084` is the symmetric
  inverse square root of `I + sigma^2 A A^T`: the rank-one eigenvalue factor is
  `1/sqrt(1+lambda)`, with the zero limit handled as `-1/2` for the correction.
  Residual whitening and the pseudo-Huber expression in
  `variational.py:6088-6125` have the expected units and stable
  `hypot`/`softplus` forms. The low-rank eigendecomposition is frozen/detached
  in the production path; its repeated-eigenvalue AD behavior is therefore
  outside the accepted derivative contract (also reported by RED as a
  non-production helper issue).
* `matrix_free.py:115-185` uses max-scaled inner products and norms, and
  `matrix_free.py:190-388` recomputes the true residual before declaring PCG
  convergence. For a symmetric positive-definite Gauss--Newton operator and a
  compatible preconditioner, the JVP/VJP normal product and PCG stopping logic
  are correct. The separate raw objective reduction can overflow at extreme
  finite float32 inputs; this is recorded by RED numerical review, not counted
  as a new GREEN finding.
* The EFSO algebra in `ensemble_sensitivity.py:400-615` is consistent with a
  centered sample covariance: cross-projection is divided by `K-1`, and the
  leave-one-out mean uses `(sum - K/(K-1)*member)/(K-2)`. The resulting
  jackknife factor `sqrt((K-1)/K)` is correct for `K >= 3`. Centering checks in
  `ensemble_sensitivity.py:756-764` are correctly restricted to float32/64 and
  scaled by component magnitude.
* Range geometry in `range_geometry.py:1-607` uses projected Euclidean metric
  distance, strict radial edge ordering, half-open bands except for the last
  closed band, and a `-1` source sentinel that is masked before distance
  indexing. The partition evidence therefore has disjoint, complete coverage
  on the valid grid domain. Calibration identity/period canonicalization in
  `calibration.py:1-804` is deterministic and enforces positive case counts
  and finite metric thresholds.
* The variational trajectory and the nowcast slice-remap convention agree in
  the read ranges (`variational.py:4428-4622`; nowcast comparison was read at
  `nowcast.py:9597-9627`). For the frozen active branch, the adjoint equation
  is `H lambda = dS/dc`, with observation parameter derivative `-lambda^T
  (dg/dp)` plus direct score terms. The detected and censored scales in
  `sensitivity.py:15037-15901` have this sign. In particular, for
  `r = delta*softplus((p-L)/delta)`, `dr/dL = -sigmoid`, yielding the code's
  `sigmoid + (r/delta)*(1-sigmoid)` cross scale.

## Confirmed finding

### Low — CSI accepts invalid thresholds and can return a perfect score

Location: `src/advar/metrics.py:23-39`.

`critical_success_index` validates the forecast/truth tensors but never checks
that `threshold_dbz` is finite. With `forecast=[40]`, `truth=[0]`, and a NaN
threshold, both event masks are false, the denominator is zero, and the
function returns `1.0`. Positive infinity has the same result. This violates
the metric's threshold-exceedance meaning: an invalid threshold must be
rejected, rather than converted into the no-events convention. A finite scalar
check (and a regression test for NaN/Inf) is sufficient; ordinary finite
threshold behavior remains unchanged.

## Adjudicated non-finding: publication active-set distance

`src/advar/sensitivity.py:11082-11130` intentionally computes the absolute
distance to each fixed publication boundary. The FSO code freezes the issued
domain through `_metric_domain_weight` (`sensitivity.py:10838-10865`), while
`ForecastResult.valid_mask` is produced by the same support/confidence
predicates (`nowcast.py:9858-9886`). An excluded cell with support far below a
lower threshold is a stable excluded active-set member; it must not be rejected
merely because its signed feasibility slack is negative. The relevant local
condition is distance from either side of the boundary, so `abs` is correct.
The partial-mask scalar example considered during review does not produce a
public FSO counterexample. The margin is therefore retained as a valid
active-set-distance diagnostic, not reported as a defect.

## Validation

Commands run with `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1`:

* `PYTHONPATH=src python -m pytest -q tests/test_metrics.py` — **3 passed**.
* A direct probe of `critical_success_index` returned `1.0` for both NaN and
  +Inf thresholds and `0.0` for the same data at threshold 35.0, reproducing
  the finding.
* The requested numerical/PCG/shift test collection under the default
  launcher used Python 3.9 and failed during collection because the package
  requires Python >=3.10 and `matrix_free.py` uses `Real | float`; the
  Python-3.10 launcher then lacked `pygments`. No full baseline suite was run.

The known active affine componentwise overflow limitation documented in
`NUMERICAL_REVIEW_CHECKLIST.md` was reviewed and deliberately not reported as
new. The prior centered-check, scaled radial norm, and crop-first/offscreen
clone fixes were verified in the ranges listed in the coverage artifact.
