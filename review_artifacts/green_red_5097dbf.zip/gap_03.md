# GREEN bounded review — unit 3

Repository: `/Users/yhlee/ADVAR`  
Scope: `src/advar/ledger.py:10001-15000` (baseline `5097dbfd1ddf51483578bef5889ebc809ff0240`).

I read every line in the assigned range in bounded `sed` reads. Context read outside the range covered the product validators and constructors in `src/advar/promotion.py`, the replay/tensor helpers and trust-activation helpers in `src/advar/ledger.py`, and relevant ledger/promotion tests. No source files were changed. No full baseline tests were run; no MPS/CUDA was used.

## Contract conditions checked

* Prepared analysis provenance may become active only after immutable bytes, raw receipts, processor authority, derived tensors, raw-resolution history/registry side effects, the ledger instance, signed preparation receipt, deadline ordering, and the same raw-ingestor trust snapshot all independently replay.
* Operational raw-resolution history is append-only per slot. Sequence numbers, previous-entry digests, transition labels, authority binding, canonical times, and legacy-anchor preimages must agree.
* A scoring replay bundle must contain product-owned semantic cases, one exact preregistered holdout input artifact, one registry chain, current raw trust, deterministic CPU/runtime/source lineage, complete tensor shards, and replayable evaluation/verification provenance.
* Trusted process receipts and promotion/deployment certificates must preserve the signed process/artifact chain and distinct authority roles, with current trust and deadline/chronology checks.
* Operational deployment publication is failure-atomic and must bind the decision to current provenance, runtime activation, release approval, ledger chain, and current trust snapshots.

## Unconfirmed hypothesis (staging-only unless a two-plan integration fixture is supplied)

### H-01 — scoring replay append does not bind the input artifact to the replay cases' holdout plan

**Disposition:** Unconfirmed as a reportable deployment defect. The append method has a real missing local equality check, but I did not run a full two-plan fixture; downstream promotion validation blocks the mismatched row from becoming promotion/deployment evidence.

**Location:** `src/advar/ledger.py:11631-11634`, `11735-11739`, `11983-11996`, and `11998-12008`.

`append_neural_prior_scoring_replay_bundle` derives `plan` solely from `ordered_cases[0].plan` and checks that all replay cases share that plan. It checks the supplied `HoldoutScoringInputArtifact` only for a self-consistent digest and equal `ordered_case_ids`; it never checks `scoring_input_artifact.holdout_plan_digest == plan.plan_digest`. During the durable commit it looks up the scoring-input row by artifact digest alone and accepts any candidate-scoring start receipt whose subject list contains that digest. The SQL lookup also omits `holdout_plan_digest`, and the start query omits the catalog/plan identity.

The constructive pair is: a valid `HoldoutScoringInputArtifact` from plan A and valid `ScoringReplayCaseArtifact` products from plan B, where A and B use the same ordered case IDs. Their product factories are independent; the append method recomputes B, writes a semantic replay manifest whose `scoring_input_artifact_digest` points to A, and can satisfy its SQL checks with A's registered row and scoring-start subject. The static proof is saved at `/tmp/advar-green-red-5097dbf/gap_03_plan_binding_proof.py` and its stdout. A full integration fixture was not run, so this remains a caller-trace hypothesis rather than a reproduced acceptance.

Caller trace closes the deployment path: `append_trusted_process_start_receipt` does require `scoring_input_artifact.holdout_plan_digest == plan.plan_digest` at lines 12604–12609; completion only links replay manifest to the supplied scoring artifact at lines 12847–12852; then `compute_neural_prior_promotion` calls `validate_holdout_scoring_artifact`, whose checks bind the scoring artifact/input/start to the plan, and `load_neural_prior_promotion` repeats that validation before any deployment certificate can be issued. Thus the proven impact is limited to a potentially malformed intermediate replay row.

**Smallest sound direction if confirmed:** require the exact plan binding before any filesystem work (`scoring_input_artifact.holdout_plan_digest == plan.plan_digest`), and include `AND holdout_plan_digest = ?` in the row lookup. Also require the selected scoring-start row to have the same catalog/holdout plan digest as `plan.plan_digest` (rather than checking only process kind and subject digest).

## Hypotheses not promoted to findings

* `operational_raw_resolution_predecessor` does not walk the entire history chain when returning an existing tail. This only matters after external database corruption; `load_operational_raw_resolution_history` and append-time validation do walk/validate the chain, and the schema has immutability triggers.
* `append_neural_prior_holdout_scoring_input_artifact` checks case-ID set equality but not uniqueness. The current `HoldoutScoringInputArtifact.from_cases` validator has the same omission, while the current replay manifest constructor rejects duplicate case IDs before a replay bundle is committed. This is a malformed-input staging gap, not evidence of a reachable promotion/deployment bypass in this range.
* Public replay loading retains an activated historical raw-trust snapshot after a later trust-store change because it has no trust-store path; promotion/completion/certificate/operational-decision paths recheck current raw trust before using evidence. Historical audit loading appears intentional.

## Verification

Read-only static review only. No source or database mutation, no full baseline test, and no MPS/CUDA execution. No formal test command was needed; M-01 follows directly from the actual plan/artifact checks and SQL predicates listed above.
