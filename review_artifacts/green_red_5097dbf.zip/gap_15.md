# GREEN/RED review unit 15

## Scope and method

Reviewed every line of `tests/test_promotion.py:5001-10000`, including the
semantic replay construction and mutation checks, legacy replay-generation
decoders, uncertainty/state target identity checks, input-plan resolution
check, the independent-material promotion fixture, and the durable replay
round trip. Related production paths were read in `src/advar/promotion.py`,
`src/advar/ledger.py`, `src/advar/nowcast.py`, `src/advar/sensitivity.py`, and
`src/advar/variational.py` (see coverage JSON).

The mathematical contracts are coherent where exercised: replay stores a
single product-owned tensor snapshot; current replay reconstructs raw and
source-composed verification lineage before optional semantic recomputation;
uncertainty targets are bound to a planned source/time/error contract; and
promotion counts material cases by physical-event cluster. Legacy v1-v24
manifests are explicitly audit-only, which is consistent with the loader's
current branch and the tests' expected failures.

## GREEN: strengths and conditions

* `ScoringReplayCaseArtifact.from_products` requires exact shipped product
  types, validates forecast/run and target lineage, freezes tensors, and
  rechecks live tensors against that snapshot. The tests cover constructor
  denial, several type substitutions, forecast mutation after digest
  replacement, time-resolved quality/background shape, and raw-input/run
  disagreement.
* Current replay loading verifies shard/member checksums, tensor records,
  raw provenance, source-composed verification provenance, and then compares
  semantic case tensors and recomputed evaluation digests. The durable test
  exercises post-commit activation recovery, source/runtime mismatch status,
  forecast and provenance attacks, shard swap/removal/addition, and final
  promotion-certificate lineage.
* Target construction rejects a wrong radar source, legacy measurement source,
  wrong observation-error plan, and a post-construction identity mutation.
  `_validate_input_plan_resolution` is checked for all four operational
  identity fields it owns (radar product, background cycle, mask policy, and
  QC pipeline), plus grid/time identity.
* Legacy replay generations are decoded as typed audit artifacts and are
  prevented from semantic replay. This is an intentional compatibility
  boundary, not a current-operation regression.

## RED: investigated candidate, no production defect

A CPU probe showed that `ForecastRunContract` accepts a NaN background and a
background with a different dtype. This is intentional repository behavior:
missing backgrounds are normalized by the preparation path, background input
is converted to the frame dtype/device before model use, and the raw input is
digested independently. The acceptance therefore is not reported as a bug.
The scoped background test correctly covers the unsupported shape case
(`tests/test_promotion.py:5171-5191`).

## RED: test-strength limitation (not a production finding)

`test_scoring_replay_reproduces_evaluation_digest`
(`tests/test_promotion.py:8993-10000`) patches
`PriorHoldoutEvaluation.from_forecasts` to return the already-created
evaluation by case. Within this scoped test that checks the replay protocol,
the final digest equality is therefore not an independent numerical oracle.
This is recorded as a test-strength limitation only; independent metric
oracles may be covered elsewhere in the repository.

`test_promotes_only_independent_material_holdout_cases` is a positive fixture
with permissive thresholds. It establishes the eligible path for two distinct
synthetic events, but does not probe duplicate physical-event clusters,
duplicate storms/days, a harmful score, or an unapproved classifier lineage.

## Validation

Environment: `/Users/yhlee/ADVAR/.venv/bin/python` (Python 3.12.13,
Torch 2.13), CPU only, `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1`.

* 13 scoped tests (legacy generations, semantic replay integrity, target/input
  identity, and positive promotion): **13 passed**, 214 deselected, 315.76 s.
* `test_scoring_replay_reproduces_evaluation_digest`: **1 passed**, 226
  deselected, 71.06 s.
* Tiny background-input probe: **reproduced acceptance** of NaN and float64
  background tensors; no source was changed.

No MPS/CUDA, full baseline, source fix, or commit was performed.
