# GREEN/RED review unit 09

Scope: `src/advar/promotion.py:15001-20000` at baseline `5097dbfd1ddf51483578bef5889ebc809ff024f0`. The complete assigned range was read in 300-line (final 200-line) numbered chunks. Caller and contract context was read for `PriorHoldoutEvaluation.from_forecasts`, `ScoringReplayCaseArtifact`, the Gaussian score helpers, `MetricSupportContract`, sample-size preflight, and the current scoring path.

## GREEN findings

The semantic replay artifact freezes detached tensor snapshots, revalidates the source-derived analysis inputs, target digests, raw-slot receipts, global resolution, classifier execution, forecast-run input digests, and live tensor digests before recomputation. The replay path therefore has a coherent immutability and lineage contract under ordinary product construction.

The probability scores use interval likelihoods for quantized dBZ. `_quantized_bin_bounds` makes the threshold cell a half-open detected-support interval and subsequent lattice cells disjoint; the current tests cover the partition and local detection-limit cases. `_truncated_gaussian_diagnostics` computes the conditional interval probability by dividing the Gaussian interval mass by the lower-tail survival probability. Its midpoint PIT is the probability midpoint of that same conditional interval, so the current tail formula is mathematically consistent. The already-applied right-tail reflection in `_standard_normal_log_interval_mass` gives finite values and gradients for ordinary extreme tails; the targeted numerical tests pass.

The prior and state score callers construct paired domains from the same target mask and nonnegative metric weights. Echo intensity is scored only on support events, while support Brier and false-support terms use the full applicable domain. Range component counts are physical pixel/object counts, and unavailable components are omitted consistently.

Metric support contracts are derived from the shipped metric definitions: FSS is bounded by one, log-echo MSE uses the configured dBZ range, and projected centroid error uses the full affine-grid diameter. Production promotion checks the support digest against the exact forecast run, grid, and metric engine before applying bounds.

## RED finding: finite-positive scale contract admits nonfinite interval scores

Severity: P2 (medium robustness; a valid typed prior output can abort holdout scoring).

Reachable path: `variational.py:1973-1984` and `variational.py:2936-2942` accept every finite positive probability-head `truncated_scale_dbz` (the current validation has no upper bound), and `promotion.py:2944-2953` accepts every finite positive `reflectivity_resolution_dbz` in `PriorUncertaintyTargetPlan`. The current production caller `promotion.py:14205-14230` calls `_prior_uncertainty_scores` for the candidate and parent, which reaches `_truncated_gaussian_diagnostics` at `promotion.py:16921-16929` on every echo target.

Expected contract: for finite location, finite positive scale, a finite positive quantization width, and a reference in detected support, the interval probability is strictly positive and its NLL/PIT should either be evaluated stably or be rejected by an explicit numeric-domain contract. Actual behavior at `promotion.py:16449-16472`: `_standard_normal_log_interval_mass` evaluates `log(exp(a)-exp(b))`; when the standardized interval is below float64 resolution, both log-CDF values round equal and `_logdiffexp` returns `-inf`. `_truncated_gaussian_diagnostics` at `promotion.py:16817-16872` then raises `ValueError("truncated-Gaussian score is not finite")`.

Reproduction (CPU, current code; no source changes):

```text
app.truncated_location_dbz = tensor([0.], float64)
app.truncated_scale_dbz    = tensor([1e16], float64)
reference                  = tensor([5.], float64)
support_threshold_dbz      = 0.0
reflectivity_resolution_dbz = 0.5  # the normal default
_prior_uncertainty_scores(...) -> ValueError: truncated-Gaussian score is not finite
```

The direct helper also fails with a tiny but finite interval around zero (`lower=-1e-300`, `upper=1e-300`), returning `-inf` log mass. The default physical resolution is enough to trigger the failure through a sufficiently large valid predicted scale, so this is not limited to an exotic quantization plan. Existing validation only checks `scale > 0`, finite, and `resolution > 0`; it does not establish a lower standardized-bin-width or upper scale condition.

Smallest theoretically sound direction: either add and seal explicit physical/numeric bounds on probability scale and quantization resolution (with a clear rejection before scoring), or implement a relative/asymptotic interval-mass calculation for narrow standardized intervals and retain the existing finite-score check. Add regression tests at the first failing scale and for the truncation denominator. Silently replacing the interval mass by zero or merely clamping the resulting NLL would violate the likelihood contract.

## Hypotheses checked but not promoted to defects

`MetricSupportContract.from_run` trusts its caller-provided `grid_shape` instead of comparing it to `run.grid_time_contract.grid_shape_yx`; a direct caller can therefore request support for a different rectangle. The current promotion caller passes the validated input-frame shape, and `ForecastRunContract.from_inputs` validates that shape against the grid, so I found no reachable current promotion bug. This should be hardened if the factory is intended as a standalone public constructor.

The artifact validators contain ordinary Python type looseness for a few boolean/count fields and do not rehash every nested product in `ScoringReplayCaseArtifact.from_products`; normal constructors and the subsequent exact product/reproduction checks close the current caller path. I found no falsifiable ordinary-construction bypass in this range.

## Validation

Environment: `/Users/yhlee/ADVAR/.venv/bin/python` (Python 3.12.13, Torch 2.13), CPU only, `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1`. Targeted tests: `tests/test_numerical_review.py` tail/interval-gradient cases and `tests/test_promotion.py` quantized/truncated interval cases: **3 passed, 238 deselected**. The custom CPU probe above reproduced the scale-boundary failure. No source files, commits, baseline tests, MPS, or CUDA were used.
