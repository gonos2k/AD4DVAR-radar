# GREEN/RED review unit 22

Scope: `src/advar/nowcast.py:6443-10518` at baseline `5097dbfd1ddf51483578bef5889ebc809ff024f`. The complete assigned range was read as bounded numbered chunks: 6443-6742, 6743-6842, 6843-7142, 7143-7442, 7443-7742, 7743-8042, 8043-8342, 8343-8642, 8643-8942, 8943-9242, 9243-9542, 9543-9842, 9843-10142, 10143-10442, and 10443-10518. Contract and caller context was read for the state/metadata dataclasses, grid/time affine, configuration, remap/physical echo primitives, and the targeted nowcast tests.

## GREEN findings

`ForecastResult` exposes grid velocity in `(y,x)` metres per step and projected velocity through the authoritative affine contract. The forecast recurrence uses the same displacement and geometrically decaying log-growth sum in `_forecast_linear_at_step_core` and `_forecast_fields_from_state`; the positivity boundary is checked before dBZ conversion. The current-state merge gives the latest direct observation priority and only fills missing support from transported older sources. Direct state verification is kept separate from path verification, so a transported historical echo does not become a direct radar observation.

The tendency estimator normalizes two-frame and long (0-to-2) shifts by their frame span. Pair conflict selection is explicit, and the uncertainty multipliers increase for persistence, single-pair, weak-PSR, and aged-background paths. Physical motion limits and physical pair footprints are routed through the grid/time affine; completeness uses the possible footprint while support verification uses the certain footprint, which is the conservative direction for their respective predicates.

The forecast contract checks tensor shape/dtype, finite state and support ranges, source-support decomposition, nested verified supports, motion/growth pair provenance, background-age lineage, and exact closure of the issued forecast/evidence against the state. The targeted tests below passed, including partial observations, missing-middle normalization, path verification, pair conflicts, uncertainty, physical PSR, and issuance closure.

## RED finding: floating-point input validator admits CPU float16 but the live moving-echo path aborts in FFT

Severity: P3 (input-contract robustness; the accepted input type fails with a backend RuntimeError instead of a deterministic contract error).

`_validate_frames` (10405-10411) accepts any `is_floating_point()` tensor, while the issued forecast contract only permits float32/float64 (6450-6454). For a moving float16 echo, the current reachable path reaches `_phase_correlation_details` and `torch.fft.fft2`, which does not support CPU Half. A tiny CPU probe with a `(3,32,32)` float16 tensor at 20 dBZ in locations `(16+s,16)` produced `RuntimeError: Unsupported dtype Half`; the same input in float32 completed and estimated the motion. This is a real mismatch between the input validator and the actual supported numerical domain, although it is not a high-severity scientific error.

Smallest direction: either reject dtypes other than float32/float64 in `_validate_frames` with a clear `TypeError`, or explicitly upcast supported lower-precision inputs before all physical/FFT calculations and seal the resulting output dtype contract. A regression should assert deterministic behavior for float16.

## Hypotheses checked but not promoted

I initially suspected that `_actual_state_path_provenance` should symmetrically relabel a `BLENDED` path as `EARLIER` when only source 0 contributes. That is a false positive: `_adjacent_source_paths` transports source 0 using the cumulative earlier and recent displacements (lines 7895-7915), so source 0 genuinely depends on both pair intervals even when source 1 has no echo at the destination. The existing recent-only relabel is correct because source 1's path uses only the recent interval. The use of independent source paths for current-state reconstruction can also differ from the selected future tendency (for example, direction-turn data). This is intentional: the current state is reconstructed from each source's own measured path, while the selected tendency controls the future recurrence; the targeted direction-turn test exercises that distinction.

`prepare_input` marks an all-missing observation with a latest-frame background as `STALE_BACKGROUND`, while older-only background is `UNAVAILABLE`; the targeted tests cover both and match the latest-source contract. Physical PSR uncertainty, remap support, positivity, and the forecast growth recurrence showed no additional falsifiable violation. Empty CSI and publication absolute-distance behavior were treated as the known conventions requested by the review instructions.

## Validation

Environment: `/Users/yhlee/ADVAR/.venv/bin/python` (Python 3.12.13, Torch 2.13), CPU only, `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1`. Targeted command:

```text
OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -m pytest -q tests/test_nowcast.py -k 'missing_pixel or all_missing or stale_background or conflicting_pairs or growth_disagreement or forecast_evidence or issuance or phase_correlation or local_motion or source_path or middle_missing or long_pair' --disable-warnings --maxfail=1
22 passed, 145 deselected, 27 subtests passed in 1.38s
```

The custom CPU probe reproduced the float16 observation above. No source files, commits, full baseline tests, MPS, or CUDA were used.
