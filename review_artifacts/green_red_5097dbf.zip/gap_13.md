# GREEN / RED bounded review — unit 13

Baseline: `5097dbfd1ddf51483578bef5889ebc809ff024f0`.

Scope: `tests/test_ledger.py:5001-5909`; boundary context `4671-5000` was
also read because the assigned range continues a schema test. The current
`EpisodeLedger` append/verify/migration paths, SQLite triggers, certificate
chain caller, and operational provenance caller were traced. No repository
source files were changed.

## Finding

**P2 — the evidence validator accepts malformed non-finite values on a
caller-supplied snapshot.**

- `EpisodeLedger.append()` calls `_validate_m0_snapshot()` at
  [ledger.py:4962](/Users/yhlee/ADVAR/src/advar/ledger.py:4962). Evidence
  handling is at [ledger.py:22004](/Users/yhlee/ADVAR/src/advar/ledger.py:22004).
- The range check only examines `value[finite]`. For an available cell, a NaN
  or infinity is excluded from both the `[0, 1]` check and
  `joint_evidence_available`, so closure is skipped for that cell. The other
  finite channels may consequently disagree without rejection.
- Repro on the current checkout: clone the normal test snapshot, set
  `path_evidence_by_metric[0, 0] = NaN`, construct the normal episode, and
  call `EpisodeLedger.append()`. It succeeds; `ledger.verify()` and default
  `ledger.load()` also succeed, returning NaN while
  `metric_available[0, 0]` is true.
- This is a malformed partial tuple, distinct from the intentional all-NaN
  representation when `_metric_evidence_ratios()` has no usable denominator.
  The current producer initializes all four evidence channels together and
  writes all four together ([sensitivity.py:12572](/Users/yhlee/ADVAR/src/advar/sensitivity.py:12572),
  [sensitivity.py:12720](/Users/yhlee/ADVAR/src/advar/sensitivity.py:12720)).
  Thus no normal producer fault was demonstrated; this is a fail-closed
  validation gap for malformed caller input. Unit 5 independently reproduced
  the corresponding durable `Inf` path and records its exact probe output in
  [gap_05_probes.stdout.json](/tmp/advar-green-red-5097dbf/gap_05_probes.stdout.json).
- Smallest sound direction: validate each available cell as either a complete
  finite four-channel tuple in `[0, 1]` that closes, or a complete all-NaN
  unsupported tuple; reject infinities and mixed finite/non-finite tuples.
  Add NaN and Inf regressions to the malformed-snapshot test.

## GREEN contract review

The bounded tests cover schema 3–15 legacy loading, current array layouts,
duplicate/traversal rejection, file-set and checksum verification, run
identity separation from model contract hashes, tensor ownership, same-ID
append serialization, certificate-chain serialization, scalar-impact
migration, signed raw-resolution transitions, and prepared immutable
provenance rows. The source invariants include finite available forecast and
sensitivity data, direct-map/norm consistency, evidence closure, and
fail-closed baseline/reward lineage. The evidence finite-mask gap above was
the only confirmed counterexample.

## Validation and limits

Using Python 3.12.13 / Torch 2.13.0 from `.venv`, CPU only, with
`OMP_NUM_THREADS=1 MKL_NUM_THREADS=1`: 15 assigned-range tests passed in
2.68 s; five schema/identity tests passed in 2.96 s. The NaN probe accepted,
verified, and loaded the malformed episode; the analogous Inf probe was also
accepted. No full baseline suite, MPS/CUDA,
source edit, or commit was done.

The certificate test mirrors the production chain SQL but does not execute the
full promotion preimage/signature workflow. The raw-history test calls the
private append helper rather than a complete operational artifact commit, and
prepared SQL coverage does not exercise every activation/expiry transition.
These are coverage limits, not additional defects.
