"""Rerunnable CPU probes for GREEN/RED review unit 7.

This script performs no filesystem or ledger writes.  It reports JSON so the
review evidence can be rerun with the pinned project interpreter.
"""

from __future__ import annotations

import json
import sys
from datetime import datetime

import advar.promotion as promotion
import torch
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey


def _parse(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def acceleration_probe() -> dict[str, object]:
    # The adjacent segment speeds are 0 and 0.1 m/s.  Their midpoint spacing
    # is 0.1 s, so the physical acceleration is 1 m/s^2, above the stated
    # 0.25 m/s^2 contract.  The implementation clamps this duration to 1 s.
    timestamps = (
        "2026-08-10T00:00:00Z",
        "2026-08-10T00:00:00.1Z",
        "2026-08-10T00:00:00.2Z",
    )
    centroids = ((0.0, 0.0), (0.0, 0.0), (0.01, 0.0))
    constructor_args = {
        "timestamps": list(timestamps),
        "centroid_xy_m": [list(point) for point in centroids],
        "object_mask_digests": ["d" * 64] * 3,
        "source_radar_ids": ["radar-a"] * 3,
        "association_edge_digests": ["1" * 64, "2" * 64],
        "spatial_reference_digest": "7" * 64,
    }
    parsed = tuple(_parse(value) for value in timestamps)
    segment_durations = tuple(
        (second - first).total_seconds()
        for first, second in zip(parsed[:-1], parsed[1:], strict=True)
    )
    segment_velocities = tuple(
        (centroids[index + 1][0] - centroids[index][0])
        / segment_durations[index]
        for index in range(len(segment_durations))
    )
    midpoint_duration = (parsed[2] - parsed[0]).total_seconds() / 2.0
    true_acceleration = abs(segment_velocities[1] - segment_velocities[0]) / midpoint_duration
    implementation_denominator = max(1.0, midpoint_duration)
    implementation_acceleration = abs(
        segment_velocities[1] - segment_velocities[0]
    ) / implementation_denominator
    try:
        track = promotion.PhysicalEventTrackArtifact(
            timestamps=timestamps,
            centroid_xy_m=centroids,
            object_mask_digests=("d" * 64,) * 3,
            source_radar_ids=("radar-a",) * 3,
            association_edge_digests=("1" * 64, "2" * 64),
            spatial_reference_digest="7" * 64,
        )
        accepted = True
        error = None
        canonical_timestamps = list(track.timestamps)
        terminal_velocity = list(track.terminal_velocity_xy_mps)
    except Exception as exc:  # pragma: no cover - evidence capture path
        accepted = False
        error = f"{type(exc).__name__}: {exc}"
        canonical_timestamps = None
        terminal_velocity = None
    return {
        "probe": "physical_track_acceleration",
        "constructor_args": constructor_args,
        "canonical_timestamps": canonical_timestamps,
        "segment_durations_seconds": list(segment_durations),
        "segment_x_velocities_mps": list(segment_velocities),
        "midpoint_duration_seconds": midpoint_duration,
        "true_acceleration_mps2": true_acceleration,
        "implementation_denominator_seconds": implementation_denominator,
        "implementation_acceleration_mps2": implementation_acceleration,
        "stated_limit_mps2": 0.25,
        "constructor_accepted": accepted,
        "terminal_velocity_xy_mps": terminal_velocity,
        "error": error,
    }


def malformed_reference_probe() -> dict[str, object]:
    key = Ed25519PrivateKey.from_private_bytes(b"\x31" * 32)
    plan = promotion.RegimeReferencePlan(
        case_id="case-1",
        labeler_id="labeler",
        labeler_public_key_hex=promotion.regime_reference_public_key_hex(key),
        source_contract_digest="1" * 64,
        labeling_valid_time="2026-01-01T00:00:00Z",
        adjudication_policy_digest="2" * 64,
    )
    # This is the shape accepted by the current ledger decoder's
    # _new_regime_reference_evidence path.  The key signs exactly what is
    # retained, so the result tests schema validation rather than forgery.
    values: dict[str, object] = {
        "reference_plan_digest": plan.plan_digest,
        "full_analysis_input_digest": "not-a-digest",
        "verification_bundle_digest": "also-not-a-digest",
        "observed_regime": "",
        "observed_storm_id": "",
        "labeler_id": plan.labeler_id,
        "labeled_at": "2026-01-01T00:00:00Z",
        "labeler_signature": "",
        "contract": "neural-prior-regime-reference-evidence-v1",
    }
    values["labeler_signature"] = key.sign(
        promotion.json_digest(values).encode("ascii")
    ).hex()
    evidence = promotion._new_regime_reference_evidence(**values)
    try:
        promotion.validate_regime_reference_evidence(evidence, plan)
        validator_accepted = True
        validator_error = None
    except Exception as exc:  # pragma: no cover - evidence capture path
        validator_accepted = False
        validator_error = f"{type(exc).__name__}: {exc}"
    return {
        "probe": "malformed_signed_regime_reference_schema",
        "plan_constructor_args": {
            "case_id": plan.case_id,
            "labeler_id": plan.labeler_id,
            "labeler_public_key_hex": plan.labeler_public_key_hex,
            "source_contract_digest": plan.source_contract_digest,
            "labeling_valid_time": plan.labeling_valid_time,
            "adjudication_policy_digest": plan.adjudication_policy_digest,
        },
        "payload_signed_by_preregistered_key": values,
        "decoded_via_current_ledger_helper": "_new_regime_reference_evidence",
        "validator_accepted": validator_accepted,
        "validator_error": validator_error,
        "promotion_bypass_demonstrated": False,
        "promotion_bypass_reason": (
            "This probe exercises the decoder helper and standalone validator only; "
            "it does not construct a full typed candidate manifest. Normal candidate "
            "case consistency and promotion-time validation were not bypassed."
        ),
    }


def main() -> None:
    result = {
        "environment": {
            "python": sys.version.split()[0],
            "torch": torch.__version__,
            "device": "CPU only",
            "thread_env": "OMP_NUM_THREADS=1 MKL_NUM_THREADS=1",
        },
        "probes": [acceleration_probe(), malformed_reference_probe()],
    }
    print(json.dumps(result, sort_keys=True, separators=(",", ":")))


if __name__ == "__main__":
    main()
