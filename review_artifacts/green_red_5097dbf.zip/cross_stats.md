# Statistical cross-check: gap 10 / gap 16

Baseline: `5097dbfd1ddf51483578bef5889ebc809ff024f`.

This was a read-only cross-check. No source or git files were changed. The
three candidate observations were traced through all current callers found by
`rg`, then checked with small CPU probes using
`/Users/yhlee/ADVAR/.venv/bin/python` (Torch 2.13, one thread).

## (a) Zero-weight cells and calibration counts: not reachable through the live scorer

The helper functions do count the Boolean mask rather than positive-weight
cells:

* `promotion.py:16727-16801` counts `echo_mask`, `clear_mask`, and
  `evaluation_mask`.
* `promotion.py:16903-16973` does the analogous prior uncertainty counts.

That observation is real for direct calls to these private helpers. A two-cell
direct probe with weights `[1.0, 0.0]` and both cells in the mask returns count
2. However, every production call from `PriorHoldoutEvaluation.from_forecasts`
first constructs the evaluation mask with strictly positive quality weight:

* `promotion.py:14181-14223`: `prior_valid` includes `(prior_weight > 0.0)`;
  the score mask is `prior_valid` and the score weight is zeroed outside it.
* `promotion.py:14285-14322`: `state_valid` includes `(state_weight > 0.0)`.
* `promotion.py:14562-14614`: range-band masks are subsets of those already
  filtered masks; their weights are zeroed only outside the filtered domain.

The live promotion gates consume the resulting counts at
`promotion.py:21513-21515`, `21545-21579`, and the evidence fields at
`15136-15194`. The direct helper's inflated-count behavior therefore cannot
inflate current calibration sample gates through the shipped caller. This is a
**non-finding** for the current production path. It remains a private-helper
input-contract fragility: future callers must preserve the positive-weight
mask invariant, or the count should be defined explicitly as
`evaluation_mask & (evaluation_weight > 0)`.

Probe results:

```text
direct-mask-count 2 0
production-style-positive-mask-count 1 0
state direct-mask-counts 2 2 0
state production-style-positive-mask-counts 1 1 0
```

## (b) Automatic metric-cell bounded UCB is still blocked by bootstrap resolution

This is a **confirmed P2 false-negative / availability defect**.

`compute_neural_prior_promotion` computes one metric-cell bootstrap diagnostic at
`promotion.py:22261-22275`, regardless of inference mode. Each metric cell then
requires `metric_cell_tail_ok` at `promotion.py:22586-22596`, before it reaches
the bounded empirical-Bernstein calculation at `22598-22629`.

In automatic mode, `allow_shadow_small_sample_bootstrap=False` by default
(`promotion.py:18373-18384`), and the metric-cell calculation is the bounded
path. `_bounded_event_mean_upper_bound` (`promotion.py:20879-20917`) consumes
bounded event values, event clusters, variance, support, and family-adjusted
alpha; it does not consume bootstrap replicates. Therefore bootstrap tail
resolution is an unrelated gate on this branch.

The rejection is reachable before deployment eligibility is assembled: the
metric-cell completeness flag becomes false, so the corresponding range group
cannot be certified (`promotion.py:22790-22895`), and deployment eligibility
requires certified groups (`promotion.py:22923-23032`, especially the final
`deployment_eligible` construction at `23225-23232`).

Independent probe with the same policy parameters as the reported fixture:

```text
bootstrap_samples=1024, family_size=16,
tail_replicates=1.6000000000000014, minimum=20, gate=False
bounded UCB remains callable (values are finite and support-bounded)
```

The smallest sound direction is to require this tail gate only when a
bootstrap method is selected, or make the metric-cell condition
`automatic_bounded_path or metric_cell_tail_ok`, while retaining the gate for a
selected shadow/bootstrap path. This is a conservative false rejection, not
an unsafe confidence claim.

## (c) Zero-variance shadow simultaneous bound: intentional diagnostic behavior

The direct behavior is real: `_simultaneous_uncertainty_upper_bounds`
(`promotion.py:20962-21077`) sets the studentized statistic to zero when the
standard error is zero (`21017-21020`). In shadow mode this returns `mean +
critical*0`, so one cluster with value `0.2` returns:

```text
method=exact_sign_enumeration, bound=0.2, unresolved=False, effective_replicates=2
```

Automatic mode does not have this behavior: it selects
`_bounded_event_mean_upper_bound` at `21034-21052`, which returns the finite
support bound for one event. The existing automatic regression at
`tests/test_promotion.py:12010-12040` verifies that zero variance does not
become a point estimate there.

The shadow behavior is **not confirmed as a defect** under the current
contract. `allow_shadow_small_sample_bootstrap` is explicitly a diagnostic
mode (`promotion.py:18373-18384`, `20392-20420`), and the repository README
states that small-sample bootstrap is allowed only for shadow diagnostics while
sample-size preflight fail-closes automatic deployment (`README.md:1140-1147`).
The preflight sets `feasible=False` whenever shadow mode is enabled
(`promotion.py:20867-20875`), and `deployment_eligible` requires that feasible
flag (`promotion.py:23225-23232`). Thus the point bound cannot pass the current
deployment certificate path. It may be a misleading descriptive field if a
downstream audit consumer mistakes shadow diagnostics for a confidence bound,
but that is a documentation/consumer-contract risk, not a demonstrated live
deployment error. A future tightening could set `unresolved` for zero-variance
shadow comparisons or expose the result as descriptive-only.

## Validation limits

No full baseline suite, MPS/CUDA run, source edit, or commit was performed.
The focused evidence and probes are recorded in
`cross_stats_coverage.json` and `cross_stats_probes.json`.

