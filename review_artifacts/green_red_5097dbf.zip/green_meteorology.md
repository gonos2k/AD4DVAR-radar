# GREEN meteorology review

Baseline: `5097dbfd1ddf51483578bef5889ebc809ff024f0`  
Scope: meteorological meaning and applicability in the requested ADVAR nowcast,
variational analysis, calibration, range-geometry, scoring, acceptance, sensitivity,
ensemble-FSO, benchmark, and initial-field-lab files. No repository files were
modified and no baseline test suite was rerun.

## Overall assessment

The physical contracts are unusually explicit and are generally internally coherent.
The implementation separates dBZ observations from the positive internal linear echo
quantity, tracks pixel and projected frames, propagates valid times and background age,
and distinguishes finite-but-QC-rejected data from missing data. Its stated operating
model is a short-range, translation-plus-growth radar echo extrapolation model; that is
appropriate for a nowcast baseline when the input is a Cartesian radar reflectivity
field and the limitations are carried into the API. It does not claim that the internal
quantity is rainwater content or rain rate.

The NOAA NWS radar training material describes dBZ as a logarithmic reflectivity scale,
and the NSSL material gives the usual sixth-power drop-size definition of reflectivity
and an explicitly empirical Z--R relation. This supports ADVAR's choice to keep a
linear reflectivity-like quantity for transport, while also supporting its warning that
`q` is not automatically rainfall. See [NOAA NWS radar reflectivity training](https://training.weather.gov/nwstc/NEXRAD/RADAR/3-1.htm)
and [NOAA/NSSL reflectivity and Z--R discussion](https://www.nssl.noaa.gov/publications/mpar_reports/LMCO_Consult2.pdf).
The PySTEPS paper describes optical-flow tracking followed by extrapolation as a
standard very-short-range nowcast pattern; this is consistent with ADVAR's documented
use of phase correlation plus advection, provided the motion field is treated as a
short-range approximation. See [Pulkkinen et al. (2019), PySTEPS](https://doi.org/10.5194/gmd-12-4185-2019).
WMO's nowcasting summary defines the horizon as the current state plus local forecasts
up to six hours, so ADVAR's 0--180 minute horizon is within that broad use case, while
its translation/growth restrictions remain material. See [WMO nowcasting guidelines summary](https://public.wmo.int/media/magazine-article/nowcasting-guidelines-summary).

## Strengths, with conditions

* `physics.py` converts dBZ to a shifted linear reflectivity coordinate
  `q = Z - Z_floor`, with a stable `expm1`/`log1p` pair. The floor keeps the state
  nonnegative, and the inverse preserves the configured dBZ floor. `q` has no rainfall
  units; a Z--R or hydrometeor-specific conversion would be a separate calibrated
  model.
* Remapping is a four-neighbor bilinear map with explicit zero padding. The zero padding
  is a boundary outflow convention, so the internal echo sum need not be conserved at
  the domain edge. A CPU probe gave sums 120 at zero displacement, 66 after a one-cell
  row displacement, and zero for a displacement outside the domain. This is coherent
  with the README's stated outflow semantics; it would be wrong to interpret the sum as
  total atmospheric water.
* `RadarGridTimeContract` consistently distinguishes `(dy, dx)` pixel displacement,
  `(x, y)` projected displacement, and metres per second. Its affine convention places
  row zero at the first cell-center row and uses negative y for increasing row index by
  default. A phase-correlation sign probe recovered approximately `(1, 0)` and
  `(-1, 2)` for synthetic shifts.
* Valid times are timezone-aware and canonicalized to UTC. Background age is retained as
  provenance and gated by the configured maximum age; the code deliberately does not
  decay or physically age the background field. The lab regression test records that
  choice. This is a model restriction and should remain visible to callers.
* Input masks distinguish observed finite values, finite QC rejects, nonfinite missing
  values, and finite background coverage. This avoids silently turning missing pixels
  into observed echoes. The resulting `UNAVAILABLE`, stale-background, partial, and
  observed statuses are physically interpretable only relative to the declared QC and
  background contract.
* The forecast is explicitly a global translation plus multiplicative echo growth with
  optional retention/decay. It cannot represent rotation, deformation, cell birth or
  cell splitting. The README states these limits, so they are applicability conditions
  rather than hidden defects.
* P1's state head is a deterministic Gaussian dBZ field, while its probability head is
  a support event plus conditional truncated-Gaussian intensity. This prevents a
  probability channel from being silently treated as a point analysis field. Confidence
  is an uncertainty/support score in `[0, 1]`, and the README correctly says it is not a
  calibrated event probability.
* Range geometry is explicitly horizontal projected range and excludes beam height and
  blockage physics. Verification carries elevation, blockage, attenuation, age, and
  source-selection evidence separately. This separation is scientifically cleaner than
  treating projected range as a full radar beam model.
* Sensitivity scoring carries a fixed issued or dynamics-anchored domain, verification
  lineage, quality weights, and fixed A/B domains in the initial-field lab. Missing truth
  cannot shrink a candidate's comparison domain. These are important safeguards against
  evaluation-domain leakage.
* The analytic support contract for `log_echo_mse` correctly derives the natural-log
  endpoint from the dBZ bounds (`(max-min)*ln(10)/10`), so its implementation and support
  range agree. The metric is therefore log-linear-echo MSE; it is not numerically equal
  to dBZ-squared MSE by a constant factor. The current promotion support code accounts
  for that factor.

## Confirmed defects

No meteorological implementation defect was confirmed after tracing the active
verification API. In particular, the apparent threshold mismatch needs care: P1's
`>=` support event and detected mask (`src/advar/variational.py:4054-4057` and
`814-818`) are an inference target, while the current product-owned verification path
uses report-kind evidence and rejects threshold-ambiguous source pixels. The equality
regression in `tests/test_sensitivity.py:4105-4133` explicitly marks an exact threshold
as uncertain and removes it from source assignment. The `>=` branch at
`src/advar/sensitivity.py:6705-6710` belongs to older non-current derivation inputs, not
the current scientific v15/v16 mask path. This is therefore recorded below as a
documentation/contract question rather than a confirmed defect.

## Uncertain questions and model choices

1. `_observation_residual_from_prediction` in `src/advar/variational.py:4602-4622`
   uses a smooth `temperature * softplus((prediction-L)/temperature)` barrier for
   censored observations. A proper left-censored Gaussian likelihood would involve a
   normal CDF and the predictive scale. The README documents the proper left-censored
   likelihood for the diagnostic verification artifact, but does not state whether the
   P1 objective intentionally uses this surrogate. This is a statistical-model choice,
   not a confirmed implementation defect; document it or align it with the declared
   likelihood if P1 residuals are meant to be probabilistic.
2. P1 classifies exact `detection_limit_dbz` values as detected and its neural support
   event uses `>=`, while current verification deliberately treats exact threshold values
   as classification-uncertain and excludes them. These are plausibly different
   contracts (inference support event versus product-owned censor/report evidence), and
   the current code has an explicit equality regression. The API should state this
   distinction in one place so a caller does not assume P1 masks and confirmatory
   verification masks are interchangeable.
3. The metric implementation calls the score `log_echo_mse` and uses natural log of
   shifted linear echo. README prose calls the support “bounded dBZ log-echo MSE.” The
   promotion support contract is mathematically consistent with natural-log units, but
   the user-facing unit wording should say explicitly whether “dBZ” is only the bound
   source or the metric unit. This avoids comparing it to ordinary dBZ MSE.
4. `metrics.critical_success_index` returns `1.0` when the event denominator is zero.
   That is a defensible convention for an empty case, but it should remain explicit in
   metric metadata because some verification protocols mark no-event CSI undefined and
   omit it from aggregation.
5. Horizontal projected range is not a beam-height, melting-layer, attenuation, or
   vertical-volume correction. That limitation is correctly represented in the API; a
   deployment using single-site polar data should provide product-owned geometry/QC
   evidence rather than infer it from the Cartesian range field.

## Verification performed

I ran only tiny CPU probes with `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1` and no MPS:

* dBZ/q round-trip at `[-10, -5, 0, 5, 70]` recovered the configured values;
* zero, boundary-crossing, fractional, and out-of-domain remaps showed the documented
  zero-padded outflow behavior;
* synthetic phase-correlation shifts recovered the expected `(dy, dx)` signs;
* an exact 5 dBZ P1 input confirmed the current `>=` detected behavior.

The corresponding unit-test files were read for regression coverage. Existing tests cover
round trips, remap behavior, time/grid contracts, mask provenance, P1 head separation,
fixed-domain lab scoring, and numerical invariants, but no test currently asserts one
threshold inequality across P1 and verification contracts.

No repository or git files were changed. Detailed path/line coverage is in
`green_meteorology_coverage.json`.
