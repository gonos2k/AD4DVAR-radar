# GREEN bounded review — unit 1

Scope: `src/advar/ledger.py:1-5000`, read in full in bounded chunks. The range is imports/constants, trust-store loaders, episode/model contracts, current and legacy scoring-replay manifest types, replay tensor/schema validation, raw/verification provenance reconstruction, and `EpisodeLedger` initialization plus the beginning of episode append. Relevant current callers were traced in the scoring-replay append/load paths (`ledger.py:11605-12570`), operational completion (`ledger.py:12800-12930`), and deployment-ledger binding (`ledger.py:15998-16080`, `promotion.py:27631-27675`).

## Findings

No confirmed reachable defects were found in the assigned range.

The principal invariants are coherent in the paths reviewed:

* `ModelContract` and `SensitivityEpisode` bind configuration, grid-time, forecast-run, and verification lineage digests. Complete verification additionally derives valid times from the timezone-aware issue time and positive leads.
* Current scoring replay manifests require exact case/role coverage, SHA-256 tensor and shard identities, one tensor layout per content-addressed shard, a bounded shard count and expanded byte budget, current raw-ingestor and verification provenance digests, and CPU-only backend certification. Repeated records sharing one shard are intentionally charged once in the expanded-byte calculation because the manifest rejects equivocation of a shard's `(dtype, shape, tensor_digest)` layout.
* `_semantic_replay_execution_device` requires one device and matches every replay component's exact numerical-runtime digest; its current caller then applies the CPU backend gate before recomputation.
* `_validate_scoring_replay_case_tensors` checks role set, dimensionality, dtype families, scalar/vector conventions, forecast/verification spatial agreement, source-cube dimensions, geometry-grid dtype, dynamic source coverage dimensions, and non-empty tensors. The apparent all-missing raw-product edge is excluded by reachable product construction: single-site derivation rejects missing volumes, while mosaic resolved coverage requires positive cells and rejects a source map selecting a missing volume.
* Current raw and verification provenance loaders reconstruct typed objects from durable JSON/tensors and rederive the raw input transform, source coverage, verification masks, observation-error contract, geometry, registry, and all content digests. Legacy replay generations are dispatched as audit-only types and cannot enter current semantic promotion paths.
* Trust-store loaders enforce absolute paths, final-file no-follow, regular-file/root-owned/non-writable checks (with size bounds where the current raw/target stores are used), and the caller rechecks current raw-ingestor identity and digest at commit/replay activation.
* Episode initialization binds canonical native `Path` members and an internal initialization token. Episode append writes and fsyncs complete temporary artifacts before directory publication and SQLite visibility, with rollback cleanup for failed publication.

I specifically attempted to falsify the tensor-budget and empty-raw cases. The former is a deliberate per-shard accounting invariant, and the latter cannot arise from a valid current `ScoringReplayCaseArtifact` that reaches the scorer. No mathematical, numerical, meteorological, or input/output contract violation was established.

## Caller trace

`EpisodeLedger.append_neural_prior_scoring_replay_bundle` builds product replay tensors, calls `_semantic_replay_execution_device`, `_validate_scoring_backend`, and `_validate_scoring_replay_case_tensors`, then constructs `ScoringReplayBundleManifest`. `load_neural_prior_scoring_replay_bundle` reloads content-addressed shards and runs the same schema validator plus both current provenance reconstructors before exposing a current bundle. Trusted scoring completion calls the loader with product cases and requires semantic replay/runtime agreement. Deployment current-runtime verification opens the ledger through `_open_existing_index` and then `_connect_approved_index`, which performs the ownership/identity check before the DB-backed decision query.

## Validation

Environment: `/Users/yhlee/ADVAR/.venv/bin/python` (Python 3.12.13, Torch 2.13), CPU only, `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1`.

* `python -m py_compile src/advar/ledger.py` — PASS.
* Tiny CPU contract/runtime probe covering `ModelContract.digest`, timezone normalization in `_expected_verification_times`, and `_validate_scoring_backend(cpu)` — PASS.
* No full baseline tests were run, per the bounded-review instruction.

No source files were modified.

