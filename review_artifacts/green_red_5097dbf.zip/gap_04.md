# RED bounded review — unit 4

Scope: `src/advar/ledger.py:15001-20000` (inclusive), with bounded caller and contract context outside the assigned range. Review was read-only; no repository source, tests, baseline, MPS, or CUDA state was changed.

## Finding

### P2 — concurrent resume can fail on a unique insert instead of returning the committed authorization

At `src/advar/ledger.py:15435-15472`, `_ensure_operational_decision_commit_authorization_receipt` probes for an existing authorization before taking the writer lock. If two retries for the same operational cycle race, both can observe no row. The first transaction then inserts and commits at lines 15527-15573. The second acquires the writer lock afterward and unconditionally executes the same insert; the unique `certificate_digest` key raises `sqlite3.IntegrityError`. The method has no retained-row recheck or conflict recovery after `BEGIN IMMEDIATE`.

This is reachable from the current issuance path (`issue_operational_deployment_decision`, which calls this helper at line 15364) and from the bound validation/resume client in `src/advar/promotion.py:27647`. It violates the helper's stated terminal-authorization/resume behavior and the issuer's failure-atomic retry design: a concurrent retry of one cycle can fail despite the first retry having durably completed the exact requested state. The same check-then-insert pattern exists for activation receipts at lines 15297-15327 (`INSERT ... WHERE NOT EXISTS` followed by a required `rowcount == 1`), so concurrent activation resumption can likewise surface the synthetic integrity error.

Minimal falsification used two SQLite connections against the same schema: both performed the initial `SELECT` and saw no row; connection A inserted and committed; connection B then began `IMMEDIATE` and attempted the insert. Result: `IntegrityError UNIQUE constraint failed: operational_decision_commit_authorization_receipts.certificate_digest`. This reproduces the unhandled database outcome implied by the live code; no MPS/CUDA or full baseline test was used.

Smallest sound direction: after acquiring `BEGIN IMMEDIATE`, re-read the authorization row (and activation row in the analogous helper), validate the retained payload and state, and return it when it is the same committed receipt; only issue/insert when still absent. Alternatively use a conflict-safe insert followed by a locked read and exact receipt validation. Do not treat an arbitrary duplicate as success because the retained signed payload must still be checked.

## Context and non-findings

`_issue_operational_deployment_decision_legacy` at lines 15701-15996 has no repository callers (`rg` found only its definition) and was treated as legacy/read-only audit scope. The long v3-v32 promotion loader branch and schema migration code were inspected; no additional falsifiable current defect was established. The unsigned active-set note, frozen covariance note, and already-applied Gaussian-tail fix were not applicable to this ledger range.

## Validation

- Read all assigned lines in 15 bounded commands: `15001-15350`, `15351-15700`, `15701-16050`, `16051-16400`, `16401-16750`, `16751-17100`, `17101-17450`, `17451-17800`, `17801-18150`, `18151-18500`, `18501-18850`, `18851-19200`, `19201-19550`, `19551-19900`, and `19901-20000`.
- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -m unittest tests.test_ledger.EpisodeLedgerTests.test_previous_scalar_schema_is_migrated tests.test_promotion.NeuralPriorPromotionTests.test_raw_trust_artifact_activation_change_fails_closed` — 2 tests passed.
- `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -m unittest tests.test_promotion.NeuralPriorPromotionTests.test_late_final_operational_row_is_recorded_unusable` — 1 test passed (44.831 s).
- Minimal SQLite two-connection race probe — reproduced `sqlite3.IntegrityError` on the second insert as described above.

