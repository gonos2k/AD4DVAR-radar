# RED bounded review — unit 25

Baseline reviewed: `5097dbfd1ddf51483578bef5889ebc809ff024f`.

The assigned range `tests/test_run_artifact.py:1501-3025` was read completely
in contiguous bounded chunks. It covers durable forecast round trips and M0
restart, pair/grid/prior lineage serialization and predecessor migrations,
tamper rejection for state/evidence/metadata/config, and ZIP/NPY resource
preflight including the same-file-after-preflight check. I traced the current
production serializer/loader (`src/advar/run_artifact.py`), current contract
registry (`forecast-run-v72`), CLI output caller, and the delayed-M0 restart
caller. No source or test files were changed.

## Findings

### P3 — documented default archive member limit is stale

`README.md:405-408` states that the forecast-run loader's default ZIP member
limit is 160. The reachable current implementation at
`src/advar/run_artifact.py:74` sets `DEFAULT_MAXIMUM_MEMBER_COUNT = 256`, and
`load_forecast_run()` uses that default at lines 997-1001. This is a direct
documentation/runtime contract mismatch, introduced when the implementation
was raised from 224 to 256 (commit `47596355`) while the README sentence was
left at 160.

The behavior is reproducible with a tiny CPU/Python probe that constructs 161
valid NPY members from the declared core/CLI name sets: `_preflight_archive`
accepts 161 members with the default (256), while the same archive is rejected
when `maximum_member_count=160`. Thus a consumer enforcing the documented
default will reject artifacts that the current loader accepts; P1/CLI output
may also use the expanded CLI-member set. The mismatch does not alter forecast
mathematics or the explicit API override.

Smallest sound direction: update the README to 256 (or deliberately restore
the code to 160 only after proving the current core plus CLI output member
set fits); add a contract test that compares the documented/default policy to
the implementation and exercises the CLI-extra archive path.

No reachable mathematical, numerical, serialization-integrity, TOCTOU, or
production-caller defect was falsified in the assigned tests. The loader's
independent artifact/state/run digests, exact enum/provenance validation,
legacy audit mapping, and descriptor-bound preflight remained coherent under
the inspected paths. Frozen version mappings and detached serialization
diagnostics were treated as intentional audit contracts.

## Caller and contract trace

`save_forecast_run()` calls `forecast_run_arrays()` and atomically writes the
sealed NPZ. `load_forecast_run()` opens one file descriptor, preflights it,
rewinds that descriptor, materializes each core member once, reconstructs
`ForecastRunContract`/`ForecastResult`, and revalidates issuance and all
derived evidence. The CLI calls `forecast_run_arrays()` and adds the
`output_contract_version`/analysis extras before sealing; the preflight allows
those extras only when that marker is present. Restart sensitivity calls
`compute_sensitivity_snapshot_from_run()` with the loaded latest frame and
embedded latest background, so the tested round-trip fields are live inputs.
The registry declares current `forecast-run-v72` with `forecast-run-v71` as
its predecessor; v42–v71 loader branches are audit/migration paths.

## Validation and limits

Environment: `/Users/yhlee/ADVAR/.venv/bin/python` (Python 3.12.13,
Torch 2.13.0), CPU only, with `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1`.

Targeted probes:

* Tiny `nowcast -> save_forecast_run -> load_forecast_run` round trip — PASS;
  forecast and run digests matched.
* `forecast_run_arrays()` key-set check against `_CORE_ARRAY_NAMES` — PASS
  (151/151); contiguous/Fortran artifact digest equivalence — PASS.
* Valid 161-member archive preflight — default 256 accepted; explicit 160
  rejected with `forecast run archive has too many members`, proving the
  README mismatch.

No full baseline or test suite was run, per the bounded-review instruction.
No MPS/CUDA, source edits, or commits were made.

## Coverage gaps

There is no test that asserts the documented default archive limit, nor a
default-limit probe for a CLI output archive containing the optional analysis
members. The assigned tests otherwise cover the current core round trip,
tamper/re-sign validation, legacy v42–v71 migration semantics, resource
limits with explicit values, and preflight same-file binding.
