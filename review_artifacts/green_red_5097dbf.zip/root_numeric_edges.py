"""CPU probes for root-adjudicated edge cases; run with PYTHONPATH=src."""

import json
from dataclasses import replace
from pathlib import Path

import torch

from advar.matrix_free import gauss_newton_value_and_gradient
from advar.metrics import critical_success_index, mae, rmse
from advar.nowcast import ForecastRunContract, NowcastConfig, RadarGridTimeContract
from advar.promotion import _truncated_gaussian_diagnostics

torch.set_num_threads(1)
rows = {"torch": torch.__version__, "device": "cpu"}

# Four residuals make the half-sum representable while the unscaled sum overflows.
point = torch.full((4,), 1e19, dtype=torch.float32)
value, gradient = gauss_newton_value_and_gradient(lambda z: z, point)
oracle = 0.5 * point.double().square().sum()
assert torch.isinf(value) and oracle < torch.finfo(point.dtype).max
assert bool(torch.isfinite(gradient).all())
rows["gauss_newton"] = {
    "residual": point.tolist(), "actual": str(float(value)),
    "float64_oracle": float(oracle), "gradient_finite": True,
}

for name, metric, magnitude in (
    ("rmse", rmse, 1e20),
    ("mae", mae, torch.finfo(torch.float32).max),
):
    forecast = torch.tensor([magnitude, -magnitude], dtype=torch.float32)
    result = metric(forecast, torch.zeros_like(forecast))
    assert torch.isinf(result)
    rows[name] = {"actual": str(float(result)), "oracle": float(forecast[0])}

forecast, truth = torch.tensor([40.]), torch.tensor([0.])
rows["csi_threshold"] = {
    str(threshold): float(critical_success_index(forecast, truth, threshold_dbz=threshold))
    for threshold in (35., float("nan"), float("inf"), -float("inf"))
}

frames = torch.ones((3, 2, 2), dtype=torch.float64)
run = ForecastRunContract.from_inputs(
    NowcastConfig(), frames, torch.ones_like(frames, dtype=torch.bool), None
)
replace(run, input_bundle_digest="0" * 64).validate_integrity()
rows["altered_input_bundle_accepted"] = True
grid = RadarGridTimeContract(
    valid_times=("2026-01-01T00:00:00Z", "2026-01-01T00:10:00Z", "2026-01-01T00:20:00Z"),
    dx_m=1000.5, dy_m=2000.5, projection="EPSG:5179", grid_hash="a" * 64,
)
rows["integer_affine"] = {
    "actual": grid.projected_displacement_xy(torch.tensor([1, 1])).tolist(),
    "oracle": [1000.5, -2000.5],
}
for scale in (1., 1e16):
    try:
        scores = _truncated_gaussian_diagnostics(
            torch.tensor([0.], dtype=torch.float64),
            torch.tensor([scale], dtype=torch.float64),
            torch.tensor([5.], dtype=torch.float64), support_threshold_dbz=0.,
        )
        rows[f"truncated_scale_{scale}"] = [item.tolist() for item in scores]
    except ValueError as error:
        rows[f"truncated_scale_{scale}"] = str(error)

output = json.dumps(rows, indent=2, allow_nan=False) + "\n"
Path(__file__).with_suffix(".json").write_text(output)
print(output, end="")
