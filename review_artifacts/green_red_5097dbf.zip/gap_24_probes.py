"""Tiny CPU probes for unit 24's current/legacy background lineage contract."""

from dataclasses import replace
from pathlib import Path
import tempfile

import numpy as np
import torch

from advar.nowcast import (
    _forecast_fixed_input_context_digest,
    _forecast_full_analysis_input_digest,
    _forecast_run_identity_digest,
    nowcast,
)
from advar.run_artifact import load_forecast_run, save_forecast_run, seal_forecast_run_arrays


def _drop_background_whole_cube_digest(result):
    run = result.run
    fixed_context = _forecast_fixed_input_context_digest(
        observation_masks_digest=run.observation_masks_digest,
        observation_quality_weight_digest=run.observation_quality_weight_digest,
        observation_std_dbz_digest=run.observation_std_dbz_digest,
        source_available_mask_digest=run.source_available_mask_digest,
        learned_model_input_features_digest=run.learned_model_input_features_digest,
        background_frames_digest=None,
        background_age_minutes=run.background_age_minutes,
        grid_time_contract_digest=run.grid_time_contract_digest,
        operational_calibration_manifest_digest=run.operational_calibration_manifest_digest,
        operational_calibration_approval_digest=run.operational_calibration_approval_digest,
        operational_data_identity_digest=run.operational_data_identity_digest,
        input_plan_digest=run.input_plan_digest,
    )
    full_input = _forecast_full_analysis_input_digest(
        input_frames_digest=run.input_frames_digest,
        fixed_input_context_digest=fixed_context,
    )
    tampered_run = replace(
        run,
        background_frames_digest=None,
        fixed_input_context_digest=fixed_context,
        full_analysis_input_digest=full_input,
    )
    tampered_digest = _forecast_run_identity_digest(
        tampered_run,
        result.state_metadata_digest,
        result.forecast_dbz_digest,
        result.valid_mask_digest,
    )
    return replace(
        result,
        run=tampered_run,
        forecast_run_digest=tampered_digest,
    )


def current_omission_probe() -> None:
    frames = torch.full((3, 8, 8), 20.0, dtype=torch.float64)
    frames[:, :, :4] = torch.nan
    background = torch.full_like(frames, 19.0)
    result = nowcast(
        frames,
        background_frames_dbz=background,
        background_age_minutes=0.0,
    )
    assert result.metadata.background_used
    assert result.run.background_frames_digest is not None
    tampered = _drop_background_whole_cube_digest(result)
    tampered.validate_issuance()
    print(
        "current_result_validate_issuance=ACCEPTED",
        f"background_used={tampered.metadata.background_used}",
        f"background_fraction={tampered.metadata.background_contribution_fraction}",
    )


def legacy_omission_probe() -> None:
    """Legacy v42 may omit current full-context members and remains audit-loadable."""
    frames = torch.full((3, 8, 8), 20.0, dtype=torch.float64)
    frames[:, :, :4] = torch.nan
    background = torch.full_like(frames, 19.0)
    result = nowcast(
        frames,
        background_frames_dbz=background,
        background_age_minutes=0.0,
    )
    with tempfile.TemporaryDirectory() as directory:
        path = Path(directory) / "legacy-v42.npz"
        save_forecast_run(result, path)
        with np.load(path, allow_pickle=False) as archive:
            arrays = {
                name: np.array(archive[name], copy=True)
                for name in archive.files
                if name
                not in {
                    "observation_masks_digest",
                    "observation_quality_weight_digest",
                    "observation_std_dbz_digest",
                    "source_available_mask_digest",
                    "learned_model_input_features_digest",
                    "background_frames_digest",
                    "fixed_input_context_digest",
                    "full_analysis_input_digest",
                }
            }
        arrays["forecast_run_artifact_version"] = np.asarray("forecast-run-v42")
        np.savez_compressed(path, **seal_forecast_run_arrays(arrays))
        loaded = load_forecast_run(path)
    assert loaded.run.background_frames_digest is None
    assert loaded.run.latest_background_digest is not None
    assert torch.equal(loaded.forecast_dbz, result.forecast_dbz)
    print(
        "legacy_v42_missing_whole_background_digest=LOADS",
        f"latest_background_present={loaded.run.latest_background_digest is not None}",
        "current_full_context_digests=absent",
    )


if __name__ == "__main__":
    torch.set_num_threads(1)
    current_omission_probe()
    legacy_omission_probe()
