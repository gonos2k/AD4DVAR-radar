# GREEN numerical review — baseline `5097dbfd1ddf51483578bef5889ebc809ff024f0`

Scope was numerical behavior in physics, matrix-free AD/PCG, variational residual/IRLS/whitening, range geometry, nowcast metric paths, calibration/acceptance records, ensemble sensitivity, sensitivity metrics, diagnostics, and the corresponding focused tests. No source files were edited.

## Runtime and evidence

The authoritative runtime was `/Users/yhlee/ADVAR/.venv/bin/python` (Python 3.12.13, Torch 2.13.0). `torch.backends.mps.is_available()` and `is_built()` were both `True`; CUDA was unavailable. The CPU probes and focused tests below did not execute an MPS tensor. Root's independent MPS reproductions are retained at `/tmp/advar-green-red-5097dbf/root_mps_scalar.json` and `/tmp/advar-green-red-5097dbf/root_mps_p1.json`, and must be read together with this report.

The runnable probe is `/tmp/advar-green-red-5097dbf/green_numerics_probes.py`; its complete stdout is `/tmp/advar-green-red-5097dbf/green_numerics_probes.stdout.txt`. The probe uses the actual `PrecisionOperatorArtifact` constructor and records the low-precision backend exception. Complete focused-test stdout is recorded in `/tmp/advar-green-red-5097dbf/pytest_core.stdout.txt`, `pytest_contracts.stdout.txt`, `pytest_variational.stdout.txt`, and `pytest_sensitivity.stdout.txt`.

## Findings

### LOW (P3, outside the configured radar scale) — float32 Gauss–Newton objective can become `inf` for finite inputs

`src/advar/matrix_free.py:180-183` computes `0.5 * torch.sum(residual * residual)` in the residual dtype. The public helpers accept any real floating dtype (`:16-23`) and do not constrain the scale or reject a non-finite objective. A CPU probe with `dtype=torch.float32`, `x=[1e19,-1e19]`, and `residual_fn=lambda z: 2*z` returned `value=tensor(inf)` and a finite gradient `[4e19,-4e19]`; the exact mathematical value is `4e38` (representable in binary64, outside binary32). This can poison a caller's objective or line search while all inputs and the gradient remain finite. The current P1 path bounds dBZ and uses the rationalized robust objective (`src/advar/variational.py:6101-6125`), so ordinary configured P1 magnitudes did not reproduce it. PyTorch documents that finite float32 norm/square intermediates can overflow and recommends a wider accumulation dtype: [PyTorch numerical accuracy, extremal values](https://docs.pytorch.org/docs/main/notes/numerical_accuracy.html), [vector_norm dtype](https://docs.pytorch.org/docs/stable/generated/torch.linalg.vector_norm.html). This is P3 for the reviewed configured radar range because the failing residual scale is far outside ordinary dBZ inputs; no production-range failure was observed. A future fix should either accumulate this scalar in a supported wider dtype while preserving the API contract, or explicitly reject/report an unrepresentable objective.

### LOW (P3, outside the configured radar scale) — `metrics.rmse` squares before reducing and overflows on finite float32 values

`src/advar/metrics.py:16-20` uses `torch.sqrt(torch.mean(torch.square(forecast - truth)))`. With finite float32 `forecast=[1e20,-1e20]`, `truth=[0,0]`, the result is `inf`; `mae` on the same inputs is finite. This is a direct public verification-metric behavior, independent of model state. Typical configured dBZ values (roughly the default `[-10,70]`) are far below the failing scale, but the function accepts arbitrary floating tensors and has no scale/domain contract. A stable norm or wider accumulation, or an explicit finite-domain contract, is needed if arbitrary finite inputs are supported. This is P3 for the reviewed configured radar range because the failing values are far outside ordinary dBZ inputs; no production-range failure was observed.

### LOW — precision-operator artifact accepts unsupported low-precision dtypes until a backend exception

`src/advar/ensemble_sensitivity.py:91-96` accepts every floating tensor, while `:176-196` immediately calls Cholesky/eigvalsh. On CPU, a 2x2 identity `PrecisionOperatorArtifact` with `float16` or `bfloat16` raises backend `NotImplementedError` (`"cholesky_cpu" not implemented`) rather than the module's documented validation error. `float32` and `float64` pass. Ensemble centering explicitly restricts to float32/64 at `:756-763`, but the dense precision artifact does not. The supported scientific precision should be made explicit before linalg (or the tensors should be promoted with a recorded precision policy), so unsupported precision is rejected deterministically and does not escape as an implementation exception.

## Verified numerical strengths and conditions

* `physics.remap_core` uses a frozen integer cell and differentiable fractional bilinear weights. At origin, positive/negative integer cells, and fractional cells in both float32/float64, outputs and first/second derivatives were finite. `shift_zero` avoids empty-slice padding, preserving the MPS VJP workaround documented at `physics.py:163-177`.
* `dbz_to_echo`/`echo_to_dbz` use `expm1`/`log1p`; round trips over `[-90,-30,0,30,60,90]` dBZ were finite and accurate in float32/64. This assumes the configured dBZ range keeps the exponential representable.
* `audit_transport` accumulates scalar budgets on CPU float64 (`diagnostics.py:108-134`). For a 5x5 fractional transport probe, float64 closed exactly; float32 showed only approximately `1e-5` absolute budget error for a 325 integral (about `3e-8` relative), consistent with output-rounding. The audit reports the error but does not itself impose a scale-aware acceptance threshold.
* PCG's scaled inner products and scaled norm (`matrix_free.py:74-125`) handled tiny float64 and large float16/float32 right-hand sides without false convergence in targeted CPU probes. It recomputes the true residual at convergence/restart (`:346-355`); no PCG defect was found in the tested SPD ranges.
* Pseudo-Huber evaluation is algebraically rationalized (`variational.py:6108-6112`) and retained small float32 residual costs in the focused regression test. Frozen IRLS weights are detached (`variational.py:5015-5028`), and the final polish checks stationarity, robust stationarity, and the IRLS fixed point (`variational.py:6904-6932`).
* The compact low-rank whitener matched a dense eigendecomposition on a two-frame/three-mode probe to relative errors `3.9e-7` (float32) and `7.2e-16` (float64). Directed interval geometry in `sensitivity.py:2694-3102` consistently casts to float64 and outward-rounds with `nextafter`; source-selection certification explicitly requires CPU binary64 (`:3243-3246`).

## Targeted verification

Ran with `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1` under the `.venv` interpreter above:

```text
OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 .venv/bin/python /tmp/advar-green-red-5097dbf/green_numerics_probes.py
OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 .venv/bin/python -m pytest -q -rA tests/test_matrix_free.py tests/test_pcg.py tests/test_metrics.py tests/test_numerical_review.py
OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 .venv/bin/python -m pytest -q tests/test_calibration.py tests/test_ensemble_sensitivity.py tests/test_matrix_free.py tests/test_metrics.py tests/test_acceptance.py
OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 .venv/bin/python -m pytest -q tests/test_variational.py -k 'numerical or residual or irls or whitener or robust or smoothness or gauss_newton or bounded or derivative or finite or precision or amplitude'
OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 .venv/bin/python -m pytest -q tests/test_sensitivity.py -k 'metric or finite or residual or gradient or interval or range or centroid or fss or pcg or adjoint'
```

* `tests/test_matrix_free.py`, `tests/test_pcg.py`, `tests/test_metrics.py`, `tests/test_numerical_review.py`: `41 passed`, `30 subtests passed`. The selected MPS tests passed in this focused run, while root's ordinary P1 MPS solve and scalar JVP probes independently fail as recorded above.
* `tests/test_calibration.py`, `tests/test_ensemble_sensitivity.py`, `tests/test_matrix_free.py`, `tests/test_metrics.py`, `tests/test_acceptance.py`: `44 passed`.
* Numerical subset of `tests/test_variational.py`: `27 passed, 115 deselected, 37 subtests passed`.
* Numerical subset of `tests/test_sensitivity.py`: `19 passed, 74 deselected, 52 subtests passed`.

Untested here: a full MPS solve by GREEN, the full baseline suite, large production grids, and overflow-scale model configurations outside the physical default dBZ range. Coverage JSON lists exact source ranges read; some large modules were reviewed in explicit chunks, so this report makes no claim that unlisted functions were numerically audited. Delegated child-agent execution was unavailable in this runtime; the evidence is therefore from this direct review plus root's independent artifacts.
