# GREEN / RED bounded review — unit 18

## Scope and method

Read every line of `tests/test_promotion.py:20001-20794` in bounded chunks
(`20001-20350`, `20351-20700`, and `20701-20794`). The range contains eleven
tests covering raw-trust activation races, fractional chronology and authority
checks, event-catalog timing/membership/association, required end-to-end range
metrics, trusted process start/completion, scoring-plan binding, and receipt
signature integrity. I traced the corresponding current callers in
`src/advar/promotion.py`, `src/advar/ledger.py`, and the relevant nowcast
contract parser. No source or test files were modified; no MPS/CUDA or full
baseline run was used.

The assigned chronology test exercises timezone normalization and fractional
revocation boundaries correctly, but it uses a one-element `valid_times`
tuple and leaves the input-plan `contract` at its default. The production
constructor has two untested invariants that are material to the replay input
contract.

## RED findings

1. **Medium — `NeuralPriorInputPlan` accepts unknown/legacy contract versions.**

   `NeuralPriorInputPlan.__post_init__` canonicalizes fields and checks the
   latency window, but never checks
   `self.contract == "neural-prior-input-plan-v2"` (`src/advar/promotion.py:2818-2846`).
   A direct current-object construction therefore accepts an arbitrary version
   string and incorporates it into a valid digest. This is reachable from
   current durable replay/provenance decoders that instantiate
   `NeuralPriorInputPlan` directly (`src/advar/ledger.py:4467` and
   `src/advar/ledger.py:8932`); they verify the recomputed digest, not the
   supported contract generation. The current prospective intervention path
   rejects non-v2 payloads (`src/advar/intervention.py:1850`); the general
   nowcast parser deliberately has separate legacy/audit allowances
   (`src/advar/nowcast.py:5656`). The current semantic replay/provenance path
   is neither of those legacy paths, yet its typed constructor accepts the
   unknown generation.

   Reproduction on the current checkout (Python 3.12.13, Torch 2.13 CPU):

   ```text
   NeuralPriorInputPlan(..., contract="legacy-input-plan")
   -> ACCEPTED legacy-input-plan ...
   ```

   The expected contract is that a current v2 constructor rejects unsupported
   generations before assigning a digest. The smallest sound direction is an
   explicit version check at the start of `__post_init__`, with a regression
   in `test_fractional_second_chronology_uses_instants_not_strings` (or a
   focused neighboring test) asserting an unknown contract raises.

2. **Medium — input-plan valid times may be duplicated or out of chronological
   order.**

   The same constructor only checks that `times` is nonempty and that its last
   item equals `observation_valid_time`; it does not require unique, strictly
   increasing canonical instants (`src/advar/promotion.py:2827-2833`). A direct
   probe accepts both:

   ```text
   valid_times=(00:00Z, 00:00Z)  -> ACCEPTED
   valid_times=(01:00Z, 00:00Z)  -> ACCEPTED
   ```

   This is a reachable scientific input error, not only a serialization issue:
   `_derive_analysis_inputs_from_raw_products` first checks set coverage and
   then iterates `input_plan.valid_times` to append frames in that exact order
   (`src/advar/promotion.py:2188-2207`; mosaic replay does the same at
   `2217-2222`). Duplicate times can append one raw frame twice, while reversed
   times reverse the temporal tensor sequence. The holdout and operational
   provenance plan checks also compare time sets, preserving this defect rather
   than repairing it (`src/advar/promotion.py:10004-10014` and
   `src/advar/promotion.py:1810-1818`).

   The expected invariant is a strictly increasing sequence of canonical
   instants ending at the observation valid time. The smallest theoretically
   sound direction is to reject any adjacent `later <= earlier` pair (which
   also rejects duplicates), then add two small constructor regressions. The
   assigned fractional-second test cannot catch this because its tuple has one
   element.

No other reachable defect was established from this bounded range. The raw
trust activation tests exercise both pre/post trust checks and durable
expiration; event-catalog tests bind plan time, member input availability, and
association components; and the scoring-start tests cover registered catalog,
ledger input, chronology, and algorithm-family checks.

## Validation

Environment: `/Users/yhlee/ADVAR/.venv/bin/python` (Python 3.12.13, Torch
2.13), CPU only, `OMP_NUM_THREADS=1`, `MKL_NUM_THREADS=1`.

The tiny constructor probe above passed by demonstrating the two unexpected
acceptances. I also launched the eleven bounded unittest selectors for the
assigned methods with the required CPU environment; fixture setup remained
running beyond two minutes, so I terminated that reviewer-owned process rather
than let it become a broad baseline run. No targeted test result is claimed.
