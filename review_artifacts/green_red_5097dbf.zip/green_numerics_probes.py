"""Small CPU numerical probes used by the GREEN review.

This script intentionally does not allocate or execute an MPS tensor.  It
records backend availability so that the separate root MPS evidence is not
silently conflated with these CPU checks.
"""

from __future__ import annotations

import platform
import sys
from pathlib import Path

import torch

REPO = Path("/Users/yhlee/ADVAR")
sys.path.insert(0, str(REPO / "src"))

from advar.diagnostics import audit_transport  # noqa: E402
from advar.ensemble_sensitivity import PrecisionOperatorArtifact  # noqa: E402
from advar.matrix_free import gauss_newton_value_and_gradient  # noqa: E402
from advar.metrics import mae, rmse  # noqa: E402
from advar.physics import RemapCell, echo_to_dbz, dbz_to_echo, remap  # noqa: E402


def precision_artifact(dtype: torch.dtype) -> PrecisionOperatorArtifact:
    eye = torch.eye(2, dtype=dtype)
    return PrecisionOperatorArtifact(
        precision=eye,
        covariance=eye,
        observation_ids=("a", "b"),
        forecast_run_digest="1" * 64,
        observation_error_model_digest="2" * 64,
        calibration_manifest_digest="3" * 64,
    )


print("interpreter", sys.executable)
print("python", platform.python_version())
print("torch", torch.__version__)
print("torch_version", torch.version.__version__ if hasattr(torch.version, "__version__") else "n/a")
print("mps_available", torch.backends.mps.is_available())
print("mps_built", torch.backends.mps.is_built())
print("cuda_available", torch.cuda.is_available())

point = torch.tensor([1.0e19, -1.0e19], dtype=torch.float32, requires_grad=True)
value, gradient = gauss_newton_value_and_gradient(lambda z: 2.0 * z, point)
print("gauss_newton_float32", value.item(), gradient.detach().tolist(), bool(torch.isfinite(value)), bool(torch.all(torch.isfinite(gradient))))

forecast = torch.tensor([1.0e20, -1.0e20], dtype=torch.float32)
truth = torch.zeros_like(forecast)
print("rmse_float32", rmse(forecast, truth).item(), mae(forecast, truth).item(), bool(torch.isfinite(rmse(forecast, truth))))

for dtype in (torch.float16, torch.bfloat16, torch.float32, torch.float64):
    try:
        artifact = precision_artifact(dtype)
        print("precision_artifact", dtype, "ok", artifact.condition_number)
    except Exception as exc:  # record the backend's exact unsupported-dtype behavior
        print("precision_artifact", dtype, type(exc).__name__, str(exc))

for dtype in (torch.float32, torch.float64):
    dbz = torch.tensor([-90.0, -30.0, 0.0, 30.0, 60.0, 90.0], dtype=dtype)
    roundtrip = echo_to_dbz(dbz_to_echo(dbz, min_dbz=-90.0), min_dbz=-90.0)
    print("dbz_roundtrip", dtype, float(torch.max(torch.abs(roundtrip - dbz))))

for dtype in (torch.float32, torch.float64):
    echo = (torch.arange(25, dtype=dtype).reshape(5, 5) + 1.0)
    displacement = torch.tensor([0.25, 0.40], dtype=dtype)
    moved = remap(echo, displacement, cell=RemapCell(0, 0))
    audit = audit_transport(echo, displacement, cell=RemapCell(0, 0), moved=moved)
    print("transport", dtype, audit)
