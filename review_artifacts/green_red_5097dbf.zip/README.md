# GREEN / RED review evidence — 5097dbf

Canonical source commit: `5097dbfd1ddf51483578bef5889ebc809ff024f0` in
`gonos2k/AD4DVAR-radar`. Review date: 2026-09-05.

This bundle preserves a read-only audit by 33 `gpt-5.6-luna` reviewers and
root adjudication. It contains no production patch. The authoritative finding
status and severity are in `FULL_CODE_REVIEW_CHECKLIST.md`, copied from the
repository. Reviewer reports include provisional classifications; their claims
must be read with the root report's caller-path, mock, scope, and withdrawal
qualifications. Findings are not all proven end-to-end promotion failures.

## Contents

- `manifest.json`: the 60-file, 162,670-line source/test/tool/UI/config inventory.
- `source_hashes.json`: baseline Git blob and SHA-256 identities, with proof
  that working-tree bytes matched the reviewed source at packaging time.
- `coverage_union.json`: union of actual reported read intervals. It is not
  evidence that both teams or all four disciplines independently read each line.
- `green_*.md`, `red_*.md`: eight perspective lead reports.
- `gap_01.md` through `gap_25.md`: bounded follow-up reviewer reports.
- `*_coverage.json`: read ranges, caller context and scoped verification logs.
- `cross_stats.md`: independent caller-path adjudication of statistical claims.
- `*_probes.py`, `*.stdout*`, `root_*.py`, `root_*.json`: small reproductions and
  captured output. Some isolated probes mock I/O or trust checks; see each report.
- `SHA256SUMS`: SHA-256 for every bundled file except the checksum list itself.

`unassigned_gaps.json` is an intermediate scheduling snapshot, not the final
coverage result. The final `coverage_union.json` has no uncovered intervals.

## Reproduction

Use a checkout of the canonical commit, outside any shared checkout being edited.
The authoritative local interpreter was Python 3.12.13 / PyTorch 2.13.0 at
`/Users/yhlee/ADVAR/.venv/bin/python`; CPU probes used one thread. CUDA and the
whole baseline were not run. Actual browser rendering was not verified.

From the repository root, with this bundle extracted to a separate directory:

```sh
OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONPATH=src:tests \
  .venv/bin/python /path/to/bundle/root_numeric_edges.py

OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONPATH=src:tests \
  .venv/bin/python /path/to/bundle/root_mps_p1.py

OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONPATH=src:tests \
  .venv/bin/python /path/to/bundle/gap_20_probes.py
```

The MPS probe requires an MPS-capable Mac. It records failures rather than
pretending that finite forward values establish differentiable P1 execution.
Repository README line 1717 already declares full MPS P1 NO-GO. R01 therefore
records a concrete existing support boundary, not a new supported-path regression.
Several reviewer probes contain the original absolute repository path; change
that path if reproducing elsewhere. Some reuse existing test fixtures and take
longer than a pure tensor probe. Do not run all scripts as an undifferentiated
test suite: select the finding and read its probe's setup and limitations.

Root's `gap_10_probes.py` extension confirms the same favorable analytic UCB
`-0.45463951720986906` while changing only bootstrap samples from 1,024 to
16,384 changes the unrelated tail gate. This is not a full signed promotion replay.

For representable-result overflow, use `root_numeric_edges.py` and its strict
JSON output: four residuals of `1e19`, mathematical half-sum about `2e38`.
The earlier GREEN probe with two residuals of `2e19` has a true half-sum about
`4e38`, outside FP32 range, and cannot establish this particular claim.
Earlier raw `root_candidates.json` output uses Python JSON's `Infinity` token;
the later root probe uses strings for nonfinite results and is the portable
reproduction. Do not count overlapping test runs as distinct tests.

## Status

Review is complete for the inventoried read scope. R02–R11 are unresolved
follow-up groups, with concrete completion conditions in the root report.
R01 is conditional on a future decision to expand the existing MPS P1 support.
Numerical correctness is not proved for every input, dtype or device.
KG refresh updates the existing code graph only; this archive and the tracked
report retain the audit reasoning without claiming automatic semantic ingestion.
