# RED numerical audit — baseline `5097dbfd1ddf51483578bef5889ebc809ff024f0`

Scope: numerical behavior of the requested physics, matrix-free, variational,
range-geometry, nowcast, calibration, ensemble-sensitivity, sensitivity,
metrics, diagnostics, acceptance, and benchmark paths. No repository files were
modified. Probes used `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1` on CPU.

## Findings

### RED-N1 — float32 metric reductions overflow although the mathematical result is representable

- Severity: medium (public `mae`/`rmse` API; high magnitudes are outside normal radar dBZ but are admitted as finite floating input).
- Location: `src/advar/metrics.py:13` and `src/advar/metrics.py:20`.
- Analytic expectation: for `x=[fmax,-fmax]`, `y=[0,0]`, both MAE and RMSE are `fmax` in real arithmetic and are representable in float32. The reduction should accumulate in a wider dtype or use a scaled norm.
- Minimal reproducer:

  ```python
  import torch
  from advar.metrics import mae, rmse
  fmax = torch.finfo(torch.float32).max
  x = torch.tensor([fmax, -fmax])
  y = torch.zeros(2)
  print(mae(x, y), rmse(x, y))
  ```

- Actual result: `tensor(inf) tensor(inf)`. `mae` computes `mean(abs(x-y))`; the float32 sum of two `fmax` values overflows before division. `rmse` squares and reduces in float32, overflowing as well.
- Scope/impact: any finite float32 metric pair whose elementwise reductions exceed the accumulator range can produce an infinite verification metric even when the final mean or RMS is finite. Ordinary radar dBZ values will not reach this regime, so this is a robustness defect rather than a normal-case forecast failure.
- Small theoretical fix direction: accumulate absolute values and squares in float64 (or use a max-scaled reduction, including the element count before rescaling), then cast the final scalar to an output dtype that can represent it. Add an overflow regression with the two-element input above.

### RED-N2 — Gauss–Newton value reduction has the same finite-result overflow

- Severity: medium (public matrix-free API; generic finite tensors are accepted).
- Location: `src/advar/matrix_free.py:182`.
- Analytic expectation: with residual `r=[1e19,1e19,1e19,1e19]` in float32, `0.5*sum(r²)=2e38`, which is finite and below `fmax`.
- Minimal reproducer:

  ```python
  import torch
  from advar.matrix_free import gauss_newton_value_and_gradient
  p = torch.ones(4, dtype=torch.float32, requires_grad=True)
  value, gradient = gauss_newton_value_and_gradient(lambda z: z * 1e19, p)
  print(value, gradient)
  ```

- Actual result: `value=tensor(inf)` while `gradient` is finite (`1e38` per component). `torch.sum(residual * residual)` overflows before the factor `0.5` is applied.
- Scope/impact: matrix-free callers can receive a non-finite objective and reject a valid step despite a representable mathematical objective. P1’s normal dBZ/grid scales are much smaller, but the helper’s contract only requires finite floating tensors.
- Small theoretical fix direction: use a max-scaled inner product for the objective (the same idea already used by PCG), or perform the square/reduction in float64 where supported; preserve the input dtype/device for the gradient and add the four-component regression.

### RED-N3 — precision operator artifact accepts float16/bfloat16 then fails backend factorization

- Severity: medium (dtype/device contract inconsistency; public `PrecisionOperatorArtifact` constructor).
- Location: `src/advar/ensemble_sensitivity.py:91-96` and `src/advar/ensemble_sensitivity.py:184-186`.
- Analytic expectation: either the artifact accepts all floating dtypes and performs a supported validation path, or it rejects low-precision dtypes with a clear contract error. The constructor currently only checks `is_floating_point` and then unconditionally calls Cholesky.
- Minimal reproducer:

  ```python
  import torch
  from advar.ensemble_sensitivity import PrecisionOperatorArtifact
  digest = "0" * 64
  PrecisionOperatorArtifact(
      torch.eye(2, dtype=torch.float16),
      torch.eye(2, dtype=torch.float16),
      ("a", "b"), digest, digest, digest,
  )
  ```

- Actual result on the repository’s Python/CPU environment: `NotImplementedError: "cholesky_cpu" not implemented for 'Half'`. `bfloat16` fails analogously. The same API accepts float32/float64.
- Scope/impact: callers receive backend-specific `NotImplementedError` after passing the documented-looking floating tensor boundary. MPS and CPU have different low-precision linear-algebra support, so behavior is device dependent.
- Small theoretical fix direction: constrain the artifact to float32/float64 (matching `EnsembleFSOStatistics`) before Cholesky, or explicitly promote to a validated factorization dtype and record that policy in the artifact contract. Add dtype rejection/promotion tests.

## Checks and limits

- Existing repository files were not modified. Only this report and its coverage JSON were created under `/tmp/advar-green-red-5097dbf/`.
- Targeted numerical tests passed under the declared Python 3.10 runtime: `python -m pytest -q tests/test_metrics.py tests/test_matrix_free.py tests/test_pcg.py tests/test_numerical_review.py` → 41 passed.
- The standalone `pytest` executable on this machine is Python 3.9, below the project’s declared Python >=3.10 floor, and therefore gives a misleading collection error for `Real | float`. The supported `python -m pytest` invocation under Python 3.10.11 passed the targeted suite: 41 tests passed.
- I did not repeat the root agent’s MPS P1 reproducer. The active affine-component overflow issue remains a known documented limitation and is excluded from the findings above.
