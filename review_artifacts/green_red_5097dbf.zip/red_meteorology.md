# RED meteorology review

Review target: ADVAR baseline `5097dbfd1ddf51483578bef5889ebc809ff024f0`.
This is a source review; no repository source was modified. The review covered the
nowcast/physics/variational/calibration/range geometry/metrics/acceptance/sensitivity/
ensemble-sensitivity paths, the initial-field lab, the variational benchmark, README,
and the associated tests. The exact inspected line ranges are in
`red_meteorology_coverage.json`; ranges are intentionally limited to lines actually
read.

## Metric convention review

### No-event CSI is an explicit convention, not a confirmed defect

**Location:** `src/advar/metrics.py:23-39`, especially lines 36-39.

`critical_success_index` implements the documented ratio
`hits / (hits + misses + false_alarms)`. For a finite clear-air verification slice,
all three event counts are zero, so the mathematical ratio is `0/0`. The implementation
explicitly returns `1.0` at line 38. This is an existing convention and is exercised
by the repository's metric expectations; the review found no production caller that
aggregates this helper into a promotion or acceptance claim.

Minimal CPU reproduction, run with Python 3.12.13 and Torch 2.13.0:

```python
from advar.metrics import critical_success_index
import torch

critical_success_index(
    torch.tensor([0.0]), torch.tensor([0.0]), threshold_dbz=35.0
)
# tensor(1.)  # explicit no-event convention
```

The MET verification reference defines CSI as `n11 / (n11 + n10 + n01)` and explicitly
says it ignores correct rejections: [MET Appendix C, CSI](https://metplus.readthedocs.io/projects/met/en/main_v10.0.0/Users_Guide/appendixC.html#critical-success-index-csi).
A clear case supplies no event-discrimination evidence, so an *external* protocol that
averages this helper's no-event `1.0` with event cases could inflate skill. That misuse
is reachable in principle but was not found in the repository's production paths;
there is no demonstrated protocol claim or aggregate here. Keep the convention
documented, or add an explicit support/`NOT_APPLICABLE` value if a future scoring
protocol needs to distinguish no-event cases. This review does not classify it as a
repository defect and made no patch.

## Hypotheses and known limits (not additional confirmed defects)

### Raw PSR weighting can suppress a recent motion signal

At `src/advar/nowcast.py:8434-8465`, consistent adjacent motion pairs are weighted by
`(1-recent_weight)*first_psr` and `recent_weight*second_psr`. With the default
`recent_weight=2/3`, a tiny 16x16 CPU case with a stationary first pair and a one-cell
recent displacement produced PSRs of approximately `1,000,000` and `138.8`, and the
blended displacement was `[0.000277, 0.000000]` rather than approximately two-thirds
of the recent displacement. This is an analytic concern only if `recent_weight` is
intended to guarantee recency dominance independent of PSR scale. The code and
`tests/test_nowcast.py:1706-1723` explicitly treat PSR as part of the confidence
weight, and the model assumes a globally coherent motion field; therefore this is
reported as a hypothesis for a future contract decision, not a defect.

### Reflectivity and echo interpretation

The README correctly bounds `q` as a positive, defined echo amount rather than water
or rainfall (`README.md:68-88`). NWS describes dBZ as “a logarithmic power ratio ...
with respect to radar reflectivity factor, Z” and notes that beam width, precipitation
type, drop size, clutter, and anomalous propagation affect reflectivity:
[NWS dBZ glossary](https://www.weather.gov/spotterguide/glossary_d#dBZ).
The NWS radar-rainfall review also states that different drop-size distributions can
produce the same Z but different rainfall rates:
[WSR-88D rainfall limitations](https://www.weather.gov/mrx/radarrainfallestimates).
ADVAR does not claim a Z-R conversion or precipitation amount, so this is a known
scientific limit rather than a code error. Any external interpretation of q as rain
rate would be invalid.

### Radial Doppler identifiability

NWS defines Doppler radial velocity as the instantaneous motion component parallel to
the radar beam: [NWS field-guide glossary](https://www.weather.gov/spotterguide/glossary_d#Doppler-Radar).
ADVAR estimates image displacement from dBZ phase correlation and does not ingest
radial Doppler. A motion component perpendicular to a beam can therefore have zero
radial velocity while producing nonzero image displacement; conversely radial motion
does not uniquely identify a 2-D grid translation. This is an observation/model
identifiability limit, documented by the global-motion caveat in `README.md:96-111`,
not a promise violation.

### Model, prior, and sampling limits

The read paths preserve the intended bounds: `README.md:96-111` describes global
translation/global growth, local observation-derived prior dependence, and an
uncalibrated model confidence indicator; `README.md:339-351` and
`src/advar/nowcast.py:4032-4115` enforce aware times, interval spacing, and background
age; `src/advar/physics.py:82-88` states that edge loss is boundary leakage; and
`examples/initial_field_lab/server.py:254-313` fixes the A/B scoring domain and
reports missing scored pixels. The variational censoring path
(`src/advar/variational.py:4575-4622`) keeps detected, censored, and invalid masks
separate. I found no additional reproducible meteorological defect in these paths.

## Probes and validation

The requested environment was available: `.venv/bin/python3.12` is Python 3.12.13
with Torch 2.13.0. CPU probes used `OMP_NUM_THREADS=1` and `MKL_NUM_THREADS=1`.
They reproduced the CSI result above, recovered known synthetic phase-correlation
shifts `[2,3]`, `[-2,-3]`, and `[1,-2]`, and recovered constant synthetic motion
approximately `[1,2]`. A targeted Python 3.12 run of
`tests.test_metrics` plus two phase-correlation tests passed (`5 tests`, `0.388 s`).
Earlier CPU runs of the relevant test groups also passed: metrics/ensemble/calibration/
acceptance/lab (`44 tests`) and nowcast/variational/sensitivity (`402 tests`). One
initial selector typo was corrected before the passing targeted run; no source test
was changed.

## External scientific references

- [NWS Field Guide glossary: dBZ and Doppler radar](https://www.weather.gov/spotterguide/glossary_d)
- [NWS WSR-88D radar rainfall estimation limitations](https://www.weather.gov/mrx/radarrainfallestimates)
- [MET Appendix C verification measures](https://metplus.readthedocs.io/projects/met/en/main_v10.0.0/Users_Guide/appendixC.html)

## Delegation status

No child IDs exist. The collaboration namespace (`spawn_agent`/`send_message`) was not
exposed in this session, so the requested Luna child delegation could not be created;
the review and probes were performed directly by this agent.
