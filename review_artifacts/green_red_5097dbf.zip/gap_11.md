# GREEN bounded review — unit 11

Baseline: `5097dbfd1ddf51483578bef5889ebc809ff0240`.

Scope reviewed: `src/advar/promotion.py:25001-27989`, read in full in bounded
chunks. The range contains deployment release approvals and runtime activation
receipts, operational decision ledger/publication/activation receipts, the
committed operational-selection replay, and the durable deployment-artifact
validator. Current caller context was read in `ledger.py`, `run_artifact.py`,
`variational.py`, and the focused promotion/run-artifact tests. No repository
source or test files were modified.

## Contracts established

The deployment boundary uses canonical JSON payloads, SHA-256 digests, and
Ed25519 signatures. Release, runtime activation, promotion certification,
ledger issuance, and operational decision signatures are intentionally
role-separated. Authority trust-store membership, revocation windows, current
runtime closure, and release/activation expiry are checked at the relevant
boundary.

Runtime activation sequence numbers are discrete positive chain indices: the
first index uses the fixed genesis digest and later indices reference a prior
receipt. Operational ledger indices have the same integer/positive invariant.
Operational chronology is ordered before publication:
`observation <= available <= accepted <= committed <= proof <= decision <=
deadline < publication`, with release/runtime and activation receipts bound to
the same bundle and approval.

The selection replay chooses the candidate only when promotion eligibility,
certified regime/geometry/range groups, non-OOD classification, weather top-1 /
top-2 separation, and confidence margins all pass. Otherwise the parent is
selected and a typed fallback reason is retained. The durable validator then
reconstructs policy, geometry, ledger receipts, and selection and compares
their digests and lineage to current trust stores and optional current-run
identities.

## Confirmed findings

### P2 — Both legacy deployment file loaders discard every read block

At [promotion.py:25088](/Users/yhlee/ADVAR/src/advar/promotion.py:25088)-[25096](/Users/yhlee/ADVAR/src/advar/promotion.py:25096),
`load_deployment_bundle_release_approval` creates `retained = bytearray()` and
reads each `block`, but never appends or extends `retained`. The same omission
exists at [promotion.py:25467](/Users/yhlee/ADVAR/src/advar/promotion.py:25467)-[25475](/Users/yhlee/ADVAR/src/advar/promotion.py:25475)
in `load_deployment_runtime_activation_receipt`. For every non-empty regular
file, the descriptor reaches EOF while `len(retained)` remains zero; the
following size check therefore raises `ValueError("... changed during
validation")` before JSON parsing and signature validation. The runtime loader
also calls the release loader, so the defect blocks the complete pair.

This is reachable through the public legacy loader functions; the runtime
loader's in-range caller invokes `load_deployment_bundle_release_approval` at
[promotion.py:25518](/Users/yhlee/ADVAR/src/advar/promotion.py:25518). It is
separate from the current numerical/forecast path, which parses an already
embedded artifact payload and does not call these non-authoritative deployment
tools. The finding therefore establishes a broken public legacy loader API,
without claiming that the current numerical path is operationally blocked.

Expected behavior is to retain each successfully read block until exactly the
initial bounded size, then parse the retained immutable snapshot. The smallest
theoretically sound direction is `retained.extend(block)` (or an equivalent
chunk list plus `b"".join`) before the EOF/metadata-stability check, preserving
the existing descriptor pinning and size checks.

Tiny CPU probe [gap_11_probes.py](/tmp/advar-green-red-5097dbf/gap_11_probes.py)
(Python 3.12.13 / Torch 2.13, with `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1`)
patched `os.read` to return one valid non-empty block and then EOF while
returning stable regular-file metadata. Both loaders made two reads and failed
exactly as predicted; the complete stdout is retained in
[gap_11_probes.stdout.txt](/tmp/advar-green-red-5097dbf/gap_11_probes.stdout.txt):

```text
load_deployment_bundle_release_approval ValueError bundle release approval changed during validation read_calls= 2
load_deployment_runtime_activation_receipt ValueError runtime activation receipt changed during validation read_calls= 2
```

### P2 — Fractional runtime activation sequence numbers are accepted

`DeploymentRuntimeActivationReceipt.activation_sequence_number` is a chain
index, but both the issuer at [promotion.py:25257](/Users/yhlee/ADVAR/src/advar/promotion.py:25257)-[25273](/Users/yhlee/ADVAR/src/advar/promotion.py:25273)
and validator at [promotion.py:25365](/Users/yhlee/ADVAR/src/advar/promotion.py:25365)-[25379](/Users/yhlee/ADVAR/src/advar/promotion.py:25379)
only reject `bool` and values `<= 0`; they never require `type(value) is int`.
Consequently a signed receipt with `activation_sequence_number=1.5` and a
non-genesis prior digest is issued/validated successfully. This violates the
discrete sequence and genesis/append contract even though ordinary
`EpisodeLedger` insertion currently compares the value to its integer head and
usually rejects it before persistence. The validator is also used while
replaying durable operational artifacts, where the optional current-ledger
check can be disabled.

The smallest sound direction is an exact positive-integer check in both issue
and validation paths (`type(value) is int and value > 0`), with a regression
covering fractional and boolean values. A direct signed probe built a normal
test receipt, changed only the sequence to `1.5` and its prior digest, resigned
the unsigned payload with the trusted runtime key, and called the current
validator; it returned successfully and printed:

```text
accepted fractional 1.5 float
```

## Selection replay note

The `low_regime_confidence` branch at [promotion.py:26776](/Users/yhlee/ADVAR/src/advar/promotion.py:26776)
is unreachable whenever confidence is below
`minimum_regime_confidence`: `branch_stable` at lines 26763–26767 already
requires `confidence - minimum_regime_confidence >=
minimum_deployment_confidence_margin`, so the preceding
`ambiguous_classifier_branch` branch wins first. Low-confidence inputs still
select the parent, but their recorded fallback reason is systematically
misclassified as ambiguity. This is a P3 contract/diagnostic defect rather
than a candidate-safety bypass. The smallest direction is to classify the low
confidence condition before the stability gate (or remove the redundant later
branch) and add a deterministic replay case below the confidence threshold.

The same runnable probe also exercises the fallback replay with confidence
`0.2` against the `0.8` threshold and records the current result:

```text
low_confidence_fallback ambiguous_classifier_branch parent
```

The always-raising `_validate_operational_deployment_generation` and
`infer_deployed_neural_prior` functions are intentional frozen scientific
package restrictions, not findings: their callers/tests expect operational
selection to go through the ledger-backed deployment path.

## Verification

Environment: `/Users/yhlee/ADVAR/.venv/bin/python` (Python 3.12.13, Torch
2.13), CPU only; no MPS/CUDA.

* `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -m py_compile src/advar/promotion.py` — PASS.
* [gap_11_probes.py](/tmp/advar-green-red-5097dbf/gap_11_probes.py) — reproduced both loader failures, fractional-sequence acceptance, and the low-confidence fallback label; stdout is [gap_11_probes.stdout.txt](/tmp/advar-green-red-5097dbf/gap_11_probes.stdout.txt).
* No full baseline tests were run, per the bounded-review instruction.

No source files, tests, baseline state, or commits were changed.
