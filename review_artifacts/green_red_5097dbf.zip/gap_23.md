# RED bounded review — `tests/test_nowcast.py` lines 1–3300

Baseline reviewed: `5097dbfd1ddf51483578bef5889ebc809ff024f`.

The assigned test range was read completely in contiguous bounded chunks. I
also read the active production callers for the tested paths: input preparation,
state estimation, source tendency selection, source/path verification, local
dynamics evidence, public `nowcast`, `forecast_from_state`, and forecast
evidence construction. No repository source or test files were changed.

## Findings

No reachable test-oracle defect or production defect falsified by this review
was confirmed in the assigned range. The analytic expectations that are
material to the tested paths are consistent with the current implementation:

- displacement is estimated per analysis interval and long-pair motion is
  divided by its pair span;
- support is transported as fractional mass and remains separate from the
  echo numerator, so fractional support is not promoted to full provenance;
- conflicting pair components fail closed to persistence unless the selected
  pair has the configured PSR advantage;
- local motion/growth evidence is evaluated only against the selected pair
  spans and requires exclusive endpoint matches;
- forecast support/confidence is remapped by lead and publication gates are
  applied to the corresponding evidence channel.

The tests also avoid treating frozen constants or detached diagnostics as
gradient obligations. The subpixel phase-correlation derivative test checks the
active differentiable path, while detached scalar decisions remain diagnostics
or branch selectors in the current callers.

## Meaningful coverage gaps

These are test gaps rather than confirmed defects:

1. There is no public end-to-end regression where observations are unavailable,
   a moving background supplies the tendency, and the first forecast field is
   compared with the independently advected background truth. The range has
   metadata checks (`test_background_tendency_preserves_usage_and_age`) and
   internal merge checks, while the public background-only field test is
   stationary. A moving-background oracle would protect the actual
   `nowcast -> estimate_prepared_state -> forecast_from_state` caller chain.
2. Search-boundary rejection is tested directly for the phase-correlation
   helper and for a missing-middle long pair, but there is no adjacent-pair
   public `nowcast` case with both frames present and a displacement exactly at
   the configured search boundary. Such a case would verify that
   `_estimate_available_pair` actually fails closed through the production
   caller, rather than only that the helper reports `search_interior=False`.
3. QC-mask tests use a mask hole shared across all frames or a regular
   irregular mask. A temporal QC rejection that removes an echo from only one
   endpoint, combined with a valid background at that cell, would exercise the
   distinction among `observed_mask`, `qc_rejected_mask`, source support, and
   background provenance through the public output.

None of these gaps supplied a falsifiable current failure from the source
paths read, so they are recorded as follow-up regression opportunities rather
than findings.

## Validation and limits

No test suite or formal test command was run. One tiny CPU input-contract probe
was run with `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1` under Python 3.12.13 /
Torch 2.13.0:

```text
for dtype in float16, bfloat16, float32, float64:
    nowcast(torch.full((3, 8, 8), 20.0, dtype=dtype),
            NowcastConfig(horizon_minutes=10))
```

All four dtypes were accepted and returned the same dtype, so no dtype finding
was raised. A tiny CPU moving-background smoke probe recovered approximately
`[0.99796, -1.00058]` pixels per step and selected `TendencySource.BACKGROUND`;
it was used only to check the proposed coverage gap and is not represented as
formal suite execution. No MPS/CUDA, source edits, or commits were made.
