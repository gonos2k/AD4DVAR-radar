import json
import sys

import torch
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

sys.path.insert(0, "/Users/yhlee/ADVAR")

from tests.test_ledger import _DeweightOnlyQcAction, _prospective_run_and_context
from advar.intervention import (
    InterventionActionGenerator,
    ProspectiveInterventionDecision,
    RealizedInterventionReceipt,
    ReusableInterventionPolicyEvidence,
)


class _RejectOneQcAction(torch.nn.Module):
    def forward(self, context: torch.Tensor):
        valid = context[1].to(torch.bool).clone()
        valid[0, 0, 0] = False
        quality = torch.where(valid, context[2], torch.zeros_like(context[2]))
        return valid, quality, torch.tensor(True, device=context.device)


class _ZeroDbzAction(torch.nn.Module):
    def forward(self, context: torch.Tensor):
        return torch.zeros_like(context[0]), torch.tensor(True, device=context.device)


def _decision(policy, generator, context, run, plan, intervention_type, decision_id):
    return ProspectiveInterventionDecision.from_policy(
        policy,
        action_generator=generator,
        decision_id=decision_id,
        case_id="case-1",
        radar_id="radar-1",
        intervention_type=intervention_type,
        actual_input_context=context,
        actual_input_before_run=run,
        input_plan_digest=plan,
        decision_basis_digest="d" * 64,
        decision_policy_digest="e" * 64,
        decision_trust_store_digest="f" * 64,
        decided_at="2026-08-08T00:22:00Z",
        observation_valid_time="2026-08-08T00:20:00Z",
        input_available_time="2026-08-08T00:21:00Z",
        decision_deadline="2099-08-08T00:30:00Z",
        publication_time="2099-08-08T01:00:00Z",
    )


def _policy(generator, context, intervention_type, *, quality_limit=4.0):
    return ReusableInterventionPolicyEvidence(
        policy_id="probe-" + intervention_type,
        action_generator_digest=generator.generator_digest,
        context_schema_digest=context.context_schema_digest,
        applicability_region_digest=context.applicability_region_digest,
        execution_policy_digest="e" * 64,
        allowed_intervention_types=(intervention_type,),
        maximum_absolute_delta_dbz=2.0,
        maximum_changed_fraction=1.0,
        maximum_global_quality_precision_scale_l2=quality_limit,
        maximum_tile_quality_precision_scale_l2=quality_limit,
        validation_evidence_digests=("d" * 64,),
    )


def _receipt(decision, policy, generator, before_context, before_run, after_context, after_run):
    now = "2026-08-08T00:23:00Z"
    return RealizedInterventionReceipt.from_decision(
        decision,
        actual_input_before_context=before_context,
        actual_input_before_run=before_run,
        actual_input_after_context=after_context,
        actual_input_after_run=after_run,
        action_policy=policy,
        action_generator=generator,
        executor_key_id="probe-executor",
        executor_trust_store_digest="0" * 64,
        executor_private_key=Ed25519PrivateKey.generate(),
        executor_sequence_number=1,
        applied_time=now,
        receipt_time=now,
    )


frames = torch.zeros((3, 2, 2), dtype=torch.float64)
masks = torch.ones_like(frames, dtype=torch.bool)

# Active-cell bypass: QC changes only quality in the approved action, while the
# executor supplies a different standard deviation on every still-active cell.
before_run, before_context, plan, _ = _prospective_run_and_context(frames, masks)
after_run, after_context, _, _ = _prospective_run_and_context(
    frames,
    masks,
    quality_weight=0.5 * torch.ones_like(frames),
    observation_std_dbz=torch.full_like(frames, 9.0),
)
generator = InterventionActionGenerator.from_model(
    _DeweightOnlyQcAction().eval(),
    before_context,
    intervention_type="realized_qc_intervention",
    action_reason="deweight",
)
policy = _policy(generator, before_context, "realized_qc_intervention")
decision = _decision(
    policy,
    generator,
    before_context,
    before_run,
    plan,
    "realized_qc_intervention",
    "active-std-change",
)
receipt = _receipt(
    decision,
    policy,
    generator,
    before_context,
    before_run,
    after_context,
    after_run,
)
active_std_changed = not torch.equal(
    before_context.observation_std_dbz[after_context.observation_masks],
    after_context.observation_std_dbz[after_context.observation_masks],
)
print(
    "ACTIVE_STD_BYPASS",
    json.dumps(
        {
            "receipt_accepted": receipt.receipt_digest == receipt.receipt_digest,
            "std_digest_changed": before_run.observation_std_dbz_digest
            != after_run.observation_std_dbz_digest,
            "active_std_changed": active_std_changed,
        },
        sort_keys=True,
    ),
)
assert active_std_changed

# Legitimate normalization: the only rejected cell is canonicalized to std=1
# in the after context. The still-active cells retain exactly std=2.
after_masks = masks.clone()
after_masks[0, 0, 0] = False
after_run, after_context, _, _ = _prospective_run_and_context(
    frames,
    after_masks,
    quality_weight=after_masks.to(frames),
    observation_std_dbz=torch.full_like(frames, 2.0),
)
generator = InterventionActionGenerator.from_model(
    _RejectOneQcAction().eval(),
    before_context,
    intervention_type="realized_qc_intervention",
    action_reason="reject-one",
)
policy = _policy(generator, before_context, "realized_qc_intervention", quality_limit=1.0)
decision = _decision(
    policy,
    generator,
    before_context,
    before_run,
    plan,
    "realized_qc_intervention",
    "mask-normalization",
)
receipt = _receipt(
    decision,
    policy,
    generator,
    before_context,
    before_run,
    after_context,
    after_run,
)
active_std_equal_after_qc = torch.equal(
    before_context.observation_std_dbz[after_masks],
    after_context.observation_std_dbz[after_masks],
)
print(
    "MASK_NORMALIZATION",
    json.dumps(
        {
            "receipt_accepted": receipt.receipt_digest == receipt.receipt_digest,
            "std_digest_changed": before_run.observation_std_dbz_digest
            != after_run.observation_std_dbz_digest,
            "active_std_equal_after_qc": active_std_equal_after_qc,
        },
        sort_keys=True,
    ),
)
assert active_std_equal_after_qc

# No-op dBZ actions are accepted as decisions even though an unchanged input
# cannot satisfy the realized receipt contract.
generator = InterventionActionGenerator.from_model(
    _ZeroDbzAction().eval(),
    before_context,
    intervention_type="realized_sensor_correction",
)
policy = _policy(generator, before_context, "realized_sensor_correction")
decision = _decision(
    policy,
    generator,
    before_context,
    before_run,
    plan,
    "realized_sensor_correction",
    "zero-action",
)
print(
    "NOOP_DECISION",
    json.dumps(
        {"decision_accepted": True, "changed_pixel_count": json.loads(decision.action_safety_diagnostics_json)["changed_pixel_count"]},
        sort_keys=True,
    ),
)
assert json.loads(decision.action_safety_diagnostics_json)["changed_pixel_count"] == 0
