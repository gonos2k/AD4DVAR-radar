# RED bounded review — promotion.py unit 10

Baseline: `5097dbfd1ddf51483578bef5889ebc809ff024f`.

Scope reviewed: `src/advar/promotion.py:20001-25000`, with the complete current promotion caller, ledger append/certificate path, deployment selector, policy defaults, and focused tests read separately. The assigned range covers current evidence validation, paired scoring, physical-event resampling, bounded empirical-Bernstein UCBs, bootstrap/tail diagnostics, classifier and metric-cell multiplicity, `compute_neural_prior_promotion`, classifier evidence, and deployment-certificate preimages.

## Confirmed findings

**P2 — Automatic bounded metric-cell UCBs still require an unused bootstrap-tail gate.**

- `compute_neural_prior_promotion` computes `metric_cell_tail_ok` from `_bootstrap_tail_diagnostics` at [promotion.py:22267](/Users/yhlee/ADVAR/src/advar/promotion.py:22267), using the local metric-cell family size and `minimum_bootstrap_tail_replicates`.
- Every metric cell then rejects certification when `not metric_cell_tail_ok` at [promotion.py:22585](/Users/yhlee/ADVAR/src/advar/promotion.py:22585), even though the same branch subsequently computes its bound with `_bounded_event_mean_upper_bound` at [promotion.py:22598](/Users/yhlee/ADVAR/src/advar/promotion.py:22598). That UCB does not consume bootstrap replicates; it uses the analytic bounded support, event means, empirical variance, and the family-adjusted alpha.
- This is reachable in the current automatic mode: the policy default is `allow_shadow_small_sample_bootstrap=False` ([promotion.py:18377](/Users/yhlee/ADVAR/src/advar/promotion.py:18377)), and `deployment_eligible` depends on certified groups ([promotion.py:23225](/Users/yhlee/ADVAR/src/advar/promotion.py:23225)). A concrete current fixture probe with automatic mode, `bootstrap_samples=1024`, family size 1, 16 metric/issuance tests, and `minimum_bootstrap_tail_replicates=20` produced `tail_replicates=1.6`, `automatic=True`, and `gate_result=False`; the metric cell would be rejected before its valid bounded UCB is evaluated. The existing focused test suite still passes because its fixture uses shadow mode and a minimum tail of 1.
- Expected contract: bootstrap resolution should gate only the bootstrap fallback. In automatic mode, metric-cell certification should depend on the bounded UCB and its event-count/support conditions. The smallest theoretically sound direction is to condition this gate on `policy.allow_shadow_small_sample_bootstrap` (or use the same `band_uses_bounded_mean or band_bootstrap_tail_ok` distinction already used for range-band skill), while retaining the gate for an actually selected bootstrap path.

This is a false rejection/availability defect rather than an unsafe-confidence defect: the current path can prevent a statistically valid automatic certification and therefore deployment, while the bounded calculation itself is conservative. The old broad “automatic bounded UCB uses an unused bootstrap resolution gate” concern is therefore not fully resolved; it is fixed for the top-level and band-skill aggregate paths but remains in metric-cell certification.

## Intentional diagnostic limitation

The shadow simultaneous path can return a point estimate for zero-variance clusters: it sets zero-standard-error studentized statistics to `0.0` at [promotion.py:21017](/Users/yhlee/ADVAR/src/advar/promotion.py:21017), and its unresolved flag remains false at [promotion.py:21033](/Users/yhlee/ADVAR/src/advar/promotion.py:21033). A one-cluster probe returned the observed mean rather than the support-bounded automatic UCB. This is a known limitation of the explicitly non-deployment shadow/diagnostic mode: `allow_shadow_small_sample_bootstrap` makes sample-size preflight infeasible, `deployment_eligible` remains false, and the ledger refuses a deployment certificate when that field is false ([ledger.py:13590](/Users/yhlee/ADVAR/src/advar/ledger.py:13590)). I found no promotion or deployment bypass, so I do not classify this as a defect. The automatic path uses the support-bounded UCB at [promotion.py:20908](/Users/yhlee/ADVAR/src/advar/promotion.py:20908).

## GREEN / RED contract review

The current automatic aggregate path uses `_event_fractional_rate_interval` for equal-weight physical-event rates and `_bounded_event_mean_upper_bound` for finite-support means. Physical-event digests are used as outer clusters, and repeated cases within a physical event are averaged before the rate/mean bound, matching the declared equal-weight physical-event estimand. Candidate-family multiplicity is included in aggregate bounds; classifier and metric-cell families are expanded for their registered endpoint/cell families. The exact-sign/multiplier path uses a shared-cluster max statistic for shadow diagnostics, while automatic uncertainty comparisons use support-bounded UCBs.

The main resampling inconsistency found is the metric-cell bootstrap gate above. I did not establish a separate multiplicity under-adjustment: the shadow max-statistic uses a joint maximum, and the automatic UCB applies a Bonferroni-style `candidate_family_size * len(comparisons)` factor. Deployment reachability remains fail-closed through `deployment_eligible`, certified applicability groups, and the certificate check.

## Verification

- Read every line of the assigned range in bounded commands: `src/advar/promotion.py:20001-25000` (15 contiguous reads; coverage recorded below).
- Read caller and contract context: `promotion.py:9780-9910`, `17960-18140`, `18110-18280`, `18290-18540`, `18840-18940`, `20300-20490`, `20879-21028`, `23218-23255`, `26600-26820`; `ledger.py:13100-13150,13588-13602`; focused sections of `tests/test_promotion.py` around policy fixtures, bounded inference, preflight, and metric-cell certification.
- Targeted tests: `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python -m pytest -q tests/test_promotion.py -k 'automatic_small_sample_aggregate_does_not_use_point_bootstrap or automatic_uncertainty_never_treats_zero_variance_as_certainty or metric_cell_family_includes_local_issuance_bounds'` — **3 passed, 224 deselected** (Python 3.12.13, Torch 2.13, CPU).
- Tiny CPU probe: [gap_10_probes.py](/tmp/advar-green-red-5097dbf/gap_10_probes.py), output [gap_10_probes.stdout.json](/tmp/advar-green-red-5097dbf/gap_10_probes.stdout.json). With the current fixture plan, automatic mode, `bootstrap_samples=1024`, metric-cell family size 16, and minimum tail 20, it returns `tail_replicates=1.6`, `metric_cell_tail_ok=false`, and a finite bounded UCB of `1.0`; the exact gate outcome is `reject_before_bounded_ucb`. It exits 0 under `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /Users/yhlee/ADVAR/.venv/bin/python`.
- No full baseline suite, MPS, CUDA, source fix, or commit was run.

Remaining uncertainty: the metric-cell P2 is a certification false-negative whose operational impact depends on the root-approved production policy's bootstrap sample count and tail threshold. No promotion bypass was established.
