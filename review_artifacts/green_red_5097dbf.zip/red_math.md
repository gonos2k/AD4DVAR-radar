# RED mathematics review

Commit reviewed: `5097dbfd1ddf51483578bef5889ebc809ff024f0`.

Scope covered the requested physics, matrix-free, variational, range-geometry,
metrics, calibration, ensemble-sensitivity, and sensitivity modules plus their
corresponding tests. No repository files were modified.

## Findings

No reachable mathematical defect was confirmed in the requested scope.

## Validation

The targeted numerical and matrix-free checks were run in both available
project environments. The fresh project environment is Python 3.12.13 with
Torch 2.13.0; the prior system environment is Python 3.10.11 with Torch
2.13.0. In both cases `python -m pytest` was used, because the standalone
`pytest` launcher on this machine has a Python 3.9 shebang.

Fresh `.venv` 3.12 command:

```text
OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONPATH=src .venv/bin/python3.12 -m pytest -q tests/test_pcg.py tests/test_matrix_free.py tests/test_ensemble_sensitivity.py
39 passed, 18 warnings, 2 subtests passed in 5.97s
```

Fresh `.venv` 3.12 focused variational command:

```text
OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONPATH=src .venv/bin/python3.12 -m pytest -q tests/test_pcg.py tests/test_matrix_free.py tests/test_ensemble_sensitivity.py tests/test_variational.py -k 'common_bias or bounded_controls or radial_velocity_control'
9 passed, 172 deselected, 18 warnings, 21 subtests passed in 5.34s
```

The corresponding targeted and focused selections were also run with the
system Python 3.10.11/Torch 2.13.0 environment and produced the same pass
counts. The targeted numerical and matrix-free checks were:

```text
39 passed, 2 subtests passed
```

The focused variational selection also passed (`9 passed, 172 deselected, 21
subtests passed`).

No whole baseline suite was run.

The coverage JSON records the bounded `nl -ba ... | sed -n ...` source/test
reads, `rg` inventories and call-site trace, and `wc -l` line-count checks.
No Luna child task is listed: the collaboration/spawn tools were not exposed
in this agent session, so the review was performed directly in bounded
chunks. This limitation is recorded explicitly rather than represented as
delegated coverage.

## Non-findings and limitations

Physics remap/shift derivatives, PCG scaling and true-residual restart,
ensemble centering and jackknife algebra, range-band boundary partitioning,
metric support guards, calibration canonicalization, common-bias forward
whitening, bounded-vector Taylor branches, and the targeted variational tests
were checked without a falsifiable additional defect. The low-rank helper at
`variational.py:4812-4822` does produce `NaN` gradients for repeated
eigenvalues when called directly, but exhaustive call-site tracing found one
production call only: `_freeze_observation_whitener` at lines 4685-4688, where
the canonical mode weights and resulting correction are detached before being
retained in `FrozenObservationWhitener`. The current residual/solver AD path
therefore cannot reach that derivative; this is documented scope rather than a
reported finding. If the helper is later made differentiable or reused before
the detach boundary, it requires a repeated-eigenvalue-safe matrix-function
derivative.

MPS-only execution was not available in this environment; CPU checks cannot
establish MPS kernel availability. The active affine-component overflow
limitation is known and was not reported as new.
