import os, sys
from pathlib import Path
root = Path(sys.argv[1]).resolve()
os.chdir(root)
sys.path[:0] = [str(root / "src"), str(root / "tests")]
import advar
assert Path(advar.__file__).resolve().is_relative_to(root), advar.__file__
import pytest
raise SystemExit(pytest.main(sys.argv[2:]))
