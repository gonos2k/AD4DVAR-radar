from pathlib import Path
import json
import os
import subprocess

root = Path('/tmp/advar-a3-regression')
checkout = root / 'mutation'
source_path = checkout / 'src/advar/promotion.py'
source = source_path.read_text()
denominator = '/ ((parsed[index + 2] - parsed[index]).total_seconds() / 2.0)'
old_denominator = '/ max(1.0, (parsed[index + 2] - parsed[index]).total_seconds() / 2.0)'
assert source.count(denominator) == 2
parts = source.split(denominator)
results = []
try:
    for index, label in enumerate(('constructor', 'validator')):
        replacements = [denominator, denominator]
        replacements[index] = old_denominator
        mutated = parts[0] + replacements[0] + parts[1] + replacements[1] + parts[2]
        source_path.write_text(mutated)
        completed = subprocess.run(
            ['/Users/yhlee/ADVAR/.venv/bin/python', '-I', str(root / 'run_pytest.py'),
             str(checkout), '-q', 'tests/test_review_promotion_contracts.py',
             f'--junitxml={root / (label + "_mutation.xml")}'],
            cwd=checkout, env={**os.environ, 'OMP_NUM_THREADS': '1', 'MKL_NUM_THREADS': '1'},
            text=True, capture_output=True,
        )
        output = completed.stdout + completed.stderr
        (root / f'{label}_mutation.log').write_text(output)
        expected = (
            'test_physical_event_track_rejects_subsecond_acceleration_in_constructor'
            if index == 0 else
            'test_physical_event_track_validator_rejects_rehashed_acceleration_tamper'
        )
        assert completed.returncode == 1, output
        assert f'FAILED tests/test_review_promotion_contracts.py::{expected}' in output, output
        assert 'DID NOT RAISE' in output and '1 failed' in output, output
        result = {'mutation': label, 'returncode': completed.returncode,
                  'expected_test_failed': expected, 'reason': 'DID NOT RAISE'}
        results.append(result)
        print(json.dumps(result), flush=True)
finally:
    source_path.write_text(source)
(root / 'mutation_results.json').write_text(json.dumps(results, indent=2) + '\n')
