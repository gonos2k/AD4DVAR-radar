# A3-01 validation

The scoped and final runs passed. Each isolated old-denominator mutation must fail one rejection test.
The mutation checkout is based on 3d75242b and contains the changed test file.
To reproduce, adjust absolute workspace/checkout paths in mutation_check.py and run_pytest.py; use a disposable checkout and the current test file. The script restores promotion.py in finally.
This archive does not contain or claim to rerun the user-supplied independent probe bundle.
