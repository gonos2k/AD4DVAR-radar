from pathlib import Path
from xml.etree import ElementTree as ET
import hashlib
import json
import platform
import zipfile
import torch

root = Path('/Users/yhlee/ADVAR')
evidence = Path('/tmp/advar-a3-regression')
artifacts = root / 'review_artifacts'
files = [
    'scoped.log', 'scoped.xml', 'final.log', 'final.xml',
    'constructor_mutation.log', 'constructor_mutation.xml',
    'validator_mutation.log', 'validator_mutation.xml',
    'mutation_check.py', 'mutation_results.json', 'run_pytest.py',
]
summaries = {}
unique_tests = set()
for name in ('scoped', 'final', 'constructor_mutation', 'validator_mutation'):
    tree = ET.parse(evidence / f'{name}.xml')
    summaries[name] = [dict(s.attrib) for s in tree.iter('testsuite')]
    if name in ('scoped', 'final'):
        unique_tests.update((case.get('classname'), case.get('name')) for case in tree.iter('testcase'))
assert len(unique_tests) == 26
source_files = ['src/advar/promotion.py', 'tests/test_review_promotion_contracts.py']
record = {
    'base_commit': '3d75242b67421bb3341c7ae3ebc83d8f94702bdd',
    'scope': 'A3-01 subsecond acceleration regression; no product source changes',
    'python': platform.python_version(), 'torch': torch.__version__, 'device': 'cpu',
    'source_sha256': {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in source_files},
    'unique_passing_scoped_tests': len(unique_tests),
    'junit_summaries': summaries,
    'mutation_results': json.loads((evidence / 'mutation_results.json').read_text()),
    'style': 'ruff 0.16.6 and git diff --check passed',
    'peer_review': 'gpt-5.6-luna / xhigh: theory, precision, and rejection isolation reviewed',
    'base_ci_run': 33963828991, 'base_ci_status_at_creation': 'in_progress',
    'new_pr_ci_status_at_creation': 'not_started',
    'limitations': ['No repeated full local baseline', 'No CUDA or full MPS P1',
                    'No real radar data validation', 'P0 rejection is not automatic-learning efficacy'],
    'evidence_sha256': {name: hashlib.sha256((evidence / name).read_bytes()).hexdigest() for name in files},
}
record_path = artifacts / 'a3_acceleration_validation.json'
record_path.write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')
(evidence / 'README.md').write_text(
    '# A3-01 validation\n\n'
    'The scoped and final runs passed. Each isolated old-denominator mutation must fail one rejection test.\n'
    'The mutation checkout is based on 3d75242b and contains the changed test file.\n'
    'To reproduce, adjust absolute workspace/checkout paths in mutation_check.py and run_pytest.py; '
    'use a disposable checkout and the current test file. The script restores promotion.py in finally.\n'
    'This archive does not contain or claim to rerun the user-supplied independent probe bundle.\n'
)
with zipfile.ZipFile(artifacts / 'a3_acceleration_validation.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for name in [*files, 'README.md', 'build_validation.py']:
        archive.write(evidence / name, name)
    archive.write(record_path, record_path.name)
    archive.write(root / source_files[1], source_files[1])
print(json.dumps({'unique_tests': len(unique_tests), 'zip_sha256': hashlib.sha256((artifacts / 'a3_acceleration_validation.zip').read_bytes()).hexdigest()}, indent=2))
