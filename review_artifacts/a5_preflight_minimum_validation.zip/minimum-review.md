# Explicit preflight minimum review

Verdict: the new validator checks match the normal production producer.

- Metric floor: `max(item.minimum_physical_events,
  policy.minimum_deployment_metric_cell_events,
  policy.minimum_continuous_metric_cell_events)`. This is the same expression
  used when `compute_neural_prior_promotion` initializes and updates
  `metric_cell_event_count_map`, and the same floor used by its metric-cell
  qualification gate.
- Issuance floor: `item.minimum_physical_events`. This is the same value used
  by `compute_neural_prior_promotion` for `issuance_cell_event_count_map` and
  its issuance qualification gate.

The implementation validates row shape/types first, exact unique policy keys
second, and then rejects a required value below its keyed floor. A required
value above the floor remains accepted and `cell_feasible` compares available
events against that stricter value, so conservative caller supplied minima are
preserved. The `zip(..., strict=True)` check is safe after exact-key and
duplicate validation. The planned tests cover each metric floor source,
issuance floor, below-floor rejection, available 5 versus required 10, exact
boundary 10, and stricter 12 success. `git diff --check` is clean.

No mismatch with the normal producer was found. One pre-existing documentation
nuance remains: README says automatic deployment metric cells require 5 events,
while the default continuous floor is 10 and the producer deliberately takes
the maximum, making the effective default metric-cell floor 10. This is outside
the validator change and should only be corrected if the policy semantics are
intended to make deployment and continuous floors independent.
