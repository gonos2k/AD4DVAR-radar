import ast
from pathlib import Path
import subprocess
import sys
from unittest.mock import patch

sys.path.insert(0, str(Path('/Users/yhlee/ADVAR/tests')))
from test_a5_loss_stats import _preflight_fixture
from advar import promotion as module

old_source = subprocess.check_output(['git', 'show', '0512c25:src/advar/promotion.py'], text=True)
functions = {'_validate_explicit_metric_cell_event_counts', '_validate_explicit_issuance_cell_event_counts'}
body = [node for node in ast.parse(old_source).body if isinstance(node, ast.FunctionDef) and node.name in functions]
assert len(body) == 2
exec(compile(ast.Module(body=body, type_ignores=[]), '<0512c25 preflight validators>', 'exec'), module.__dict__)
for source in ('metric', 'minimum_deployment_metric_cell_events', 'minimum_continuous_metric_cell_events', 'issuance'):
    plan, policy, classifier = _preflight_fixture()
    if source == 'metric':
        policy.required_range_metrics[0].minimum_physical_events = 10
    elif source == 'issuance':
        policy.required_range_issuance[0].minimum_physical_events = 10
    else:
        setattr(policy, source, 10)
    metric = ('convective', 'near_range', 'log_echo_mse', 60, 10_000, 1)
    issuance = ('convective', 'near_range', 60, 10_000, 1)
    if source == 'issuance': issuance = (*issuance[:3], 5, 1)
    else: metric = (*metric[:4], 5, 1)
    with patch.object(module, 'validate_neural_prior_holdout_plan'):
        result = module.promotion_sample_size_preflight(plan, policy, available_physical_events=10_000, metric_cell_event_counts=(metric,), issuance_cell_event_counts=(issuance,), classifier_subset_event_counts=classifier)
    assert result.cell_feasible and result.feasible
    print(source, 'old validators accepted available=5 / supplied minimum=1 / policy floor=10; cell_feasible=True feasible=True')
print('Four former-validator counterexamples reproduced; no normal producer or operational deployment bypass is claimed.')
